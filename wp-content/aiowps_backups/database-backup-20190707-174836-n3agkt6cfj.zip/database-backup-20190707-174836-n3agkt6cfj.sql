-- All In One WP Security & Firewall 4.3.8.3
-- MySQL dump
-- 2019-07-07 14:48:36

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_aiowps_failed_logins` VALUES("1","0","уцукцук","2019-04-10 22:22:27","::1");


DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_aiowps_login_activity` VALUES("1","1","admin","2019-04-03 17:10:29","2019-04-03 17:12:47","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("2","1","admin","2019-04-03 17:12:51","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("3","1","admin","2019-04-03 17:15:59","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("4","1","admin","2019-04-06 14:47:17","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("5","1","admin","2019-04-07 13:54:20","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("6","1","admin","2019-04-07 14:08:08","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("7","1","admin","2019-04-07 14:49:46","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("8","1","admin","2019-04-07 14:57:23","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("9","1","admin","2019-04-07 15:35:59","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("10","1","admin","2019-04-07 15:37:18","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("11","1","admin","2019-04-08 14:57:49","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("12","1","admin","2019-04-08 19:59:51","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("13","1","admin","2019-04-08 20:00:08","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("14","1","admin","2019-04-08 20:16:59","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("15","1","admin","2019-04-08 22:49:14","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("16","1","admin","2019-04-09 14:41:44","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("17","1","admin","2019-04-10 13:53:57","2019-04-10 13:54:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("18","1","admin","2019-04-10 21:09:40","2019-04-15 22:33:15","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("19","1","admin","2019-04-10 22:58:41","2019-04-15 22:33:15","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("20","1","admin","2019-04-15 21:49:14","2019-04-15 22:33:15","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("21","1","admin","2019-04-15 22:33:45","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("22","1","admin","2019-04-16 18:50:40","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("23","1","admin","2019-04-18 19:29:27","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("24","1","admin","2019-04-21 22:14:01","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("25","1","admin","2019-04-24 14:23:45","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("26","1","admin","2019-04-24 16:00:53","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("27","1","admin","2019-05-01 18:49:40","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("28","1","admin","2019-05-03 00:28:26","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("29","1","admin","2019-05-05 13:14:20","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("30","1","admin","2019-05-05 13:16:43","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("31","1","admin","2019-05-08 17:32:15","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("32","1","admin","2019-05-09 00:10:33","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("33","1","admin","2019-05-09 02:01:33","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("34","1","admin","2019-05-09 02:21:26","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("35","1","admin","2019-05-09 02:29:20","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("36","1","admin","2019-05-09 16:22:36","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("37","1","admin","2019-05-09 16:30:55","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("38","1","admin","2019-05-09 17:33:41","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("39","1","admin","2019-05-09 19:00:39","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("40","1","admin","2019-05-10 17:35:04","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("41","1","admin","2019-05-10 20:41:36","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("42","1","admin","2019-05-14 20:29:55","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("43","1","admin","2019-05-14 21:07:54","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("44","1","admin","2019-05-14 21:15:05","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("45","1","admin","2019-05-15 14:04:02","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("46","1","admin","2019-05-15 16:51:34","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("47","1","admin","2019-05-17 10:51:33","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("48","1","admin","2019-05-17 11:32:09","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("49","1","admin","2019-05-17 11:42:21","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("50","1","admin","2019-05-23 13:48:46","2019-05-23 15:56:10","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("51","1","admin","2019-05-23 17:19:27","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("52","1","admin","2019-05-24 14:01:32","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("53","1","admin","2019-05-24 14:36:56","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("54","1","admin","2019-05-24 14:37:28","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("55","1","admin","2019-05-24 14:47:22","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("56","1","admin","2019-05-24 15:18:39","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("57","1","admin","2019-05-24 20:59:32","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("58","1","admin","2019-05-25 11:10:27","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("59","1","admin","2019-05-27 22:59:59","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("60","1","admin","2019-05-28 13:39:44","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("61","1","admin","2019-05-29 11:41:02","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("62","1","admin","2019-05-30 15:51:27","2019-06-01 15:33:50","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("63","1","admin","2019-06-02 15:28:59","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("64","1","admin","2019-06-02 16:30:49","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("65","1","admin","2019-06-04 14:53:52","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("66","1","admin","2019-06-05 12:41:07","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("67","1","admin","2019-06-08 14:27:45","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("68","1","admin","2019-06-10 11:54:49","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("69","1","admin","2019-06-11 15:21:28","2019-06-18 13:53:08","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("70","1","admin","2019-06-18 13:57:02","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("71","1","admin","2019-06-18 14:01:18","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("72","3","yana","2019-06-18 14:02:49","0000-00-00 00:00:00","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("73","3","yana","2019-06-18 14:03:38","0000-00-00 00:00:00","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("74","1","admin","2019-06-20 00:37:38","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("75","1","admin","2019-06-20 14:06:34","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("76","1","admin","2019-06-21 14:42:50","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("77","1","admin","2019-06-22 16:46:52","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("78","1","admin","2019-06-23 14:59:21","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("79","1","admin","2019-06-26 14:23:11","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("80","1","admin","2019-06-27 14:20:17","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("81","1","admin","2019-06-28 17:00:10","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("82","1","admin","2019-06-28 17:05:12","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("83","1","admin","2019-06-29 10:13:21","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("84","1","admin","2019-06-29 10:13:34","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("85","1","admin","2019-06-29 11:06:17","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("86","1","admin","2019-06-30 17:39:54","2019-07-03 21:13:06","::1","","");
INSERT INTO `wp_aiowps_login_activity` VALUES("87","1","admin","2019-07-03 16:46:42","2019-07-03 21:13:06","::1","","");


DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_commentmeta` VALUES("1","2","verified","0");
INSERT INTO `wp_commentmeta` VALUES("2","8","verified","0");
INSERT INTO `wp_commentmeta` VALUES("3","9","verified","0");
INSERT INTO `wp_commentmeta` VALUES("4","10","verified","0");
INSERT INTO `wp_commentmeta` VALUES("5","11","verified","0");
INSERT INTO `wp_commentmeta` VALUES("6","12","verified","0");
INSERT INTO `wp_commentmeta` VALUES("7","13","verified","0");


DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","Автор комментария","wapuu@wordpress.example","https://wordpress.org/","","2019-03-26 16:18:24","2019-03-26 13:18:24","Привет! Это комментарий.
Чтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.
Аватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.","0","1","","","0","0");
INSERT INTO `wp_comments` VALUES("2","91","admin","domaratskiy1990@gmail.com","","::1","2019-04-24 21:52:06","2019-04-24 18:52:06","Лучше всех","0","1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","","0","1");
INSERT INTO `wp_comments` VALUES("8","134","admin","domaratskiy1990@gmail.com","","::1","2019-06-12 17:01:45","2019-06-12 14:01:45","dsfasdfasdf","0","1","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0","review","0","1");
INSERT INTO `wp_comments` VALUES("9","139","admin","domaratskiy1990@gmail.com","","::1","2019-06-14 15:59:44","2019-06-14 12:59:44","Херня","0","1","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0","review","0","1");
INSERT INTO `wp_comments` VALUES("10","139","admin","domaratskiy1990@gmail.com","","::1","2019-06-18 13:52:58","2019-06-18 10:52:58","dsfadfasdf","0","1","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0","review","0","1");
INSERT INTO `wp_comments` VALUES("11","134","yana","domaratskiy1991@gmail.com","","::1","2019-06-18 14:03:01","2019-06-18 11:03:01","это я на 2","0","1","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0","review","0","3");
INSERT INTO `wp_comments` VALUES("12","134","yana","domaratskiy1991@gmail.com","","::1","2019-06-18 14:03:56","2019-06-18 11:03:56","Это Яна","0","1","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0","review","0","3");
INSERT INTO `wp_comments` VALUES("13","134","admin","domaratskiy1990@gmail.com","","::1","2019-06-18 14:05:08","2019-06-18 11:05:08","нагибайся!!!","0","1","Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36","","12","1");


DROP TABLE IF EXISTS `wp_gs_woo_meta`;

CREATE TABLE `wp_gs_woo_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `wc_attribute_tax_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://localhost/tes","yes");
INSERT INTO `wp_options` VALUES("2","home","http://localhost/tes","yes");
INSERT INTO `wp_options` VALUES("3","blogname","Ткани Экспрес Сервис","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Ещё один сайт на WordPress","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","1","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","domaratskiy1990@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","6","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","1","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","13","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:10:{i:0;s:31:\"query-monitor/query-monitor.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:22:\"cyr3lat/cyr-to-lat.php\";i:3;s:21:\"imsanity/imsanity.php\";i:4;s:33:\"kama-spamblock/kama-spamblock.php\";i:5;s:55:\"pagination-styler-for-woocommerce/pagination-styler.php\";i:6;s:73:\"variation-swatches-for-woocommerce/variation-swatches-for-woocommerce.php\";i:7;s:32:\"woo-better-usability/wbulite.php\";i:8;s:27:\"woocommerce/woocommerce.php\";i:9;s:24:\"wordpress-seo/wp-seo.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","3","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","a:5:{i:0;s:90:\"C:\\xampp\\htdocs\\TES/wp-content/plugins/all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:73:\"C:\\xampp\\htdocs\\TES/wp-content/uploads/bws-custom-code/bws-custom-code.js\";i:2;s:74:\"C:\\xampp\\htdocs\\TES/wp-content/uploads/bws-custom-code/bws-custom-code.php\";i:3;s:74:\"C:\\xampp\\htdocs\\TES/wp-content/uploads/bws-custom-code/bws-custom-code.css\";i:5;s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES("40","template","tkani-shop","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","tkani-shop","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","44719","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","0","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","page","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","file","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:3:{s:26:\"woo-product-filter/wpf.php\";a:2:{i:0;s:8:\"utilsWpf\";i:1;s:12:\"deletePlugin\";}s:57:\"load-more-products-for-woocommerce/load-more-products.php\";a:2:{i:0;s:12:\"BeRocket_LMP\";i:1;s:12:\"deactivation\";}s:55:\"pagination-styler-for-woocommerce/pagination-styler.php\";a:2:{i:0;s:19:\"BeRocket_Pagination\";i:1;s:12:\"deactivation\";}}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","88","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("93","initial_db_version","44719","yes");
INSERT INTO `wp_options` VALUES("94","wp_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:118:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:15:\"manage_berocket\";b:1;s:23:\"manage_berocket_account\";b:1;s:33:\"manage_berocket_pagination_styler\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("95","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("96","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("97","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:33:\"woocommerce_layered_nav_filters-2\";i:1;s:32:\"woocommerce_product_categories-2\";i:2;s:25:\"woocommerce_layered_nav-2\";i:3;s:25:\"woocommerce_layered_nav-3\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("103","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("104","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","cron","a:16:{i:1562181038;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1562187600;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562188238;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562199038;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1562203106;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1562235332;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562246347;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562246782;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562263837;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562263838;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562263848;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1562510920;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1562512237;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1562512706;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1565049600;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("113","theme_mods_twentynineteen","a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1561731847;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:33:\"woocommerce_layered_nav_filters-2\";i:1;s:32:\"woocommerce_product_categories-2\";i:2;s:25:\"woocommerce_layered_nav-2\";i:3;s:25:\"woocommerce_layered_nav-3\";}}}s:18:\"nav_menu_locations\";a:1:{s:6:\"menu-1\";i:20;}}","yes");
INSERT INTO `wp_options` VALUES("126","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("143","recently_activated","a:4:{s:25:\"duplicator/duplicator.php\";i:1562161629;s:31:\"alphabetic-pagination/index.php\";i:1561796217;s:57:\"load-more-products-for-woocommerce/load-more-products.php\";i:1561731117;s:25:\"pagination/pagination.php\";i:1561730448;}","yes");
INSERT INTO `wp_options` VALUES("170","woocommerce_store_address","","yes");
INSERT INTO `wp_options` VALUES("171","woocommerce_store_address_2","","yes");
INSERT INTO `wp_options` VALUES("172","woocommerce_store_city","","yes");
INSERT INTO `wp_options` VALUES("173","woocommerce_default_country","UA","yes");
INSERT INTO `wp_options` VALUES("174","woocommerce_store_postcode","","yes");
INSERT INTO `wp_options` VALUES("175","woocommerce_allowed_countries","all","yes");
INSERT INTO `wp_options` VALUES("176","woocommerce_all_except_countries","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("177","woocommerce_specific_allowed_countries","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("178","woocommerce_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("179","woocommerce_specific_ship_to_countries","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("180","woocommerce_default_customer_address","geolocation","yes");
INSERT INTO `wp_options` VALUES("181","woocommerce_calc_taxes","yes","yes");
INSERT INTO `wp_options` VALUES("182","woocommerce_enable_coupons","yes","yes");
INSERT INTO `wp_options` VALUES("183","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO `wp_options` VALUES("184","woocommerce_currency","UAH","yes");
INSERT INTO `wp_options` VALUES("185","woocommerce_currency_pos","right","yes");
INSERT INTO `wp_options` VALUES("186","woocommerce_price_thousand_sep",",","yes");
INSERT INTO `wp_options` VALUES("187","woocommerce_price_decimal_sep",".","yes");
INSERT INTO `wp_options` VALUES("188","woocommerce_price_num_decimals","2","yes");
INSERT INTO `wp_options` VALUES("189","woocommerce_shop_page_id","88","yes");
INSERT INTO `wp_options` VALUES("190","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO `wp_options` VALUES("191","woocommerce_enable_ajax_add_to_cart","yes","yes");
INSERT INTO `wp_options` VALUES("192","woocommerce_placeholder_image","","yes");
INSERT INTO `wp_options` VALUES("193","woocommerce_weight_unit","kg","yes");
INSERT INTO `wp_options` VALUES("194","woocommerce_dimension_unit","cm","yes");
INSERT INTO `wp_options` VALUES("195","woocommerce_enable_reviews","yes","yes");
INSERT INTO `wp_options` VALUES("196","woocommerce_review_rating_verification_label","no","no");
INSERT INTO `wp_options` VALUES("197","woocommerce_review_rating_verification_required","no","no");
INSERT INTO `wp_options` VALUES("198","woocommerce_enable_review_rating","no","yes");
INSERT INTO `wp_options` VALUES("199","woocommerce_review_rating_required","yes","no");
INSERT INTO `wp_options` VALUES("200","woocommerce_manage_stock","yes","yes");
INSERT INTO `wp_options` VALUES("201","woocommerce_hold_stock_minutes","60","no");
INSERT INTO `wp_options` VALUES("202","woocommerce_notify_low_stock","yes","no");
INSERT INTO `wp_options` VALUES("203","woocommerce_notify_no_stock","yes","no");
INSERT INTO `wp_options` VALUES("204","woocommerce_stock_email_recipient","domaratskiy1990@gmail.com","no");
INSERT INTO `wp_options` VALUES("205","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO `wp_options` VALUES("206","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO `wp_options` VALUES("207","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO `wp_options` VALUES("208","woocommerce_stock_format","","yes");
INSERT INTO `wp_options` VALUES("209","woocommerce_file_download_method","force","no");
INSERT INTO `wp_options` VALUES("210","woocommerce_downloads_require_login","no","no");
INSERT INTO `wp_options` VALUES("211","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO `wp_options` VALUES("212","woocommerce_prices_include_tax","no","yes");
INSERT INTO `wp_options` VALUES("213","woocommerce_tax_based_on","shipping","yes");
INSERT INTO `wp_options` VALUES("214","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO `wp_options` VALUES("215","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO `wp_options` VALUES("216","woocommerce_tax_classes","Пониженная ставка
Нулевая ставка","yes");
INSERT INTO `wp_options` VALUES("217","woocommerce_tax_display_shop","excl","yes");
INSERT INTO `wp_options` VALUES("218","woocommerce_tax_display_cart","excl","yes");
INSERT INTO `wp_options` VALUES("219","woocommerce_price_display_suffix","","yes");
INSERT INTO `wp_options` VALUES("220","woocommerce_tax_total_display","itemized","no");
INSERT INTO `wp_options` VALUES("221","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO `wp_options` VALUES("222","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO `wp_options` VALUES("223","woocommerce_ship_to_destination","billing","no");
INSERT INTO `wp_options` VALUES("224","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO `wp_options` VALUES("225","woocommerce_enable_guest_checkout","yes","no");
INSERT INTO `wp_options` VALUES("226","woocommerce_enable_checkout_login_reminder","yes","no");
INSERT INTO `wp_options` VALUES("227","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO `wp_options` VALUES("228","woocommerce_enable_myaccount_registration","yes","no");
INSERT INTO `wp_options` VALUES("229","woocommerce_registration_generate_username","no","no");
INSERT INTO `wp_options` VALUES("230","woocommerce_registration_generate_password","no","no");
INSERT INTO `wp_options` VALUES("231","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO `wp_options` VALUES("232","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO `wp_options` VALUES("233","woocommerce_registration_privacy_policy_text","Ваши личные данные будут использоваться для упрощения вашей работы с сайтом, управления доступом к вашей учётной записи и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("234","woocommerce_checkout_privacy_policy_text","Ваши личные данные будут использоваться для обработки ваших заказов, упрощения вашей работы с сайтом и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("235","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("236","woocommerce_trash_pending_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no");
INSERT INTO `wp_options` VALUES("237","woocommerce_trash_failed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no");
INSERT INTO `wp_options` VALUES("238","woocommerce_trash_cancelled_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no");
INSERT INTO `wp_options` VALUES("239","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("240","woocommerce_email_from_name","Ткани Экспрес Сервис","no");
INSERT INTO `wp_options` VALUES("241","woocommerce_email_from_address","domaratskiy1990@gmail.com","no");
INSERT INTO `wp_options` VALUES("242","woocommerce_email_header_image","","no");
INSERT INTO `wp_options` VALUES("243","woocommerce_email_footer_text","{site_title}<br/>Built with <a href=\"https://woocommerce.com/\">WooCommerce</a>","no");
INSERT INTO `wp_options` VALUES("244","woocommerce_email_base_color","#96588a","no");
INSERT INTO `wp_options` VALUES("245","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO `wp_options` VALUES("246","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO `wp_options` VALUES("247","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO `wp_options` VALUES("248","woocommerce_cart_page_id","39","yes");
INSERT INTO `wp_options` VALUES("249","woocommerce_checkout_page_id","72","yes");
INSERT INTO `wp_options` VALUES("250","woocommerce_myaccount_page_id","75","yes");
INSERT INTO `wp_options` VALUES("251","woocommerce_terms_page_id","3","no");
INSERT INTO `wp_options` VALUES("252","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("253","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("254","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO `wp_options` VALUES("255","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO `wp_options` VALUES("256","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO `wp_options` VALUES("257","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO `wp_options` VALUES("258","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO `wp_options` VALUES("259","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO `wp_options` VALUES("260","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO `wp_options` VALUES("261","woocommerce_myaccount_downloads_endpoint","","yes");
INSERT INTO `wp_options` VALUES("262","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO `wp_options` VALUES("263","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO `wp_options` VALUES("264","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO `wp_options` VALUES("265","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO `wp_options` VALUES("266","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO `wp_options` VALUES("267","woocommerce_api_enabled","no","yes");
INSERT INTO `wp_options` VALUES("268","woocommerce_single_image_width","600","yes");
INSERT INTO `wp_options` VALUES("269","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO `wp_options` VALUES("270","woocommerce_checkout_highlight_required_fields","yes","yes");
INSERT INTO `wp_options` VALUES("271","woocommerce_demo_store","no","no");
INSERT INTO `wp_options` VALUES("272","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("273","current_theme_supports_woocommerce","yes","yes");
INSERT INTO `wp_options` VALUES("274","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO `wp_options` VALUES("277","default_product_cat","15","yes");
INSERT INTO `wp_options` VALUES("282","woocommerce_admin_notices","a:1:{i:0;s:20:\"no_secure_connection\";}","yes");
INSERT INTO `wp_options` VALUES("283","_transient_woocommerce_webhook_ids","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("284","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("285","widget_woocommerce_layered_nav_filters","a:2:{i:2;a:1:{s:5:\"title\";s:36:\"Активные фильтры по\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("286","widget_woocommerce_layered_nav","a:3:{i:2;a:4:{s:5:\"title\";s:28:\"Фильтр по цвету\";s:9:\"attribute\";s:5:\"tsvet\";s:12:\"display_type\";s:4:\"list\";s:10:\"query_type\";s:2:\"or\";}i:3;a:4:{s:5:\"title\";s:36:\"Фильтр по плотности\";s:9:\"attribute\";s:8:\"plotnost\";s:12:\"display_type\";s:4:\"list\";s:10:\"query_type\";s:3:\"and\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("287","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("288","widget_woocommerce_product_categories","a:2:{i:2;a:8:{s:5:\"title\";s:27:\"Каталог Товара\";s:7:\"orderby\";s:5:\"order\";s:8:\"dropdown\";i:0;s:5:\"count\";i:1;s:12:\"hierarchical\";i:1;s:18:\"show_children_only\";i:0;s:10:\"hide_empty\";i:1;s:9:\"max_depth\";s:3:\"100\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("289","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("290","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("291","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("292","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("293","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("294","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("295","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("300","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("314","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("315","aio_wp_security_configs","a:91:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"y9t13745ja38h0dirf5q\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-06-22 16:46:44\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("319","wpseo","a:20:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:6:\"10.0.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1553606782;s:13:\"myyoast-oauth\";a:2:{s:6:\"config\";a:2:{s:8:\"clientId\";N;s:6:\"secret\";N;}s:13:\"access_tokens\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES("320","wpseo_titles","a:92:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:45:\"%%name%%, Автор в %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:64:\"Вы искали %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:57:\"Страница не найдена %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:84:\"Сообщение %%POSTLINK%% появились сначала на %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:54:\"Ошибка 404: страница не найдена\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:1;s:25:\"breadcrumbs-archiveprefix\";s:19:\"Архивы для\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:31:\"Главная страница\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:17:\"Вы искали\";s:15:\"breadcrumbs-sep\";s:11:\"fdhdfghdfgh\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";s:1:\"0\";s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";s:1:\"0\";s:18:\"title-tax-category\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:1;s:13:\"title-product\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:16:\"showdate-product\";b:0;s:26:\"display-metabox-pt-product\";b:1;s:26:\"post_types-product-maintax\";i:0;s:23:\"title-ptarchive-product\";s:54:\"Архив %%pt_plural%% %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:21:\"title-tax-product_cat\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_cat\";s:0:\"\";s:31:\"display-metabox-tax-product_cat\";b:1;s:23:\"noindex-tax-product_cat\";b:0;s:29:\"taxonomy-product_cat-ptparent\";i:0;s:21:\"title-tax-product_tag\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_tag\";s:0:\"\";s:31:\"display-metabox-tax-product_tag\";b:1;s:23:\"noindex-tax-product_tag\";b:0;s:29:\"taxonomy-product_tag-ptparent\";i:0;s:32:\"title-tax-product_shipping_class\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:35:\"metadesc-tax-product_shipping_class\";s:0:\"\";s:42:\"display-metabox-tax-product_shipping_class\";b:1;s:34:\"noindex-tax-product_shipping_class\";b:0;s:40:\"taxonomy-product_shipping_class-ptparent\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("321","wpseo_social","a:20:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("322","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES("323","_transient_timeout_wpseo_link_table_inaccessible","1585142782","no");
INSERT INTO `wp_options` VALUES("324","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("325","_transient_timeout_wpseo_meta_table_inaccessible","1585142782","no");
INSERT INTO `wp_options` VALUES("326","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("409","current_theme","Tkani setvis","yes");
INSERT INTO `wp_options` VALUES("410","theme_mods_tkani shop","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1553806485;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("411","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("415","woocommerce_maybe_regenerate_images_hash","754dd1df38b3ce671631b909d4cc4ded","yes");
INSERT INTO `wp_options` VALUES("417","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("512","theme_mods_tkani-shop","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:4:{s:7:\"primary\";i:20;s:12:\"catalog-menu\";i:32;s:11:\"sab-catalog\";i:32;s:6:\"menu-1\";i:20;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1561731799;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:33:\"woocommerce_layered_nav_filters-2\";i:1;s:32:\"woocommerce_product_categories-2\";i:2;s:25:\"woocommerce_layered_nav-2\";i:3;s:25:\"woocommerce_layered_nav-3\";}}}}","yes");
INSERT INTO `wp_options` VALUES("646","fakerpress-plugin-options","a:1:{s:5:\"500px\";a:1:{s:3:\"key\";s:0:\"\";}}","yes");
INSERT INTO `wp_options` VALUES("650","_transient_product_query-transient-version","1561799261","yes");
INSERT INTO `wp_options` VALUES("665","_transient_product-transient-version","1561799261","yes");
INSERT INTO `wp_options` VALUES("710","_transient_shipping-transient-version","1557503435","yes");
INSERT INTO `wp_options` VALUES("1255","_tes_header_logic","no","no");
INSERT INTO `wp_options` VALUES("1256","_tes_header_logo","","no");
INSERT INTO `wp_options` VALUES("1257","_tes_header_site_name","Ткани Сервисс Экспресс","no");
INSERT INTO `wp_options` VALUES("1258","_tes_header_site_desc","ffff","no");
INSERT INTO `wp_options` VALUES("1259","_crb_email","","no");
INSERT INTO `wp_options` VALUES("1260","_crb_phone","Сайт","no");
INSERT INTO `wp_options` VALUES("1401","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("1978","yit_recently_activated","a:5:{i:0;s:44:\"yith-woocommerce-category-accordion/init.php\";i:1;s:44:\"yith-woocommerce-category-accordion/init.php\";i:2;s:41:\"yith-woocommerce-ajax-navigation/init.php\";i:3;s:41:\"yith-woocommerce-ajax-navigation/init.php\";i:4;s:56:\"yith-color-and-label-variations-for-woocommerce/init.php\";}","yes");
INSERT INTO `wp_options` VALUES("1979","ywar_enable_review_title","yes","yes");
INSERT INTO `wp_options` VALUES("1980","ywar_enable_attachments","yes","yes");
INSERT INTO `wp_options` VALUES("1981","ywar_max_attachments","0","yes");
INSERT INTO `wp_options` VALUES("1982","ywar_import_review","yes","yes");
INSERT INTO `wp_options` VALUES("1983","ywar_summary_bar_color","#f4f4f4","yes");
INSERT INTO `wp_options` VALUES("1984","ywar_summary_percentage_bar_color","#a9709d","yes");
INSERT INTO `wp_options` VALUES("1985","ywar_summary_percentage_value","yes","yes");
INSERT INTO `wp_options` VALUES("1986","ywar_summary_percentage_value_color","#a9709d","yes");
INSERT INTO `wp_options` VALUES("1987","yit_plugin_fw_panel_wc_default_options_set","a:3:{s:15:\"yith_ywar_panel\";b:1;s:26:\"yith_wc_category_accordion\";b:1;s:15:\"yith_ywcl_panel\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("1988","_site_transient_timeout_yith_promo_message","3112076038","no");
INSERT INTO `wp_options` VALUES("1989","_site_transient_yith_promo_message","a:6:{s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:10:{s:4:\"date\";s:29:\"Mon, 22 Apr 2019 09:33:58 GMT\";s:12:\"content-type\";s:15:\"application/xml\";s:10:\"set-cookie\";s:137:\"__cfduid=d4f2a048cce798afcd4b59ee53f090c2e1555925638; expires=Tue, 21-Apr-20 09:33:58 GMT; path=/; domain=.yithemes.com; HttpOnly; Secure\";s:13:\"last-modified\";s:29:\"Mon, 08 Apr 2019 14:04:39 GMT\";s:25:\"strict-transport-security\";s:44:\"max-age=15552000; includeSubDomains; preload\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:9:\"expect-ct\";s:87:\"max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"\";s:6:\"server\";s:10:\"cloudflare\";s:6:\"cf-ray\";s:20:\"4cb69967efd38b94-KBP\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:4:\"body\";s:1048:\"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!-- Default border color: #acc327 -->
<!-- Default background color: #ecf7ed -->

<promotions>
    <expiry_date>2019-04-25</expiry_date>
    <promo>
        <promo_id>yithhappyeaster2019</promo_id>
        <banner>banner_easter.jpg</banner>
        <title><![CDATA[<strong>YITH Happy Easter</strong>]]></title>
        <description><![CDATA[
            <span>Don\'t miss our <strong>30% discount</strong> on all our products! No coupon needed in cart. Valid only on <strong>April 20th and 21st</strong>.</span>
        ]]></description>
        <link>
            <label>Get your deals now!</label>
            <url><![CDATA[https://yithemes.com?refer_id=1072986]]></url>
        </link>
        <style>
            <image_bg_color>#2695e4</image_bg_color>
            <border_color>#2695e4</border_color>
            <background_color>#ffffff</background_color>
        </style>
        <start_date>2019-04-19 00:00:00</start_date>
        <end_date>2019-04-22 07:00:00</end_date>
    </promo>
</promotions>\";s:8:\"response\";a:2:{s:4:\"code\";i:200;s:7:\"message\";s:2:\"OK\";}s:7:\"cookies\";a:1:{i:0;O:14:\"WP_Http_Cookie\":5:{s:4:\"name\";s:8:\"__cfduid\";s:5:\"value\";s:43:\"d4f2a048cce798afcd4b59ee53f090c2e1555925638\";s:7:\"expires\";i:1587461638;s:4:\"path\";s:1:\"/\";s:6:\"domain\";s:12:\"yithemes.com\";}}s:8:\"filename\";N;s:13:\"http_response\";O:25:\"WP_HTTP_Requests_Response\":5:{s:11:\"\0*\0response\";O:17:\"Requests_Response\":10:{s:4:\"body\";s:1048:\"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!-- Default border color: #acc327 -->
<!-- Default background color: #ecf7ed -->

<promotions>
    <expiry_date>2019-04-25</expiry_date>
    <promo>
        <promo_id>yithhappyeaster2019</promo_id>
        <banner>banner_easter.jpg</banner>
        <title><![CDATA[<strong>YITH Happy Easter</strong>]]></title>
        <description><![CDATA[
            <span>Don\'t miss our <strong>30% discount</strong> on all our products! No coupon needed in cart. Valid only on <strong>April 20th and 21st</strong>.</span>
        ]]></description>
        <link>
            <label>Get your deals now!</label>
            <url><![CDATA[https://yithemes.com?refer_id=1072986]]></url>
        </link>
        <style>
            <image_bg_color>#2695e4</image_bg_color>
            <border_color>#2695e4</border_color>
            <background_color>#ffffff</background_color>
        </style>
        <start_date>2019-04-19 00:00:00</start_date>
        <end_date>2019-04-22 07:00:00</end_date>
    </promo>
</promotions>\";s:3:\"raw\";s:1659:\"HTTP/1.1 200 OK
Date: Mon, 22 Apr 2019 09:33:58 GMT
Content-Type: application/xml
Transfer-Encoding: chunked
Connection: close
Set-Cookie: __cfduid=d4f2a048cce798afcd4b59ee53f090c2e1555925638; expires=Tue, 21-Apr-20 09:33:58 GMT; path=/; domain=.yithemes.com; HttpOnly; Secure
Last-Modified: Mon, 08 Apr 2019 14:04:39 GMT
Strict-Transport-Security: max-age=15552000; includeSubDomains; preload
X-Content-Type-Options: nosniff
Expect-CT: max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"
Server: cloudflare
CF-RAY: 4cb69967efd38b94-KBP
Content-Encoding: gzip

<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!-- Default border color: #acc327 -->
<!-- Default background color: #ecf7ed -->

<promotions>
    <expiry_date>2019-04-25</expiry_date>
    <promo>
        <promo_id>yithhappyeaster2019</promo_id>
        <banner>banner_easter.jpg</banner>
        <title><![CDATA[<strong>YITH Happy Easter</strong>]]></title>
        <description><![CDATA[
            <span>Don\'t miss our <strong>30% discount</strong> on all our products! No coupon needed in cart. Valid only on <strong>April 20th and 21st</strong>.</span>
        ]]></description>
        <link>
            <label>Get your deals now!</label>
            <url><![CDATA[https://yithemes.com?refer_id=1072986]]></url>
        </link>
        <style>
            <image_bg_color>#2695e4</image_bg_color>
            <border_color>#2695e4</border_color>
            <background_color>#ffffff</background_color>
        </style>
        <start_date>2019-04-19 00:00:00</start_date>
        <end_date>2019-04-22 07:00:00</end_date>
    </promo>
</promotions>\";s:7:\"headers\";O:25:\"Requests_Response_Headers\":1:{s:7:\"\0*\0data\";a:10:{s:4:\"date\";a:1:{i:0;s:29:\"Mon, 22 Apr 2019 09:33:58 GMT\";}s:12:\"content-type\";a:1:{i:0;s:15:\"application/xml\";}s:10:\"set-cookie\";a:1:{i:0;s:137:\"__cfduid=d4f2a048cce798afcd4b59ee53f090c2e1555925638; expires=Tue, 21-Apr-20 09:33:58 GMT; path=/; domain=.yithemes.com; HttpOnly; Secure\";}s:13:\"last-modified\";a:1:{i:0;s:29:\"Mon, 08 Apr 2019 14:04:39 GMT\";}s:25:\"strict-transport-security\";a:1:{i:0;s:44:\"max-age=15552000; includeSubDomains; preload\";}s:22:\"x-content-type-options\";a:1:{i:0;s:7:\"nosniff\";}s:9:\"expect-ct\";a:1:{i:0;s:87:\"max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"\";}s:6:\"server\";a:1:{i:0;s:10:\"cloudflare\";}s:6:\"cf-ray\";a:1:{i:0;s:20:\"4cb69967efd38b94-KBP\";}s:16:\"content-encoding\";a:1:{i:0;s:4:\"gzip\";}}}s:11:\"status_code\";i:200;s:16:\"protocol_version\";d:1.1;s:7:\"success\";b:1;s:9:\"redirects\";i:0;s:3:\"url\";s:59:\"https://update.yithemes.com/promo/hotlink-ok/yith-promo.xml\";s:7:\"history\";a:0:{}s:7:\"cookies\";O:19:\"Requests_Cookie_Jar\":1:{s:10:\"\0*\0cookies\";a:1:{s:8:\"__cfduid\";O:15:\"Requests_Cookie\":5:{s:4:\"name\";s:8:\"__cfduid\";s:5:\"value\";s:43:\"d4f2a048cce798afcd4b59ee53f090c2e1555925638\";s:10:\"attributes\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:5:{s:7:\"expires\";i:1587461638;s:4:\"path\";s:1:\"/\";s:6:\"domain\";s:12:\"yithemes.com\";s:8:\"httponly\";b:1;s:6:\"secure\";b:1;}}s:5:\"flags\";a:4:{s:8:\"creation\";i:1555925638;s:11:\"last-access\";i:1555925638;s:10:\"persistent\";b:0;s:9:\"host-only\";b:0;}s:14:\"reference_time\";i:1555925638;}}}}s:11:\"\0*\0filename\";N;s:4:\"data\";N;s:7:\"headers\";N;s:6:\"status\";N;}}","no");
INSERT INTO `wp_options` VALUES("2136","wcmmq_g_universal_minmaxstep","a:7:{s:21:\"_wcmmq_g_min_quantity\";s:1:\"1\";s:21:\"_wcmmq_g_max_quantity\";s:2:\"50\";s:21:\"_wcmmq_g_product_step\";s:1:\"1\";s:22:\"_wcmmq_g_msg_min_limit\";s:34:\"Minimum quantity should %s of \"%s\"\";s:22:\"_wcmmq_g_msg_max_limit\";s:34:\"Maximum quantity should %s of \"%s\"\";s:35:\"_wcmmq_g_msg_max_limit_with_already\";s:32:\"You have already %s item of \"%s\"\";s:28:\"_wcmmq_g_min_qty_msg_in_loop\";s:14:\"Minimum qty is\";}","yes");
INSERT INTO `wp_options` VALUES("2229","wbu_notices","a:1:{s:19:\"premium_advertising\";a:3:{s:7:\"message\";s:235:\"You\'re using the free version of WooCommerce Better Usability. If you want more features and better support, please <a href=\'http://localhost/tes/wp-admin/admin.php?page=woo-better-usability&tab=tab-buy.php\'>check the premium page</a>.\";s:4:\"type\";s:7:\"success\";s:11:\"dismissDays\";i:90;}}","yes");
INSERT INTO `wp_options` VALUES("2239","wbu_settings","a:36:{s:20:\"hide_addedtocart_msg\";s:2:\"no\";s:18:\"hide_viewcart_link\";s:2:\"no\";s:15:\"product_max_qty\";s:0:\"\";s:21:\"checkout_allow_delete\";s:3:\"yes\";s:25:\"checkout_allow_change_qty\";s:3:\"yes\";s:27:\"checkout_display_unit_price\";s:3:\"yes\";s:23:\"enable_quantity_on_shop\";s:2:\"no\";s:18:\"qty_as_select_shop\";s:2:\"no\";s:26:\"show_show_quantity_buttons\";s:3:\"yes\";s:22:\"enable_direct_checkout\";s:2:\"no\";s:29:\"direct_checkout_add_cart_text\";s:7:\"Buy now\";s:22:\"replace_view_cart_text\";s:13:\"View checkout\";s:29:\"shop_change_products_per_show\";s:2:\"no\";s:21:\"shop_products_per_row\";i:4;s:19:\"hide_shop_paginator\";s:2:\"no\";s:17:\"hide_shop_sorting\";s:2:\"no\";s:21:\"hide_addtocart_button\";s:2:\"no\";s:21:\"qty_as_select_product\";s:2:\"no\";s:24:\"product_ajax_add_to_cart\";s:3:\"yes\";s:27:\"product_hide_price_variable\";s:2:\"no\";s:26:\"product_hide_price_grouped\";s:2:\"no\";s:21:\"product_hide_quantity\";s:2:\"no\";s:23:\"enable_auto_update_cart\";s:3:\"yes\";s:16:\"cart_ajax_method\";s:18:\"make_specific_ajax\";s:21:\"cart_updating_display\";s:3:\"yes\";s:22:\"cart_updating_location\";s:12:\"checkout_btn\";s:18:\"cart_updating_text\";s:11:\"Updating...\";s:16:\"show_qty_buttons\";s:2:\"no\";s:22:\"qty_buttons_lock_input\";s:2:\"no\";s:18:\"qty_as_select_cart\";s:2:\"no\";s:16:\"qty_select_items\";i:5;s:21:\"confirmation_zero_qty\";s:3:\"yes\";s:26:\"zero_qty_confirmation_text\";s:52:\"Are you sure you want to remove this item from cart?\";s:18:\"cart_hide_quantity\";s:2:\"no\";s:16:\"cart_hide_update\";s:2:\"no\";s:18:\"cart_fix_enter_key\";s:2:\"no\";}","yes");
INSERT INTO `wp_options` VALUES("2336","wpseo_taxonomy_meta","a:3:{s:16:\"pa_product_color\";a:5:{i:26;a:2:{s:13:\"wpseo_linkdex\";s:2:\"27\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:27;a:18:{s:11:\"wpseo_title\";s:0:\"\";s:10:\"wpseo_desc\";s:0:\"\";s:15:\"wpseo_canonical\";s:0:\"\";s:13:\"wpseo_bctitle\";s:0:\"\";s:13:\"wpseo_noindex\";s:7:\"default\";s:13:\"wpseo_focuskw\";s:0:\"\";s:13:\"wpseo_linkdex\";s:0:\"\";s:19:\"wpseo_content_score\";s:0:\"\";s:19:\"wpseo_focuskeywords\";s:2:\"[]\";s:21:\"wpseo_keywordsynonyms\";s:2:\"[]\";s:21:\"wpseo_opengraph-title\";s:0:\"\";s:27:\"wpseo_opengraph-description\";s:0:\"\";s:21:\"wpseo_opengraph-image\";s:0:\"\";s:24:\"wpseo_opengraph-image-id\";s:0:\"\";s:19:\"wpseo_twitter-title\";s:0:\"\";s:25:\"wpseo_twitter-description\";s:0:\"\";s:19:\"wpseo_twitter-image\";s:0:\"\";s:22:\"wpseo_twitter-image-id\";s:0:\"\";}i:25;a:18:{s:11:\"wpseo_title\";s:0:\"\";s:10:\"wpseo_desc\";s:0:\"\";s:15:\"wpseo_canonical\";s:0:\"\";s:13:\"wpseo_bctitle\";s:0:\"\";s:13:\"wpseo_noindex\";s:7:\"default\";s:13:\"wpseo_focuskw\";s:0:\"\";s:13:\"wpseo_linkdex\";s:0:\"\";s:19:\"wpseo_content_score\";s:0:\"\";s:19:\"wpseo_focuskeywords\";s:2:\"[]\";s:21:\"wpseo_keywordsynonyms\";s:2:\"[]\";s:21:\"wpseo_opengraph-title\";s:0:\"\";s:27:\"wpseo_opengraph-description\";s:0:\"\";s:21:\"wpseo_opengraph-image\";s:0:\"\";s:24:\"wpseo_opengraph-image-id\";s:0:\"\";s:19:\"wpseo_twitter-title\";s:0:\"\";s:25:\"wpseo_twitter-description\";s:0:\"\";s:19:\"wpseo_twitter-image\";s:0:\"\";s:22:\"wpseo_twitter-image-id\";s:0:\"\";}i:23;a:18:{s:11:\"wpseo_title\";s:0:\"\";s:10:\"wpseo_desc\";s:0:\"\";s:15:\"wpseo_canonical\";s:0:\"\";s:13:\"wpseo_bctitle\";s:0:\"\";s:13:\"wpseo_noindex\";s:7:\"default\";s:13:\"wpseo_focuskw\";s:0:\"\";s:13:\"wpseo_linkdex\";s:0:\"\";s:19:\"wpseo_content_score\";s:0:\"\";s:19:\"wpseo_focuskeywords\";s:2:\"[]\";s:21:\"wpseo_keywordsynonyms\";s:2:\"[]\";s:21:\"wpseo_opengraph-title\";s:0:\"\";s:27:\"wpseo_opengraph-description\";s:0:\"\";s:21:\"wpseo_opengraph-image\";s:0:\"\";s:24:\"wpseo_opengraph-image-id\";s:0:\"\";s:19:\"wpseo_twitter-title\";s:0:\"\";s:25:\"wpseo_twitter-description\";s:0:\"\";s:19:\"wpseo_twitter-image\";s:0:\"\";s:22:\"wpseo_twitter-image-id\";s:0:\"\";}i:24;a:18:{s:11:\"wpseo_title\";s:0:\"\";s:10:\"wpseo_desc\";s:0:\"\";s:15:\"wpseo_canonical\";s:0:\"\";s:13:\"wpseo_bctitle\";s:0:\"\";s:13:\"wpseo_noindex\";s:7:\"default\";s:13:\"wpseo_focuskw\";s:0:\"\";s:13:\"wpseo_linkdex\";s:0:\"\";s:19:\"wpseo_content_score\";s:0:\"\";s:19:\"wpseo_focuskeywords\";s:2:\"[]\";s:21:\"wpseo_keywordsynonyms\";s:2:\"[]\";s:21:\"wpseo_opengraph-title\";s:0:\"\";s:27:\"wpseo_opengraph-description\";s:0:\"\";s:21:\"wpseo_opengraph-image\";s:0:\"\";s:24:\"wpseo_opengraph-image-id\";s:0:\"\";s:19:\"wpseo_twitter-title\";s:0:\"\";s:25:\"wpseo_twitter-description\";s:0:\"\";s:19:\"wpseo_twitter-image\";s:0:\"\";s:22:\"wpseo_twitter-image-id\";s:0:\"\";}}s:11:\"pa_plotnost\";a:1:{i:28;a:2:{s:13:\"wpseo_linkdex\";s:2:\"27\";s:19:\"wpseo_content_score\";s:2:\"30\";}}s:11:\"product_cat\";a:2:{i:33;a:2:{s:13:\"wpseo_linkdex\";s:2:\"27\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:15;a:2:{s:13:\"wpseo_linkdex\";s:2:\"32\";s:19:\"wpseo_content_score\";s:2:\"30\";}}}","yes");
INSERT INTO `wp_options` VALUES("2513","_transient_orders-transient-version","1558701631","yes");
INSERT INTO `wp_options` VALUES("2871","woocommerce_thumbnail_cropping","custom","yes");
INSERT INTO `wp_options` VALUES("3319","new_admin_email","domaratskiy1990@gmail.com","yes");
INSERT INTO `wp_options` VALUES("3447","rsssl_activation_timestamp","1557408586","yes");
INSERT INTO `wp_options` VALUES("3474","woocommerce_bacs_settings","a:11:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:48:\"Прямой банковский перевод\";s:11:\"description\";s:324:\"Оплату нужно направлять напрямую на наш банковский счет. Используйте идентификатор заказа в качестве кода платежа. Заказ будет отправлен после поступления средств на наш счет.\";s:12:\"instructions\";s:0:\"\";s:15:\"account_details\";s:0:\"\";s:12:\"account_name\";s:0:\"\";s:14:\"account_number\";s:0:\"\";s:9:\"sort_code\";s:0:\"\";s:9:\"bank_name\";s:0:\"\";s:4:\"iban\";s:0:\"\";s:3:\"bic\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("3475","woocommerce_cod_settings","a:6:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:36:\"Оплата при доставке\";s:11:\"description\";s:69:\"Оплата наличными при доставке заказа.\";s:12:\"instructions\";s:69:\"Оплата наличными при доставке заказа.\";s:18:\"enable_for_methods\";a:0:{}s:18:\"enable_for_virtual\";s:3:\"yes\";}","yes");
INSERT INTO `wp_options` VALUES("3476","woocommerce_paypal_settings","a:23:{s:7:\"enabled\";s:2:\"no\";s:5:\"title\";s:6:\"PayPal\";s:11:\"description\";s:214:\"Оплата через PayPal; вы можете произвести оплату с помощью вашей банковской карты, если у вас нет аккаунта в системе PayPal.\";s:5:\"email\";s:25:\"domaratskiy1990@gmail.com\";s:8:\"advanced\";s:0:\"\";s:8:\"testmode\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:16:\"ipn_notification\";s:3:\"yes\";s:14:\"receiver_email\";s:25:\"domaratskiy1990@gmail.com\";s:14:\"identity_token\";s:0:\"\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:13:\"send_shipping\";s:3:\"yes\";s:16:\"address_override\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:10:\"page_style\";s:0:\"\";s:9:\"image_url\";s:0:\"\";s:11:\"api_details\";s:0:\"\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("3564","woocommerce_flat_rate_1_settings","a:3:{s:5:\"title\";s:25:\"Единая ставка\";s:10:\"tax_status\";s:7:\"taxable\";s:4:\"cost\";s:3:\"500\";}","yes");
INSERT INTO `wp_options` VALUES("3582","woocommerce_free_shipping_2_settings","a:3:{s:5:\"title\";s:37:\"Бесплатная доставка\";s:8:\"requires\";s:10:\"min_amount\";s:10:\"min_amount\";s:4:\"3000\";}","yes");
INSERT INTO `wp_options` VALUES("3588","woocommerce_gateway_order","a:4:{s:4:\"bacs\";i:0;s:6:\"cheque\";i:1;s:3:\"cod\";i:2;s:6:\"paypal\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("4465","widget_bellows_navigation_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("4467","bellows_main","a:7:{s:4:\"skin\";s:13:\"blue-material\";s:7:\"folding\";s:8:\"multiple\";s:17:\"current_expansion\";s:3:\"off\";s:10:\"menu_align\";s:4:\"full\";s:10:\"menu_width\";s:0:\"\";s:13:\"container_tag\";s:3:\"div\";s:11:\"font_family\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("4468","bellows_general","","yes");
INSERT INTO `wp_options` VALUES("4471","_bellows_menu_styles","a:1:{s:4:\"main\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("4682","_bellows_menu_item_styles","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("4796","theme_mods_twentyseventeen","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:3:\"top\";i:20;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1561731898;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:33:\"woocommerce_layered_nav_filters-2\";i:1;s:32:\"woocommerce_product_categories-2\";i:2;s:25:\"woocommerce_layered_nav-2\";i:3;s:25:\"woocommerce_layered_nav-3\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("4813","theme_mods_twentysixteen","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:20;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1561731949;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:33:\"woocommerce_layered_nav_filters-2\";i:1;s:32:\"woocommerce_product_categories-2\";i:2;s:25:\"woocommerce_layered_nav-2\";i:3;s:25:\"woocommerce_layered_nav-3\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("4920","widget_yith_wc_category_accordion","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("4957","sp_eap_settings","a:3:{s:15:\"eap_data_remove\";b:0;s:18:\"eap_dequeue_fa_css\";b:1;s:13:\"ea_custom_css\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("5036","wa_wcc_version","0.0.1","yes");
INSERT INTO `wp_options` VALUES("5037","wa_wcc_settings","a:8:{s:13:\"posts_orderby\";s:2:\"id\";s:11:\"posts_order\";s:4:\"desc\";s:8:\"category\";a:1:{i:0;s:2:\"21\";}s:13:\"hide_if_empty\";b:0;s:10:\"show_count\";b:1;s:8:\"duration\";s:3:\"400\";s:5:\"level\";s:1:\"0\";s:10:\"custom_css\";s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES("5038","wa_wcc_configuration","a:4:{s:19:\"deactivation_delete\";b:0;s:13:\"loading_place\";s:6:\"footer\";s:13:\"load_velocity\";b:1;s:10:\"load_mtree\";b:1;}","no");
INSERT INTO `wp_options` VALUES("5039","widget_wcc_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("5058","wcsca_closed_icon","fas fa-chevron-down","yes");
INSERT INTO `wp_options` VALUES("5059","wcsca_open_icon","fas fa-chevron-up","yes");
INSERT INTO `wp_options` VALUES("5060","wcsca_font_size","","yes");
INSERT INTO `wp_options` VALUES("5061","wcsca_padding","","yes");
INSERT INTO `wp_options` VALUES("5063","wcsca_icon_size","","yes");
INSERT INTO `wp_options` VALUES("5110","widget_wp_categories_widget","a:2:{i:2;a:6:{s:9:\"wcw_title\";s:13:\"WP Categories\";s:14:\"wcw_hide_title\";s:0:\"\";s:17:\"wcw_taxonomy_type\";s:8:\"category\";s:23:\"wcw_selected_categories\";a:1:{i:0;s:0:\"\";}s:17:\"wcw_action_on_cat\";s:7:\"exclude\";s:14:\"wcw_hide_count\";s:1:\"1\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("5132","widget_postaccordionpanel","a:2:{i:2;a:14:{s:12:\"widget_title\";s:20:\"Category & Post View\";s:11:\"category_id\";s:1:\"1\";s:22:\"number_of_post_display\";s:1:\"2\";s:16:\"title_text_color\";s:4:\"#000\";s:23:\"category_tab_text_color\";s:4:\"#000\";s:29:\"category_tab_background_color\";s:7:\"#f7f7f7\";s:17:\"header_text_color\";s:4:\"#fff\";s:23:\"header_background_color\";s:7:\"#00bc65\";s:15:\"tp_widget_width\";s:4:\"100%\";s:24:\"display_title_over_image\";s:2:\"no\";s:17:\"hide_widget_title\";s:2:\"no\";s:15:\"hide_post_title\";s:2:\"no\";s:8:\"template\";s:12:\"pane_style_1\";s:5:\"vcode\";s:36:\"uid_b4044dae3fe6f452005efe0a5395ac62\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("5429","_transient_timeout_wc_product_loope90c1559749680","1562588275","no");
INSERT INTO `wp_options` VALUES("5430","_transient_wc_product_loope90c1559749680","O:8:\"stdClass\":5:{s:3:\"ids\";a:0:{}s:5:\"total\";i:0;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:12;s:12:\"current_page\";i:1;}","no");
INSERT INTO `wp_options` VALUES("5497","_transient_timeout_wc_shipping_method_count_1_1557503435","1562748890","no");
INSERT INTO `wp_options` VALUES("5498","_transient_wc_shipping_method_count_1_1557503435","2","no");
INSERT INTO `wp_options` VALUES("5649","_transient_tawcvs_attribute_taxonomies","a:1:{i:5;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"5\";s:14:\"attribute_name\";s:5:\"tsvet\";s:15:\"attribute_label\";s:8:\"Цвет\";s:14:\"attribute_type\";s:11:\"colorpicker\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}","yes");
INSERT INTO `wp_options` VALUES("5650","tawcvs_backup_attributes_time","1562161809","yes");
INSERT INTO `wp_options` VALUES("5681","imsanity_max_height","1000","yes");
INSERT INTO `wp_options` VALUES("5682","imsanity_max_width","1000","yes");
INSERT INTO `wp_options` VALUES("5683","imsanity_max_height_library","1000","yes");
INSERT INTO `wp_options` VALUES("5684","imsanity_max_width_library","1000","yes");
INSERT INTO `wp_options` VALUES("5685","imsanity_max_height_other","0","yes");
INSERT INTO `wp_options` VALUES("5686","imsanity_max_width_other","0","yes");
INSERT INTO `wp_options` VALUES("5687","imsanity_bmp_to_jpg","1","yes");
INSERT INTO `wp_options` VALUES("5688","imsanity_png_to_jpg","0","yes");
INSERT INTO `wp_options` VALUES("5689","imsanity_quality","82","yes");
INSERT INTO `wp_options` VALUES("5690","imsanity_deep_scan","","yes");
INSERT INTO `wp_options` VALUES("5830","_transient_timeout_wc_cbp_8cef2d2a7c1b892e0973027fd0427cc9","1562940105","no");
INSERT INTO `wp_options` VALUES("5831","_transient_wc_cbp_8cef2d2a7c1b892e0973027fd0427cc9","a:0:{}","no");
INSERT INTO `wp_options` VALUES("6035","_transient_timeout_wc_cbp_2cf5cb5b9502c6af30b42f06c316c002","1563447782","no");
INSERT INTO `wp_options` VALUES("6036","_transient_wc_cbp_2cf5cb5b9502c6af30b42f06c316c002","a:0:{}","no");
INSERT INTO `wp_options` VALUES("6180","wp_paginate_options","a:21:{s:5:\"title\";s:6:\"Pages:\";s:8:\"nextpage\";s:7:\"&raquo;\";s:12:\"previouspage\";s:7:\"&laquo;\";s:3:\"css\";b:1;s:5:\"slash\";b:0;s:6:\"before\";s:42:\"&lt;div class=\\&quot;navigation\\&quot;&gt;\";s:5:\"after\";s:12:\"&lt;/div&gt;\";s:5:\"empty\";b:1;s:5:\"range\";i:3;s:6:\"anchor\";i:1;s:3:\"gap\";i:3;s:10:\"everywhere\";b:1;s:9:\"home-page\";b:0;s:9:\"blog-page\";b:0;s:11:\"search-page\";b:0;s:13:\"category-page\";b:0;s:12:\"archive-page\";b:0;s:8:\"position\";s:4:\"none\";s:24:\"hide-standard-pagination\";b:0;s:4:\"font\";s:12:\"font-inherit\";s:6:\"preset\";s:7:\"default\";}","yes");
INSERT INTO `wp_options` VALUES("6235","numberposts","10","yes");
INSERT INTO `wp_options` VALUES("6236","widget_listcategorypostswidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6264","woocommerce_show_marketplace_suggestions","no","yes");
INSERT INTO `wp_options` VALUES("6313","_transient_wvs_get_wc_attribute_taxonomy_pa_product_color","O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"1\";s:14:\"attribute_name\";s:13:\"product_color\";s:15:\"attribute_label\";s:8:\"Цвет\";s:14:\"attribute_type\";s:5:\"color\";s:17:\"attribute_orderby\";s:4:\"name\";s:16:\"attribute_public\";s:1:\"1\";}","yes");
INSERT INTO `wp_options` VALUES("6362","widget_yith-woo-ajax-navigation","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6363","widget_yith-woo-ajax-reset-navigation","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6364","yit_wcan_options","a:6:{s:29:\"yith_wcan_ajax_shop_container\";s:9:\".products\";s:30:\"yith_wcan_ajax_shop_pagination\";s:26:\"nav.woocommerce-pagination\";s:36:\"yith_wcan_ajax_shop_result_container\";s:25:\".woocommerce-result-count\";s:31:\"yith_wcan_ajax_scroll_top_class\";s:19:\".yit-wcan-container\";s:31:\"yith_wcan_ajax_shop_terms_order\";s:12:\"alphabetical\";s:22:\"yith_wcan_custom_style\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("6460","wp_installer_settings","eJzs/elyHNmVJor+7jKrd4gTfVpJdiEwDyRyqAOCZCZUHCACTCqtrQ3HEeEAXIwID7lHEITaZFaP0W12jple5No106PUC9xXuGvce+3BI4KplErn3qpuSQQQsX37Htb4rW8Vx3vH/6M93tk97jflrG6red1UZdv/ujjexT/sH/fvZ5Mx/rwjP4+KeUE/0zfhi9Wo/3V7vPeEPzqY35WD+7oZzZqybQeTxXhejavp7aIYD2bjxW01xU/DONNiUtI/t4/7H85fv+oNepd3Ze8DfPUcv9p7bb7aO3dfxbnOmnq0GM4HbgweguZx3F80Y/rg4XH/bj6ftcdbWzizzbq5xd/vwqfhRcurj+VDezUppsVtOSmn8yv53t5O+r2tYjisF9P5Fn6x3dJ5tIvZrG7mV/PitpU1qo63zeItneDe08yDbupmMWm35vWsGg5gXPoLPPCPf2yPYYlnxfAjzJeetodP293fOzw83IMfj4L9cDvXNY8deM1R2Q6bajaval7abfg6bsKwnszG5bzsyeM2erd1PerB3HrF9KFnN7WHK7LRq6bD8WIEv+oV47YOP/Ghrk/ryaRshmVPVmwTHwevX01gdF34w9zC388Gw3o6h/3ZWszGdTFqt3a3d/a3tp/QZwbj+rbeGWzvbM6mtLsHx304QWXT/xp3AgbFNWvg6/qLJ+746CLCi8NUgpMKs5oOH2hL463EzwZH80Q+m11SONwyq1lTDUucxM7BU/zsER6fa/fhq/nDjP98tLPzBI/pbuYDV/Py83zVLOKRq+lNrd/5qSya8UPP/p3uxJPcw8rfL6pPxZgWj9bg8Gh3JzzDB7k9++diNBrM68GwaObf8gHd+VUxmX19vXi4mtb339IgT1DmTMt7ODC40NvH/4OP+GJ22xSj0vwSXohFB1+yI75lMOtDvskZUTOctLSY+Kk9kUztvIG/DuZNMW3HBb86XCD8yJEKL/+3gZcM+LE92RL62KQcVUU80L7Ilvu6HspxD+aEnznAz8BhgDf8VM0f4EJN2uRDhzIjPPcFSDn81OAo+diRvNv1YjR6SJcAP/KEj14xvJnQz3TwDuQlivF4UE3wNtJK0YLu6AsW1Xh4B3/Fhw/uZ/SJHTlDcCXbsk4etrPLT8Ojw4u/x7sMn/9Ulff8u31Zx3ldj9tyPpjAVRyXstgN3w85xLJp1fDjwwCe85EHOBTZS3+FbQYl8AnEI4mTUX0/JRmhZwd+vfMkutv4nd381T6MLtXp64v17/XR0mt9eLTzdPWt7prAX+lKy1t8+XXe/o/r/B/X+d/nOseq+hosgK77fBRdp2fw2fUv9O6qC72Gmu6cwd/ZjT54+gve6J0vvNFL7+HuGvdwb/Xd2Y/uzkH33TlcdXWOlt+cJ9HFeZq5N9sr7k3XBfjjH+FVDna24ezFFj8qj3SJf66C+/9HX4BWWNb3MF3fo4zkiRf4CyTOgSzwddFWwx65wJ/KpoW/miUOFg8f2P6dLVfmoFKkIFXyq8WBfs4sKN5DWprcsUVHHp7RX0PS5M843gc+4w2cb5pub75opq0JQ9ixNntn8x7IzrY3dxtnxFUPl7uBCw03YwSHf1zft/7vcB9kO3QLh3fF9LaUE7J79OQAFu2bu/3v9jd3N482d77Zgn9/c7f33cuygFmVLfxi77t//IdvFmP47x783zfj6ruzCezJp3LUG5WzcjpCL7A3vCuHH3vX5fy+LKe9UXVzU+I+6vlqe/WNvC6MCWMEo43JSIIBh4t2Xk964+q6KZoHOo6n9XhcDuc0Bv5cTttFw282mcE7XsNKzR9699X8rlfDGjXRY77Zorl/c93gf+OrVZ873gv/AovYuynmsONl08DjYHuK0QT++/4O3uvisle1vcVsVOBsr8sb3MVT+K/onXik/vvpsFjc3s17L3Cs497puIDt/QpP19VbVqivRfzC9jZwovF5bT2B81G0ZcsPpceRbFvA4sA/h7DPD9knFlOZtoxG32/BUsRv975fwFG4Lpvb4AT9rr7m1St6bN/SmSmqKX8JPtbebWafBp9r63Epj4RXbXFRHuBL4/JmDiek6d00sJ14cl/hK/TGBR7q23i5Lsp5718Wzahq79xHeuMa3rPszetef/jxup+dAY4sk7av1JSzcTGkQ0VnBqTY8GPLb6mfK65h8Go6hUnKHaErxL/hL8Rv/Z72nR56BrZT77r+jPuF2/lVq7qlB/cdrkDndMdVO+fxYXeq4V3vvmh703regzs1K9EIAwmIC4mCAT5v3wuMlXnddG1Gch2ur1me4OiwjBW8ZYPXUrZ7Mb+DtZlhbC8a8WQ0wtstErb3/t2rFqfToOHX0LLSoGC08p28HS/KjtvNQ+nawCz0fUpZhGIO+3cNJxNE2BCkImlx+ByJ4N/Cf2B3bqrbRUNLEL87Dw8ytpjh9xbTaliP4PbcFQ04PiB7cN7+3MePzI52U43pm8Fk5ZTBaHKYcJC2h6HpVJ6xdMTdA3E7QkmO4o/EOsi6Xj0cLhqQjrh88Hs6xKB84MHlmPYdrvELlomwuFN4oeyONyUei09oJsF2wmUZLuScwP//UE1h/+IXvCw+19N6AoY+bBYfAzwVIIB6YNAvSr3E4BrA/YfXbuDINSB+cUi4y3BJZun15elUbQsDkMR5Qed0q3dxV896IuFg6CkexBEYBiDBYOyiN6vbeV6OBTLYCbMKhQ2MzZJJDIPeo8zRv/iAdp9a74+tLlB1dyjKbt8qu32vFP6TPxG4Q2i/XOGEr3AGV5NyXlyBALgC361u8Ll8bPDUsJKlb4lswO/RzHv4PRIc+r3NSE/hfERDxZMx69zy7uPc6h57R7gocgdFb7T4K3DfwI8Yg5EFu9rCovIZaTd7b+r7DbKf+YKD3QUGxH3xAAoOzoC7aWYdYFuqz/hEUsKlkwH4VdAy8Il6CgKMni7CYrTZu7wDnXlXjmd0peBXC7DEwVttit59g8kNumm0xFf1jDU9iedwCnoy2hJuDy64HDjcbqc0WvhxiEYAufubuX0/WGHk2Ped4jzRxBnBxrUtPqG4rhdzr5PPfzhXGyfZyayt8Z8CbW3egZRD8h5w7+Z6aYsG3EK67yCyc4tTj0YkkcBMxKs8HtPSBmvK54X0GNs1sofJcLDS+G762vBJsl7A/Lw0GulFqJHMl8NLCXcVHj5xBuJPddGywn1T905hNrc12HvPcN6PWPQ/Dgd9V4Kp8ckffxRUuv56DOncWeO3oKXqgUKmq0LL7ARrOun97X2ROKjU4HbCXQIhNOTpVe4JsFH9eNp9WWZS5+UUl3qUPX77amXTcZB3gxMEKvUeBOwtLtUQ7ghcqVE9hf9iaxcfCp4G2AYi4m9QApTw5PxT8s8g7fbZLV563GCbYXUWoNiqtpjNyoIeTlYcmaWhCMk9eS9+sjd9jEwHW/jtq1cnl2dv36BFjYoBFFDFHujpDyfvTk4vX7zrXby4zD5kd5077BSxWh849jOyANiQAsH8qO+Mg/7jrPG3/m3uzatJicKhnjrZ3xv86nb+dQ8MXDyQLZ9Hd4pI+N7BgSl6dwv4w3QxucY7f8NqguyB7EUv5DIPa9kLq33puVWre1XyotIGVA3cOpxmdtBEHC2muBRivrQP7RxuME9q1TuG4wcmETif6MPWvVuw+vEXoR0DT8I3RzPJWTE9tIz5SvMs8ouSzN9KqtcuGA9//0PRjOjQtXf1PQ5LC3fJkTHwVR5gG1t1z/FGgzEJM8w9FZ9DNpRcTHr486r9/SKa5AXLL7rIYIfXzaQAC1CmHDhPRROcBQ5gkw3RxkJx4pY1dLC84+X9KXA8Vi8b2S7iBKKlpW63WuFZsUFWNnqsuI4NWz6j8qYAg9d/GE4kG0Z5uWhiDyscdGcAFWNnAIk2puPIsg3nIHG/CqQO3Je83/SLn5oqOS3yvB/QF1CrYliyuhAvD3a/EQcNHFceuBiRTQeL3+A+s0LT5YwHfwfLPQSZpidyOL5ywamrVq8me5wN69LWT6MVn0RcHBL1NCX45mKWOMJOGReoHGFXURbFURM6MmDqz/VKfKpwajAyqn0f7bp48VZu2ooNUq01Kgftw3QITsEUtsRfupPRJ7xRoyUGSnDittc3BHFJvwf9BEdpmm6ByjgXxrLyQGXvtLzHSBEomHaOej0yGu3TnpXTW3iYi1YHH3nf4n0ryPq+R5PgEz+TLry7vbj3oN7c5VtMR2JMwlScpGbB/X0Jk4Ktm1GoPVAh4UEWVfir6XU7+3o9lYjm2X3RTN1tmTcP4uCP4P7yxvWvSjXKroZt22cdE77285puHpgls3EBtv+Up+bfUIM4mNWyRhPrPDrHcoVzQnCEN2VIVuKiZbccPH4QuY/QKujN7ma9IzRtchZpcJ9ZAJKzKNdshBHzqxluN0xErMSm5KAvfncyAwNZ4gvwHYwS8DWExfvHf6ALldV3z92cj91kj8GenkqeGo5cCQIH417jMVjeLF/gO/iWoNP4U62KoJsF3oGMKT9NAnzVlI21T2AeShwNVAX8Sq8j7vTNuLhFzxLP0XXJLwdPhPOa3YHQXzAi2UdCaFiMSLEoDL8xpNgqfgNNMP8lUeI0g3/8h249Ho9nZoCH+GBzb/Oz9athHW+vJij9rsDI6rIMbgoK5Pfevbi4JJe4bOfiRngJGNhqJDrBaee4C7oXKC7zGhU/6j4XTsEvwDkml3uv8PCZZITqYryJJ6BKaQZlMcKT/2PVYuahc7y6N+i9wCylu3TO2ngJZg0s2ghtO5Qfn+BTrB1QDBq5DMJruTFiNGBBwlNGhfkG4bFLuD8YCcnv6fXi1kZKJL8gNqxRi3heKX6DXjQHRbMRkKy1hxdpRihUcRUfBuSBs5PLNz4c7L95uGpb1v+99xrMuN5XZOF9xT4CTJaCRijIJ8WM0zsjlyGhv2G61wUFzOKuYR1P4RzCL0+fn1ye4Dn67auzly/J7O7wNzovx8mnYlREiQZJIJThlhu7bP1IArpv8we6Q2L3ScQdfAOyx/Bgvbt85W5FNP/3kqvBx54vpr8rritjJIOIii1qiXfiMZOQvA/AoDTjgzn14YF5EFOtOHom17hEKxozWXmb4RVG18nYojdChbFoKCqMYTTR1hpIC8M+xpLZSb393JYnMV0nqfEp+GqybZxqJImFv4VjelN91ufS8KciO0D61MMFXkTeQwy6SYDMhmF8/J1eAd4YnlCAgMDLUU5bXiy849cNeHu04tfBA9XRKXq/+82ihPU0mUcne/TLLmbNwq736AaNlJ5LxoGpXFL0XbJyMqSEIUDKwskdPV59h/AM30qWTC++KlMO5biDxopsinHY4L2smfSGolga7JbN94FjTisJCMLqN3OqOqfqgu4jk8h4VhaYonu2qCg6HOUEV45JBv3tuL5GFIZmaMd1GyXjQAncYFycpBpHHoOhL+b1bMbJRIxQeR8/jE/ihbw2sZs4btk5TbdSYA6DzkJ9RX73BPNEnNTlFbHCSM5CaC1Eqt2+P2NpnEXFbhZ4iYsxZonVatX4uJyR4LtftUs3ALQPvtcPlwjZQNurMMKy25kvpuAjDeEh9s5bVSxiZRTkQPt4bvtoImK4cQL2Ysej2C4MVPUUE2PF8G7CtjiJ0bsK/AtUUzgTPNEdK6oavpqT1crZ0ZLzDHbGpAGeFR/x1vb5SxXK3LYalddF08/KyL1l8YXOFbyYFyjAR+Bc4mF8I4cRJ8Q2rRxb2loJLrImM6G+qWQzwzGcWexOx2qRc/LudUlhIbFqyZNG43RbsmPFEIZ2evZ+JpdoVkzLrI1aREl8jV6RzWbkduifd56Ck+DKIpLnK46WUKAjWB5jSluTQBev84HGPHT2hhFv9nitacFEDoZsh06sf1pP8N8XdT3t9+aRtRkcsd3sEetCmVwXw49wqIdllOW0HscaydHoFfBERIKd3sqnTS0eTlOo5MiFpmOCK4lcXDrRGBqVEASJ0Gr68Pr0BatkddRg4y/Lz3Ow1/Ci5h7gskM88vmzUH9I4vi6dMAbPjZTjhrD+V+GiwjWKoxAoLABuwMc5vIzuEcoscyDcxNltS6ZXgSM4TCaXhB5rkektSHUappJPOXS57ibuKJVvWi3prhuIEeqqbev8mMF53BZKDW4Er++sAtjMutodfi7CSs8lOtZdoXTdr4knFbIJQwQFk7aoKJGWG6MwgkS0ZqXFLHTGfljHS6hOHBGs8NlAAR4lDF+TE5a72xChmtOKr3QBLG/g9ZBRAU4xJsjel5QSA4L0oAhW+BpyiV79GXRNL7hRWXLWYB+izbBqVQ8U5LC00EAdhLgCmXBAgnRlepnPAM8789/kksOS7C4xjDoH0hxOSiHogzzA8nM8cFtSWA+igaSjbS4HmBRJIYdIufcWU9e868e3+FtSPteiwRkt4OfOKpRJ4mrE6LBJApJq0ewVNq9T3UFpgXssV4HFHaNmOby4hvwKPxhRqKlmms0Ja+JJlUbpl+H9XgxIRX5coFBYd0YjOAyFDL35jat6YNJMNFZDScwOkqn9ogfgzPExvTrt+z0uzB1/9blQ3tYUgDrhVZz7kW8RvDJg1wKnkIVeGpVW6BsAzP4TvIhAj60O/YFyVcXhv118akQj49jpjwwB2EwySAWhz7RLdlXHdKtW0LoYv1mUc85nXG+GI9/Tz/JLQtgZ9lx8Qqj4WtEFlwCcHR/V7mYrE5sCQiw01bEHAn5ez57yEtgjj3iWtAPwtMrDs8CwaWdd06PsEOZBIo1QV7csYXmV0Ki9rhkHWk2jeznn+tHyppzDlCpuSKvKEwUMDIXSYKKhbHcFieEiLfrcwEe/jOlTtAS18NG2X4K7nCYSGO6fU1omB1RVwxxKLAZaCcqQioOAfd5+9KUY+RZuRgVSPRJyxjUzAn9gtBVV/L0mQRh3lmHUwS0355RzWjNaYmLhE+xDioq7+ntGNHALLnl7fWX+Rm9K9Eg4/f9ppx8tzmpv9mC/2UwAV7Z9x8bhDWbFB64jBgLuEcw1O8WFBKt5q2BHuNAi480TtfaqhgWJKc9oZ8UTSKvThYjHc8wEb5kSf2x4K3znieHn3i/AnsZkfZ0rAPck5tXBzRj0apVhmeTkr/l51nZVBgpwzEFyojlQ2C6ZMPEPt7AlipsZIBZExMgPllrxKu9ccUjR8EB54Wvd0jd9iPMZoBoTL+sTXkDSuEOlw3vOK2hkWjL1lKjlIFkI0vWZRpavRIatCQ3yiVkJcinMWYbSqF0RU+w4l3i2STmnU8lx4jzUITm7/nC1LyYS/EpHF24Xow/DkZgJvGKuNm1S1c9cqrZtse0RivGLKJH03frRIAG28mjiYQRBdf3M+trKG/VqHBj2gqNwN9TMFgtCBbzDFtAZ0IDL5QkdsBtNh+LcUVFGwX/pZ6Wkgu4fqBtXhLNoGCdWI8edyh6gCbhxUoV4nOND7a9+aTLB+sFUEANpk8l5Fyrl1QmJQc3ZTkiDURXl9C6i1mjeGM6xnSEGWEM+znt7W0+QWfQR/hsDoaywjjWSQPyZhhXhIjBx/9vtQdrzpjAjnA/BuyZW53nqix8KBbFJv7FvG0UlsTxT3598luC0lrEGsP35xJcoxy34J8cloclPBhy88ygDiTzDKtH2W7nozabjV3kCeXNFaVUvHXPTlkcP7ULgXLRo0K83CQgMFt/3bo9kAJJ5MQHF62Ee6knxOWSuiw7RpVaZOxSKT1CcCMeulsHkwq8ukysxt6socRd+j/U9/j2OiswmgJweKfMumWpLMoUPLpqRIowOBWoLMEGq258wBBPVR9N90WbLCwiuNi4oDqV0CohOHQ5Q+jPq1g1RkaHupDiM1Phry6Sw8aIAOkaQxdmHi5M4P26XBodarSdg4SfulQN/L5s0bGmyASLBAyN3aFwj0z1KemWUA3SojAelvb/7fTyrvy+vqBMEBZXlQ0CplbumckicbIWr4PLa6IzCpYaQyvX3n+q40En1s32h8vL86sf3l5caswP95Gvpn6B6J4Wzbhj7fOwOb5BcHyuqhFfFy2j5EfjX1SswUc22I1QOcf3S6Rb0WaMBIukahY+wwgucJCo5/oABuqGJYguJ+nWgqqCBiVM5FG5ebspALIZuDp3RRsW6vBu8OiiPedgHD9OLolRFL3rmu0XjqQWfOPaagIu3E2FEIa7ChRtLiC/vXnUpQ6XAEtF1LncrkHb+HMr6AxvYmPwfnF7JwhyWiE4cHgSk7qQVK9lZpNzbyWg8eG8d7FAWMIp2DgZHKhYgEmOQHGqPyIjgAN9ud27Q7g/4/T4KXCDcQ0PV8FmOY5XgyldTUqXDmjjwAbhROAmy42pAhS3m/y4/FTAcedqYjFD2WnnOBxbLGtG+mGlJEsoYvK2wXuFuWVN8ErVAUgEuLrD3tnzzvU8XQqAiV4svTUTvjFYYysZxQAmv7pa8i/LLuS0OZs/d4UxZBnCYuu3nY/Gsga/cfY8lE1k9IXWVrqO/Gaqtn6/qIYfiZKFRCc7SfbAOIepiiCruVWLTqRJSMXWLIIItFSNwqbnvkD9GzjuR3DgO1DbzkHAokKsM5VoHDsKWtdE1wZX6uTyRTzSG1stB1vccHzo+oEqefy578jBXWOJIUehvSdafi4Q6KIhJVk2jEAXOCkQQwRRzI/o/E9Gx4o3YKI0TpvcEOBiOiCDt2phSecGlBrI3MMvSANRYkMQsWQ4UFRIkxqMxOlVN72muGfog08KtFrbncvYcWQDiRGw1lBCQjDrenr7HUFzx+2VXqQrrDqBOcqfNe1xV9cfk0Aw4b5mLq9Dpk4k5txUKevurdV1804U53JGO5xPCsILMoJTSLmRcLpSqEGijhM0hIoqMQhbNxqfUpQUaffcUKF+UYfXJhua8hbTpcIVUH+sXHJlWCDS1hWLsOTGX+BQ2fSNHZehhCLoNBnzBamATqcw2iMbRiZVTaQxBc0njO/ASGjUoqDidyHHXh30FGvgtIXPjQSI7oPtbSuCHVyfbSG4Li3PL+CswSLqtKbKBHcDWO3cxlrqWMtzeTYB0YLj+VXrAtcm5LhuWUVcojkR4GQYDwwmGuZmVp0Mq7/tKLCkDFYm9Vy3cS7TTYmRHOLGYzEEgfx6N4spx+Pgdl2h4Lm6fnj0uJ8aT8jxAdJqfl83HxWs3YUPDiQNz/yKk5pXmJORGucrATM4yfPnPxUen+VMhygpCt8nQCYDGCOhgrwykgETWphxTgmiL0WKiNIALFLxlF+XhNnQyCfF5jhTwMZSg3nuJr7Gf7/uhKoBpIYiuebpjgTwMP39olyUUSoW5ZksY1zBp/A+PBFkmTbBZjObmFclJn/qoCvz+s9/0u+4Ai33lZXShG/kjCSz5pB0uM27OUdoAmVWRqLGvakiTMFeKzio3iVkQre4XVxPqrnExHEVePNOmWuQKgDa3pGm/mjVfbqFw7ydVQudNTUKFfPm6IyCDhP262El4kC9GI5prGtLd4QG7CgHj8qN8kQseBIns7kGxxhn4megcSqC7rvvYK5uDHMdPQgYoivXaGVQWm37yi9E964xyQLH/CuuyMHwLZG6CCcER+d5RXBJ/QJrUnFZlsHukjG72YTjijS/LSYTLbeaXOgg/B9CVjqyEzazoSgzbzOJ/XAfwc3i/Mg1ezrsemhGmK8Y1RUEehtfFN2AtuXQH9Xot9Hg57wAUW68dYEpjRq7MqB588C8PFI8xbLQlO111GKACfcRUwLvz/RgyJ56v6CwCekIw9sN37SGnWODYr9iKpU4MXMUOg03snQrHhBGpplTgIVEcF10/oi0QwmaNXdBBeIL4t5w/ZwhaZCUY5vjybi4A5NdckZMakA5eb9Y7nB6pJJLL40YXeXgH52uRyQ2UZKMxTOzlh1fE0L3I68hq3oUa+Uci6s41Eyh2LWkJK6bnHqTz7TY85wxyGJQdYiegCseqEMxZaSjlxsezJQg0FzVUrQrryrQKLyklORmxLDMt+9Ii2yWu6+5UhcaAguEwlfEwIAMCpNEvUT7QhaOP5ELEVmu6ky8rk9wWD6cD05fnWUdXuGTkYXyTq/8AsN7NvuWGre2QsGHd/DaLRNlLnGPKAM0bDucyRtYJRoMPh6w8YWeJt6VQR59RQFKfT12vTreLclpZoOnAl+gdcBYk4rLOHcLe0wJ/i/IDVvEADs5CgSy9xUtKoX6CfSHuU70yJkP+tuSkSYxKY3HwY2UozCV+mIBawoVJoCnaL9j5NO37wKQ7tpmDu15h7nEi5o9zfvrhG+eUbB73mNoEjw+1aLMpSemN4ejQBHNFUhCDtUXu/ZmexmJbVFDsBKwptPRAKT/eNSU026epCjRaEltVP0b2XiGZdPg+/VefAY128BC7uwsq0zQ8BmJJdliB+SS/XIxBNYobEF6tIcv7xTcB4dRVqR3RDiLVFbUFT9BbU0MIyqKjFiOxqM8s4icPwsFua7n83E5LTXXK9o7AB/dRLKkzR2yfC1OkOC31CYCOWIIglBvcBre+8bJwtoq6bCSju7NaME1tjHSJZdijI7LLRZqw02DqTRzSuNaTpB0d10Q2xZdOTvj7LkrlNGohKSa6V7rM1Zn6IlJ4X52dUt0Dph9XFSj/T7R6Dj8wL7P59BIr2mR6fp+5QK+g6IdWBEoQZJC0rcdF1g3N18Fk17mwL8JAMRIVcUsmJhB9UEaJU2Ay9SWG7qF4L1KloiqVQsKqiPaYdHQb04FG9Z0IjplDk1GqGimxFi9acJEAT+66+qYB7e433F5+x1yP5cgPoadmt/VHMu4omKrq9fldHF1BnbD8fHV1bzmGMWjx70JXA5ZMW/LE8ljvA7sUQSlsy6z4UEdzKPhosd6uzDvT+ef8gxkx/qi/xheEpyTpYQ/3fHcS4I6DAuJWHniBDTTqMpbOBDtNY/JaM7kW8mZ8GmewMvUvNXvWvUYJsUsK9rWqoKJXiwDbmlDlgGnUyzGOjGvDZWqu0ZFYDMhKI1BGeYMu69ljgdKDYRe0E1iaFzR3C5cmUTm4Hxx2cFaJQenkmgvutBFTT1OTnYWVkTSC4GfXbhPrleWwoWqC0Ybzk4K4n1wjQA05E6ABK/+gMExij0TOmUokBE3nVPLcavMBipG8BNbPt4DDsQWa0dj3mGcFt4i9hAcI1Ef0YUDsEbLPj35kvwsXIXMmmGWgg5jSuxMs5UUmRTA8u1jgOiHc1ywm/GiveM1JYJPcM3GZYgR5aopESwu4SYkqxqR1FDAHi6GnDpcw7sCSwhAL4zHzGW10MyOMBl8sWEJ835NtIcXGGBHBkSGCcQutDB+c+0j7xIeEOlXMEqkCb5P5GS5OIfUjPsCMYUMciy8uJZP5PKGbPiUU7AMYIJbo5L/QVsbJUQQmSAGC9nkZA0OC7DgwSRcbhuffhkidSWU+K6ah4ZjPqrqAkDkLQRrliuSs5Zi/zLI9PV7o6aejRwTunGeMPNs6YfNpLUqUjGZGg5gdR5mn4qI3CIzXGaswGKGAxARZGQGWUyNQSaAU86eUUEVvAxjUduMDPYF0BSYAQv+FulAYqwEx8MM5s3TpMRHV1sCLj8+1zDAR6yWo6icmzCWYl0wq40DWFuSQHH37yo46rkXYSPNEW5ExRDM25KDiYrVvcRxowio6DEqT4lYEiTz01aTioCpYGjklqCz0Nyb4XubTzc/o8XJAqXzLVNT1EFwCd4obFdprDcjNFRaeOCQ0fxIc0ntkEgRbX4GsUW5I4sFdd+jCjEajsQw3snM84xyKq7LMQGPOWSnhMTKhZ09rbwAhCYir02hqXgy+awnNJTLnHLPhw3/hVQdcFwGZM2TKJqg4epm3JFop2QoXTaQSxzysMUNkdtUOR5gBjcsrZaweLLfFZ+FvJmzrmjCszbFjIS42C6S2hUeqG7MyV/+RCGr4Rwg1o5K0ELjRTZHBLeWmPYDniNNjGNCM/Mo76E5UqFMSi/gG+mCOuBxcLVF/iho/4o0Cub8ly+AydpTbAKXoAAFIuWZkVMYR8LSxpYROYgOOtRftKHqg93yblNU+JcW/fmjtUZewAGrnMGv+8qnRrcRS7G5wMNsDvXA4d9KRG+L+kdttYtpU7Xl5uxultkr4rSKbqnESCUy6nFnnXV1BVpVPj+dr1zoIkoKR/1+gVLXFWekp0NA+ZXxZSX1h0yqS/Nxgap0RNpuZHKarj4VYAJg5GBScw3/lFwxd42zFs2CClfFrDUMlcgO4oIiJUgVcPeZozfJAOBHjzAkk98iiysWa8zWiYl2FhJHV2S3IqIaliyymhQ1TZIGlAd2shmAghHCw1yGx4IcSdWM2D1dIT0vbLmz9+5QdIu08t18PGKfPw4eTv8EfArna2lsxnn4qLf3v4DlJRGyuJQs0Xk2rpAkuHVYX3BBFy5FSMW45CXWhs807m3ube7bJ3h3Es7kcwFjVHLLA2ZKbBW3mDlaykGC3AgWZ29dxL11ToNGW29nPpBMdXdRI6fV8Hk7tGsWccNfCNYwjUNaVxdeE8YYPzD7MvyWCL/03kVDnfqWH6fP39A2s/OPHdLIZ4V/UMBZQAKaMRKyZRKxnXt8jrHQJFRaT4UnaDf7XiBiFlMs4aWwPxuObB5HZq2//s7R4/YwlI/Dq9Gn2JMYGv2gALW/Kc/tAhgbZryWibJsQN5I9xtwub/q1M0uGuLHy6luOiTY2+zouC/JTvlJOpz1ucvcnPgvpQXdAXLmSHc3RGlpU8zd7Z2ng+3Dwc5Rb/sIe2EeHIadLvePcp0utW/St4fbT578SmbxrXn+DoyAaVmwPwf3M+oRL80rd+EPovkH2U/gV7ElSQO7NGjKWW06cD457mMe1fWxW9mfjtrI1ouZrAl26NQuddiHk7rnILWNds3E5pXY6umKYOrSlpSei7V282LqOgqbT5HQ1r56Z6evri7OLl+cgyF4cfXji3cXZ2/fuOakmOu4yjVJ/eOKHryZLn7Ygzkl9otb+C0bNNu/b2/vCffvy5AGKiebNOELWHkcs7tSBLIYHQt9Jd7AyuZp1LMT9wRBqyABNie1cLSi1FtrGt7eQH6DIH6MgGPkFoHz1HKbQYRBjxE+8lAvzOzRZhpoWmnEX/Cl20h6L5WRAuhyyXIEA2KJAgrkDbHCb8cI6sfPYCAAk//wMrnuhDvbB7vSnXB3c2d78+CL2xPa2JMAn5lAAl0AMaoJOigp+nwt8lo9A4N0CYGF/wmbBf5T7/K1a8pEDZa4MhP5VrjoQixODSGmYpSp/Gmbr4REgbHABGSWqIeyA1dwXalBU8VrICF7qsyKhkbeTfIS2hZn9PwZfTZocgMvwP1zCG6KbOLqMzQlRlcyvbt6iK8iO7sZ8zKjDchYawl4SyrKjWzC1vatjUl32ZNz3+OOuY5A1jWMkgp8WUxHE+f4RarufolRdoCuF/OPTjjXNryrWxeIcsYOHUk1BVe17Io5JZM7uykJkfgFcUZf8pKJTUbT/HnUl6xs4e6MXTw112vxd/V1F39HgF3tSNv8Gr7O5OSWL3M60KvqKFUZCbSq6CfqU6bWlmlD4EvKukRnN4kOLv9dWdhWCplBcglP2od1M+Nu6QKSO/ajUIggNFLJFnYPDqjbYQdz3E3Qry0hd2BJIuAnhRIVE81fcWL7IfqAWolrrXzf9QiYVC351eWIpAJapX3PhOBiORvGCJfVBdl0yoIiv67rtI6x0wugqBwWWHea7D2uMcPl/QyLudTblqOwq8GvXzzXzCjaBXtUJwoCQXRIPLoAMYk6FEZsRjFqXi0Gg4tokU9TQniFBOnJSMsv7vbKQxsV2lEOr51f4Xm9Mqftqi0Q6PyH8s9/ytTYmYc+1YuynM+cgiI/n9c6eGD+BMVniEtBe9h2qBHyUTJmrpuyYMo3+ywGoOKB48X2kRb5S3ATtfwtO721QAXnFsrE6j8ooAuuqa1j5BaHuoBtifjpwHzVyMsXpFX/Pci42EyR3iSWn0KrjSTvkFniJ5Y5JzgBKbzVnUKHT6YoBdMAiqn3Cucs3VD6AauTSX36HSB93ma1SaDtpJRcHhY23I3JPbiEHoHBVJHe59ri6/rzBoy5mDo4+IrZh+2Mo4dIdBHDwpkoFHKvrFqb3FYcfUGALcdUhckK5agyWRcU12JvoilD9QUXv3mlwNxVNAfa6GMqPdU/z/VRDNpjnv16wRxS9TzTqgFf7nBNG+AG4WsEbtI2wZoQ+zwfdHNy5vunYDqAASLOgqNS1j//ScHX2QJMDEy5bn1B83HW8nfenVV0ke9jdMtl4qtqI7ypKccTnnV7O9bb9ec/rTqfHebWk5+Hy0dYQEjfxkLcYWnRPM+CXl03JQzX1xiu+2wa7vngZSeQPmpd6UKY87ty5bRyTQyk8W5FpFHZQtAAOOth+CYZEMh/fjViH+b6NXrDNh4guxk/M2h+Jo2mqKK+nkZsebj1iClzQU6CFBU5K/HJOphjSYwE/YVX4m59vw7s6QOyYYE8DqYZt3OnZ0XjsN0ONklriLDJSQ5PixNf12uIy84wWavZO4VJtsZ0VUwjczXh/W1d7z8hepsyp5urfM5Nb10YJyWtErwyAVnPm+pTMXy4OmV4UZ8WhpWU70ZHQRUux/e1tD2BXKbT+gI2cluL47LEtJIUBu/0NS3wCLW3S9RxZInvjBcNgcjYECdEnfmW493Yhmu2QHO/GJZ39RdSISeIB7blFBgm01BOLCTSEHywK9j3mfosUrjsrgfA3UQu83nF1GNki7WSeSYElov5twTf87XuFDXc4thWgLU8R6PwWVhHEJZaFmpLj8ECj5pChIglwtszSuC6ujXdVWOeiayWCrpjvjFohzbMeWptlYCxRCX4NCQXtimbCujWW86HUCVgpIInXqor8J1pNFQa+4Ztsnv6e3Pvy+mnCjQMvuEK+LvkeoNeLafnl5z5uSs8sdkKnqBOLBN9xxd64ViKD9XOWVla3EwVvIopNeeGFj4rzE4B6kFdXlgrF0NnSFMQdjUS5GiFwvjiZKM/shkmJnVeW1eCW0qF7G6ei2nu9yJo5xxnDjt4SNy2s+1yzowK/vrloRYy2VNGn8qXeEu1TInaenHZV6sN0qswhavru24P78AQsjup14sYpGBOAxTCj16/fxxHS9YQnfY5rjdDuJ+rzO2mzGFVOXCpujaHQo3IaWZNOXDWeqYyS0ClsBAzWQdxRyRwD8aQmKibM80WrXQURGhGSGUzsw2KHKHgdmL8ugYTcFg3nMcKn/G6GNniUmKJ4Ao0l73IVHIGx2OZXZG1Fc2ZJjaCdY5063y4pFd1xG8m8ejsVL/A1uDIl2DneOldFZkp33hEdz8oCHlMoV+BwjDiO0LidASAKGypzpsPCOpNirSOBF5MfII6zsEyT1iaiuhJ6+zMjeQGBi7bJr0MmB9Xvq9LTlpq9bp/qREUXUxDC1oEjFpYP2bRJ/Zv4D2j31nP70rviquVp/XxZvFO/UP+Wo/IOc9hZ9YW3CXq/JyjSbeXbqVM8H2S8Kg465G6h9ZcHqFFpRmzWEw9zfUxXtxqflMHWbWMA5ky3oaCN6tQZnrU1ATIX+/1DViE/KjJYDsy+4yn6uVV+LMkQ6ax/TBkgBd8dG2tOG+ZmGVq0bVFi1pB00Soi7ESgc65juqaZh6b6MgqQyowCggDbeD697Mrk3teNGMN89D0uhFkjSWAW75aoVxyyh1FzilWcUu4c0UNt6BySVApgfZN0SLGJyCS5LXiKNKSIOeSSnG269mWx7xMRcEw1+CObm3Q+bNrSPEbHPCRIfIpFbnRM4dqka6KIIkN2KNyRgVUtxKZCOCtxs3Uv9O+j66Pj8EOwYBFNioa1EYGXhrL2w0SYfe1K5VQJuoN7WxbBtWMHhTm6Bayz9W4sss3VWFt89PEG8OJvOcqKIPkyQ4OO0v0TPgIiZJ4FgevPUwvOxQNAXYR3muzd7Zsetx/Z0QsCapOCx3ujjg72Rwr4xWwFqoKvTijICUbN3UoTvBiVBlQTHYZfPVTzAhs30R42dyNNb3kJWD7KxeuzQkkg/TIYAos/MEZGuLdtgY/S3oSUTWk3wIBu+T88KkVpiWEHgq+xXnpLoWkNlpBH6eaByXty4wuYoilgYrwSXnV1DAysfIgVUtDdU3MbsdA00l9LRUCk/Jx7t7vLr33S2kybAhC+cw5iK0OZqp1Ko0k3NtKd4QskRmnyY/C2Gqr9IxQSj+/DqrhUEKAtTLlgtgPQfdX7siYUx+SAXO5mMV0zvXSXybfz6boGbRi6xbSjUuToEjGFQfGHwkJ+2e6+Jg/wn8/zol4ZfSSFEVT1Y1wJ3Sk+K5hb8osgn9+VwkI4MEjyaa6DLnjsvNFaqITv6+xLHuEfOELiTbTSNRaWwl8+YfzcN+dZalWlTYHdbhHDvvHbQVlYBDoimKupCS4nRPOEbdl+FHBjc6Sfv3WS6rA+O1agzB+5wQOUgwQYn+pru8aNGMaWsI1fZrUGIcl4dQ0Kioz7sA6PznuK17yLwM7P43Azk9WgJ2f7jqws53A3wjtvBzK+wtBneXZXRBn/fNKMPORTNbMcuCbMmUBzbhaeQxdDGpeNXge2LwNQ3zA2/mAmefhuKKcORZBVBz1AbUwLe/BetOISuDVoh+/wd+l4DisppNTlfzuuqSoHMrpLjiggJfvyvGs5dgAXcVWWlbJaAGRMIxMQ6K8RH5fTGhM0cIZC8EedSHXr4AQ2iA6QwIuSh58wjNtsOAOzKRbsnJEduAk/u1f/1fYz4C5mjezsOWDw/1dhS0/8do7TjNiSBD+h/t7VmKlSWj1t69fhTHtPJRgXUA0tZr0YIAHLoJjQYfMhFhi1MfauSuKN/bBIJq5ZnBtRH/DG9FEwu510aBDiuBItQN/++rs5Uta2NPLF8xzOeJusQj8pvYaSBzp7dC18NbPqX2rhJh7/TcESmarrM9bKrL58nXvedHeXdfUa6EaflzMsNaYDYbOapUoYAIyB10ksuSxDGhexnCyWOk58LlpzxDzVp2dFlMxTzA0rCwvhWmezn6SWmRi4jo6Vn4c/l+O1zlOPHSHBe9nA+0Pn6pvm7tRBi4BpLq6fQ7yKCo3s0JTsz/L9CNT++RlAnP9IPX1HUyG1swVNewc2E3I4T+WgLPdXrXzh7EE04WIRztuC492m0MxE3R5NWeyix0QRQG9UX1j5dHSsRXIE5XSrghPB8aoY2PXvqI3nieDoAB9pYb4Wc/qwnms7v7galjJ2WtKT4Tb+qLcpc290SZo8V8P6AxiMmIxmwsWQssPUoZl6uTgwNVIAsCNsOKibEeU7rIcGz40RzK0WMA/yX+hCunct13dAxNo2Wzdl0ezbWuTWplzSOpFzJU4ASI35wmjBd5ipYdGEImxjnEPK5pmZh+pXcCyZ9dcXS+B/9JpsIRghe6u1Kky5iL5E0ttV2HMZ6y1F62z0pw7L2DHOAbidp+4r1piPXbtrFlJKHPUuouxRGgsO+0W2Se90tAJ9xjogmCdpf+bC4eGR/MRvTWFy/mzjAYh2E2JNG6coRmD5Uc9PPxXH6+WdcTxcHJ+JmXNNKBqPlw7YtFg/m9PPY+HIW4OGBEJKTHbzbi490dAcK68hf1eO+MOXLSXy7djtHo7RPt1Mo7d69Gx6pBqsTTlwVxVLohi+iKFLxc0a3WBZrEFfBkIN7AvXStLLcy4YTwESQK/l9dqXZA5kk3USjzXKzyaASkehsi0vVsy96XcZGd7e3v1EXB7juyiadqDdGxT37AkKMZ5oWsyI0yxQPF87Kq6nr7Nq9OoQQos8rr0roVBR1nWcy72Xi42liESE3x5ChDx9OsSnyIZVFMH1+nACdA4ErF80GAwztg630c6WKVEIz8LmRh35AkORMm1NnQw7MJdeOUrLZ8QZS6H2PE9fflRMBfYUv1WXp67OIurVEeKrRquuYQ3uqhyVUJphsdunQOVcH+4qIjNllvYS7AauSHuQ3rXMoV5qd0Vw7q53o+GEmOeRIqFDEaCZTnBOkb4BtZyX6be+FFEgQTaQ1IlHPxxBp1wMaxhKsw5pC/9jVtf4dJGi/3nP907urGo0dlUOp2x3ZG9xF9UeyZw7bRxzTcEABmO4Vh/26+mWFU0wF/1v2ulowTcafzFd9wfCq8s0ntyae8Gnl5anMHSCskllQ2uW27HVcn1E2C3wmiU+HXNMWux2tjIXVfWSUtxXXK3h7rHSIiMc5TB0JIl0VVvh6ambL+fMQOk0C0nYRoEsBkvtM67/GJXRkMaQtjdNxK4HxilhuOIcLLGhuKzgJlD/sJxr39f8AvaY1A3/ezxXa+yzPEYs1UtfdC0EhYPJAd7MI+0styMKZJcx0QppBPuR4nDxZSQMclTJQXkqV9nnSC6y47QysHu/FzjlgoSVSqkXVm93Bqf2nP6Va+cFBVztjnTIEYg/mp63c6+Xu7xvcJGLsOywY7FjHzvMj9LpiJuNadOlUxVU2ZbFWRlJDHahI1sNQFTcCKOTzDGX8iQlUiC3SHLvIih1K4uFYs5AttvgmbhnjnOcNtkmmnipq7dhs49UmouWoWLOqCdFz6kQD8r3pyFz5SyJf7jObl/lBpvefI1bT9RROUZP8tV7La3HZHVlwxraKXzvZvakkm70NkV9gczLiaE4UXhxqh35zzR/JKtay62E6pa9K/HIDHmyzJtVTuXwzlGOBhzOQjqlEOd4ut8Aew01uiXHA9lv5XhYlUagIHt/lgmKkWB4Gnjb5cWZQyvFVQOd2etui8HobpmeKZWqV1MJkXjXsAenWfhC1iJLukBHxLiLDoXhhlcjyw8lxKdooFTDVc5SH9/pcVRt+voyuBMZMtMZNfUgLMnQHqPFDP1y5O1sFom1XzdHAu+wCFNzkj73IEmDDoik8gMpW1B+I1u4DhyHEszvEtka3pSXAthLrTpj8Bb76OgmNchta5YEHYEL5seGc+/sNhlw4b7OHMHDm0Rd8w+Z0s9g7egOK4vlIpM4Hc1Xr5RVYzr2/CI5pno0nLxtqT+TAnV4rWsGIaFHlF9I56muWAvr+F5/Ld/YtdxcP2gJJxcXaxx0/xKfEkNtev7bNxVbRb/qnhAa2CFR3FZNAjdEUkwqUdgAbFFwD2SmWSC1W52uutWRYdyfpl1JhLVF85LdE7hZCaPLYIP3b64ECA8/Sq5mcmOB/UEEFh56rdX4Tefx9XNzQAT5/DBP//JAXHI1/vzn6TVC+3/vLCJ04x9eoINhXAVFpRNZWM1jiTApRGT2gP2bHM8LpFNIgOK+/fl5cT9jBylY+ItU0iedcAQF86adnWgwu5F2NQ2INXGM7/cdCXCfCfXcNdmi+sxStJUxK1R+SIHHqF52CyEnDcy5dfUA77LU7fdJQ0dTMEZ4dV9/aDtnudaZxetNOns6DPZfy2YCO/utItrh+oAH1LdGGX5nd+bNQku4BrF8mkG7666vRvDf5y32a3/M9ZRTsFZkOuSevcbopWToKe9Lr03IG2QS1njBegY66wIWquxvLGd5QZZAwGqBKEk16QiB7N6tghAyt0XlJaFgEa6JNmQZpWg+7HdA9zc/Pn5AhKBVP9ElfzcYNF3Zkv3BeMJTXkLB3YsMBgt1hAsffYAfUmBf0ra4avSCYThjNN8dOfXxafigvtca8GXJUUlt3GmjbfOXph4fg5Ov24XMsfGPByjWCRgjIaFAg/NNJk97SLnZbtrl01B9jsV3Hn9II2pXXF+h1SRHtXs/iupmeVGyPiNNuQn3Ap8mqU+WYAhlE1yXqzCpL4ww3G4hsfnTDE0aa0qg199+Oni7MNP37ve54KgKdqwM0M9zUxnCS7274CpwD3tL2o3he+0ltf3AttAD80NRnFjcnEBrtAgBaUKtJZC1b4ern4+9kYn3hqTVuW7FidftT3qAbW2Tri4RxNDM/WuzOAa0XrlPBkGNkybvuRQH6RftRMp2/Uai7qmDmZUycyg4qzXFKpiLoAiJMM9KQvnUGXc6WzyWSpCg2FfFx+DjgH9EPWWUbMq1jtWtO9aUZj2j5hghm0NqacTNVyk5DPsZEr6LJy479lo7USX0+1z9mtWcoVx34SFBYiBBXzUjynsFdI9P0FfSJCP8kSKuBGy1YwKjhN4iB53AUMKzrArs3wTncsaloFKLzD8YqUTdbZ5gP1ra+a8viNiOQSD6r6TRsjZDrlSSyEfwWK9ppwgByyYjL9rLQ0j9ZduQNhQiwdRHbhmj357cfG492kxRnZf0lNV9BC72Ik6OtfSBkecIomPYuqtzlpIsgjoIJ93bMGGOknvXVoGxzO59HuaC2fYHsOUDVNYDt3vT0iIoXZ6IPH0dPZRLH4xNitWWGd/kcIK4qCyLAolYcAyOmFBWokTUJpCj+9/1hE6D0nopczt8rzHqeTWgC1Df9/MrrPvQP8CHMKPbxfz/633Av2o3jmRwpBDIvDucENaa7OEoh9WgGT/sADrDtdACGvoVXMewPISTh9meTAZTdfXgrJTD5Prepy7+A5DEl1BQQhzNOHKJQodv49p3FFNlzTkME4pOcFb6hIrSyvySCgz6cLxsSxmWl/M4TJejK4rlAujUO0pKQ9lJ+j0RHyrG9+1ZzgEc90E9TqaM61VIqbFHuasewAVJ0T7lIm4Esh3ahMddFidX0zcEoy5CmnfoTbZanzx5sezd2/fvH7x5hKhtkyVL13VtIZY65awEmUxVWgRLGkobevPDw6v4ltDU4VPP9KR6uIVnC0mP85xy/jslh71zG36W/KnODzf21k5jalU1YiRSLIkucR6U9D20gZAucdRlMeUXTkHKCwXodJ4+vrSNkD3cgtcNJGhJ1TgSyGyVhqLOsskaxOsnvb3TfEJF/VljSYfJ3KF7UHLFjTJ0QV4ZVijawgHU5bkdeb1M47dwZrJpuA6jKoW3RrsIqlMj64RyAw7zMh2erQGI7K1aDCLh7XhMi1Qlegn+ui+SRklFLIOy3UJtuNoAN8ctMNyiu3qlPJSABuhzcZTElmHd1xAYXoOc5ZJBNyUPD3jkogUx6x3p+0VxCC4EpfKBEfl64r8VI0HoGDxsV+ZHtefY/QX5hxJ48tMBIhyD8ROd98T8ziqh82sJh1tnxlsMSNGkhy8jrPnaOqNYBsoZD6i8sxUy/6GQOsZNWtsdCyuu3dVCWS5GSbMvAcUmuiumXDs27gQHQXkllr/yRztZuG4bP0EeBB3wTL+VCsGrCj2CXIlEG6gQnQHuFtl+XFMxIRVu+HPAMWT9fxZRGHRfowp5RK2wwgu6LbnS41gG9nC0JHPZ2hzZY6jhWEBrQJQDChDJX77+tXg3flpTnRlrlaJsQ3TEuO6ZPYEEbbGO6zmsVrhFNxKiKTg0umqTSpLWG/K9cJyXTw9rlLE+7g60sUDeISfw/g50d8xrYuEQbUtCUqcL0qvwOe5jGYUZVqwAggz4/AZriulKGbTFA/cOWSl7kkVR3KEWJNk8dOdLsOzxRgOMVg3cIYv1GhgX2E9o4E45+eTK9z6gHN+eNPnztLG3NeG1eXU8PkWNu+24kiQC4Z71XKuwdZKMY50g7sl3rCZtoG/FaQnP0TRAomAaaVqp6OXcNAyPjnJFmDJoBQStfSmjkZD+C7ZM+kiWorhRXR6FN5D/vU0JLvjEJp5jBI7uWQwl0UI1rydY37F4B3zc4i8A+/q8NtZfAzm7V87uJXt95HaL/trcjv+DEIUt0ZK3tdDfuDF7VIcehJHsuwokncddlQGUxeHGTwUpfBkgk1p5yUC5En8MTdMNoli9teuo78nBVGnsx3WbR4u4arqqB7IdmeTUumfRVjwtLezd7z95Phg9wu7sz3dN4QF7vl/I76C1VX6f2ecBbsyYTpjq/uvwXjcIvnSfjJkKlgyZJakYGdvB7uvIV9c0OSMLz0eQn8nv5em93mW2s3eT/WCopRS4avxmon0+QbxJNKUs81wFTwqJFf3f7S9s61l/z4G0V18nO/Qw24jm0Vsx/hCcIX3CrE7cyRQiQWyTYklRIS6zj9xvaOEui3rzK2bFwuVghfGsmaRQUki+eLH73sclF3lRi6Psd4xQJzQ8F+1rhxd9GdyzrqaAuynZAzMjWCyIoU5LvRmjHzn+naK9SUpeR18Peyo126WP962Reb3WczA+xx1U/uG+jFodDJjcist+OYO1GZo1BkkqbOvsZZz/7dFYRpWBWtCujbsdu99BaNSpxKSSbvY3xRD/DK6n0K6RNkXtgFDHwMDqr5/SGat9tZFHL6DwzX0DixxCPHMPf0DvCH2cUvAHsta3nZD+wlCLcLMtU4TqWBSpZgHQDsVGz661CWJHFTm6LgGFZfBu38JxtBAN40Z1Qk55k1M91ZiRGygYAKhi8uJk294CN6/e9XJg8pBDYkAZt/x5wET2U3i5zsqMSMa40jtvJQqXXNH5/GR9jyvPDBY1ou43EY9LSIpM+IKCR7GVSuWu1+cYTFL8zvSVAyOPprZvWYhxFlmQhwiQ6ghwu8o8io0+kxstxFGKaOqcd3Rsts9xSliXS0VF5ntIkshu1MRgq2L9SxMP4TixItTrUDB2Vcj8tk53IoUu9Qi221UsgFOO9EmYPA42U9UYzn4hH4z+yUSaXHURq0Xjoy7g5VPK2HWj71dGb32/pqwjg3Be/lormb/AtMvyWQ0FJ/diU4OkCQFI3gGZi8nAKFp15QJ5SmPcAqIWyGEJFHe9+NfYci8T3vZvy3nVy01qb1ylAR9lwxj2UH8O4K7qLjFa/bl124zU8ASMo2ev/NB4wIXaMYkj7VKJNY5kjusZ9VtpVVj5SjkkM/H7FheWRnNFXN6GAI7i/vWBgQF175TseN3NQlC8gnlTZef0Ihzmj1oOQhmnQQb4jrKMpOFpVb5TxlLy90qxwXoMVsZWkYivgkZKVZdq1hQqQFZJz0zgzOzbmFUDEz76hS1PPUB1i5kPv2METE82LRRV+JXPHr8VR6oxpuUm9zfI2puf3uv138Dg5ws5uCzYqSz33tBj/WcSc4a5q3AMzrkZ9Dz93N9g/bWzmylHaZBVTGCDEskxQUi5i/B3PHR7cghXmBGQ8Ts3WJyPcXUQRLYlQ+QuKxyKbFIkVN8z6t707Rbw/ICXiDZa4+vF5Qx2QEH8m0s0FnhKHi4C0g5kVi8y+YNinbgxw8H1XQMJk08H1nS+jCjbt+Vo1LKT414uH5wZHc0Jo2WylU3HV0dhKU5sXX9IGGFyB3MQr6zSRW35xkz94Upd5YAYS4N9f/M/eQ14TEuyKlg6dsR/kx3ZnhX162mTcUcZoLH9s6xOUSm0JemrFD7arh4RT2KY07GIhEMsMzLqU8+jJE+UQiTA7njUAk0d+Y4IKnWwR9SdHWz9OEtDWp9qsr7jOH/fgpvdHs3N5bsV9JC76S5JcauF/qXr4IWkQ54IweraJc4LIn9IMfF9y8xHa8eCDDO4WhWhxgWhuPvT40RwLtfFJr/q71vbmLrwYqStfEdSDFwRaI7WR08V5Qf9FRetKS5aUTszksqdQLbF7tZzzBcPB0+KB03CExL3r+BqyAp/0nZcGsymFVqG61fj5JbnG7kIJ+jV0SJ+tA7aduKoFJ9LdXiW9gBMCMg1AkYRK4zRV+eHAfQfK/qYkIl0FjU0dk8WMOcE7MjabBBIftuWs44JcfCc52hIOyj+Oct7ofc5MFWb6/a6qR96SkaYNishfVRNpS0lEaexnov9hel8t2xqcp2Q7SA7uDY5GAxTKRoGzpbA7LoKO1HmYvMpdrZ3N1fy23vTHu7Rr8Tp7EYRdbcFtMKdMjkQbZQeIAnYIPeDeiDD2XRDK6JAl7q7PomcwWGNKfjre1/Uc5DFIKlf3MXnVwHd5Wzry1SbvbdN9f60tfffbM1S0IV2XysNskA7fSpuuWpRO5zjN2jJxkq2M4HnoyKmcKN2J4dgyqcyzkQb1B8OtOQbjqyfTnUX7t6/eL52cnVs5PL0x+uXp29Prv0+Ef0irgfApo0sGSdTeg3d306hX7cMVF8v0iRDRO5yZ4V6mZc3Pb6z3WD4g+GAHQ4E1jlCTZm7bvZWFkmbxM9nI9jwDdEwoCreUx2P3zPbfee+RsR5JHM+fBSR+oWFCQQStS2DKrVgmfvPKXBKbXUlEgKXWpArmVJgBYTITk3ekJXVRZTDAVMo5I+23wej9dFyQvv8mWbk5H2KmEribN5fAs3PGPqAqS5glf5y8y5HaaPDzB9fPBzksf7g9293vYTZLvfj9nuD5Ymj4/2j2zy+OBvmjpemjb9O8saw7rf1/VQaLYGljM+mzfegxEtL9c37ayYfme77MBlwF/FueSlD8pT3h9uw8NAMtKZ/9V/frK7c/g1viz98+hrPZaT4iMCTOa+WA+Trospnc+HkAYfadtk5tJDmayCb4reXVPefOuPVN2MkH6jpXMlpZ9b5gW2+t+ZZfhmq/iO7lkwkDmafbyz3/anNdwh8KbgyyB98VubKOP/AS/5v4ATYmIa+9+RGPmHMCCPAaUMLVrbe9RSLdMGSOmmwqDYBtc5Y/G0nltuhUIjvijah0BTemgDA99l3I2Ym8A7EX6wfynLmelE44SdhdbQ+USqCkmj+W9fUCsCQbCgcymtDdgyoeYClfa9CQg0/8Hlh/ETnyj38sBdAhQDhA8k8gfKuupakaER9qDjRZlyl23NqCCJ7xR73dsV504mXAaqQHpGAg4rN9gW7Rzs4WnaMMYO9gJ2ZtqyR0M7PoMXmlC+htgD0weDBddq+a9+dzP4XNDxCrvL0y2ITUIumm/MKBtSvwjfPOZDqccvvR0qcJVnms6QvR4DP+4g8Ce2TPhlYL9wXde4S+2gS0pspXfIvPUz+TreKb+jf5OZE3JjgAnCQXtXzWbx39d/iUvKZL2jHgwy0r/D+wQkFT/zTS7sGP8O7yB3fSCuzc98C22hfKIO0r/H2RLUWfPzz5Qi2M38WUDNvnvF14ZkPhe1+in66CWbbCSRYzmCeuyfe86CVPqUX3RxkvdTm9O+Z27eucmGSvc9FWycIZHsYjgPBPFLqnwtZxhppv+tzKd6tY93oIkdNdu5q2cbYJ6QkX5bE3SmwzCI1kOoPPD8/g6cgcDk+IJND3QA7D6ZZWCiCO5qxpqGY37oII3xs2jYE9qKq/lQp0sVA+J+OK2oNeWIJApC9PydWppskwsilT/MT2iCj7A6whhtGV4YicqxGiLUEqX6gEAKjlPwAdVyVPcel3cI6EZfqJoy/xAOIvaitk5Xm5GsCiy2dmbNBhdChMYNnyFE3YDCdU/S/kvEtkgAv41V2wsXazFpt+b1rBrCbb4Nbci199AkMBaT8Ag/F5/Hn1yyl03ZU+eoSO3ZplbJr27nX/f2ONnGL45gTMJcFuO25rf/YksXg1O3JW2hC0pl0roaIupIRjCqpt0waX8s0nQntWsfZuDY38F1TNc8WJHT1xdyUQjJ4Ff5dTWtJouJL9eiKi4lQJVZuR3oXHEpS3DdM3kShJbSgXHDDLFqxV0H6ykbxdpmqIxsNE6vRa8iTYjo7O987VKq/guZ9bdf2EX8XPCFjl3xXziMFMwHscIFfkAJ8bsSxKIY2RtLTiceOCmiL7xbx3uSg/g+3T5Cfxi3a99xZhkvCtb7xSdaxtNiXCKTxbEWl/ectLkR1N38algrfTW/P4EwxLBAogS0yRH6QWJUzxf6KrBf10G/Bslf0Xc06ay9sN2Dcb+VBQQ+PvzoH30ZJAptEkeay1Y3Hl6C4A4XGFpMxsVCnClf+yHvYOtivqcG31jH9hwDs3f+4ef0pgR9WczrwbAYD5VuK8IlBsk6eVl88KieividC1iG/micOFrC3y+q4UfGEasT66ZKv1DY8rAxNZdwP86eGyeOA+2YVr4fYtGRLt2V2uZXExBC9eiqml4pcwNH5ewri6dIQAj6I5d9acmXWzmG7jI9Ze/9DJZi3G6dMpEH/rvHwFF6B1P87B/FjN14wzeZX55Z6DDhxEeMwRbSkEXnRbS2lKMT6f327bMXtiKLxsY+nDFjIlVEUYKGiDXxBamVa+tehYPIuGG721+/gXV8i9Bc+hluOBdlI/kOueb+YT/qDtlGznpGCbSqpoZonL3t7X+y+2rCDn5UmcYPGIR2fR90Li6zlDSnMJwdxhnfd6RiXiicCZnWsEDHWrcqgPAxVUrAQoGRAU4byRcMJao0wRBC9rjMR2PTUmhsbpNye2hhJCHipHcEvSCteDyI4xBE3rzynrHUpGR98L9CHKj7wLi8IdijnuV6WoaDyprDTb2S17vSsXTlgx5CYZco/fr5+0v9NF+48CFwzGZ1JR2qXj/0TobMdmzwQULMLfKEuLldli4cjMTllSR7Im4UOlexPFEQAX7Phr7MbR2DEhgHjykzzHh6bSyoRL1G7EabKE2lP2UG3nFNlou/BfEDTUfqUdVyM+UR9SgR8cAc6WThK2UqzGFLkxoMq3fMM+kRcjWo6PrR3TayDTGGSihiRpIdfjvt/VCP3W2EM6hbzyE++Jb8LVlGWaFbgUv4ZLv0IRk54DstIGdrghSOywMqBjD/VjqlC3SswX95WbozzOvnTgfjekzYwsuueGj/edKKn2DV6HAhVp2hjl7aBuIlrPRcT/3i+WZ6C70y2uK73WIiWNvH1WbGttJoqaAfpoYEABSQEw0seq5rwmyEsjgQoopy8GKUuPIylyN2Lfbg2/81O+Q6A6qOYqMnURb4Hakq5aW+uh9esQQFY24x9y3qXSfC8MvjuqaipdhS8n2vPfivLbNLk12Y6LgLpoVUJWtn/QSv1ykt03b0YtzqLI0QKjoYfydGl2oVqSfIGJu5BwXvsZ15D36QG4OSjEZbcRE/kvmjkAhlEooyFCD+nYSYqfdfr4xHfIU8eWig+XJuWqf/6v8Qrkq0pHRlhdZrwfVnBmitpnt8JcBAXeCyumVz4i4QtHj03FsJTgksOq+bGUg8Ugc3PvfRhmauC1obmifhDAMzCLOe0sO4YhgKTd3BQWZVmplJfOgZP+PpSntx01n3WbhFs9qrojCBbjRExlS5z7hPfHhc42PhWVUbrGbLdPXQk4dBYc0Hb1sEh98rNq1AcwRNoiW0049BmzlrM70kB8klQQpLGQqh3QgupDOLlCyqdojtwLdl+OAPv3tz/Hjs0DjgOJUq0XmFTa5dpx0e8nPvuqk/Inlb3qKI2BhtDyPaSuwp9+uaqI4V5K1FilUraLhwwBtwELQoVtD2IgoKUxF1X42QgB71lMwgvoXU1hIfH5So0o5/OEUgnKyNtaVAGC4R/nKsOKE+Z7LFVGGUI3cy8URayWlHMYcSXUs+j0TsMITlTiwETWYxSzJ/lC+V+8tYjnYijdT9B3+48FR4gXEUdaML2ydVyQsGDQRYd8bAXPPpeTbYgMYsbM9WhphRmvJNpxwFsGHhUV5JRzV+eXtS6L8W1xgId3oG6QXz5ugSq1N5OGGKeJf+96uLFxcXZ2/fOL8gFL2pgjDdyqgV3Hdv6Ifj3lssp/Gj+ND2rGiFMZu6dpTURp2+6ke2hEQG/ckdU9EwnUjQ0eQxbJjQ9ZNiRm0GKcTbqSZGaLQGVLj11EDWIpLnwDKZYmkhnjJ/Mqh+P4oxRDqjmNIBoUhdZIHI1lGkhvP+V/oBPQZxbMYd6R7TY6MX+rHUXuxcn+S0tARPys/ydDSSzApZvejjFxf3xOLIZvX5XT2v2wgTG2Q+cogIFrXhCgo0n5QSes0ZAMKJCwZFmIGfKoS4CJ2RE4XFdYI32Mca+qwRqo2M0IrxhehdNv5+YpBbRaUzAOFIUpqvtOssg732bsf1Nda60Sci19/XHyXusfHFfzWeUwR6czsbU1X9RENQ4RDsyh6jcu3TEIFRE6muM+Zdhy8SIq2978ESZJYRtwcxvLWUN/Me4WnUNY3UY1xxlU5nxRdy634SrapCyJVLwqnNLcc3j9faFdK7+GaAlaXif0J6YsgLUeZYUILhZJevQYtm4MJulZFfWii5n+5A0kjreoF0yj52BrMrxm0kNphCaIi5HbMaGiD3nF2EcuTPRW2cVJIk7q8hp2oKSjeQlVAI4VHgq+ma5c5HxvxT3Lrxr9u2HiLpT+/ZyelFTwzVVhMDEXBIXp4NpbD0hyIA80YaEKEq8d+h+OiSCCCGzDYwnDJn8gGqs7dfSNQ0Y8zZ9npV39bpYXNiCOOcp/V4MZkae00MI8WX58UawZBPsyPFsWz2VO6vONQndQErDKPYeWHx6VUX6zRqo01k6wheo4iO8IFGZlZUIVXaGLMxbJTtiQ3KZiF0GytwPiZ4lD23Vifbcii2XpEPgqLs8ZRvfCqIeeTI6m8q5d0S3Bu3EqHwh61oivyMwlPuOXA2EdvHNyyEw3s34PzdWy+FqcuAJ+EGjWighlFxeWkbLZoH/Ra7NxFxp88wuRf+lMtItMlmRFClKIrYVQvzEmZFkT0svotEl/mYS4aJwnRnj7t3RkXVXAmRUktEzHeBMmrEECKkPGYWlRcElMwivgbiS7LrGVt6kgyLbCT+Csl2J/iFzQDECuPWcSRK3YKJIuZdlfeNXLTh179fUHvkmtAYHAoSsSbFCtK/Np385yhoq4srxuQ1YqhdlBfs+UF9M2CPKinY5XMujLRxak4FHb7HfdHEh0H5B2gZqb1DlHlIboXbfARFmwL88T2ahRKKeAG3OQgAS965oJYwDucYTYZSh8kDA9VLPXgUGNsjKH8IOjB34hGiPw4ep7eBmnN4/6toPeTLJRn4TybbueGpdUelJG8tMYAvFWO/d25En+oGkQ0P3EFCl8zLfkZkIRlGhueXk9CO3Zd48PhIm7bHMJZ2SYj1MV20uJSfs1pcRvP+3aurl3wejo9ZcV+xBXyF8Z7WWLtk1qbhwETWcDKYdBKesPuhFyKpTY3TIZ9HFp+DASj54reWj3GgOLa4gvSPVnmkO20oRM0EvGXrzMvwjRQk4gEFDXIMiOxjumawTJCXEhl3UqdPa/gSRR405ettEQtMXA7pXvOFplGE38s34djf3g8TNsmFGmKxKv5DqlfN7Qf/FZtkWfGxtOGwsl5MQPNKpogQlCjQdRKEuUt3uqLQQpznhHMvmDeQefUN3SVFvRlfBSfrOEky+e7oUEg8kQmF6BRnUxAGncAQdT6+1snnJoxkD17XzVwFNBpI/pGn0da2Ilo5xDSTrpWjypnEwTWnGJH4/JTrEWoxzubEmsSSAiBOzMeNLeip97JoEf/aO6UK1PyRvpGUoyg/pyila1T8ZMvBXc7XgQeJTWSMZcQkv7W7JRa7xowkOESndMnzMf2nzy8eGGJHgq31vIqRQWp8ICUZi33kuAmjyyJb3mQnaURik+ywQcpiGieNnjEjXE5S4mxfwQgXs5IKbXGzCGYXWofK7R7MCMT3EifR0DWT8sGbipeI0lQE/o8yMo2LhLRI0LqglOWYOdW5XQHaSqmZj+mDdV8t4x+Fs9aGZRifE4RoiIBYkhvxlBrSajRg3ohoY6MDcRgdCLWiiPCGY6HN1aIZUzH7nOvZe0S90FB5cvxKL60JY9gb9FZvKMZGq88NRZXP7IzqMOichIi1K5S/w8o0T4lVp6mwVwwTtXHZLTziENbrtponchrVCc87srS94qKuxp/KbBIAnqQVvT6dJzRgd6gdZqI2ULCOhg34sZlw4F4Cg+TYZDuPfVt3MNR4SGEDDtoUROyYHJ6aaWZUAzk6MZqwag0yTEbFQHpV6Ib9hsCAiJZRRQG+bCaRTU1Wojh2agd3EHcUTmdRH9IUjpM4nN7rEPbALpP/VX3PED7XTkuUs812o7K/whzzFdp5qqwpQ4jLKUuRq0gBp5UWVhfHwePp0COuew3okkU7mWwUy4Dr6tbQL3QEuXHfk4Al2dXkXoD8nYKt+zQOjHseM5zsEFSv77eH0XHvxA4JUis404+VL0AIJ8GOg632FzyuSngigfFgvaz3EXUBETtCBqUCmcSQyG3NM45uRiejVYHs0qQDl7GL4qFLcnPwPJ+oaOW+dTYxtXQ4bnCKO6Dsd3GCIUhzOKdxpr8F/QZ/NuNNFvOxrcvwlqtL62PpYuxHq/QAtwk1PEeZuLFVc+tfmwNxnHWJcyOBQNvPmhx0Ao9BO07Z3QFPc4xxTnvf7mdXCJy6qqazRSIlTIDa74yWR3mMhyKB3GciE8VtlIvaP3+A2w0rqaIv7Y/unFs2HVIcWSaU4JSchcWx9eROHk5PAtkRYFJjQ9pAAF1X/DQYmMb2HnJhEFVAfVxEIWpnYbhSGcn0cduCcO3gTMegNvW6xmTTpXYRlajO6OJJjBb7R8KhnRTjOFxOfpnw4lKDuJbzkvRhWMxZ0RCdLiVVKVCVWl/OX0vyFYUsou/KpfqipGDWhs8jUONr5PmmhEIuLFgROudecQlpOtBBPQq8z0k617eQiPrvyhkdVfxd168YZiplzNRtAi9AdBgmREZs5AajG26sZbHqULokMJnGArTzgsHrTRNfHuXgNkr3YcxiKkrz5GMC6DDaS8tpHrgbHQMYN4hSME2GZK7qae6qSlrIiNYBFUb5y4LJ/XpcBlH/fHHHMtfTxiPtXNjx5ZrLKe9qMvd5DUfV8GdX0mvNWDXWuVyZZAgalFj4xb1WvtEC7zUjqrp6kE8FTZQ6XBN3Eipk/PPY5YxNR8/wPkhDqXtuHqv+cTEu4yKS7FFWWzaJcEocNY1TB6omrhYQa8M8hZ1yF5VlFhtObQypxYqeP+vIZ63fOAMoEmi0kBbPQkcrtPMckYl1dochEIYNakEMk6x23dyoy2TeKbQyktp74ooFeofDQ6aCQ8xjfExWASlSK++EisFn64boTGCqAAOhKTCRMVxB7DIID7owsgZGcx6XrLCzsbmq5wNj1+iwUpjIh6sR0oZ6ANULWEupGZDE3xt96QgU7txabjgfBOfTOHFomuH379DWq4QCcQkfBR7qFB+CJvjQBTU1ui5tZkhgrUytv5bYrMc2x/m7FH0bzip71dw1sGA877ahOtCA6bK81wsDfkkRfQweAGce7omE5/fT8HwYW/GHPEQdR0zyfpCLD+5gsb3fBpAc7TiZQxrsJRv2QgmTMdd+pUm3qwuJO15dlpPZmKRlx+heytimBG8ctJFt3QiCNx1RTo4Cvvhx9S8U6M+XMESvvkwY+AyeQRsgxGk5t8GbucXIwy5MTNNraGdkXeekGdXHsQAM6VJTScYSMwSHZLJEOea7wgQrpr2L4gZMofz3NDeQGqBu+xhc4RjuO6gfTUTLpdLxQc1mVSNgLokHU1aVz4DLPTgXwVoUlLlE4n/RYRaVkCqyH+MyTsW0kJTLYXZ8TNikQ0JZ/TpwEjz8UJIEvqDOx5VCp85mytJE4zO5nBral9pOFx1jCKqDDXOawQ9zaY5xlPx3Xh6VsqHv0BpUcmvArbz1GD9kvFSN8RhSFg7c4NiWGM1hJpCJwem7hNVv3sKiMLMrfyRskFbLapqznub24q8jMGIDyx0+jvKAe2stkpuFwIwwqIkf0LfF44CRMJH2s7LxnZpuNPF4V9qY3hIfpzvU04pj4Cuw/WvaSOkjaYgSQGwwHLNlK2aVc/FxKvpAcefKcjJmn6wvNzPf6USnBLfazMrdQoz7SwpAAH4pPCJAl5cdKYP4yznqpuNe6BwFKFuNJsS5Z5deEINSow0RTKtn5pfzOmOJGEE9YIDF1Je4Bm4a4n8yE2ILjyUAyWqPLeBJspskBm4bNRlM/YBgw0zZNEctTfgFM3rECF7JlQVreqmnrW2Y87uTpvWPUZf0nou/LwgKgk+YI+Q4K/QDKv3yTwlAWPyAi+p2iiWbN2VpCqVpKHGsQj1lhTDuCSjHGotNQGLygKds5pE179M8FC5iE46tJyXDXmbtXlTYEog6JLyFOU+qP5QNPySEviUZ4QTWkyniTQ1UTYQa2jk3cpiK67haPZ7cM++Xhiu6LC6QYMZqmAlnLbRCpSPO5euw3OUzld5wFjGNNeuUslEwhl/hrfQJQwsJoQNk2qVn6x1YX5/goLdVR8Yeb4lapBxpyRc+5KTw087ayN/PH9y1cz0SSE078A5CkZJ+h5EfL5YbIRWxRnPPR3j8qF2K6rnN9hIgBrFjrXp1nseANsVVvi3J+GqSaXhXt1FgX1S1a+CCFCGTAp3TfICp9I5L712J4pQjtT7uhKEdu6lV2RpLjhz7TPFEsD9PlhVAxECsp9kRou//WLVoMj4rPiJokUVigkPgc+/sxtoZZ21Q+5Eycih3hHByhPzpS6xpTqJgdz4btHfPwnUyikIAMWHFYzF1hTYWqwPziHHEvswd4+jClUtgnOh9XP2WQPUtnWhqbjPgB+Wnsz4DXFRHtU6gL8T+kgTrS1Cu+M+97a83HVOszToHTB4KRkmP6/eugmWAiWXLAqOGvO61yxmiubnUivxvDGcg//2/d8OQ5Y3elcLFeK1g9TomR0vEv+FhiQVBmwLm2UxUt0BFB0jaMR+VucY0EJ3HMNkY937mYAFuXVjAp+uwxmYalEFTasDMh7mXhdZfqwLFI847/mjXqLTHsqqpfs3XqqNDQX4luSDV0AGVbqqmNSYEx8mMBRWIkqOOMqLQyQ+qsqivEnwzLQAShyP7nC7O4KCME9XPGsXOzLlnb66sHYa5CLGzntP0RiqDFZnBOgeONZpgqCSNCarygoIb5nQokR0+/9seNSAJhydTA9HGvGvSfIzotLiGSBJGhfTwM6jWR/w/cC3Kx8HZdK6dnhIfU8rzyawvArovvYoTXmlj/soFVEnrTl7wUCMCwM80AYiyGYzrW8xZOwaRDgSEY9JuykFT3lYtledzlyEJOXDAqWj1FNmKGOQFbAU3kQCs1F8wh7GDmUe7gAaCKjQBjJ2WDJBQtslM5e+OPAp93qCbbMTU1W2Yvnjf+/Hk0m0X/rvVDEH5mZpyMuJ8QQd6mXFthxXXBN8vyDGagiUyox0YrGr5Vm05OJiJeJNfChZ/AfK0wwZGyT3FHi6+IBfRo3gxY3+291NxV9eu4ptzzc4icFi56xJjmCUeIYR9Ek8E03IaDXWBrqJHw+Bjn4UIGPZpXawLSxCdtL6vqZEgSWUBzqAvEpYzeWqpyUMv4IYIIpCEDEL+LA8ADWRqjGXs4NUNONJhg00pkiKWzYGd+7JdM9nQ3PJhZDAAJpUgG3u/q68ZYlPn0mZt7799OCf6BpnXfzdOHLm0Aeg1hPtucNuyKXcDF24lakrsFPL4QeUGBWHWkWjaOCLEcHrRk88yvpQSny4QTRDvDCjSQ3GKYjQwCgKZGtRFRA70crPMLWPA3dg45uxrb15gJM44+gbkb6IV5Myy36NyT90z/Jlqosk1wvBmCOYWc4F0qXBIBd5BUiphbBrqAzIjerop6Is/+MpC/3GqP+F4CNW1DvVoaDFIfiMCHs+0aFLWUXOGAvp/SfWMlIdeHnYVOm4nx0449oxC25adqyXANgvCjap6IX4Qw4rg5VzsNaofsKfRyGJTUxgofJswYqkUYx7bGcraT+UUKy2JvMEZQfBF0Bk5ARRjdzkWo0hSZE24q0aCI4Xzg30+qAO3+j0StcE6Awmq3hGTIj6VPm+iXPxNkz/icKLAIM+V3xRtpd4jzMQrrsEXoz6G280hURJV5piY65XNGbSc4F9MbRZOcwdkgVggStRhjFjgNH5BIDEyNVJnU0MzHCaVFvcEKWKPI6S+S7NSX+CMnttbiB1lQMDDAhMkB8znUPga3SgBA4rwmDQKwzaLqD+6mqOSBIlj49Q87pqbx/lQhJ5b017TIqG54ytmGROc/zgEwNyOcX2cYxqXj6Dcx/cO5BGD41xyCUORHRlpwnSRNRH6Shg7smtPnOMvPlNkvunAHrEIBgt4tpjbILVv4BFUHjuY31rlwBzMel0SevWumtnUliuJaoxIe0+HnEmYfGKUxTIJBoZHU24Qlb1isyXdH8MwEbXi+KRTFiMX9OAjnqPSsAAm8r5Oe89LCvon6/m6+MwrjiV2bGKmqRI0IiMdp9dB4t1oG4p1rInF3MQUpEVELDnui0BYxrhgxg3au2K2WTvh+b0WGAIVIhG367z43OMq5SRBcpGIhi1nCzSpd2u3FKYzMklh7n0r5Eb6xfjYcUF0J7yLaBRS/+QNo2ZdY4Rs7qEjqiJydjYbP/A9Rd63TIGxO3y4pYLoFdRQcMGcd6fGSpEapJRk8lXRnNGVEFRqNXmmge6FyWcZuR7gAR1iCehgXbOze1kbs4PgVYADI+CLclGkcTQvfIlY1KuWmtp5lWaNad82di3TqYvTeDdBKZ5kcGdqUI5KCybBOHiyUsEMBATm249Hz45hW6+9v/XMUp3xQXexaUeD1k2G9F7DYQkZuClqFi45hy0NylzNYKdxIi4pC2TmBQN1mQkS8T/j9cdeYKUPnGQKBoukw7q7Fx75Z3RP54qHXRIu4O6WBi906VtbaF9EH+TWUBXxghSZcG8xRGryFWW/HwJAYmE/tRGsUMAeRBACfFlTdAKr58Av6szPjFHSyjXJvh6LQ+RRw2ZszqKFeyo1QilulDzpUhi6XfmdHz2MBG39F/kH2M/z/+JpgWX7XUPY8KTE5r7nhnXhb5gy9zzPEQLfaDwKmyOzOvqDoTTn+FoErULcWNqpgZtOmH07jSzRUC5Ga3E2d0fE9s2TfuIhbNzB+bN1yYVrzrctq7TyKRn2NDpBrSLYTZSQ0FI6SA6xkd7tdv6AzrSLJOLdVgHIt49KRQpT0LEkU3/plgOrIpjcgnBOOCmVCklWz1kTvhGNoSfEo8wsKlwfPa6wla0GR6gNZRaSnmJ3s6RTpqrcbBTXsNG900THJ27d7gjdY7cXfd5MQ10nx4V7WK3XabdYc9fFaQNrHTJ/qI386n452F6RlTv4AunkNbIQsKsy1hSfoW+/nLswSdDoiirnvXTZTcv+5wK/NdFvBcsrRMmuEy8fz2dchwgsqjj3VBwhL7W5A0zMyzEflUMIiIOVpXXSuOcSvGUG34cqjVZAFg5DKVM9peyF+8pNCVjpESPyXjFebV2JDIeqwpikoc3yiGlWkEAMiXQlSXvFAZ3HkVJ1cHpXJqMz/HAuk2wry5ZmgUAcHAq9NYwLZWxd9nqvF1JvBBOEc22yMbrr8LYjry/IrggiqEggK60wIshuF/ZMOnnmKQNLw7fFB8hrTZ/xCZiaLUXspRq2jKmJVKuRHkOiNuUCq5LB+FxbLYG18YM7ZM6/BxfKHKY6Kjq/t31hcFyaZAyulBgyGGGBFRr45NboH0mk2NAwxOkiPiS2vCTM2uXD0nRs2CoR0S2R+zoqP+nEW3I0l0FmZk4U8vTJE6Row2IGahdVNPDWcJ06t5wvNFJuVnD8P1UjDndHCVUfHzMLoLwbBp8UTr1bqyi2QHAFMclER78NCivZJFudVMxE0F8p3RQgExqRTT3OP85ygeViJAxvN9XTJNEmWEsVDOai3VUTtLJBoSOko8bzO1XSYI5eS3uPmCnsc/ya9rx62RgSwSDbl9yB8+TiI1eIweRlyAWCZIjr5EJjJ2ZaFN36OvKjyf1vgzrHQKIVQeYl3QSUMcybTDHrprjneQiPoxAj6/uwoJHGXxSnoRAt9+ki094g153wRaoByy5DUKpu5prd9dg7vaHKjhgGhFoGocpekVB7mKWUeZ0jtZ3Bgoo53uL2dy+im3IeRFolNmyq+UQpSmD9dT2GHevJlxzeWMO1M7ZL40NrYhtYrVxo0F3Q3sQNNP1UgdxzVcyctQ1DJt6+8Juh2pkRIaChNmTLpSuHj7UI97z1423AyNUpByj+1qSekZJcPj1xKd+oTUrk+DKbiAv5yJyxRpJcPhCwcuU81DGgl2YXGVmp/+XFT3qk1X2RCoDwZkSILo+cJtmUs7TIh1YmRWQ1xx2E98c057i+z4DB2nw6sA0vmynNKtqORVoWXBLfaowAnmZ0jv3TPcXgI+GuIebcxy55h0bqFRp5i2YMUqG8oTJkY0CRHRmuGK+HYW+mBXaNLMbEvUISQZfG4pmTQE1njIZ2coQxTYziXtYLMmuTcOpJSM1H4wVgIzrME+Kopg5AUyW7zMe7rbLPgpLbMA5jqN3RcmXF5it7RaLgtnCU021F2Bdk+3G4yl4NhQn7yKNcTigVfQYJBRKnkyfsQqPmtl9cON8n9bJ0z/X0ZVrH6r1LUZIM6HVIXo6ZcZzDZz1HcbYpDNSlee2AgS5DF8MNdJRUJ4ryuEVa5kZfsAM+j1pfkCX+u+JTwVo4wlooYmhlXIZwv7jY47JowhxGQL9NgeOT3xVYfARHlhB+4w5YU2TPH8s/uItZG0KdDE1EEYIhrBkfCiQXZp7AdASTxFqXtzPgnws6zmAQOggsa3ICm5oQyMiiXG3NNtU2451y9KGaNcBDoDypwkp4jeZhmsqIXfFAXerrS/1aeDFz932DpkeT3kjvflQerxKBBOjG6qjTTppbI/HGRyequzW4MBeZu4gjI60UJRjGL24C0V5xqoyydFfzGnz+YtrVC0KjxfDt03rGfIbkXo8a2Gj9FgVxKVYnNdoeQxZVt2ZwfySAfeWWtLGl/ceOVBXFNmBfh5Ixot/KFx7gzxsxGW3GkR4OwaiYzslvM+HzzOFzEY6NiNxXDagJwohDZ79I7XE3XtWgRYAkRHxqYNcCXJOTtQYcSfpW0E0Rx7CNycaGRjVNV4LkPnvUfDF1zsuDXRf+pHeQDHhCJR/08+W12dxAh0SUM+1k87WSNMWytSOdx6RPEkzlmFPufuXZD9hnMoFI5LdaxkP84fwK9Onxsfwt6Tjjq/HTLWYbkJFAKj6iEmr/ir62LkOAvu7MXU+r++EVWyZXQtn06HHH1NmVT0h0hUMDmVFW5NYcnBxWPU19wnmjGJNx8Jes2LBVkgxrhkzrDlvFLWvuAOSLBCi6RvbqweZ+Dn2SX3ftTvTeLXUF//p87OYDgqljgXMbRySk//av/5OOGJaG/Nu//i9ujYwVkOq926atU7I2bQv689dJxlQk99mUG/kQ143zPy7+5b0rJPJbLMSwdWPzkwHACL73l53FD6fu8EnG3InFAKxNGQHFSUkz89zGZiq2S9MgjMu11/nii+kds8V5/hnZTWumIKYTQ7DOthbgX5RXj4qYsdjEnS6QVUn5Z2cww5lOVENZBfq0zZjIFvks7xOztSMGCiMJyFQWRUhWj29Dc2nDkWVF/I/E5t+Qo93EK/R46dAnpy8JFPUIuaDb5Z/Nluiu9cXz3gWDky4WzafyIf0SHK9jGzxi/yvn91M+XuU594n38WaTixOjyQZtwEjcjB6JOjnuxpmv5Ig0CakYBMeS5BaD2tEHpY0O4web8jP0q+DphFlO7QxFfPnIUWCmc0oXQe9hVXn2RU1ls74jchC2Kb8DPAwk5/Ok4lfKXp2piyKV5nO7aOjB8XPf2uImr6FhcF/x95/x7pybLBaOalqTI+I1MHjxM/GDfLpbIwDuHXOGQRzMs28Pk9vAKRBJVsLGmO6k4X1Fy3TiTFM7Z2fbvX/3aplpFw+PuGNkQDTvI/UZnVbOenLGTd6Z1H7icipMctFgEBU4Unj+SHhIe9e7LadlQ0LaNx5MDuLlXRnx3uYQP2Hd1LJiKRr02YNp4Gna/G0wYkL9HieJU9gD70dUZINZbMRxxI/7EK63d6eVsIKeGiaRkiRJZ3RK2mIb0On2Rrivn6JskInRJgc7t/6mfQjmkjVZFWXHHJF+kPwMPfxVG5VaCNuJU/4MTOMbnBrXPXqUNfdiEA/YSVdPse0s6ASZlmETMpEXfV4+YWFiy5Td9ZRFiBULqC9XZiPdoxw9gEdOM4uAxBDrxlUJSGTpdmrZv/DEDMcL4ZHDkLpRenyYqibqruYeXtAsvQexvbkbnVsMoMkBbW3rveBNo+OhJ0EIGpKQj398NnLNe8qw/S6/hyLSjFZB/EJgyOrTo+S6e6qW1HjbIaBIT6SpMw+Vnya44lJEjji95gabPmGbZwq7LMUkutlUeTed6DwUbGzBpS7aVsypjhDjBr1HHaddbbHHmQfLriL3maN7NC9PANEmg7AJs2CdAVlPL481SiGmWXVFxOcUyII8U2kQIuJaCuRyfpgitt0/ZFz68V2+hrjrwe88yD0ujlcoj1xssfmbcRNwRkuq0wu9NIhzhVlV0TYILC/GPHvv5sOoPs+0jxXw6UTzfrVbZybLqhBWwPEsDEKb+52wQEa01xHs3Z020nxCDCD+FpX0UIAOmYyPJfzNeaK6UZ3Z/byAAMpYET5uEyh+W5EWSJ+AfTS3ZN2JcdN1U0zVsisN2rrETZSSmQSiVdmTePy4pZHkpuN2RU6zR5ncIEaQYqVy78HBx3VC8q1JYVermvbynmuvwfSIWk990apjXVApaus6B1MB0GwxLnxuflz6BOQXzGExg7/F0m7XTkdPW2ctxU81tlC4eIEdHMtJtZgc995JWUvrSRXCkG2ItswV7mdZrZfMoqMC+7j3wyWWMqA6BDU1Q7BcrbVerYnZh2GGIsyjOVmfb5hDL8P31akaTiPYNO8j42+5Du58MXJqhTzRwax48FA9wYDjyxgeBsbtteX4hlei6F3D0fzISa74Gu9tPs31fXEBVCPwKurQsbnP8kxkmcGn5SowErFBI3QR+ObaYZLt/iitO3qs/IfeBTN10wkBRgr97MbJxcfnZAHeF4LvN9+ACDg5e937Hs4lmGC9O2wAO81gAYYNmSqMTRHgV4c5TJDN6OyAgATL0/pFjn7Es6fnm+stuRLvyk/1eEHfvRhXAaepNjWaU2k/Fj9ynjvsnxl0R8WjDBKmgDtrUzbjNh/EixbZSC5WAlRenrS4jfy0v9j3yHg6Ybii8hlOF6JY/6lMwq84dBuL6ChE+ZkC7bzB6382/VQnzRkT6W5pPuMaIU/q6/CBrn8Vc+ZF5PH6BbMn0jqNwRDIkxw23ghuft72jIoDNWeTT6XMa4dBcptmKYBpBxRqOdP42bBsMIi55Pqb+IlNc0dxKrKr86mmSfHRuS5JFxJn4ySCiQ0ykWWjcpo9gR2AFQctChY5trjdBXjfaq0YJebQtVBeEupOQYvvPHEOSHV7ipNyulh1y9B5cG5jgge1eaAskRM7FsSukjwniVyTmKrmsZjyoeWuJgpuSM83IIBIKtkhn3FSTTUeUI663JGkXbYb+WQlisy5KknNR7DoyPD4CPE6WBRnrAQN5QoHHQE9FbcsFS7cL8BRQ7bCe2V0SHCK0kSje5tcgjUibuG+BIGXqFCyg83DhLGYHrhENhhtMXfBTEtBo9HMMD4mRYwrAgVaM825AU/64VFWXP8rnaElkKJCYpSy8QZ3gTAlGrqIouVRYC9QtrlNybpbw+VZI0zYPVL8jlRn98r5UIgPzRk60+M993F9A2gBfVkPK9oG62C62MmagsL7VhEmyGcK53dJtV/8/ei7cjPZxCMDf16YqE53xV7O06PddfrEFbusGAm8tJqqokJui8DrpCs4qSWaR3VYWmNdB9QJ0wfj7FXs/0X9WV+TS7h04ZERCtaectdN8tHsttzXhIpCkH459HYe4TgodSC/Pg497FA35W6Cs5VaLWJJ8oZgBcdc/oZjxAcmOy6aB42zjMNiI3gVvWQ+mEsaurxn/uRylHXV3chelWPK0FNzUbCJZIFCjAQ6JydFlgut41xsMsAIFnkTW0xwXB50/mewO8bDWQb7D33GVocI7lWrZbTeCY2q2dwo2Rpm9cyQz0UZf7jY6XEGyeZqAmWjfSXwy6Z0/SwfsWCJhvuZNrKncfiCHGVId9hNcf3ZQLY7+vB2BCBWvU0QxMPxYWZUjSU20Ye9y9NYHy4RS6s8giWsWakCepLw3BGxs+XokfKb1pPTuUwtTJbxSTlzrrB8ruGIASIqa5t7B5mirONCwhWZ+sSccOKGccsMY5e6T6rS0+ChzwM4KLFScsewWn2JUcUmt0RFg0RA0KDKqbS427W9quUnRFaUA4IpFNo9tf4YgT11UoyDFbt3EJary/ki+zd3HPKRI6pfcLSN5qxKaRZFoO0W56llMl1zMC+z5LoEdE+oxS8qamf4YyaA6JYsG/peRS0qPPzNRwUXfta2uGqItyEfBgURp0yEBm+RmUeM1U7jEnWNsUTnnqpwZ6BHeKRSEBeBu2eT8YAD8pufJ+MQRkJWyTHm5h5UVPqeM+HqgENbyxKETqlQSFlj5i29MhdrEgTJucJcm+Pye7nz1Zm3jnrXj7QBsWr7bHOfbMfFipXY3Hp3ErlRGkAWZxmn5UlKqEP6wVpseocyWe+4p2OIYAu0LhpZuTC4xGPYVbfjMSscM4JzN0wvs6RY7ucpCamHcUzgp+4MYTU+20CyGUKi93MVeMjjhZX+SSV0MvR673DqOpV01cmTdYZycb0B03Isd1JzzXJQSWlm2GFPxB4aNfUMswpqE9WmprjV3EgKcuLML4LGN2xIYtFYS7sbMBCJ4y5MX65qK5cl7A67hsN3XlNzOWXt8IC7aJqr4Y3DaTnLItMKMIgWzk3DwCqCcIHMlZAYduHispFsGYNfyaX5/Miz0e62YUsNvslp7w92OAiyY1PImUn8ouIx6784KGXUHidrrKmp74hizk1teUetA0rXzkgmLaPyVKb1zA4tOgyaZ3RngIwx0Ml0V1nfQVP1CaYxw1YnDQZ4u4Z3pXFJCc+OA+USfmGuohMlm+9GY+6lxRnm7qf/bgRWDSKH8/IOjhM1K5PUgClhdK+qVFi5ByUQRO86r7K0QvY/Gkc7MSwXuYGMCLrqBbfTc72JJc4xoEiOxpudN7I450cbDV7sneZQiOyuUTQKqharQDrSLPgxzs0cB1y+jo6MLAamSGgTrgZpkqZYQwndBAdGOn44gwMhA43Jy+ersfK5vfVUZS5rtre5/U+rTf0OMyFp/kR7jkX9VuIFeEYUj4McSWQmlho5xcdO7LjbmDCNBTIsH9Ze++2odBb5ZEToCVAgFUZV1LH1Sx7iQyVesDtonKFzyqam6ttbAiQr9CakXF7DhYv4SeMy+nmuamz1KItmMcl/t/uc4he9behM3Jja1psWi3k98BBsDqiFlaI5RLjfOeJtWEyr3y9yHqGXjxq6IhYYNYJ4YxbXc8Kkjnrbm9umgeNrooQwzxZKHE95ZQ6Am6xyb3LxNmjqhCHb47Dw7ZVJAasJfjh3mgpFCZwHqocE7w7TNNOsh5fwkVJNbomsiBsi/8YYukA77aYsx0ITPjEoOhKlWGW+h+6ik330+8zaR/azOZ+U/pv5hKJ1zZxb7yIx5lHYv04qlIhBCZ40FNvK+tfiqBPvcUe8/EXRVmUTxw2wfMEmGibwAGFExHUIcXaF7wvhtlqC0VFhv8LKlPBdV8YejJQw7wIrEG7v5vDpe2QYacs51hFXf8AfEM2x6EYX2zPOlf1nzG4G7+w6ypQ3MPSc7H2B64rYccYs38c2PJOi2PKALMrqICe6ZF4oIUJA+wQ/zvEKttmIrQe7ZSLcwHBaSYO01Qaz7fFrF0W634omoXDKLSopqtgyivXNAj6PMYhrlgmateXjZjNC5lIdbe7EYdoVlWW7m4fguhtGKKpNB+FTcOKmVczpz3Xlc0r/UYTFidzN1NXM2cimd1XeXA5tTO+ZhHuX0VbuERlF2ftVMZl93TuZkbXMYR4CTbc907WN9aON+3BQeRLEXtxzGDaZIYX25ktqi4WmWHgIumB9Qcj02cnphUta3gqszXpWjE8JKWYzRXE5jLq4W2tahVGCJHyXDsige5cQppgL3x0rvVWcobUZ+MhzEJP7dcCLlWR3HKuyNRPC6cdhQn+4TOyhSAoo4F2wDk1JRVN+0w5UmSTg4BIzpseTmFIUuJuCsOtGL9+x47QP/bx5EE/HEPhmOfdIaUqDkC9/MJPPu/W4o+aYRNgrawnyK+F+gN+FxFHk7fn0c2dvV681/UFQsIDcndZLdSpvY0hu5KYH2X71HdlLJAieAfJSgMpoESc+/1BPRRvoQQ4cTO0MG9ESeSxVeEDzrBIGmOcYxlxFirah93WUwkfkQewH8U5L7+3WlJhwJt0sucCEliIbcqiJrMAOvkUNUBO9baJrEQt0jBULl6wTHkX+Zzcu3HAVzVyvefE+OgnnQqSDFbw31OmErKjYygixJ2LdZV9cneQiqCvxWjbAxwgbwwWDoFZXXeZMJNdKNoJA3ZeYJlpS1hj4RwzXj9L7ERU0ugGuHYC99GEnRG3Gjr4t2bUrYFUO1sZINwpI724a/+uCMl7hKGH+y5RaLLkykb4m1YZNvgpb/p5SZneAfkJ8EAeEsqc7T0ZRBKyrfkK5JKH4W49Qu+FviFSlHl8XjZp5X2JNvi4nFFOjkKtvqn4c50FA9DfDOywczBL6gKzquFRKAkxcz3osI/IBhQe2pr16WK/Uy0qkKqEE4zwInoSzKUXcZIWceF+eIklqmZcasN6oQQO/EOqxpMp+wxJA8G1i1UkrXY7cuzsADeavJkSKsgxWGxCibWS0a1Ij6s10jxOyIEyXG1taeF1GnFMx5jbk76QQQtQuTIQdPP3Edh6JHh/0FdRS3tAezvtflxidanuvqZnVCIwabJKVEvhaXWwb5xiYda0OKiWoDDeeomOS6nupoXblV3LgX0xvQYTc5R/uEPo2MBVUNMpqYSp9E6ahHLK9dnGDVZ08zyA9xOfsCwTB9w1IffjVyxrtBhudfZuDLB0lqNmoEEXeILjkQiTurYyuJGc8Vk0BGW4QLcBoEMRDIfJWQnt/H5lBRAFSkRuWfZs4YmYzD96CVPNjuUVAaR29jZvIAo+1ye1m3dyuOropKc3O5lNs9qfguJrkU0YHWrOedaeq0p8bXAhamUi+2bTvdDlP39cMP7Kbxff9JQ8uEpA/eAK3t2T9jxaN0ySuOEVqVlck6l669VzXQ4rm5bJ6GxZiByvke0Yvg8l9GWZDjrAUyLXHcsRtzsQ7RVtDKTu7Z7LbZaVyRkeoP8tsStOHFK5A5hVWu7CML01nc+0LGZHu5rR2nkCA50wNUlwPHDWJy7mxe7Xrpcsea8pSjd/ahy0Lz2jW6SWHvFuduZzF+COS7g0/mnATZ5+XaNKbcXEbManmwm3wcp8s6pFXXnlQUPnAfWc4JbxYdzOKwPLCIiGC8wjSwvUTz1OSeuXjwBsdO2X6Vs6XWihgAKHUZtFhemlqW1G12BvbPTOXAFTDgqGTgiu9qykuIbBUQe3lKZBzEv9ouf5KyuZCMUS+bjV3OBp8jZcwV7qW2fRYWAdrYw8omkYU5ocdo5QyIhWXf78TphR/zXwn7Qmh7VgfsQ9vAbHRBjAoIdO2xhxnBXG7mscr1JVX/IvWE/xVCb6RQsvGxysD29UwofP0lfE/t60ZJDUl60EbcvrdND0PoRVxlJKZoGJuGkI5rChylnIgjSpwbZAHO0vBXhBX0vQ5oosEVKStEaU3pwek52BZa6ZvVxzR2BYOAlOu5Oo6COWZkj3hICD57KMgAdcLJxT3Nnf+KYP7POoumV8WPsAxI9KUvc3d3qNMDV1O+Kqd4KnPyJ3MEuyIhvTvrCT66s+A1vwveHv/i2oAUwdCgWPLFmBnkaHTvOG+V+C8wL1kJ51SlCT2iLh4VFJrZw37FRoI7D0KOFXxDBz3nh4+2UltwejgUrNoqsgtHs7xwmhwvgP8Y66PAi4tHLMwgEw5wwj5WT4LV5PvcfnaR8rBdYqmKR4c0i0Ax9kVv6OO6RiUweFyJ25VBsQEY8LER8/2Ry7SUL0rPc09NY9vDjLGKYDZSOdHYU3jY8foD9O+Qb47jgvl4uLLH+VTu8V1UAn6qCNX8As+GtaVxD33na0XDRVCZemhfvn35Z7x3O0teGbEUvrljya6mLSilHuq+1l1DZcUPaVImvWNbCL6zsUV8bISZ7ut/BEuGSr+WVxjACMbxk7DcBnr5K4CBdwM7x7YmyUU2WNjGg+n5WjNwmLWhFxHy13ZCR3iC/yIWEY2lElm0tgYk7twcDqDuOzmPo/5yCSlzHQNAnMkanmsNrUrjK1VEHg8lMInsr9vFhTUYOK29V6/o8OGhvpd8sPyT1llZtti/lL5BoOmtxfAS3eq4i3QdFlNb/QolaWkd/wnENiYU+XcwQCd3at6euVcP8V1tlfV9Mr1kLZsA4b32pkBTA9mGOxygjxPwxbTaKmj09E3mLzER+AGgDQNy1OWHYgvLt3ycMQQhEhsy2Skc+owBtdngLlf/OwM/O9R3rOiDccSY/7TMK4pWWbCmUTAqoaKfHHMHdRovDEfbNgjol8J5FEGJe5pCVVwuloPIuBEa26RMhXfLAihKV/K15Q4e9UxJAdBHNtOyhJ/FWkbb9qllF2SDRump9YL0dEK0d88bqxj11bpnl1FpJM8wcd8rArBGOjNexk8kjoeutLwa2IUI/Rw8TALcW9GN1BlJC7GXTVj+Z8EgbxZF2g5at2ZV4BR48Ewq7cUFuazk9kAL77fuupdjVNwfms+186p7rRGMxNeaXxqXJEYspNymc0AHmZgGdwRXtCE7CjCCJL76D16x39qnRf4T395DXpnG3uLeUN4Al7+3qPGTSEfa3/yC0yJnDIWXkxJKgwEYhuwzxamDLAc6ufNTdw0F/w2LUkzdoJtSGqEms9VSokyN2KipCZ/FPwe+Eeb/+CoXhZUXb8U0dSUCVEAqmCPsDC8xBpoRpFZNa0nry1uCy7pzcHKk5AOvoRW4+BYlW+yc42N0obNYnLtBYIV9BQyRRplMiWwe1A15P4mJDqmCWVeCgzLlX2hANIXBrNgzvFAl5GMPV1PwJVPcjgwciZu0pnxywG1nU5FBymFd2DaG+xbtqDuEFkeFFWuAH0EiZWcpQ0PvuLw5ubvWuKGtr3ncNcwCCyai10fD0iZluWoy28pwqiPkpMLH0in2dBFc0HpAF+lGyiRYAD35SzRMdcR6weRC7Ew6XUXg9XKEHzMJy4fptuKXTsYJZL011rWDiRX5xVbBWzWIHoaVkxwC0WPErFc8tSVqUu10GEK9fJW5VoxeM44TcN0JysXZ3882tvc2XzqW4eEE4jROG4JTgPnJwy2xNRnjIwC+8Lx1ImZf4FeoAAG1dRn7pXMop978FGOv6rwQJyoAxoInx5oDi97KhP64mKtWV7s6DTv6pmNpPnz5tu0aezbCcU0Wo5hYqoA/Cc/VZ65Hr5FM6ZPZKYS73x3PlwDrqIqcIquEs8ZA7YUWUh6yDMtWaPYCOF9TlNcWuwXcT15GhSDM0wt8S/QgzjB83I0QnLhjmh8O38g8CF/S0udg6Npiw9TZz9Gw7brSuQo6OX5UhXCQdStmZW7cFnEjggUmyCSYFncJpGuIujrvC6pfu52xwAVf9WiW53HkgqpSiDfzZl3BMS23YU2Lo+wwfviPWTWy/QHzhOluKS8QZsl4WDav3aGbP7eS5NLO+mCrs3vEna2v6jZBwd/sHlTtJpx27VxyIvLV8u1rw5wl0WT4SPtPA/ua6zakCoI3NKa8Dvw5+cvLk5zByWplpMqYWwTzs0WuuCm0TZvfu49SjZnwwNFcsred0+yPFoGnYjPydb5YK5OrYvxg+CDYBlVEeKrHeQeuVSu0jl7qBcut1SoWPVCQApVN0TIinOV1Oyrx9N5+JdOJG5N4ufBksGjJXmeqds+cyxX/JEvnYF7nvoWpBjLhHzcNrlYxdqxeu2L5Lm21iTdAzeZmecAMZUpS2ejFgDBWn4zdwk1ZshT8T2Gv5auzCVLIN+NeT5Mwg3eyHISdh16CO8kpWp3s1du3m6iJ9P78c1zoWef4r+PX7x/F/ZFwLO0t72xvb19vJPbIApkeX6XhMI6w25gla+zfWz3h+LWpj2D1cnjFTqom7n/jCZ5Q55fkwX3SfDcE+Mc+wsJCsSi1R3PUPol7Qyz/LVhOIqjg1L8GYFVFTeWVGC5O8Vn/r7OxaIy0zjhDtNZn4eCIKAc/HY68I1+nHXHRrIcsWDP6GsMHy63Ju2VuSmqMcfJ0Jw0UQZpa8zun76xo+aJ+xs7k44rfmjFMXpDIoB9w2U0bWiwLeFq0yjatDZkbMoC4W5uzuxdzDj7th62MjY4H9GFpo91Aawy0TAGxhqK15gTPyZq98tAItC1i8j3TOSMUNDLUGBnUSlgwhZn3LwQi5zSXkS1bdKLIptfdqN+zzH8E2MRZkB0OUJhOIOrSguSL2V6L+bwQLmriYcIPutQHKpw5gKTdPjRmCclQy1iWMBdqZykdbEsxduLy9pT26qWrtvhom9aEZgohqQZY5aPar12CuHaq5tnMlGc+xCzuV1MJqgtHcueo7FAEFev0nIEb1qS/G5dgF7TXsT2DIuST+/Yelovk4wwIwNNVhcZJvCFx6UtmXC7SzSWZDllHvQeFW93GU7CuWZq/WKAUsFx10CmPXKcS0oX/TiIBtiIZ3knecy1rmC4bfRPZiMIeossue2rQgdBajUh54limRhB/AwbgeEWugeFaF+kmGLdhha678soVmTFGWCMsw0pyo8PY0IHPMwgSesiG8vrZJQ8L5q21K7P0veMftroLabl5xnDyC+vzk9OXp/8dPb66s2Lf3n//O0l/htb+YRtcg43d/JOVMxB1hV+oK5/KgVcG4sYshjz4G12WjsravEjtZZbuWW9O1bbfXH0Uzp9gz6jM3uZnNng2Z1EcCdeUlI+mV2fZY6Pgf/ns4Y5ZRizvyiHeQdnbL4R8tqMbEY95p6TeYSiOkfuzKjC4oq2WTEtc/rzkrM3t0Hv54wQ08cl+iOKZAjHTceT8s3uQ5a5SIULc41rsqAFmo+i+EH2tuEziaKpGFE/42rkwd0FR0io2YYG4oNCZLwV98MreJhjWyPDteM5sgOtiVETDDlpNCYhb5O28+aO8q8EFz93p62l7kwEMPpmVO3Q3TB2adVBzkUKhHlbTEFo/aG8YjRblG2AsZ/DB9o7Su58j3hb29PAtStATOZE2LVdueTcRMdR3ZnTgOT/TG7kR3uuOAk+uIw25sz+vTCWiKW7gaaFHLENvvx5SmMfjegWomFax3m9UV0p44DNmVKySHhJf2Z3BUjiPl1wQpOtdv8NRirDmzoK+DaD7ThMsB22MFC9sMDFjLFfbGapitBGnwKB2M2sCY7MHZN4KVBItIZGg4nRxmFN7JKS1CooQfUYxWpUqlujqUbc0PxGcWjbuelE4atihwG7WhdJ4suRpQQfxKfc1tNys3eC1ExkhQShGQfJkuc15UDzPOWdGyc7P8tzHzyQj+0MuYvcxsfEPHx+meeUkhCOiyfr1+UmYMzsKkjU5GhOTeKwCMJ8Di2WewS7TjgHwjHogKx0hR6mGzRORUUG4dDmHuGi/Ql+t1MKYkRFzLhlZQ2ejMEdzBm+SaohkkQH84tQ2p+JV+DudKVSglyOcwRZsGSltMJgL++q1kefWi21QZVs2xThWV9Mi09g2eOzNgUA26VLHI4PcRNlKLnUzrDhKUfK6r3XKCLmottL8CQnUWaIg0DYf0ledltxu/zbTOuObuine8rrGqw8dBiw1Yh3km3JocAQEybPxLXU7glZHSLyKcCxM8Ba+6yPF7c54d3ZRlfjQ9o/SrORrgd6B/FvxjSL0f4/J6vWvdjnnuUxYL8/7t2U98ire937/YLSVBvEjQtruNl7P8NH72//F1CrVPBZI/dCc1tyxaK59xcRRaFYW3i0HPuWrd/JURhiAsjCYt+6lycNY1WSN1SpfLhu4jPeEYVRK4EJLMN0uEwZrvW0dLhOf3rca9SzAavQZeLvhAj/HaSBSlAcHGdVP65cvFm/qwSlsUfqim5zs5FXO5tKIbB7lyC7qj4E4qGoDitMR7nYBpnq1AKjy/LtglkVY4pUMtoq9+ULZuB8KySfzOJ3ipDEHhJ8WOleh4foLYdPl0TfpL8vTO/s/A2Gh1wZsMTBvM3gvWUfD/QpedX53I2R6txyzzTQVtcP2FDe+CrpVeQ3H2x2JjHKosC+GGcb4W3Q2jrG1Xh6c/14RuYdJOkdmVA5cqimIgoTBxizqBYmycjY3UO80ic/31ggXoJxnYceWmYmYwJflCAh8EPSY0xpL2x7NuVL+1g+qDazDJtDFJXjcTm6IgPuSo1kVXi2kNiP+oIidVqWzpVZXK5Oh43XRKHpHs/eVajOu/5v//o/T+Wc/du//i9BflETxyWHHrdJ4zzFNZoeWhXMzxSQMJ1kuZcqAFIi/jBDCNphPAqgRsG56Yjg0bkpPJpSeqKkspEcypwMjNY6PY/nmKe/JE5Y7AbRsvba74KvHyQhMzOkdkQ3ZL104uSo/ATTVreP8uV6LqhWlRVw575w/RG60SPD6xbrxTwipXsRMgJHhYu4dlSfg2H6ZYsoZWgFpSE1X+/D7535+YMkCLiCmWZ3c2/zc3YmK9ZecYa43DOpD16x4q9UXA7r8WIyzce1UpK27FgabKQOlk7k5av/ElpqF4eq/qBqOPuQl1LZBcYaEV258kQC5TqBgZKSXJVVNoVlub3sPEJvp4T/QRz8/A6N8VjCO3+lmy7Tnsg7Y86HVD9LIXGUp0u52zqfkZiFIdf2I61OYHtCixB8DQKXj4JFWDcW/5Ope+hocIkTQew5yFQUYihbUTCY9lza7ZL5D1yrGpRO+RgiDunsthYWi4yyEP2rpqtgtsU2DJnDoti0cJxHvnL+8Vp0maM26qzP09sBhyyNW+KoJ5nyscIrnyD+4gD0aod2HoGOEgeb7rTYEc2u2j7kQRVE3IMmEHQdzKIkHKyf5TG64ltJt9LMmCsrqRxjpnUjc4lNdBLNfkrpuCEktzzywzWUTe/RjesLlAQNNtTVNw0Rx8Xt42QGxpX1cIgIozn1GTXT15jslfwJVWcjjYeYNhw5eK5wiVB5NaeR0XhGXLf7pDl1j1c8nctDkzkYiYZZCvKK6KOPHtO7ul9ijwj5vaY/TDZR2PR7tcC7M24XzuaDOd7MtkAPYWtPZhjCDeQS+O6Segs45B10lczcuFBDaSXYLXULeODfitaoQdg3FRyDqTJaqIpcVqDuRZBxz/+lLF3+Ro8UxrbhqRjc/gh/dl43hil90+EphX5daGQjLoLhOD6f4aXysPc70IJcZhQnGlTchD2RTOA23xbU6zHWU9LTuDtNpDd4ZXc1O+1fToAzE5HWeFCu30JXhGYsjnf57C78JJxw8AJUGkwAJUezmEDcOk689SDrueIknCCKiAVXjtGUKG2jaEhS8ZtfFOOke5+UC2spr74R6hutJZnquS4/z6jYtWXmDj3ifL7gzrfhqQz1g0+gNLeLibhRTXHPfaeENytVOvvL/B8PJ09rOxmmqhFH/77dAgNcWGPFGC82CukkRgtF26UBaf4UXLgb7JfB5pgQwqgqQtNODEESSl8E43W4IWSyiefP8TYuxBXhGXaBiXVMx0L8Xz8KG1+coUfp+2//+n9b1sHEfZC+bKCqxxL7dMZ4xmPuUFs2x8jp+2ooW2Ha5uW2otMncsUELvvmK+ApQ1m1ytaaid3HFxFOS4vn+voBTwoHI29r2czrca17seQ++uAxL5M/HFQTr0Ay9QEr7dkzdqcnzThSfix3jRLujiHaVbXkd3O5Xcv+75NQwaCd9PVdBnQ94XgiIhdcBSHiHWhj0m5qCqNb3uWWtStaSOB4wv8WGYs4jvic+MtlTdjAM+5ivU2EXApKyfVB0q6FjD5x9T2BZPIoFfOQ9w7j66txbOJGLndaKtUdxmQ/LHkR6SVpaVxaTEdq688kXWmbioW+aP5in3U2/XRnXqp1jb239lBhax5DxJE0LF+V46ZgE5sQIutECb74TNhTXhbCSNtyUt/sRo0OZ3Js9i7cV0xwhIfrmkEKdgq55dUC8ET9PvrBH5VI0Trve3kXFr228wYuLlK0YD/hmRi5niJxzXrFPBwGH/hauGyz7XX9Vgk/JwuMIjh5vUdp0fpjROuAQsw/80Wuvww2CDNFx/RX0IIBYTuqPeaBEDZgWdKI7l13KpOuSIUQm70IfjSwfdyjwYqSVccA+avx/Ove7ubu5n/NPS+2nVZGO3dttPMEYW/KAr68KQjHnMjBonZ7KSrs3IUI2/TrQRtBBqUWH7HNHUHruk7YpsKazVOU0IL4DRJ0G6a9N4z/fstludap91FQ4j6FRYJDIMkHcsUTTlCkyEsRqNwPXq3tpezpGMZTgHYskDU9IuY1NzVLoFAz89pxkkY8na5emse9Z/glJ0LFLddAYwiF8jqzg5TVWFnSkA1zsLFTz1GuVZ0Pcs5veNmSh6fnKIHQexcw02W5m74k8wDRpM70743q0jBxDOvZQ1SRFBYQBTc12zvJRVdfeXeRjoMD5lJYvw11XBZW4oPWMu2gxiXXiteUa2P3QkG3uJqVwpRIRRED+fprAlSeEJsrOXyueWhA+ybmrb3DRMmL5R3UQ5SecGOCc4tWASxZ8HUwfHo+BU1G2lMxtQG4dR36kHB7TnGrJTsYRb/zvmNHUOk590ztUil6Y1TIffurWxD+Bv8UA6dPMODkej6bxDH73HIhr7ixhqtOiuUbqYlOiP2yx1Cs4wqF3BXKAXdqQdwu/zScMjSJf/6U3BF0bBZVQGZhDFlJ2I2aghUB2jqauYNdcAx+vNoX6Ch0cJVhbiq8WF6ZSJFx7eWDe53uexfaeBqi6uxJn68IkF67RtuuA+xpHehfUINYsi0IK4FyMspK4oBwQT1WDOVCBmed0oDRSBq9Yusu01E4lcKnTGvRe8lB/zSDkqqnE4+CQ/mBfKXecQ7bfS33EQKxHTvAF0mjimj3oj4EtoLOcf9psmcztWucJUM127ovKzlp5fPYuuz/8//+f7FEIlOiCmCTawJ30nm1cUg9xoXrTB2iSEPb7nNB2kjuZDioQy/gOjmsrnSXKlucuLpFLkaU1JpcNvUCm9He1TUry0z3SknnG5McD+XbfKv4AF9YzzKsy6GFvfNPHvngv+sUCVLRL7BkkkMikTahr4nP4k8T7G2wI6bY4q6WcGZStUwHxgIXugs27YmPzns3ZLN2Lb6RRI0MU0kwpohMKsukyNxCWysOI7oEA4qqCQb+iXtlf//+jD7/OsyD1zG9mn4uidS0WAaEPjgX7KDLnBjh+bxgcsc0y4jdGlweH8TjNKg77lgy9oNOX7+6usQKoeNjpx+u9AFXtIqPik91NbLdKbgjpZn1BRaKsfy2BZnSC5uiTJ2G7vNyhgTenAria7SkG2YTsVzu2N6D2NnCaClPr46v6oxHD/Ck8gzThRIxVgQVZrAHiA0jeZ7X3F+CbA9vKFKvKJ/LYpKl9C2Vyg+k4XBcFpju6xFOSqw4+D3JGfjfFhfTNIKBF8C/opmAvnEQhhZ0QyhUXovrxgg3zDPeNxV2XffuDvIBzSbjAWNCuE8qpXzLz6gbK6MCXyEwHybwXHbQeRc4KYkjs7GRN2Vtz3nvACV138wk6uq6S/aD2zJxL0XZxeIlimn4vtoYclfCnyrbHyWE0XygBjB3M1gUbEz2+wV1SkDqpTx4RKAM9Cny100JSRgQMtOLAqlxz6EerS31VXdLGkTfCGudQbQz0UIh2fJaixpcHntUG32shl2A6jazMEsMZ0zAxFwbEER8Ey1OVq3KpjvQDQrLdMn0Lrfa+Ra9V1To4JGzi2nItSBGUuwKvoZ71rgq4dB/4bYLdOvhfDGLfKdR6YeEBZNfDlQw4vbk6R/itdgMxiFxq7OhS12LZyizkbuAe+SGZjgEhnHJqYG/GVtbepozENY1eWol3dmdCncOvjQ5ZEaQ/6OcPtbyNQQmdKTbuisqfrOo4PxRND2sWZUNoZhofHXhjU5RjKKlPNXkt6zEh9OrC87+Xv1QYJV3c3wMGvPR42AZXqbtQYJuA8TlwMkQeAjKYFmxYBQX/K5iQJ6j7WIl6E86nMpqTH9pyhtQS67VbbTxYHjAFE7w1OvZKVzTiNKXjCIbopmQGucmSyLtGHPXzpQjUBu5fFBJzZ0kMGtKXAmUTILCdyODH00K68xrV3whvFgUaw0k3jG1E2CYJpsnsKtF0ExCy7FgIRRGFQ2BaED4IDyFEs+TB95PfGqdLTljLxv+7n5DtXkcSAq75gTbT087d1UBRHp7RzgFZe3sgKKv6cWsvw1qFqsSOzbqDIOcIjNGJRaRRMGkVRDRYzIxsHDKwlFwNemt6xBqLoFRwU0HTgD9gQ9zd9bZdzoWhgvBMLNHcQcuQVhe6z6tTchyLNB5BgQ1n7wWym+4cmunyZrAA3tJfPnF/C6uvpf2NeVE3KvNz4/jM+ReuSFooQkDOVLhgDYlVv/xgN/H5gFfKYQXZSptjnvPr23WSRqOrwBmhKVzXthHQ+cyC2UmmWFZM4OoUjzV0qXsjKtEUA6NNVc3JGBBs1HPhHzN240izmwbZNhthMbB/2xGj/WpXHezuFjTIFjKUQrtQPwL46GCkLJ36MJqxKixnJvbo8hFT8/QL73O59qaz0WdkpyYy7NqeN85TD6xAV/qaFOUqODIQRadajnyYV8yMQC8osKDW6XYcm/sEyA5q8Skd1ZmkqdEWSzRshtx+5BjP7Fgw6qF4V3d4k0KXZbMA/R0cCWZHgqXwZXt2/LsF6mfZIIfu0m4L+vr5GNvMnQ1T1sG/Yz87+7m9ubudmaKqxO+ixmMnYlLGaM9PCoCjzl2FQsBDfDMcgmtMUbCNe51hx81DRHFzMmUDAxStb1Hvj1ffH1fsB1O99FUtyahdLEiEKCEHXDZcTNVbPmim2N2xqSJHwM80aMPQ72r+xewiRb54ZxARXAT40oMY142pLxEcAWRGyL6DjOW6iPaAGbdxBN877ImWIksZ9xxqVoxPEQ+D7QX8OCMK6fUmLs1P0IsJ7nstSmxPrE1DRpxHMf+Vpuljc+QuRxJsN7gviI77VEFng8HwogPQVf3ce/Zi8uT9Hh2dtpDcMAZWO+vMEiHUcNHs47Wd+bMvl0ab7RXgXjOjYey1H51R4sw94Tbp3Z9bQRtL+cobe/Qv6uEI0T6uuYk/3FOC/qCQXd5sl+1xZa33GDF5UPYRQkyIq1w/D3QhaD+fq2Ues4y2AZ+xsX8gQg19AwSx5BSQeHLnTTFdTWMv4sWGXbAtDHygN6OnfvsI1N2DlVprHu4aFC8WuqGFwahLMLQDGtg72NHdaNBKP3jc2psSJSl6RXYTi4BqEjuKW16mvzuNwtMu7h2S2PQ+Y8SBlKaUuDUOQZlOuqj1aHRjpOAGyspoFPDj48OiCttrjsTqDyeheIITBQnp23GNSF11iGVJQLTlsiZ+ThBW8qIpEDaWT21nY2NfRixoCVQByl7GFe3U5cDAIOLaZe2sKUGml+S/IkpOVbiE3ghnicnLzx2y4oHgrNXpRAXDh0bIpd8ZtOgefzOnnFImUMcjlFIUqXEwui95geY/E3CPvOubOsxy5glnaBBA7bgrF4XTYC0IMVvtJxjS+peXuKBwyDLkECLj6Leu55cmQ5r8vX8BTpL+L17j4xJRLIt6HsuuVqqHMJL99imvc0HS5GQVMNpWj7KCxoJ88IX3h1jSySC2icu1fqH752YKBH4mc38RxpRLBRigKBt9wBMg4ihSYi4x9Gio0iRrhzsqAawD8pCPfonZkF77C45QhIdYlJ7tpkFGA85xVRxZaLB0MJ1RRzC3axHhfj6hTMKftw8qByAWX2cYjJI6+CodBejOvBOFejSBRxzx0mFZfmd3AG9RxaO7tHhGLrD38BjMu19kt4+jUIxMfGJ/8YUw824vs/bLmXRPmSrAPzHDSolyu6nMIU8CiCe9m4GoQo3AxQI9T6kAJjFT2WLSYNLRYQNM49Ja21qYiyMF0y4EKYpS8uJoaQuQovR9gp/3sOydPwqh7NDFwJzhm4SmgUgsGdUfnSBZOgGj9r6u41UbcSGr1c6fFPxuYvfFZ/dAKytekEtVbTRAed9Q23unA3Ye3Q3n8+Ot7bu7+837+taKjlBsm7pvd+6pu9sGVl2hnyOURWFVb4vUtVEk+f4VmFLwxbStwfPa47HnQ6H8ae4+gUNBPG+wnR37rzFDjJtQIEEfWqhCXTAkpl6w9YIDaEhh8uJQzwaoRIi6VGDyHisSoFOAJ0pn8wyjqt2FQsgLdoJN4DtJhYhk+biN7Fsspli4gnd4JAJI7yBCYZpN4NhEhDMNBOCQGLeg7TRwm5yjd+VwqkcdN2emqAiZ3OUxtcjf+jmhYygYVnQiS8LxazhSJEu4tt4M4fZ0cVEiHhLqjlaFOYQa+vAGLiE2WDe6NTLIQwTuVGu/58lCacjadNZAdugcZaMS18YjnzCxomy7KLaf24AhUJQ6yOcvrYmevsAZu0HQ+BJgIU37T0EQhm0CSgmNvBggQU+McWyKEX5550nhIfjMkyLT658pQpCwC4qGspQ9ZFVAZ3GUtOc1VgEnCuBg6Pd1+yh5pUcRjyvdEQUT2x4xbC/zSXzSdEQxhvDp33EzUwtvopojHkcj0bMXNdZsTaChQ/ksMRYpEiUolQZEO4rtFfPi7YFRevadKf+tIdpiUvswy32OucshuPeDBPRtipB+neYWBKce/f0W/A4kc10zsSoCO5r8wOT9I1rHFwGC6FijaVP2M2d1zMPwzpm0vRfX2ydXlywPKexgr6aZsdiwwvXKRS/OLmQviF/imxJI3+RzD00XTtUodsP7EdABXq0J9wl1x4KkgvOSCBMis7sw2kvrPnBE6cWN3ZXjPJUYpuFN1Cf4JK1UqbQ5p5wqniroc+FugXdSVhGWDBMtFJMr5Nhn02RMkZXXhYfBS04J6+UGePlmLW0vGlnPmaNSIojyQEiMkNWiVEPhWXGgjlhrc0RrNTUbgUy25fv6Rd+k+65wAw5ltYyvIxaYBiiZr95ATFRZHegjyCkpwmVK183UBLhaWdDaGKJOB1QKIInipbzOUOHFqE6aJi2GUUhfG35iRii3Zkj1lrB/5qgFh63zegYwil0Dwv5mIg/nIwruBBagS2qObGidtLqYoIlxj2FRdARwFOJIx2JjxW8wWuKM500ZnGJs9DMyn5X1gh2b6CZptVfJxlDQzTu/sdk0lLRRxAzjyMJaFcjKh21s70RTO1UknpxMYKrCOBnbyUtsuTTjXGxdaH2DbOjKyfgtJ4OlgDC8HVnmpd1EAhf7orpTzav7qiNVMR2QZOJ2TX0cf52+aLaor0vx+P4unKhtdJ+Zrm7O3tyRmPhzqZFROhF+9TyoxvtpIhy8XE6QGvbVSN+ZTHWptE2+tw5zrsS0a6ZnmAkw4450ud/WQWoj3jzN1jwXZcguDDVVrRV2cQiwZ1200aET6gYUXlRJIA0lhzqs68vkYww6GhyQshkS1sQ+xo5NEqsBjjQiCqAQ5zR7c1+XviWuFZGCshdzivq6iq6r0v7uFodTk+53vWpSZP0/uIwH/ZWKJqyI54iPpLKgqRnyT3HjK+5rMaFxOM8brolCfsFKfS7cjy7WYx7o3pIlDSyDRRub2PtPwFLgg0G2yfcvEYYqYy/PkvWY8mu2RNZhgSOlQERxw6cHLR0eqpdTRi4w6iEvyTdd6T61zrlNBoRCGbiejs5P6YcxTnWjqOW8cDNGy0JDZWJsZqDTfEHf33hafITkr34w9LF+Zb4Et0nH01r13NcPbLHfCvjAd7PBi2I+nbrFFUa/1uDdY+UZmk8zpmySdLA9zG/TxMNln6xKWcCLbJzMpuUcV38+O+Ik5VS0HMw53TQ9+9exRPyGkZ5zmN6EnXbCaWRzdNarGHDQhyepJuTSajlBnA78wVfZVuc6o0DSkeeihkofAGDkHSKXdKxaQ+feOW3k2bdLyn7AHqv9A3j6eP9r9vjo+O+eNb408Fxfx/bmuK/D4/7c2Kdlj8cbMLNw3/vH/dRieE/d3eO+7vbO08H24eDnd3e0+O9p8Wk9/3rS/zj3nF/0YzpIfBPDP62x1tbyvjQbmI8ANmk2s26ud3iaMOWKdkd2JDHJs1r8w/VDAfcgQFvmrIcgM11P4Ov97+ujndwQrvwBzjshHJKPrEtX8WYdDMtxgPkO8Pxto/7+D9Pjvu4CZhJobeDN+2ajywKgTllUW7HC/raDixKU9K3sB2gTm3ngD9yRSfpCtPN8kzMh83BhaQvHwafoggu/R4e8OH06vzV++/P3ly9PHv1gn4L20dVeFfGPKYVhzm8wvgWgimvF5jmCwJIKOgigUk3MW0nutn/+o+wFPSuYAvPHxAK3kZrUeBM/getgi7e3tPj/vf8DWwmDEbvN+2smH5nYULfbNGvZP3QU6ZlX/4sXuDofXeOYB1PmAHR+kXBDDZ7P8FqqI5XSL50dy2ImwIv5AMTW5vyFo+Lr8huzgCSN3tvagrjUEBG0atqK9J7bJDDahFtmzh1WCfObo9rfv0n23AcJVwhYvSbuz3GkcNPe9/9I93tf/yH3n8yall7OdDjP2KpRyNNj8j11OI4NVQdzkSoPxgEpo6tgRKzBfqPLDLEHbWzYjWbm5j0fveV0X4ZWSKXWIvCESkV6v03eHx6J1qA+RL/GkwB/mfJYhgGcBruohDemKHWvuIfm364KOqsupZ1yvHKCRR9Pj/iHckHHv+bcvLd5qT+Zgv+V5qCwYu8/9jA5leFJVmgTO99KWF0tLSQO4m78cDS4ECLjzROZsH3NneO1jwHOKvnz3otiI9JYUjWbO/H8FpikiZ6QfHrw6PPBCnEnPAV049IeolTWvlpc9+Yb2CB6+mtOSzyi3/8B/cO8H827qL4uKHCUzH3Tiw/z1CaIZ1k0bJWvIcz3NzSq2Fb4jxvgzs99EidDy9l52RMLXN3X8qLRfOpfEBkw+DtNLsIB+EiRA/lR8rKc1mRdEnFpk5CaBzjEeQL2kGNpjgytbUbHb3SyLiflq1ruozrOjilomcORw3U8I3fYn/pWwTvYd0MaluN9XwOzlAlqPs2f3j25MzLj+xlfTP77ptrffz1d99szezG0eOJJoFEbg+MHoF03lVgDidtJkgJbNAhGhbTiAeEQVqhHHE19K9YjrA79zi8QZpCvYlh8pqLM+E+3pf304p6xMCFbWCrwSLLL8nOukfJY78dKNYn3Fjm2uDbpj1VbynrOKmmMO1rLZfJTmc72KGnwU9P3E/56dKfM3MWcBWzgEitcSt2+0hgDrS7x8LNEAYctcWifMG+F1L/EOiS0Suf5+qMuy+Buz5+SKMH0WuzLKYuZ2JVk3opEJpDN9EtGuc7O1gMNvHcUvc+13E6kxTHd/zNovqD3E360oVUETq7YXMyYvWjQCoGMSnxrmpXfD1GmeOtZN2wqW8lohrfc2zQb1Q5Ti1KqWlRs4lwJZZ/tDbByrCk+1A3H1sjtpnKRD6yHxwSvuIWQoLUKUJngwOAbVRXoLjafu+RdJplJx1Vz2MdZrfjuZiO1bPa+ZEdG1d7rxwnGIo5ZwEcAE5EZtI3Jfojj08Z60NFu7P5dPPzJu6etOahI+IG2ekYhPIdMhIPJHIU/yhRDjfK+mOEX+x6OGG8grfgQJvsgdapqhG5KR6oLKY3STxwk4ErX2EC5yOa2l9xqDvri5IBvK4vuvNUfdFdcEd74OcdPDne2ws90f0D74niySbX85/VJ/32yZMnu7+SOXzrnp71Nrd/cW9zldvzi7ib8FuqKl3ma8I+fP+Sdnupj3m4bXxMbyey4o39jBZ7J4TeGDuWR+T/zkHpDfCbg6PVruU+PPiUv0ND9Y7W9y1XPS7vXR5sZ73LaBI37GSeeeCuq7/zHiMvD6MiTXH5hvqh/Pd6yqCR05dHqRk+8QIs60HubD9VB3J7DQeSbz0JtVD/qNqIXpOVS2CfdNze7Z9/e/ePwQs+2I9u75Olt3dv5+Dw8OlTc4G3/6YXePXZ+ptGjGDmH87hAF39+OLdxdnbN0svM70S3kf41vViNHqgyNwaYR54+jP8PGck176Hyx6TvYNHh+4KNospN3ULY1ptPUSk6LScE+EJso9t8E0xE8TL1Hlx9ne2d/Xm5DueWt34pl58KouFa+eb5HTsh2kKzxvkxqQC7wQ5htomfqYkCNphwf2jyCxifoMwI77mk/nm5p6cti57rea/t/6T7+SxneSqcutB38QMZ4KpHweUnzUVipe6d2BJndShJWlEToug5ZWgPNfHYSfTqjEYKNNatXuqtnKBy5fH4K5Qwoz8Ni5Fwvf57XlTc9CHDLLctGLkxvsUOdI1wx/L5roG14JZy5iDCl26B037x5tOA/0W/nPqCxzSl7H6i3HpOVTz2NGFht+YlESdw4tFNc11jxnDJlW7aLPZ0bTJYODoOVs8y0g6kyWOEjv6NouZ9konuQoK7BOCELhAgHxFZi01zYQyCD3dFW0Hj2xiuffI0ujSuSDoFBfotC69qWeeLnZ48MD3LgUBQSyxFv7J876eXYGXEH+PRQB4pq1dnJiZ1WXV6a+EziRkJ6xU7Ykgr2siJmFnYuWXbTME4i+S6B+8dsO9nqiEkamV4qNpgsBCqlPf3KAsMCc8t+CxgHFAandp7Jlzj3t27u+mPb0UTWb5q5XPEbJo2UgGSK3BhiHDvOLF6z7Ocn/CPLCJeVo4mUwOgwn1Yj5bJAWXKZxRHOkW5x3AIt0fPIgVExGjGlMV/mOOHOXY/+5V8h6Ox0qJPo1+je+pxL5w/TwFqlxWieV0gjzeWOIkPjbzOouzcohLh50yW1LX8zIHVdKGhJVvgkJRJ/M2QU17hqDCzlDy+LxhyMSDIsdhxYje95lvdAL/ZWtSh009Q1UHlymVVL0E+/zMmU49PZ2UTe7o9vSaTx0nkqWvgGo+BZ9RiZ/RPrgy+gX+Pt8WfZ5nCSoMR1CIgGykkGRKF14BUhl8Y1o4IwYMnGMwxXJNUpcf0aoVW4FLsmqwFIeGk+nXF7ziYcGpHudiaSHYBdiV99iO3S2hgJ6o64xg+55Jxx9hQFkxVdw0y5bkOJ7iLWyV2M9Om6SxOyuO/ciglCN2CzdxEGNlMeGOSt7AKLH5N6U6m5KajEixLXxCs2ggROv61kjXEoXxZu9DyWF0WvZqThUlEoAuquRLGHfuYS+oeeedg+kuJtLilovsiDmPXaU5PVDzueO65hYehKKkmOyEY//c6bSU6n5GEcOLj5lcv9T+JVUWetvJ65AezZMAZLNlq2K5bICCj6DBQPTavT3nv/IpCvdWGrjYrESHsLUIwQR8E8z5wM75VYKvCScgXGhyBJx41fi8Sg9HelO0hi0wqqSZIAoJc76oCDE9Pi0+VbcaQXRceBZY17X6Lb9KUiu2s5kijwReb3t+GfdopRGfkhr4OfitwLk+Ee+y90Zc0JCPjeeR3oEgwEM0edzJwHtv4rrytc1UHfk4z8pJZuBCifB91uH04WczPbm6PpuFIc0W13ApNG+y2ctPM+Ee2s7s6/PyEzjuM5SKoiA3RJK6SIqtMq8cI7kjnC/LEUuocoyQ3/9tOThqD0Nah18IjXoy2NmG/997crybh0Ztrw2N6oiXbKIU+tviopYHb/5mceqdbRt7WhreOnhiYtXNYrosctTGQSOOVMOMiuHNpCMkjfAjBa0IzvileFZrhsT8+PkYNOYHKOf4b//6P3E1sDGg5PkYPAxqlCHrIdbGO9jCPo0X4lM14vy/Uo1Q8FlybvkXyUfMdvEw2ARaGlm20vbk9GXv+wXMAoyZ296zcT38mMBrhIYV1Qh+/K0UB7CWdLxBQqhRjz35QO8RF+t67vKuHic6Jiqox5lM+27yKhHKih8E5qVw0XAvgaq0PdpcR6LV4IBhwojr2HHgTFxNiofr8gqbJZ+/vbh8lEUbWEjKYjIuFvNWOJJMY9rcFymBjqtxV80slw1CfHSh88VYYe0jgts0GU9t6MKHnSr3K2UDiehMDFXNCeIZvYIdv6LzdqWu0/ExTYqv/ZUg1EyfaEG6MAqpGIdP9aV137953/v+HNxycEGmLRUslLnlCLh44PXtESRr51E1JyMX8QLXRLKtNUB0yVL80RrgEIqq1EPCYo5CIk9hGFaOhMxh3TGHlZ6AKEecIfKzSMDIbCDi7jAVNaSoYti/wgZIiNeZI0sBOuTc1CgirSu6QrBI8Or8LGrm5HN+WlKpKQv+7NUPZ89fXL08e/Hq+dXJmzdvL08uz96+uaC9rGuq4Zw3izLzttuKIPDvK5RipB3I8bihXXP+OvHcVlNQr23wJllUfyxyMt+wO6citFeM3GtnZ70Xz5rH0lgh0/eDiOSsYF3PsqPs5kfpfPXsIMmBSV+LjiCOJBpGvcPcePnRNKTChQKlBBBjylXi6mOgh/IDcsu5mghzNjc3v3LEgRgmzOwGkSO75m9hDVQtI5mzzOMjYR7tOMcewQGefjX3frdjdgiex8KE3+OOoh+q0sCHCD75AzHyYLNLignhR3zyhmLRgZd7KooZRB5cPBCK1/XnYDyNEGI02dXqY/QMC6rtpc3c15OA4cjLBCsHpBRPVm0QqOybcfmZAIQ3Fov7nyRFQDvz4aeLsw8/fW8AfilFSzRqtGruPKnfYM4TT5dDhvYsMGzLdNyTnqi2aM2dsalwE8mYRbIoXSKSKRHkDPs1QnuYTrP7G3m09Ff7IJ2wgxTz2zD/8GjRqIzn4CiLoGjydjip32fiLdTQA0YKtGYdXIlTW3oO6jDr4UbDC+Sm6Hr8Oj48jp0Ic1PFJzewF6QlCKcS3M2lr23hNvhvFp4wzF11w3wEDoGdmSOLckcKWdZiYRLuv5DOoV6WhaX3MEWFwbWAA1i47oEuD/KIc0cb3qLb4N6ZIIoeg/VpZ0wE99h/qIObfmbW2xxwD4zcFihhIDxpGgpIbB+GU7eXTCS0EPSopYNzp4e2AGfZx66Bfd+oNpjBYfzUM48Pt5d0OEbjxgRGglEOuhRJNWEeA4yGm4pOOF/mKucG7BjOW9xWFGirmwop82/ssmnC1gfgUq3xeVzd3DBmkrN+fPE9VDP9yqT4XE0WE3ATmSl7jPEHqy9tq7nwpKbvmhgxLu3m+2s1VCVXakdTOmlEky+9RT3H0SPYpwEa3bACDZZ/uq96yp/HGUOGV80VgBJEVZoXews4s2kd3t330lGt450TE6jI+oegFtRglv/Dz0p/DjD8lbqYQL74mq2XrjVxqiGzSHUTiPQqbAUaCEDLArdq3xID7DXDkrG4nkw4PljunajFMPoFViMyZ/lEqvAx8qygqt4Z899jAN4f0ZZbh2A6UGqJ28gt2xAuJ+9E/fbV2cuXVxfvz8/fvrt0PS4XJXeDkl5QBOa1npB50+RyKxWbrSQ0x8lx2VrhG3iO/gajkkP1ctw7x0+9pV3b4PqOV9X040bvndEyG71LUQf4e96f5egzCtXtfTn27ABDdduHxwcHx3vbEfbscCn2bGf76dHBE4s92/vbIc9s6OhvFn2D6cE5W44QPcwjRNknRSDxhikkVhk+5XJlhymm6BtOlKHo4/EAFUwz7yw7/HDew1TMGX1q7fhb9gl5KBp8SwYPWbnEjKeWjsLRsQkn1jWxs9P6FcPQ/vEfsghOqmcU1q7gJvaCuh8qgChmlVbugLyBdaDcA0xCtQMmRXakAobLEqgpuDholLYkNgCWSGoxcrvPr1A6fEWb8hWZRl8lomI3FRU6v/Xmtp0ZUs2knGtKhQ60iuTyksGm3zrSIiF11j6zpeyMRGkOhy2YAvOUVCquC4/ce4RnoagGR082evrPncdYbqSPSqyoVCH6WRL7pmdG90/OeLTGy8uujLWTwlI1bkHAARf936v74WR85Wyhq/rmyhOioAX7sXyI2AWzT+2wWCiH2ixmczH8mnm+4UyWXjUxAne7IyW4Ktx3hEElyE8PmkjOACWR8kv5RhxmMmxIF99Xf0DTWTLvoDcr1+ckOsDvp9XvQWf+S0mxLvlJ+Hkr54dQYUruVXbNGc6fXmaq47sZ8GmQv0RQT8auqYXjqYXkGTsdz9CKQYW1hOKnuEYSIB2DYzjnHOuZ13PyipvSdZKk6lV/ZbezeO9dVa1fqnO3j3rbTzGbs3MY6dyjpTr3aHd7d3fHqVz3/L+N0u3QF1b/wkKw7OvQwNvdGlie2aV89c8r4dw7MklEeg7vYJoITYd3zitPmMtr+OApfnB9LHf3M/KZLFzkXz6T5SceUluLZZ0vlNhhLbudEzuMgL5x7dsCXc9ojYzZ7FwE+YmvZ/bC0FO/8MI8GWw/Gexu44XZ3z/effJFBRI7+/u7u7veSHUT+BsVSCw7KH9f9wZX+x55deo1SiBgJj/VmNJCFvW1zc2uJ2TvzJNduTJ9vjD/t+Op55IIYVmnKxPmM4jNAiemd8bnqvJ3YndnveIh5/363mFh+RBhWHFifnGE1AtTf/Pyr11ItD/Yftrb2T3e24Nj/EX3ZO/g8HDn6Ojfq5BoydGwt0TP8r/H/YDByYGnC/EkuhAk3+t6jOHeS/5UjHSY668zZ30X+U+Q+x7x/HFAeiPK8Jj49EMqpQnvs9l7Mf1d/RB7mhLR2uDBg6i2t9Nn9X3pq2w3yBKblmT03jYcoZdSawz0kFsFGqxplQo2f8UODp8e8iXbc5XJWfcu6Amjzet9gfdXLfd+JRv8phhmE9oes0BJ+4AI2DZnRRBoBFyAgccYVHKF6MbczeXZC/W3lPSqAA8QnukdGo0uKrIAOyogtI1Q3SRH6GsuLs+bg2RrU3b0qCsBn6rgVfI5duYwuB0TdpzeguNH5JoEebPxQo+FKWuWrDgmsAIsjHxpZtLD4XMvq+nD69MX2tmF19/CT4swZ4YLpq3jiq45PiLvlIYaVSNpJD2bUVt7LE4At7YJt5dPeAf+gHbGxNZ5eSU2c7eYXE+Jo9JVnxEwQn/fu0Z2aHDlEgtoL4MDMukFwp579ED5eYYVIOGdFoj6uxcXlwQrDqb/ozTOWrQ6jOVUsH0VtE/9bKE5Zk7R1fB33FrzwiAjSLsKEYPjBh81xe0ApMFghGjxoDXshqk9clSXfEkRywEO0wazbNXNOtdSkTOSEcdfMd56yrhahd08BK05vdh5J9/XVDI69tf1596j68WcW6xu8JeYCpD6xlh/8/FmD6koNpCjCCPrBOvQp/CkvIiTsfH1CHxeaVkO4hYraQF3XcLfsMYPb+/NDb9GQLs0qgqQiBFO6LyDLYPbnuHOI9JnIvyNFAdvSjxbzNrgWrtjtoQY9cBjJ2AWYWwQ+oc9hT5hmgJ5FRH9/QiNJ/oNs+FL92L64+N1Z3eGzXknLPTaCn+A0zSYcIf6YcGAtEmJiqBqJ9KYXpIOcW5LPP4RO0AqTFtsfOb58UWcjctPsIttFc7zg91FJLB5/eDrVPum4zJt6gueOXo7usf9D3QsieyMk7WUpjDyqC/7R5vtvqd63/XAy86LxF3zKaRsRlX2VevbR3D7TlVFcug0jiPwqMK/yvJLZtodJ2Le5n8Una+yHwEWb0ohw5xRob5jZyT4osIbKuZUWj0LzFsOnFQ1GniD6a43bDNyqQHjBZKmxTehuFxDuFCjAdbfiMHu0C8o/yiMoeLGR6mK3mumZlZCOSa7KXJakY2lQCzmH7hi5iSwJUb9+0U1/EghVMSWBMpVmn8ECJS8wsO6rAzQzhsjFE6k8pJEiUpMbVzeFsOH1GKUcN2cS1FwuPQssGOok0GT6GhzL8crtikOY8fFIVnga+mwU+SMtCDRzIOgKU15LpdpzPHqax92rFlsMMQioci5r+cjA6z34OMaS84UER1JecrIIkZII1yX1EGZ6fQqY0ZpJi9jPMkrOnCImoycV3VdUooIgYKWm++kgQ/ie4IoiGI458YONB82wjtMRZL/iCZ2nFmoQQa+T6vOa6ic+r4sVqU2346CuNXYf3AfbiUFW92CRRrPIdrcwukLcxWw7Ox76slB8ERQgKXgRtFwl6/idzput1Dpc20xHVFCB6+CEsM1LxtxmsYMAOq4zSSqGv83b8xpC8yo21T3QxMJveSpfBrxcCL8AdfCI7DBuiyoDKSe2tEoSr4hLGD3iBwj74VAy+bb8g2sMoeVHWuDDmrk17l20S3B71CK+50iytKX0znPm+r21rZetvole2Aios8RrC9bCOgPTkA+Yq5FAFloUJJ8G0muq8C2Jw+DeT3A/w0vVdXqh1e945Q9M1EbQuBvFETHaeQL5khxbl1JNhfrwZ2O7C4N9BakqQu+CFTMaOoJnIS/p9Z2HOkKmy6I3WCAp96wQDeKIGWY+dzsXZQly+w//0klctG7a8qbb13s6BYGWFxTDzsXcN661fls8Zne2jnYOzzq9+ZFc1vOv+1fXcNF+NjHFf+2P63B3phSrxICHTZl0//uZwz/zVbxnaf6QgIDsbLXOKSLqRYKgKsEGz8Xzo7rEvHIpp6iezvNemN15nhctQ7ycfKpGBW0r+/KT/V4QWNfwPEvm9WnS6QuQ3MKjAmPPfHoTTKf1gqj3MVz3iWZ+uvcKumUJpnGvHGAr9m5OEI/+0nkaCVNUxMjYkM4/ajftDPQl0UtWGJpvwourcs45Ls5mGHmHATGnKg0qf8clZJO9OXAYwn6+nJQ3f80z5uD3eMQ9W3FjYbw0DXYIY2ylQxUMLMAS2KBqrk0DgFf/hmyTwwp9IFrFjzoBbaedK2VuPAQOSPUj0edTN4KldZwlQk/8NFjDizm/yx/DUNvbWoOkGMkcTZMMnNuvXc25z4VHLlH9/TBEZhQyUQBRu/t1FpV2U1N8AcWFYKc3/MBnHVkIyNYXuBTCpFvj3pl3TbYsknoo/HIs7suZJbDcUVslekWeis2rGLoa5m4yjw5FiRHcuNMe31f+VTBvz733ZBy2vrqiOGl7ieHbgnELjvxprzF9ycrDi0iXM8DuQYnHJNE7v2KP+JcUrJt2UIop95XVOQ5LKw9ANldS0Cur1HccFtFI1iW+4ABfe2nqugqPQrevTOq/NfdWnOunD327uX3EuS6q8D2QlUDCgY/zmaz6ORlA3pDUYxaGlMdRlfMxLcQ2SxajVfQsUHnkeeuEbNLCY+oNKcjds1k0+lEjntvpz7w5txAjhBQ2EXKTbThK0u1gkN9GLOZs9eiEX3yjt4Fnk1ayyGPfk1CEMOpPs19TcaiBJwDz0nX5NfFp+KCgg0rw4a5h/6gsSQnWrh80+gq2mQJhAi5Ud2w6l5Q/ZC11fjLPyPgtPKYiTPE4UaspB/HSR8hK6qnA8I4G9plMQ+qhq1RkMYsDjrvyEGnE5/e/f3OTI+X0lLXSoG6uWJusqOlcXadl9npUrFSNjh3YTu08n2QyMbqoIaOham1NWxLZy9FNUI0FLc/9bRA1P5Iv+D7hWPj2NCx63S/umnamb6iqf6AvsmYea0yBuSy0JTVGm7MrsC7bV/m2tsL//SyXU1Lj11kWVR7f1aysdPX6z7RTLsJw0xIARJfHHWEV3z5XA0PwuTWroJHUJ/+gpLZiiBgsJo01EbkOPD4AT3oumirVuwwbKk6XTMYmwnC+VCjmMWR0e5jC2n+Vqjdi6DNgdsfRa0RX3N2UkGrpq7tFPGtfbIMlrBwZabcLTvQzcaOT9Or2f3vqqkxSq+huY24YUm7uFYzhVeSUlh8nzhNati0fdQhI89spDzih/NetfHHBMchLZmQ5Am+5KpKMi+301W+GhZD14GXHpnUahpjmxMNL/tTn3mr/owbjF2BV1o3fYRT+t6QjNElhgBEOxBixWQDsu+QpuvPJW533cC9okbpJnrXqsBcoWrtMzrqc7l0grP1faaE+7Yp7jGSAFYV8dLpW+RWwiZ4dZRFM/4Wq0L6LqWMry7aG2QdkRswwjoY8dIjp91N88uK2JH7q0XV14q/mwL0DjM1+fKsGGwQKakkgxQ4j3Ac+9u0m/IqbBirmpg1FclL9g7sYgWjMTLpZFqMH1pK/zKsQ4O7F/DlcTl4BX7JBlfsyr/PJmTnvX/3aiOOMryUIvhRlOHvOp/0KmC7ijPfwga6FpBYk0xtmXg/+BO43lQrzp4lXJyoVLidoUDXZRRvxrkwsspBuI9kVTCKbxyLSjIIuDLFDj2EQ5V6sM8ppvb9+7NgJMvtj6/pK7MlpcSeWkNQAPjcluiCYBBdypfSNtRpqWyVNL6fdXuxVnJYMuMsdVZGjlB2NNKPZffoAURM9Hu2YvDemYwArga8Y2SoCPJDsm9uPkJ7gV9wGZhJQSyH1HVSBs3MhyTf9cPc9gvp1dMgJkV5EXKx4FjWI3+/VKNVUXE79xSuqfRMihSQ1gOF64A0mMllRKEOCVLBi2z1zt+9zMxYbfrYIrPRLDN+xtA/d8mRSFc45ynIdognwkgi1hfwMmfnl9jzg9f7jrnkqPwTbJzZoiEsiimZ5SL3Ei3UNhKgLHLJ1awmOWvf1fmaAjqFSXDsi7Ej+PU0lIlEfHLf5BVjHoN4kTX0mti/vNgqDrTn0052ykcdLsU3eIK+IxF2xW9+JfWR9Af7IOpvS0H8j4Qv6EzI1s0MzxeemtDrYK9A03349zQfIMy7YPuU04UIRp8Yl0YhN0RgDQ48OqvGNM52AerMSfFZoq7msPimthlzqZRRNBLe30IlcesCiZmxG0R+SjLXiUi+wJJMpNLfMTasJmsb1Kh7ZQfLy1q3HkjHEWy1EotADKFlPa/IhhXqZN9xJzdsyMXg6rppZFj5mncO1of02rorwkq6186KoRFs3vRkicq5OvBqppjJU+Qxaf/coDpJxQByGl/uXkQWAmqB3MLlW8bUTxxqs6E0205pIwKp2AMejuxkwshXRto4lQ/waD2Xw6gRhgR93qRnVFdelUJkvJ56BVwGn8myqWvsindnYcD6gkxECtPe0IGZ6wlSySDWGT1UTBmsahow87CYmE7IIU6hbgqDmHJQhhWTCm3V6CU18ekQAq6aikU6OTa5fKdaFDbOGB5mzIKoCzqqjQ7nVWoLDPv/obz6WD7oknBqbm78i+CdjJKRtU0hTDz4h/Or07dvLl+8ubx6fvZOhs/KSfbx9XTxjZAkmpWD6jeTYysOsfM2+UTTSAZ5RdxAcTfMrG45THRLWi8pi4beA4bfdMU8VRjG6laBnzJ+bOzFzu8ajsw4959CpX/+ky7s61dXpz+8OP2XZ29/e3Xx4tWL08sXz2U2f/6TUlmteDh7394liw4lvJQJp2HhAKxyduU6eDFcPKVSFhqPuwgQKe6RAd7Q9Hh1VZorA+6UnDGenhbyG/+ZSlGk0GGV7xOWqgTHlLRpdFajWx3HUczIEgDHuajlY+UzH2aKv186mhtOEoCeYGa7kECrM0EdRa5YNaKNLb4nbm7o6WT3OA0Nr2mCoIcRUrSsiIfyRrIdqAcgN6OOMlwTGhL1Vk8z3mRv8B2j9shmTT0NwgcG3IFCf/2JznNLDvwNtUACmx23x4Qc2L7LbI2WFvlpOqtCQrE+TCWJmVyqAx+JFrm4cp8qXm1LuzJX2xS2AMlXcjCazAQjH2pK1Uykl7MJhs7t+91vMG3cew7vOoNF1maty4Dgp4wl771Qm4nNjMfBg7FW+uZBc769SaXhEKmVxg7HEo3QJsd6yDMZhGWXh3NT2tq+9456U4hbLeqWpDQifiQFSbfAl6HIlMjF3kAA9xQd7crjsxjiVailAwufxDl+fv5lew2SUGMDmmvDBiRmlyjFVOeTL6vBsaHXFMpG11FStDgHV8pRJ+3lsqEpS+R0Zxda+gyRENMSD9hsDDe76e3srH4SwcAxcdHMkyAzT18sOuxvYBL+FxevcoOz/r6bT8ZqOzjQNP9JO2nwH70iQ1xxqMi6h8e3RpmPlSB/2UhNcZ8dYJW/7blPc7tCC5uj0bQTcHadj2RQU1A9phumXYxVzHp+ZyVxJi93PsSq6XrGihHFNqqaWFZ3H6fpYkLBHEK7xoxjXfbDqhBLN29rFUcxN7x7LRcwUI0K1cUs4PhhGcaST8D9TIFHtfankQNAzS1WXEqmbeDDuOdZVnorVYwmA/NWJR2JJAIbubOc76wp9kxLAo6U+sLZQRl4NEaQ3wNhtwl8xGEOCd+06z7LofUMbC//WHXdpJE4gRKMoygkxwqQdC1zs9Ogk0MtU6JQbICUo7Qqt5rGJxL6c8R1f5j+hhlmlU2adYINPBZClI7DGL9GFGaj+1KQxZVm0MwzzvgoC2ZWFMo53GhGm1PIBOmDFkIP2S7Gcw5NGfic1Ldd0SAZeJ39O/zZdznbUEKomvtQkZi4oQRkfc8cx+g60POZKE3uxnUaMjjunYCted0OEdxJOP+0JFYBIujRfhWk8Au3kRWzI8Fv+vywvkcrUEiqXYqSgCW1YPeCor2OkZR7xoisnOxOXGkghrBxGUpPRcjnmZ0yjH9kHnUh9ge/YyCNhgVW61E1I7zapLI1fqvgSOYJz5r6IwkLI+MpmJNxDAnL4cCTIv7VdGMQXNO4ut8hcUnjVYn5eA3Lzu7mzmE3xwYVWP8cUprdp72dAyxP3/4y7oCdvScHT7cPHXeAm8DP5A7Y6eIOgFeVC5RnhHMl9vDBqh2gX6tPtCwCO9S1lHXAuBwwTuTLGeN+IV6BJ8R8gCKFqQWexn0WnnpqAfbXCaLPQJVv+3fV7d0Y/jPvf/cK3jfPvBE8I89AgE0NeHgchgu2qagTWZ9GDlOi4Xdsq84f5+UzWoUyblQ7iEwC8Ek6/WXRUuUF5trYk3vGQMOQu2az5yexAV6CMOlJp2BNdrC8uXEEHwQXdRg65ASdPrCgq4xQ6uDD2XO8c082d+nQpDSQ8HxMKVBhVWWVMCowDdy2Dy0W5JCniNGQMF6XUeCmslbWVRu0KUSSF4OBjvIqPjxeBmUya43vRRMVEVMuV6geXCC5mHtEmpWwRgA9QUmSXSpMVzOGuhOWRn+2jVHzD8gOr6QLHojjnQhxY+9nn4hjh1jlQ1EMAzaWq9YBq1oJt4VBG3lWZosRikMGB2/0x/Ih/KoG0elVox6H2bfd7l7OxOA3wOnTiws6+7++oPeLcb2tD8hVjcNTZ47NGo/Jjw9ShMFJikl/hlwgDwYOwMkr2Rv1wNZ6OK67ZoD0PoTv0DGpW/kSVlzPs4hLf4dOGtjYTNMA2JS8KOALxidNm7BQ/FfQ1aeXJtf/zCCUu+/pA5abNJRWRYoAF+ASyChTrbDnytkqsfe6j2twzX116Tvs0f4aQ5Bksyt8Mh+IC3iZU8KYcCayyvXkmgoauOqbEBXyAbZpPVJvWC+m7PA2OpTkl/BQcQHqMM8VGU3N8wGwVajBOdUNIPlYipKhJ23pCO8+9X1i+NOf85UTweOKhYYIsDqvxqWWXAfsHT+I70I1pQIYQsULHrugwFI1lZpMKjnJnLyjzYPs2bNgH4mfvS5mBugEtrENGHlN2l0j5KKzyCTNcWPH8x/AkalMxzXdKG6x2HHOxi13eADLLEZlcfKTs5yf5+CPFezPyP3kC+3peNgbwU/wzPEqcXu5kw4tGioZn8grJbIyfrBHcX5XIXs8lk8pzT8JRpFywpqRi7HPqulUmyxjWK41s9Q+UlI6WJCtgTKotRG7/IGiwMmIQTG62NHFosK5H6lpq/gY+kEKpZq605age/Aa9Twnz44295epGIv0nhQfdX/uGwQAN73nZz+6fdO4O81KDo0IZL10acJmQ4Ed18zLYIGHapzwC1B6BzT6nNFltMqrKpqiIgiJQMuAQumUKooQdmMUnrwNQ8Oya7m31DxBGcxE60yvMq9ncK0aJyI2MpOhkx7rJTXylliRmRvsxT92I+JkM2Wfuqqf/4LhhTaIzCEW7C7dgzudJ/0901BhRl2JVWo9Yzpo2CCIJXz3ZHm1bfCJqwtHI1emu5iYSgbqyjWpR+zjMB6FaAXhApbj7lq64ALfGnGmM3YNMWqjvE9+ffJbqwCc6ltHzbGwYZCfRKeKDqEhWZg7DBaJ0+A+WMi56rDAppjoJ0qy4YNfJqqrF4u3cUZJeoRzZ7XLumvnDxrxYXCui6HBZ2ml5J3Ei1G8jrRFYZlomGnoeMhgP0qPa3yGWiOZqjdnvHLzQ2y026hX+v/Md/ixarm5EorfTNodJVfexdVkMiwB9f0OMatWWEtvY18pGAl2vNBKAueLUyqL6zrwkfnO9dUIpStclkUz8kiuA9J5w7m+lS4R9G3EeBXCuTUpmo85H/PoC30u44srJNwBYsmOsM47FtqxNMKwX8eVMIRuhlyC6j06CjV9Gb2vPhQToAx6ixUGo0TTScfSwpLc0izRbha8xKeP3J4O1zMPW1c9qXEtWVR0km+Rw0ekVlQ6KcwsnHKiYJMIQj12FMDqb2AnoHA2fdKufUKA9OVp2Ql5tjJYaX6camyPmmEgiUE5wTmvowkP0RY8lVoy4cv6C567oUUNX/T886Ip4NrO7pY9+kc9shQe7FHEWvdQFnyUbkhYJsfj54ZHnTIy7ZAoM8/fIaFBHFR4iHKnfQpeA1Emoj5O/ir5huT3Vv1npvRl5/dV8QBWT27l7Di2dxDVKyLOpx+BxvD3GJyi8gIQUGUzm/et7XPX1Ivbu7UK29MpFAoxouf8qm/gxLJ5DL24+VILNPPcIJLYaiKSo2nOa+EPUekgVk0ODQjUuQn88ZW6IFTN6uKW1Oopc2z4fG2EapaVKwlMaajaw+yP6mzebdTZa2l+FVyeRpDZ0ZWciTbhvdBMwGKcv3vbp6qURaNtkKTZC2Lc5zQVZ01MM3Cc8O4sm6Nmsjv2lwo43Ryd7Qs3rSlsPFGzgdJiTjY06NeAdk6GS4AggvPWxeqcLYxZe33gWqu89Lr4GlgX3GNauJlKvVbnQp/i8mvquzmtMfU468uR9AclfpkVUMiGo800Q42iD+LiSowBc8ULzeD792fPqcGFxhJCcNaUt4MQ26S/HWrPyRBK3WmwhA1+DY/2L9jeJCog52j0ncfe58zLS8ngxoVrNsCkKPaai4boCrl0v0v2ZgO6dhjWuaQBYYf68m1PgRAzVvTxhBTjDWqUCI5RIGgIxyJj83nsB0U+8uWMQXO4ub/U8GViA8InC7TApKDZDU4iTe7ub/DPTI3weVlaA6exvtFphAudtf4PJYiTxhkzNafh02C8u0CBmQ729AyLJ7oqfWl6y8IaU3MoGJ2Aq0IEkrUWZMshpbARXskfLjEcpzSxzGHGArkzeP2KvCAJNaD3owqMJLg0svHxNzcZOrXma6Ie0BxQ4J0kjfLJGgogeJ5muVqiPTCKoBzccaW4Spmq1eJfinz2/lA2iJQ1ANygSXjnvqdWP5v5yAcl4ABDv8NGf7j37uSsJWavx8Xwo1pNxv1sjTXA6s0xnhHLPD59TFzWPOG1HsawTHkSP8X5v7TSGmVkji/qY8WtlrTnJEnOkQtD8Bi+xprQKKsFN5mOXt1lddkG7af6tYwb6rQ2iBVBtoXgHQKLC+6gU0RIjYm/y5qw682+Lwq2r9eS3kETtxoQQvG6YYB/MAFGOXKEtd1wYDotqf8rP12QlShi03lwtjBsVazKjfBHCBAqpsxwirFeKhRXesk4g5s7g9cM3bFhTdcIrjWmpdgEdvdWD/5yQUJQDFVht6OYI90gzETcqOFyx4Tn6qSr2cZBSzyViQG30buu8Q2QjMjc3i8IWH04l+vy0gQKnWGE/EaJpS3bTTGHdnF7i51g66krBqPNIVosTa1xDT+3KSVR4b7UEeW0/OJ55upWYxw03oyo56Td8qieGwIjzcYb7ngCM4qoIOK5bPK0a8HYXA3dV1EM1i4J8ghk3CSHVOt5av0XSDf3aWVuX2tO5L4YUW1AmHkhFiXpQ5G0oVjVkUAMsz61K0frZoWyuExu0kDA7JhV+w/VzO5mV3YnikRG1hgfYjfsllcqJv1ZVpL1c7I76GbQo9NDmdq5873nnaVLq4tUhPyJnU3Rpv0XmJECw9RbvJcINaTf9k6LcYmskX1tqYIi0N+caa3uaTCJU+Z0doBDBUK56wi/j1MNo5J4nOlOSR8B5xSQT8dkDqNFE8QaAtswn/LyRmqwKMcoymU1nPUAu5e3TDoHKaeeldT63cYTofaaDgAeGc7OOM5afAaZU7Qteu/ejODIba6Cj+xqRLFGmBTNElNT52j9g/B3HFkJVjlxDxh2yr06WhFADaMxStGIdmUMhs8QYDFdKitADsZIfx+Y7WLq4nvOng9H04HAShedOX7YYHBTMfqEknvkBxxXH8vIDsCTZhajIADKpHKBxUomnCs9SiGuO9vYeFGxej8L6HrUQ5TrkwToerC3FOi6u3+wd7i9Z9ov2ln80p2ylqJdI0RnCHjd+fsFvNLMUVVOyzHjXQXuCvZPgT8f4M8xShNXkC/I0wF+0N+RzPHYw+NhPicfkYfiO+52HY1DbIa9s3u8/fR4N2qGfbC8GXZ6NIIZ/PGPf+S3kB0dMG34QHKq2Z5i+HG9h6FOirtRLhk3D/Y9gPU4YU486UjUMIhW2tnyKG2cZ8m0JlMTnwUFFa3KlNGooyZDsUYNOl4+cMofUcH6RTZXWmcRexuZvU4ujmjrni4+0WQ7cLHMPe3P8lr+8Kq6Rr6FLBz4ydMDbQX4pLN8n9s0OLNQ/Dwhgm+09/UysnlujCAceggXrqS1WnVDDRnCspXAo3XKAmfYVSa/hBSH6WDIVolLZ9A3nRaC2dGTYN8hbQKSnZUt7MZJXTxMh2BfTYmtQizo0pXVlJPrkpZVI93O0K2n/lMEOI9i4VEzxcg00nSH/+RXPiadcGwEL5DUgQcgE7CD72phVsDj14rqZCChWHIUdaIKGmKuskUxwaMSesDso2oOOglFndQP85MkDM+nL/uIhFvPnmLtT4cWPHWquhUT0BB0leVc8A305EnCja0DCovLnFCR9xp7I56UaM4OZZOZd0dDTLiPX67r9wa7h1jUsnt0vB13Wl5e1LL7ZOfwaP+JaYgpE/ibqvnlov2XK3P5G7SXPZJOuOAYDT8+DMh4zzaXBf3bv6APgaimD4VdZPMD5RXd4f4xOVx2PL2iH8tyxgSIxNthMhPoe/auQatQnJwIZIOIFHhMCFfAb5QjiXvAgNR3ltCfqKJ4eCKumoqvz49YzFCg4lnd7H3Au0cFLkyrhQzsBfny7bxZDNGiRm5tcIXBjn7gQppPEiUiuiwEVuceQVi2akLIrXk5ftj8x3/I6bvdHTB1ROEdLO19ywrwlZjtHI5nSim437++oHK1RTMkHPT4QR31YN19q7mMnNpXZbbk6e/oXvDTvykn321O6m+24H9JoZBMef+xwcBC4TvvSEnwPboqv1u0mvcd17CVpOhwoMVHGic7rf3stNzE4P94agO46AjhkPlRopWp2mwTAk6bWMipqiRH6+Ycc/6WqLAgdRBMcG+NdeNSwqiUOwqq4EKcXLfYrqSkDeO1JaRHUv/r6JkdJW1bDhfENYnA1/xMRdnB0QYf+7uX4jF+syW/yK2qc9S5IsCCvM9xd12otWi1onlSNrfkWcJ7pTCK3Lx2wnnxKrpJZdpNaF2PK1PYEJPOy9vIjNEQJM58cEpAcTRjqeV3m5vT9rpzwoorJmhpJTfHgtHXeITs4op9T4z5QKODxYbs18okQiAFqfFwXDAC16o4rDkbU8MrPjhxrCUUBGEcjlnzcZ/aKNoSFXpcvvKkmlMjTSQAK2K9EnJq2qgp+BAYH7qvRmU8uAIwmJaFjhShpkwzLbKGte+KM+SYSHA8Trdtb3PnqdxG+fFJ+KNnmwzuJekz1DEDFKplszm7m0nokx4SPoL9kg/wXq25Dlh1u+c+c9D5mV33mf1wbixHnvurxjan+DVCPTMmXj7YraFUXZaIw5TOhVOq0HbGngvn6BN2Oya1aya10/mZHfeZ7a7P6Cd4E3y4imUSnlIq3nCtEF5g97D2zhBw6Ai8bxcq01ih6h+POp7Pzo98qGuX8EP6ma5d2tk8cp/hXWLJw7Wy+plDCehRH+fPcq1nHe1a3Xh7Zrw2LL6FUZ8ydoSgDAfuO10bh4Kqw1w/+Dn963cH22Cu7x0fPDne3o/M9YOl5vrh9tNtY6sf/E2b13dZpNYah4Vgaf/vZ4HvyjSHk3YwLT7ljW/49+nri96b4lN1W+gQ1vxORsla3juHT9nyDgdTIQ1LAfLE/RpNkrFLwWLIiWxigkiLg0rpKrWZyJ2O+lcXZLGPhs1ict2iiV6NN3rYxHqAh4TMK74hmNfFYhz/+GwoaHfvybY3jVMafwxI2CdSTiAk2cHLpcY7ug6pzs2YSQdqjsB/vIkEP8TGkYsU2CuPRXrY7ZT18/CuNI1CCZ0wtIRgwWNXW/9xU4va52dK4wA8Or242Pr1xWMO9KNCG5lZqHrIW4h5a/vf3QnYzRvZf0dewO6un6E/NblJZuDLmJd8rmXCrSFH7Wtexz6ShlyxEhqIFLiFvyiuOiJoGoL0g6RY7or2SmqU8CKR/ZV/38ho/7txJnbXttz/ht5EYJbuh2bpvjNLO6cdyB+a+//5vxPq9TvqH4CQuv+TKUN8x8ob1xVCWhkKdK0t52lSFW0Ybo/jkvh0KMkmxoLQPhn10jq2WUwxQb4hzFICScNVBG0zeHPyIxOHE4X4iBtzO6Iz+CF9vAmQk0Pxldw67wq49g/Z1WVbj/SRpmVdYa6wYWD6BNnpFrNNPJoXpXTAU5WzOWGmQtc5iRXlTc0nUq8pxcE1rOrIuXQePh/wRe4FB895Ke5xw7kjwk3v9cPZxclrkPK3WEAbMimQOBqOr8AOuAJVesXahq5z7LPsq6+xxGfZVwdkic+yry6E+3Hnr+uz7C/xNfyknna7LG6cJ8tdln3xKbIOx/5SX2LfPWO1N7H/C3sT+1/kTXR6Crs/K4m/h57C/tHx7tMv9RQOA09h92/oKWSM578nJwGz1Dsw53Zx7f7aXk0kNU+pekRflJ9nVSPOAf26Oj482nkC/96lj+zijj20V8Jia58Pk5ffXkn8JXo6fJfMMkEp4QO2j/+H/AVLOYnd8Go4C/+idN6DSUF/2d3WydIBf41xcAWP0A5M9Dd7MKUTRbHYfsAt9z/CmpxFMZatKoY3kzGnFo773zfgQsBl5RqH+NNwbm/1w/BvSz6e+ej9kD+KK0RTPgFBf0ZJWLdwJMbH40Hlf70rnxY3q+uQ7e7oQpgn45fE8+HPY9GaHBIpQguzMM7P5Zfacx+L7aLgwzTRXR0z37HWfmE+oW3Zsxs1MIVHW5L3BSWW31E8wbRPW7xiwxv9rN3APbwpvIEEVRhMzNJEzzBbidLlvq6HspXht+h55q/m+7q/e+lGbkU/uzfL7/nuXri/8Xpktn8f1gh95hnK5WDK+Kkt9ycdIz4Ru08yEY7oueHh2Nt338DDsWT/wnOyp08yX5CUJ56Tju/ikfkjLTP4D3c0DontpzsHxc3O/pOn10+eXB8eHR7sbO8+3RluP9m+Ptw/QJET5l89HAltR/p5D38Bg1Wkl/Z3fD5WctlENnYPSo8Xd1R+AnNupofaEvnteTzPoHduMuFeZUbfNpJtoMMcuVFCtYe6UdWeTHETzqGKH9xjbMkB4tyt5pV8FTcr89WtYkg0TXQ+2i2dkHiOV/Pitg1V3Qx0JJrPuHBHqBX2Dp7uHG7zT2YVd56486WZpKJ5iJZrV2X3gPgMgo9lAk4yC1gEqg/RVzvcy7/a/WwgVStbixmhOLbAsNjd2t7Ht8aNBJu83tmcsfqCm0geASHkdlhTz4qGtqk63j3YPgT1x2sgisgrzI6X1bNlg29P5JWTdclF2FCAMZznn7Q6HO2Tnuyat+60nXnvp3rBHQkRfKT9nAJmRekW5ZFCGq+b+v4vhWsW7rufyBrNwMZ2WASyNYwhIaZKdXxwuHMollXy9ytkioq2P12NeORqelOrlrkwf9BIf48slgcVZelT0fz/hGjsuTlLeVyoPUX/jNYauFXDopl/u3ewc3hw8KtiMvv6evFwNa3vv92RiwEHpbwvGPDINgv8UrrQm1/C7EWo9NmWcqAOYTYVeOau/GLAW0GyDw6+mrhmRDSq72DpwgF3jRRrYVHBdh0M76pxAACNPkD22R/hrD/ZefrkILnSMPUxl8pH1xj+8Mr/IXOO8YY+ZwoAWP6qKQXmp8UKlHCcVtTQqyluB3AUBxjWZeTGTTF0xJ7hxe+QaUsuvrzAkpu/t+7Nx9XHxTrY2d9O5R+a+bJzwVrB70/c7zNLhcfwVG7hPcLPPDSSWEYoYi7XszZ4lPwC/RUk4/aXr8/e06fJ+sCSgFgaRasDT+Iq3/ziHCGQhchvKYzH+FPOfzvyx+nI8TQ6CgJqcIVlzINyKmCeTcOimyzbzhcvG77LkkXb/TmLdpQsGozp4ODhqv24hPf3aN/dvnlAFKCZdsfoNu3djMvPHIwE5841Zb1veEHBy8+fs90vWbCdLVgzeo9fQgG7Fds+3E2voWWMDlfsUn+dzWyhK8PhWIr3mR5LmLUCl72k1th8DzncTw3JSTu7NMmGYcP03DL0GRbZRl8T3NkobSymuSvHM8oqLKhqZrKYoitqwvqLyS+1H6xsOvfjyc/YDooWJCrEACFDFWIs3tyW7MNH+NaLCrkvr1mLOBS4t7EZOJI7vpxRnMH23GEI16UWhYJHiFNICCkhz0aMosZNVNKYv1zsHm1tH+rHaAM220/J+u8fxBuwna491VVgdldHgzlNhx126L73VE7kY8uMbmv57YI8X2L7HR3sPllp+3U8v8vqQ8/np7Kg/h/m7+tae/Cwg6O9o8ji6zAfAotvZ/vJU7CHfjmTD3cib/MF9T5cwWI3k/md8C97kTEGx0OsaVJDStgx4LJ1MsezJmV1fChrbqMdbgJHX3PgkwbVP6sw2LGo5WJGX3j69XI0s1gPGNxwJ1SicgMuUHGiH91ZqZgYqNIamBcmjYqH4gaLVhH/Nai02dXfzFbmGegfyFbleo/8jTMk/2f2s+teu539VdfuaPW1WzKJv+rde/qz7972f9y9/7h7mbuHa+7idMgDP537fEV8+fDDeu7Pgw+ve/sOV12+9eIdnZP4K92+NM6x9s07evrL3bzDv9bFW3rkD/4+DuoemWmYnb+rm0G4izlFAXt23tS9E/r8F5hly/XDweHTNcyy9Nl/s4O5TgDuaGf/yfZ/WGP/oRG6rLF1LxnG4b7wfu0sd3vgfq22v8LH/jUtrv24uH3N67XzdO/nXS/KhKyQdQkUOSvqsAJvl7FgZivW2SR64Z0nR9nVjQThLyR58DEuynNFSQgFcvzxP8TN/++KG4KyxA8ibEy65Xa7c4B8kzW+NNFKxePbIGYuZbCD+/HNzAE7g7GwwdpX3GEN6Xoy/A4hDZepGzPVZFI/GEXYNnsnQe6maO+ua6Ru9E3dJJWB5bYP8zvHhoWt0WFfhwhTdwDUGaIUR9Un7XtHtAFwJCdl3We+x2/7KEgHxbi6nR73hkS89XX/u28qOgm9thl+624yAfSbTfo6XWdq5rO1c3S4v/vk4Ginz3Rt3/YPQVT27kpssPdtf+9wG5mcYLRrCr5924ef78vrj9WcIN0IzuSekb1J/Yf4V9HP8E48M/gHvBe+3t3+d6dvX5+/enH5ovf87en71y/eXJ5cnr19s9E7f/vhxbuX71/1Ts7PNnoXZ/gp5G/tvXz7rvfm7ZvB6dvnL95dKFB39t3ZDa7xr/7zk92do68JIIxJUOxwQ0AnxOQJ2ADhpf6jGG2eIS0S1g0r42U9gd/cldMWA9vfFL27prz5tr/1z5gtuapG3x7u9hH4+m1/Wt/U+Jr97+TEwHS/2SoQVD/jebmY9k1FUMw59wK9XVTSQykz/P7O0fbOUfIIaevRyUrCEHrXxMi0IMNUD07LxOCPZYaOtSI3j4On+zt7yTxOHSTWZVCoppG7z5jptfhMg7jtesTOuo+IX92191jvQduH3Q+SoalpKShtouxYc9Sn+VHLsKFUdq5cXgDHBLdu/ZOAdOvhMTPirjdZDO/gkcO7KRXhtPPFzQ1xl4IVNf1nJ2OIqobw1e7BOTxN/GwRqPj4ngBgvIhjjk9Hq+VFpMlOCPXi3PWvcaJSXwflwvuLy7evey/PXrx6fkGX/vTtm0uQDxu9y5Pfvn3z9vVPvcsX715f9E7ePO+9vwhkgZP1iaiXi+I6wfUeTcqCsfV+rvSXDcNMKV/W1CBduscbcb8w7XkriSzKTSMn3FRrAxhsQh3qbBrbHTfz+ienpy8uLuid3719Re/PS+Ff8j3hBTJn5mB7f/vJ/n8W2ybePk7jsDB4yOFjbL5dliuXdidGOm4LV95LJum+eNhwlWzIesTFAEHXZVMwgRe6bLBqgMfl+gY8kQ9ksXEnb/gUtzPTxiJy4l8ipcrnAk+acDr6A4gNJkBfNty5j1qrahmdS4dFr818FOZrY9QWwtyCChu1tNti/n7LuUsi4nTfU1lsXtVs7LsXr85OnoEuu3h/fv723aU5tJzmtHVKkoebcYXF72rJfi67rluUCG23kn038sCmTEmK+MSrJnP1M8wbhJtFhsqi8UoUJoYpWTyEuPCjclwhjcgtij657lieX02kITrzBQWLEVzy+Pq6bGTQ9YEq231BiL3Vm4lGE0F3QYppQE3R0GQyVpaX7fIrwguv99EPP12cffjpey9PH3kRIo2JuBHK48yXT4VUe/VcCNLeO3Uk3Mu+8Y4YhummLfvYc1clekHkxMs++xJrdDhDu+xjZ5jzNUsR7WHRa+rrBVJE4ecGsEbVH+RcSKdZrrnJLdXzYm5HNmP++oJ6mA24fWjuuy8mYG4tm/ebBV7cZZ84v4Obv+wDFx/hXZd94P27V8v+fIIdNpd94Ee01Zd94IVSihEkfNknT+tx3fByLX1nJj4joT+0i88gNd7cc0q/97bgbFYJh5sH3T5ObB0xsgONjAVYJKLnBTLEjiJ1PCCmY9IIG9quEfTPsKnbdhCXDaLGJecWqebyXJ4FGeRMtQy6ChSBvnrcKdm9fCq3zt9eXPYufzp/wUaI2CVnL7otEZDjFcaxyvliltrx1n6vSmNGCGYVmwWYT4M2aEvk9Xamh9hUUtvh26TWjgm3ZF0G2mnGvVhDiUlF3moB1CjO+eNRUSwW1bZtzS6TcYwtkXXCs8J9ELmvWjkKnxKeBYViUcciZ3qkA8qBgrV+9v7s1fMe6FbyHk9egcN4uWQbRuUNCviZHuBhcoAzZIymiB03xruPwaaCrHD0gbgr3S0o6c9srrjG8aQ2zUF7/f7V5dmrszffv4d3evfi5PlPiZZspUp2/JCJXZjTIsBmZPGTqbfCrB6URxC1JFGA4RYQ6vmGLQDa3MD0MPVmibmBUGZnW/i1MhaXK7o28RCLEUP1y28xLq7REkv6wbMlpzbZwCEcsVE2eb1CvTUzp+SSbOmLy5NnsK6XueXEfrnMMXhTTHBj4d8SwrLTI6y24f/ccJbRSDa+0jZ11w/put3fb8IM78rbmlust1lf6+0UfLTv6wv+CK/n20XjaAXp4PAVOtje3tje3u5JeLIq5DRtaKtyv2ytEGaSi3b6+gJp2VDL3yN7AdKGS235Bv7m45RajaBNN5duIRu2THLDdPWj4met6EQyhCGCzcDm3KTqrtrM/LZ2HORhtAVrIukk/OYkGg9E90Nbtdp4mCWTlB/LLgsALeC12Hm6f/SEiS2wtNayQ/aCsnRTgSOMnVqE7Og0yV3zOOyAJCzbOcJeyaD3M5Z1c6W1p8+Qvr2u9J2/Rac/fJTyT95Un4mJivsAo5GFi46hLkt1OW+Y575WiGZBfATEskpfm8/BBps4GcftPLlfEzF6pvo6++ZYXAwLdgtHAfs9cK9yVKZ046nEsPc9mqZE5Oe7WFQjaTfA9xtt5qAuUb5kefTC515W04fXpy9cF05af+4e3ZRcpi+2ujxUEBL8dh1zfET13jTUqOJifmb5x2815e1iXIR6Sxzcx/k50s6YsnteXokL3IEROgVDte3BCSlmWm3uft+7RtLyIsPeuue5WzVQfF99RAemnW/3PYGdb0wadf3BbENbRqpDJO27F2DfnJyfhW/0Y9FU9aK1zTxNobQN0/HbVdPZQrt0olCET8DfcbfNGrQxu420WQ4rIAIetQ3xSqjRs5Ly8b0FYVWTaCJBDMJijZuq5IDSU5SblbSgU6ZEg2A6bNDfQFi0d+XI423fyfe1lQQarOCv9R5dU38mcK43+Etke3LUwHaXe4wysq1J5qLIvUM/V5/Ck3LP0rHx9ahbWaXUOFiXp8j/6xL+VtXEpVLc3PBrEOdtI51imb82Ijs87yiBP+7pzmMDHO2q0DKfNZ4tZiEmfwofqT0+tM88K5FmQRddhTf8DSTOI42xGJI7/ePjdWfnSBqpNTz+AKcJ/IYJNlhVL9P3HaX9lNZgfDiDMJWlr1H52mKZNjoeplswbHsJ9nbbVuE8P9hdRGaP1w8+lt03EWzaVN/AwffN+MC9aGpnDhP83oiovvIPM44+Yv9+boKq6bxIAjafyoCLB7XbV633G9j+Vu0kh07ZB6XlvOnOu/ySxT1urORH4apb4TpbiDoAXdd7o44PHgzTP/oZdcl9oWKfaGJWzwLNpYETtEYpwwWt5uhgUjLujphIhECDF4hDMZm40yrhwhSxrpVFh8qptMWLihvbR0Zg97YDMjUDTRUlm2+BWMw/cMXMmS+E+5z+flENP2IBLF6MUN9KSa9VsPmBiWqD5s/MN06oOvtkVJJJWmT0KtKkjTHRcFsMc8TsZG6SmBWzKj0LXCxlW/gcbe7lmOO1HKrj4pAsMDVW0oaTtRmzwji6dSEim+PVn8tbEl8ZdemkV4J/OOpxssl6D+V8jTNFoXXs+70YlYGnRxrhGp1XZCUngWUsq0tNWqT2lLyiyhtHmM6EoY6+qwg9ZTLmPN0ZPojvyV1BzKTcFormw3Z5h/VI8h+bAeAxocOHGmSgPFFzW6HFoRz29KzU5tvB7dk5aeA+3ArHVHULRmo8h2hzC6cvzFW4AG/qe27o+JYVIDVbKrjbqnwVv9Nxu0m2iBLnI4o8T9nFsAqGW1JLr2GO+nTcZhJVjf+bN+Y0y6Lly9n7aR+aSOglT5U+UFNmcdPmekIo+xnuEdPh2dGIjpmts2l5P36QNnhE9ma+Ld/ARl6wsmPflw0bT3atXaZ1H0Uz32k0M305nfO8qW5vqXlZleqX7IHhHJfr2DQqkF+VLhymBDEY2zyI8YbyieUbzPGGO212N8yoWv3wqnecsrMmakOIoIyC6DiNfMFccItlLLWQIKcb7nRkd4GlVbHXiZpaOptySsa0rVcJT22KhahMSI1Du0HMbNIxzrBAz4rCBmA2gkdwUZYss//8J5XIcebrFgZYXFPiywU4tm51Plt8prd2DvYOj/rSt+/b/tU1XISPLtgC9saUuM8o4N2UTf+7nzE85cNxPdDf6CF4UazsNQ7pYkrHmV0lxIiUzP0mkY72Hj1qFr1d22nWG4M7Y3AAHR/AyadiVNC+vis/Id05/uUCjn/ZrD5dInWZE05Tt9LSDyyheD6tFUa5i+e8SwZNrXGreBp4G+TtMsYBhf27FkfIHJTGu6LGbEVqREj/yjsOyaqBviyQwRKLO7diIeX1uBpmfPTdzSMTdeo+B4ExJyoNYw4Fpl09ybc2TJeee+QtmT6AhaQFUPY4wop8XzfwHrhRPR26ZlJJD8NqGLlDQml4XUZsrwWFS6shRUNwzcI2d5/nROXFkptWB+MJzo9HnUzeyhXcyyt64BU/8NFjTobk/yx/DaNxbWoOkGMkobcbeDduyonBbTxmBTeEoiaZ+NryJex83EoDycS3CTb1MN5UF0mUNqVYB9c7UzRmSIk6GnEwFnaNccNKMotHnt115VIUOpOuRpRoxQrHmJhqfZT/1XRRqsyTY0FyJN9zsw/inLIiKIVG5ee+G1JOW18dMbzU/eTQLeG6yk68KW/x/cmKQ4sI1/NArsGJI1zRLtvOJSXbli0EZMBXX9G0h7YHILtrSQ+p1yhu6OZbwbLcBwzIXD9VRa+DGCx4985A8193a825cvbYu5ffS5DrrgLbC1XNHeITiymbzaKTV/ZnVTwVbiGNqQ4jrmfc617jFXRslJcibeCq0tx2bU0nctx7O/WBN+cGcoSAwi4CQ+V2zcqzXXCoD2M2856DITnv6F3g2dAAuUe/JiGI4VSfViFUusagA89J1+TXxafigoINK8OGuYf+oLEkJ1rIPm2NrqJNlkCI9JmoG1bdC+IWtrYaf/lnBJxWHjNxhnyWd+zy6SplXUsCXO+paUjgmxuTNQrSmMVB5x056HTi07u/35n88VJacLMUqJtnW3TqaHvJaDovs9PcekaEqAbnLlSeeTEqkY3VQQ0dy7ZYW2JbOnspjNBIF+yA4bYghEERId4FvRo6dp3uV2YnWp/RuoPT+Af0TcYEG8wZkMtCU1ZruDG7Au842SgAgueSItjLdnU32VXb/oduClKBzUgNynWfIN2xgkolDMMIGMr++sQnN9diwwORCNi9hvvDK+DAX1AyWzGnA1aThtqwmywqxgE9CFvbtmKH3VbUJ2utYGwmCOdDjbMA+2PRBBE0Rq6yNs3EA1L5PJPbH23Ug2ubnxRfkWq6dDtFfJM1rJMmpXtftNpZkkjBQ91s7Pg045rd/6R9YEKZrWVFRLmERWlqpvBKOoiAZk55teirPuqQkWc2Uu7gfi5HKF618cfaEtuUU9YA/gM2NX6pHEUxWPtync0X/akLLnCm66Hpa6yaU5JkHL3kBSY9Lxz+mlkbLlFxPDaKH1bXZCIHPegkNpyJrBBWw8rNXK9Gn/GU++Zi4zRYmDjEa+YPu37ALqoZmhCujyqYxKeiGuOhe9wjUPtcQ018LEgxe+8JHXbwxSdTJ5zwpFqfLniW26lgAawPTKqEjgklnopWzwcaDPN5LdybKLnlNmPfdU7fdayd77iBc0seJnFo1WUEIMZngyYFmUep8hskI5Q8cCthPlGwNFD+cc7A8bdXMEA+C4uqEaWiippL217EXCp+uAkDi/rMqCI+rGH8NDNNe1lt9YLEAN0OZ8ABPftOohfbalKNCzF3nNR0Lmg9zTnvq59OrWa1a7y+nVqi2nGCVQfYec1ogI78Q4LeWy6mQhRDMWerAp/0/fuz57rUTl5yAJCQv3NwleBYSpZAWMUo9sp/b9nR6nw8PU0TqiYlQMIgOa4oOKmlG0dehYaYKy3XFsRgymN4zji9Alid2/eh8CnesW0VZfhw6ay2/FlEVE6dE24xIkmS3cl9NGfQzX3QByuG2j2ZJvb+HWtElnIsZ3jimWcHbPcdIT+VghasgQfvfvaJmICpq+24rnN3hJDRHnND90xvAIV30LDsFHnB+oSGqoBP2a8j5n9DNp52GzLDObrZpFu0CU6741Q4lLA/Vw52m4uvGWW7k+mhJGasbUpZByHxKH6lQmBee3219PX6My4SvBoi0LtPWD93QPC28zb6k2ZS79l3SOFy55Iku27AiMUMm02VOfG6wq+1z0ie8EN1ezf4/YK7Jf5UF/C+Fy/ekua7bTIx9cBpJ+vPBd/b3kC6D1FoHgwcmOqf/0RpBa2ivUGo6D2VvB73kL60/938vg6QvKFXRneSIlEkAFBux0Fj6p9TaElkd57HJ6niEQqM/xUUIExsHpXMaZb6VCvVMP4xrcBadhVFUT6Ho7HBZDA0Gza9SM11Pp8i2fosWb5tinvMpkxHLMD1cOXTjEZl6DCLZvztvMGYlkLt8EhKCIPlnHwxGvIywp6T5nTnHTs/3F8tqj7aKBQbLMbYXo3tFBBaUyQwjFGYkavegaPRGDqcBCyKLlp9GY4PqsSeNRW5jawv/r/tveuSG0eSJvr7tFm/AxZmapGnC8W6k6zp1hivUvWQIodFSd1nba0sC8iqShFAopEAi6U2mfU77K9jtmvWz9KPMk9ywj93j/CIjARQEqnVHJu12RYLSERExsXDL59/bucrbo53+SOFuJqtjjmQDKYX1bTc4pIG8m+k3WyR1N9Koy3PfT2iGPwYiY7Wy7x5/qVENRq3iuyudi8z/XwBX5KsCT+hlJLiYndCLT2XyDLwUyl+Xa8wykxHe3Bhy7XJnja620Uce6Yp9pWKOEjNYuc1LAOnhMRNnZpUMnpTFe7TlNWSVYPePVEVkjCVzCcVVaWWvPGUvv7EF7a3QQBKcaFral7VADYDvs1u1/Zj+ZW6cVIg/YK9OnQGjTpEU+LeM3HcCDhW0Eh+RKIk0g88IsWJ0eGVWnncaG5EuJ3Obxal9eTBvR2UMABF4HN2+7MehaOmJn6VnLFHENzu3KI6EybI7VHWHwYQkkatT4I/ErZzr3Kv9/rN89yYfW3dxEllA3ymg9j3Gd+FrSvdO5QjBIh4Zxlwzde6e52T12/JQuM5x7VSsALo5PNsOQc+t0khQU9L0oaaRKCyDIaG6KzSzGW7I4WZcj4AW+Ocft6O7xJxgZy82hitMDPyznKNR2f0LRhtIhm4oAzqR2WGfL/Dz/oH2kVfQJ6d8ZtzkPAP9/CF7QjWOFTzoJJmj1Y9n9EWo40TX/qsgSoGir5vgyS4CXIIaVXDxqAFxYSljYqoxiAxBkupxWz9V51AHd5ME8QNF5BSTleMc5mDuA8nUbOuusD0pu05VXEShJuXlXyIBWGFenOoPAc70t2q/pV9+kLW5RcSDjisr66zIpJFZHssKjj2+O7vgX4aQjXXLJ97PdWuAeN9cTNfS/HJmu+4TWdErD6nag2NcAt2GYtV9myc31BII/jBIhM2J3o0V4KxjXL2Yiw+3Q4wnFYvGRuQHH+08UVL172VIHdzfp9eLBOMF8sG7wyvA1/mAbgPYC15P/w9sA5shrghz6ceAQ9rRHSqKclfsebdWRjwlQGVEbHrC2yYhe4glQzqZOS0Jqg1pMYPRjUyFFjl9EKO3Az1vDAwco/vXDOoWHdNXlLRYB426dQB8q2ORaTD25sDgaliYYOv8WYmm1r98qPaXOQ8S01BWIgfUB9Hp4RNpoWxA7u0dpnbNq6bG//u9ZlQdZw9PXkjzWflJDtidXfxiRBkkZWD6uGD6V5lXUpoycDRK5u4ucJG34kwHDa5ypIOyKSRMUFOOp0xcq5OygUDO9YiwjM+pdS1Twlx14ophiaB+LEzV2ViX744e/LVsyf/9vjVn89On7149uTts6cymn/+w609yc4sdNheubhsgo2WbEr3UibGSEUA3SxnZ66Fo0iCTNW0w5madhklYUSOHKFzX4tCAGLFGH50AcWvyTQeUrQwZwhZ7dqIT9dStE1xmyZ7NTnVaXDJtCyoAFB7iOYTlVPAZgYoIRRIYOTEGMwl81IiXStnJBPO46sROfTBcxmbPNk1bsfLN1RB4AHVBPrWduzUB1kP1A2QG9F+ftcZN61cb7j7UsOyN/ii10cuA5TWfjSPuDsQ8KkZejgFMxvLemghTtLAoL+gf1IJZ+T/Bh8Ea3iZxdFITBio1yskQh2id4JXySFAqEvSycWie1/xfLNT2yAc6YFFtwcrM8DEkJqiMClu5izuonMBv/93QtP1iLKDWSZ8We/O/Diq8IPw4TNRmxRmcjfq+mt3di5uFAzXY0pEmLh8W0zLciTeCU291o2egVasOkAM2vEVcplTRexruXIhqQkKLdgsjkb4lF0ZEmztLcpsQySsCsB1xr4Xqu0I11EWLHZ7YMpOBsKQkxHq7A5Hh5VI8mciGFXnUSnrs4Yy7lIvH0VR9Bh79rSUXAz6tk2HmKc63HJpZOD2n5a0w2Zjd7bnvd3d9T0hP44QHfNFK/rOwxetDiGXEBQ6PX2Ra5zv8KvFZKz6g88m469YIOiX4TKjhKv4Mutunt6a5D5FLn5eS/PiOtvAOptbob35VeGKy+7qKwvK+8obR163C94M1P7WbbrVm+NIMjtAuJx1/85KsB+sNkBEs+nqY02Loh9V81Rad2+n6XICjw7SgIJ1mtWIWs7oLjdLjI6yPqgqdWluBRNbDmAciJAcJoJHebRF1szmHXA9U0S2zIDfANU4so+zh9IdlKGSbZLAyr5O7pJRlFRes8SW6PDGRm4u90+4ojElzphSezjbKCOyx2BGYVwFobLZ1SEunGbTvnwag8lnyHer5hvukmtGaxpjcc7qoGaOsMunaxgGBxC7ZKMUAmbjAhkS9Yi0mBFzJBAwx40we9m043duAY97z1dtxvQ1ElcbzksBnasd7TR9nPBWFhyQXCiv3YnmNDy4TSg+v+TUorJZjhkvZPMKBJ50hkYyeQf2e/f1+Y1CweUS99FFiIkLhM2JWo20ezIf0D/zPsrZOG+7DY57j5y2ed4MKesFCZBt+hBFzpJV+3mEbSz8QpIlSjn3Ra/PnfUDjBNuqWYlfNRNqc0CZKpaj8NiFIPIysnexCO7uOZbfU2BgOJDNVlORN1mw4x8IJmuTkX/4HeMpNGwIBoDDgCPq0llyQ/W4bRND4/n9TsICyPj4dDJGIdM0apZJSL+VXXj7IB54IFy54RjKqhvN36fxRLupLbKEyHdGZNGRYXYFgrZjA7AsVJy8SkWTCUsExtIbv8wViChjdDJ9XjecyW1iXMNQ64araREgC04JDaTWKKNlgwWF27ylU2CGIJFyBgW2gVNAU12PR2MStdHbC1Tmkkb1n/cy84fkULj+Ikn0om17klZ3cKVul+isplCABLJeTT2mDlKEJ6ni01Bht5b1XqpNPlJp4KxwokYdGeZ8O1WT+PNZSFzZnOsQVK3ni/s5gjujeMkkJxsqizpy9yZCUw8kuEjsJdMPJoXNYtjJg5yYu+i+lAqm12uo+jXb4pK0WY0T4ozFsMN4QU3w4fb+62juec+O2xdWzE/AHJEfQ5Joobl0u5Ym5FRND3OHIIXgbo7YOg2GGjnyymsxu+0iLob5A5IUDSBL8BxGTZ+NwF7RG/Sghk9CjllcviCEUlKVT2VudF8d5xPsq+rIZ9ZNoHhTGUXg2nPa23sKXAn2BaW8Cy97XG2gNWPIZNJE8cIpI9RR8YcLalTwKJsOYmm1aSk20EgszwdWZJHh7FJuU1ZNakvAJowKVCygCdEvjgkQJTUIyDrXMuT7O3sPhzsHA72HvZ2D6mOx8FBXG+E6nVmi2powYQ/UiVtGcUfff9UC4EKpA7cq1zPiGZPal1SbYkLN0U0d4PWE7vyU/V3DpyGWZsSIQ+O+0TMY+q/+ooK7t9QM5JSI/MStHKUOuarndOjzoA9g9Ek9UTCj46ib2Hq2q+pHAldv2e5IiY/JhVACioU310l4ltTBVirRES/z9dQfXCUNOGJiqJSySDIUSojUyi4gT9nCp5s4i4i8mvmvr6q66bc/u1v3BYrJ1+k2W3OUHKfGpINwYh5FZx+hPHED44rwbqzGM0x3e0dPKSX4vP2IIP2nw5ZLgJQX1kjBTeBBLeYkFAAc4ss8j02cAyKVBQsBXtqhgDPL2fItWgcy4hfYaP2g+oGwQDQi7AW+mBbsQipTFYDNTLpQQJwVM1R8m47U5nwtblzcvLuQbtlpe0LeRvBtSKCOkLVxgpqRQUqFzEoV9RUDkTk0h5yC0tKG+sbWN535U1yr0p4EW85Kt1aDiV/I1VE5EV3unJmYg+ISbF9cnqKvf6nU7xa64yEKEU195m3mX2yQTf59kelIGs1e/lx8Y4c1wEoFeUqqEtqo85pylUZ1QMQv0PHoC7lR8TNtcjm5oVD84gR/Ln16AD48P6q5+8u1GBVTebJW4N+emzSWLvP5A1xEswBM6k514Xd/ZJXWE2DF4+j92L7dm/S6EgH6fimLEa9lxSQgf/CF27IhiWEaYRfpmUeJSORCa4n58h6Z2owgMzkAbbvQzrXsF5O2fk316Yk3k77iVmKhlVHNnc0tEAaxxayBir04nFSjiUmbiCuQyHM1jQeZtLnpz/k0+uj7oqluktR9YemWmK/bu24Iz4GzmwjlgSkTkvSbtHYjK8SvASZTXe/HQ628EcJI7wsZgb+6e5Uqz/zQF4YtwSaiTgkLDBfAmjnhcar42oc5zfszsVLXBIZzoJtfFIhQDyRCD3BgTDg48OicCcvsiv5GAd1ki0meoJHTqcIaNvXjzouy/hCCZiGUhzMSrKsUMdqPmJ6DaUGhzgU2SbKSi7YOKum01Kh/t+8edGYUTKV+EipZcQiuSRmbBO4yO8l+I+5BpGf7ORMAfX+LfI8xNWiDyKiZHiJRO3567Je5KTY/Sj2HI3HJAELEzwk25xyQ+e9pyff+iXT2CMGJPtFJLAetXbYekvhbedM2Wex2Kp+8NgR5ObcOpJ4mODsDJoRJ/nxEoOTBoUAuH0zxOBDc8PJ2zBGNjuNrYC5FboXPECQbi7qmTtMcy8TtjLjwP5O7yDV4FaoiJlzG+T9+Y2ibVourm5Hzq2aFzJZaD1Rfg/EhGHcj10lEifJ3E+iclq3IPYY5UGxSO8eLM925BQB58xopGBZZIX6C3lMmQGTeuSscw/Io8ubNMRy3M2wEh3bSyPEdMSKi+rV5rZ+9KdHf7YS3991m9xrLGIY5iyu+aJDVEgI+oo85WIR+Ae1UFaHtjUlpBO4q4c3YZo4S1cqLHotpL2Fc3u1S5OjBCHjNjYBBPcsZkreSUwUBSw6CVfh3WlCDF8ptoc0xkKy4SSkkXKetLhQvKKKBx6XBZmaj7tIUf4zvIOUxiFPrLOT27gjElodmXMNGdqEj0wQ+1ZEs+5nqGMScU5nWYnCA1tBZTGthyEi2Tm16jb1zlyZLyOK5CQsiF6omF8u2VWKXxO+tRD/+KSYv8sZkPc3t6qMea05MT4PADqDtcfJL8YyKHLVxR0Y96shGkQ6YpUn7QmUaoGJRq770rNq8wYJ0EwMp92W5j3mZiV/nVm4Jm83GDYddmUrRBxdjOoUkvkk4/eSqFxFTCUMOkLQyQF2BGxF8ulm69Pq9Ld6/XQ0fVynfWDe+tJbdkCBtJrCM+hOr+iAE2TonMF1IgUxHvCQVL4nQikitMk/o98tzei6Vf+vi3nhDuvsalXX3+puhQuvh/icrqFM+Ki9IDFbCrefa54ukZH6ukWWyW84gb2WTZTb6FNnHIA5ny7g1rcSKWh93pnl/FP27wsu/7umHY9jlXu/T7jGfgKTpc/J6YScKieWyvls0bfKjhTp2ITfrD2EQiGV6Od3fZNAIYvHQLOL26qcmX4jv2CjsAv2knnjhB8CgwyR5wwN7D24ffH42hsgvovVki1HXF+ltQF4f23F9yrfpsycIHi/CuE0vqR5temS3uiqV8EV2OSvqxFMu5Bm3P8mRHJev3nVRy7eci5Ufe7INw0KegJFv2iC+jDNgA/js7NqjIrb6Vhf8Pj4MXpl1520eWGdhYp9GNazKnjnbBkFTtRvU8oxBUvjHXFe+SWMkna40SyvPC6BCsl77pgdfKZSr/F0MPQUs3BR0/1pTUCLWV+2ZNgo6cusAX/P2YuMEapPfJCm/ZNvl3P8MAKwdRB/k7oM4qDvlJcDOSq4uj1K2csQhMPUJ8Iavvo++6esYIIR1lsWfW+d9xkz/FzwKiZpt+VHCuRAyJPEEfLgJg9tyXprbTN85+IGBN6Yfx2Y8FLiwj7tkGK81UOSRtlEggaoPWmb92M/SmuUH2d0maPtg26OCAovIBlDMFQGa8Mmb8uX5I/9Fv/N5HgfVgUpaAQbaZlGpGCH9b8qnRCZexWmZqhR27/uj02kkjvdeUZJYl3MExhZh+NiaimiAL7ytaxqJeKSXQmfEJ3Br96Sm03LgzB3NUvgTn/0C9g54kwg+0ZvLIjs6+oH4twJfjU/GGxT8zO5D1CxVHDFEv3JR13gIghsVXKW5LogP4GWY0oZwgzLlNAdwKPZ+6GcUyqAyTAAdHGtrGtr+KzSEw+wYJ8M7Sor+PGy+02zkVw9HxfDd6omGQOzMdc/32ee6ZqrzFJla9Qw4gFv1BmjzqUn7sVbuJhpdSEytzOq1y5nIF+ea4YN2P3U0cBtBFYJgO3WS2roiuF+y15eW1hPNV8ZFtmpXoANT5YF6DVB/UbHz988VBIBFQhzOutmo+/LjdrXY4l30LirunxInm7F7GcM4hZqsi2PFVYakU/cuwDHSbC2x8Gxv5h/zpPdEQ6AMEvFlCtbkCMXvBhaViANxeb24DkjE63jEkRS4iPwuqQoAXb11jf+fAkhKJqpsJrDq4gTRBGGC9VUrrjQlRrkqqeF2uctjW2L8TZcOzKc3lu4pL57LcfluXEFek2IeG1bqrUsN/wLzfLykooE1lOf74rFAR2yRsuYsoQ57iAq/I86/JhtKqy0YlGj/gy0NwPluJuhe2Sy1QtDXKth9YStTkUFCMez8dCuCWP9NLZX5WKwikgUJIA209qkmrJY67+cdPNPK8xlozHBXjGiOuKaywmxJOQei6QtheKPBEGdNaJ9xm03G7CFnXO9PuSdpNWUfqhmdjW7QjeJwzHRwXgT+2bvhUvFhDXLSqJ5XnZHVex62D0Ivi68sb3ozM5cn4UnpL9sXcpt2n9G4SaniQYV9y0hqfFp70kxLonNrK81Yq9Ru15PzrRWezRG0nItn57iqZE/Y4+j+zwNJoxK1O+RWsSFh+p5I45Ja0bLmOUrUgtb8aygmkbzcUxSXCbCKw5u4fJKSWcj5TQUorA2trE6SIkNqS2JuuxV4qyyZ9A1RdOQpR40CHbQZhaetWnC5yfgEg380ufp1EcO7tSLEk1wG07q3StGL3WXKRfyzYff/l3qhWl4FBuPGEKUyLhSpaQ7UJbmYXvj1XuwxMOuHqcqp3B1GEtJFMIZSoe/3/zXa+MwdquwsWk3THTfgR26GAOqCflgrPQbJ6E+bKoEZAKz8Pdzq7ZMd3DmszBrlezOboyWoehXC0gxRU8mQlKdbyb8smGId70DhqYz9r6ooiCRdDbcaBFghGW2kGoKojOvHQCxovHGx//Kdvf83yJ4Q6Kr3mWiQQgHUNHI769gRuevM2L56gnXIPNkA31DtlzbjWZ9YB37cQnPnlzXsjm3r+ra7cjvi/cFI1vcFj2fm0qz9jKkVaZSn+6ycH3DphaPi3DDhDBBsTImn9teeamTOXtQiKI8mHn9vcwLfWfVK9p1mTI/wHV5QuWFqWWbcQf8hCF0YN86RsOKpvowCNJ9XcyhbdqOke1qXOtO0UNkrfv8/OThG50ydcZxmyilQwmx7bZXhdbaVwhAfqCRYqRbjnp+fUPwrXRxjQRgQvdNE6Kdkd9BQkKrb6nWb7sgB2va4exBonxTdlwkorGdWvu6GKsWJ2pPb5+rcjzrEdECZGFj8hcrZsOyDxPzBhHScoSkniZqS4TF06ypUKAwLGThbwG+U3KLHRdcVs20mrfpTrd6Apl1Gz7tScP/MT+q9+WkRfWuS6eDSKGj6NV8fbt4T1/U89hID7PP6r0gG9knR317THXPskutSNOTuM+oHgIhwPoOKwrwq1Wcq2PSRjrk+wqR10QASWX/bidkdV25/sY9r0c38YUb0UV37YDNQNsUqCAjfKBRqKQj9301L3XfigHJ5CcowrDQgkJvnj1FFGVzqwmgEaYbauOQojpXhp9I4Axu7BNl9BqOC4RInSk4robVIhLZWf10xWQz21Y8B6FYrmDQCl9mnVJtmQQ+KiebuWwPO8MObQ/bKVLCY5CjKk1SqdDD2MSnhLJSnP9mzksANdc2Khxh6xoJfmXmyfNfxzzTjVjcHomdQXUHM2gzxNSQATCXHtxp3Py2uGUMKoqyNfLvkIUQiY4AxrMAZ22B9JhReggQ+u32NTX3bFrMeaNuNgUmjg6Xm9xCxqN1SWRh9WxpCNpmBYYcCx5jDhDyyHMjdtCYR3eYu2EkaNN4Y7eF9bLVC7pNpAQvmtWJ4uA2sw0nrtTEM8nBa8kdeU2d6zeoie0NsjtA1pF7ILE772ZPZ8vScq3MCo9Oh7zxMPqUK5qrffJDPioFqBdMPXHR8PdhdklmW61nI/AlXTVFqPfm1HwESzQmLPwwBOHpR6nPTHmsttwZX1xn9E969szvvjM2HPrdkAx10HXnaq2HG0rmwtUuUrQlZN5YIwFz5J7apR9e7X/xNl4BkfHugX16oHETPL3kHL4empdPnOFBvh3hq5QPBctD5Ldb/km6i0gdaWJAD7rVyLvUugZfh5ZZKwW8uTGMpveWarxNSmc8cvJiMU22iHZHRad8vQ08ikyCLSeBTfxAMTTMsECtyXxa0J9Q5lCG5F+kz4tK3IA8ta+k00YK4Yrz7bxekMTsULTz7xjla3OnzzGXVDkL/NdUDrBo3JvwismMN6xT2bvKqSWemkFSxtN6xDa5N9Lo7pkU2gG3dQ8axUB+MqBdMSiIC5C/v9f/4hH9RYWFZdN+jE61OzdZg4JEBX8xGPM+xOd8M/nlbgbC9D5wh5Ic3W5k9MuPPLLMdEgdlBJZ8n5avpRPsc6faHpG1ftqYESr6/ap++gj96aTTu/ppGrS4Zf86aef5nroBMD1zE/wK/r7u9emY4jL3/4mEXwU1XpXzsTeIqHAdUjlsGz3Ti4kJRqZgjfk6ZxwmVFff4rT/2uvR7MGK6VoVfiwa60NtqRPWyd+C45mdOa1jbhIFdO2sGUGDh9x/rF091ZupE0kUp5lhbJCeZkBH1n8O4KKku+3JZOPvcQVsClNgE+Gi93T7k0Tn7OVnkTXxOLYc5esyqml+id8z8TqDd8dcrT1JnINhufpCOjT/hGZNro8ZR7oYmbXtdCqiDIpc/d0OWcKrPfluJ7RZt1yRoOwo7ZSVxi6jkjjcp5T3WhQbqtNefIxxAmCZ5TBqVk1QTtXXHIgb6PZlXBoqNuhLCmCFmEOGKmkxJ0oi3KjQRDN3WyWgIHP6FrXEu6c54UVFp+LRlvZHek1sXFFxc//uqSzdT4nlrqFe49LICOk5iwbHW78DGuaEkk6nbbHhGilcO8WX28ctuOg87nbHpwLOR5HLh9TrYW2FPQBcpRc3dCaFKhln3LGGPOA13m798g1K/dn+FLF9yjsPa/3pBi7sOO80UUoLS5ooT/y9VPNltKfuXkIIH1KZuMkh/MCeDg+9e0BEb0avRG/Bs1ANIul+VYXoEmXRx0BGkYxlaM53Y9ie7xL7MZhi7R3WkfbE+vPHHt/+5t3BYA18McflWRPK863n8Bh3PvisXDpuBO390Wss7zUCs3lh4XwnVdydpg/3ueyLAKUDbwTTXPtZK3kWAFK11XqR/v4ipyPPs+3u+Rz/OtTEGplzFI4dsD/9ZqLJfpoWnCLQPixT1GcITjQUlejj7pHzVU56gsz2xZqb1iTe8lVrXi8fGSJ+XNeXNBJnAm9HLkkl9BsMwSAWQLI8pIjcdPl5NxkymOqJTnXJA/lp8SLRmNWr2A3yAQrt9S37PtuQdGJkCawoLRB6DFN47h2p0Wj+To8MU58OUA501z4vsujasgXtJQmuXm+LAmXw6UhxkmIK79hkhBklG7vFSxF8xo4qbhitDZEmANfgM+PyyZDFxzwGZQoafdhEYd91u8MbG0D5/SNRUwF4AWPjD++pEJOn5tKAmcSMNOP0xc8zRi+GexvNpUiBFyVIVQirwD/+i8pMUa+CNBcoOA5gA+Pz9RdhJfGx52J7jwnq+zeC0p7NQAG7+ADI8F84almwiNdDSLoqhey+pHO6XopELFWf4WA3+7xPsS/+6xwzKum9nmqp+vCY9EFQPtBdph2jc8wHFNPUXyjWHEDic44xf4sJU2W43eBRrQtBChHmFIPOtFUzrZsrrr7CXcl1AxKU1zO/DuEGsiyR2VyBNK3jj/E85BEAbeO9HK/iZiJlUQul0ViAHbsR3XK0dxdWvrWEObk9xL1OH82M3AGCm+N5vWMGLoQNTM8EJVMrUfeiPbIBNHtSp82gcJUAWoHGjIZy0JBZymCFfw8vVxS4VgSjMSSQkdsvCRvWFfsQ8tKdMQz6CKkvS8Ac+/h1hKEJK59WJHg7571hIlzJuVmAY7v9p/0vuVC2NhNc0O7iPGNlpq7GvaZ7L9QQFs8/YHphwuQ+9xAe7dl6HY2GikJeBVfToccES8pxZpYbzI5jsTjKPGpIZT4hnQFYQ4WZlQfwNDSbp5OgnLgWH0lQHbp32KjMaaKtIIx9DzUH0LU4l1Zzhhr6O82ITnlMJrBciDIQbj6laMIxI9TFM7G+smF1X/+6s2TZ2enpy/OHj19efK1x2hLhgKN2C+v6oYgWaeyC+4ofPX27euNpuBxXS/IVTZT4F3jFQ4pihzXjV9clR6IJnUDdOIBbACvJEhjzLzAqien4ZIAtaQjbbhAskWXM/6NvbEUsdeqz7cKrfcxOlMssj1ia9v3i5Xi642WwqT2nueFQj5IQc3Qsa/Wh1okAkuKqHplon3fGTivubC2TMiOC2TwYsem87oRZS4ly5ExlUwUJROjbEb6GVUG8AG8NeBlwxFj+Tj8HaGzzH1EbPhB20UR2TntcHAgBdIgvK47IsshmSy3zv2JCtdfcEKSHxlnTc/b6VSdAD4SiMyNKjpk+ABqC9X+zWleEbQroiNiqAdp+Zq/a43YbqXkSYz2jTgRW4JVZAqTQEJIunF9OXcarVMFAsqzzvKftkvpsLIYZJe6tgKskPK/Uj0rkpoZ/Tg2N7iPdozdgjZaXUScOFuqo7LPtrMOSKTetbFB3i/ZpThGGSHxSvUS0yQYbIFlhnV81U4laG35ZkjpVqSEm9uthF+vWmzwOrLb2Ffi53OLJgxoM/+lRSjXl+XiivHcnvWqGVo0Qvf7KWrKa7LOsFsUc+NOYw+QuC4G9MyPP25Zv1CxXLiR/vgjVoA/56c6nTdxqNwYcI1TvUpFQhCOLOwhevQFEbWjm1cXF3AtSvQupcy3jGrfSmlD3cYL0NNd9753VwzKL2EpidirXf8wGqhgUXiknsiOnBoRfsfMDGGZomkIZpgmTiScciLp8s6emAqJhvTDgEE5vojYntH9MtmkiZMMU8PJowgT9YbleLxh13TzeJeyqJmPWXwFBmgJ+seRBpNGqs4SqAoI0az223WO5rPPvn708tlnn0WWMQr2psIAvXsFxZ8dtPTZZ09effP1288+28yjMhEfpLEYBFcWKpRCZgdDV9A8vEfcl5f1YqBuTyDT3HYRCcPPgKmz9cjqAugb6Dr9U3grx+4SlDvH8wqg8oMPJgSqBC4rE0pJkrNIwm7X4ueyxgydLOL3BQcgnQZn6V5tMl7DCf5nZ3N9uxxPDfF9OGewa4IFUlshn+NC6e5R15GGC4FDIRBrtmrqbeAv33DeM3n+1mzwTj/LBJtEzDz/Xj0+L3Lgkgw9+y8qL3Ij6k7kiCzuFrSuqf1n6ocEdqOmVSj8d1IwL0HbfYw+Wj3kKu5t3hEeAAQkGKbF+Brc3lMK+gwtjRqixRLiksY0qrwhOrzDmzkt3kso4/xGgD9ekXDvXk8pHMXcRspdirY30ukjvJaWXIOTJSGGAxGPcUq2+IfbnCosD/DDqEYSF5q5xYDk1CEDWvR6dVXVQ6fbNFIhOWFD5g0/VcaGTnLk1QBX7lVmQdHyZaKXriC+ZMcAu0r0BvlzrxrWUy9BYNRvZho9g18Rrtm+gd1m+lYZxUBccQN3PodqQsL9qmmmGeyEUEtFqkZuwDb+wODTaVOPdWuxiQifYcH4YNkrvGKQp6MbKi/OufUezb22S18YmoEWKMUz5vCqTwcwKh6+szeyWlbYZJLzreGtHmq4dKaIxzuHI4xRWfHCV3RO8+m4cuukjvPQsa5pKjznqcYVr7tHUSiRQMyE02N3V2NoG/lCEQlGgg5brASfRVLsLdddHXMVpAldoriV5P3RE6r3tuFFEByP4IS7EgOQx/2dVNZMVApeW8qac59ECysQNfMsC3U32pDsx/UjOvInJMp/VV1ejd3/5ztoGug5nO11yjlyYuXD8KObybsg6GfB4zNJU92y1UZQquEnVRu539vdPd45cB/ettrI/s4DX23E9/8Tq43s3K7aSFKZ41dRcASjIm156pQJ1BuRciPn5aKgvw/p77TcBrXJKtXDAT0Iraq9xA9oifkJ+VJ6ohfb61reo8HuTm93D8VkjuLlPdy53fJq3z/++KPrwfWm2D/mX8T73k/rqxyE4iiP5bGowEqunXydlR033EfEPzIO9rkA3lrg/nAfcRmCZ8pqA/MHkZSGkXVQA/kKYedrtiLKg4cPeI12th+qIi5/iRJ8tf/FU22mXjolU0FqRj0GLBxSrA/cidhafKUh4J1lRuCHv6YZpeuB/zyl+duKUZWMnxPzHJPZHsNTzulRcgDAWcBjRUoHaiQhJUbdNdu5Hoy585ZC0B1deQU2KK8xjE+tOfHS2YA4SlWWNLqGjUvAmZZwMSDszZWZFvw5E6jqLlh7+Rs8knDkWVqAAN4THd6wU8EnyEDCfC/qaLM+f2JP29symiIPV1pHTjaTpnOJKpkUKSybXYA3vnAL10e7g1m4RK2rm7td69F/+7iX/LKv3LM846RF0YZrP9i71/uSm4/36MkCP5QTBZDIwhInCUVZy6B1J6ddVYiTgWeErBoqmn79vYcjeft7zwjGw71EMO6uE4y7e3v79w/2vXD0Y/hl7r680PxVXIE/YoUEj56/Eg7DlfBCn4vuBNtA9i64v0tXwWhecDyA4BWeuCzEyhvDv+vT4sPN0C3t9/YfHPn6V7kcR05FOSawKkLyAReixq1m48CYCMTCJoMbIz8PwX5uRn+XY0LVXp+BSmaU9KVtU0oU6nyBdLrVNfTg5JdVYHEzhqg842vT8gMFMzXH42RvPMkw1pqT9sMy2Jajl3u8vBxcoNxvlI4luebi4eL73Xetlz4Fz3IznE+J6yofuDqXD7FYOe2bpdoxclZfyNwHV5V7NbKSyRvzmk0YmSiKD2nx0OXUo8UZTmvxORpMEjd37wnFa7WVJ5SbXqEMd4PSJHyh8LfprJsxUrlgqihRF+w3Kv+6BH0CcoSZA/Jtcc73/qPh0B0keKBcb1HGLm5lBg0U0xtc3uclQEDiKJO63sRrxhm+9Tt+PdeRpR0UyDueZFu/WjV8Zux6FoBJAcvLdGB+5zwVtFUImT7hWhnfgdQu642L+xKrkjeks0POyqmbLCcyWUx5ROOZG/cZc8j4r+SS9fWXxje5DZUr+WsCzK81ry85aquYNNhVWSxCNoueceVKjIP2Ol2SG8hwbaA9TO0Ddw3lAKEtdi0vvUgJ9uhTm1bKYmJYcYY6wjU6AjGdiSHvT6cGnirbjCT54Jp+SPKPIhbeXTHjcrhT6LV4uxzn+etA2nfcO6GbYsJldRgByK5SJ4Qu58UkMDkOnYIyHSxnqItH8tgUo6vG6kliBI24muuEECcRe5YfiBRz8b/7pCMgHU29VbraCT4XIC0btg5x9tqpIohigfdE1FEVP4rQ1TGAkcGXxi0WV4qzUL7xelpu2Hk/ipz2o5SatneY5Ism8PAyFsEJxViq1oWWVDSLduaK29xjHELgHMEhumQwDOKIKRchii7bFStSIWtVnjboZOHtE2HmnZqc6jPRXJ3Eg+XLI+uoSNtbUBo83dEf3MxUSph0oSw3SrnpVQ/ydEupRmYUVBwPlWPU7ShfNTGb4OrBXJTlCOl2Pg56oTI3SuljRkM6oEtoDUC8dR+8N7CrSk6lmxC3PCjzKNGIMrZYfjaia0Av0PKAPYrMUI8iEIIMoKuTRKxbVhoBEbvcIV3nbn6vvizeIVd6Ljw6FC/xeDP0QLdbBABT7Bf352UmbkVYqgp7cT92WmwxK0dbEoZwQng8xhCZXXpRXMrrIbGnCYk0XD9uuJyna5MbuY7Br8X2n05ffc37oSKDczoaY5JkgdwMu5uBHaQK9ytMaTX8sObknaK3TZSX+ChXN3Cz8Xzf5EbDO/HeJxzUc5QF10inze5/jm30TMBFups91HZMKYZSNZcUNqez8IZLdCwgcLnGfLl9ua3y6BFFXmGdyAes9vk/WX0rF8MNJahPoXJ30sJUlYc7gx8xmAuc+MbU8vGvBeb+qM+nNuv3uKekQghnCbu9m5yIkXCzhJBEf3lJx1s3hmbpE7WDAa/hPV7SWFFbMJYKcucKYH5eOpO6uQr3/jlQdY3kEScxiVVjEc8Fn99WgVzhynGr/d+vZ5PxQM7n/xC0S9dFBAAeIs+WixJ46eoiaF++lmAjr7dq1CyKGckoBsL7Yl4hWaf/r04+/fHbZ29OT159DaehkvLxQcLMEvM+nUSjT+ikyjWvlgAHuZjTla/7lm6sh16XB+qLmqJIIWWi0gGXalrwhUlnGsa6+1zqPBrIwb2503ZGNfMv/3VZ0V0w7RXfI4NyIEvhsQv6WuFCyNjQyZG6VjUerYjPgdUhijqVJJ6a3tffvHjBXPc9Lp88CSgKfVSLHLNhwSSuC6Aeq3ApWLyKzjn9/bggDK7Tn146JQhaBhdsgNheZSW0S1uqLvOmHIjJne3cLUak5AnCThMRyMrjEJtUPMTZY/3lkio5UdxVChsRetRyXgemk1W7tyXSdJgBFy2lxrA039X1UGE6BK4YLvI1izOYlKRjdZ7ozaoHUrdP35xrUU17zPQ5V7Z/0VC8diMGEYSUXy2+GeYKsKrmkiZKT7fLHwmLJ0NjVUy7J59rCt+t5tKdm3vQV6G03yG1YsuHtzH00V0fVkXw2FkDqdXXSQTaMaEa/Th1GvG5274eJcAGB8ejH1ExXPEYENuxdk6djZtCrcJ6kw6zZLzzxVKIjX5iE8E/SFpu07vXe+PMujz7cvcFzbH4L+fVqGW/0Jwrhn8uhaNk4Tn7MlUl+EzuWXIcTGDO1bap/gBloWDgNxmAdW3qpFNNs/fViAnfPb2vN8jkatOrtppn3IkAqkD2XRTvSXlXttikEUseLPlwTiQKLAKQhw3fSDUSrgwdTm1cxDCcTlsZAXgSRJaklB2WzN4p/hhucKfY+gnJz5LRyPXYeEx7hCuzpd1vtbjVFEhVvj3arSixHQpf3SNVUgwZBj+1wBRJR1xTupnQpT2sG6r+NFRNuppaf3D69hlpncpqY2k+E+JDt1aUgFOOVDN4R7wvQEUhsawavvOiM2DexMHUYcV2BCapTsdAcDUJuT6U3uKSax5KjhBRW1Wpxcf5HB39Klu791z7PFTaGMFC9fBxFuKeE3lCFUBxDaNqxEobndZSnAbWZ6DO55tgjdFc3uZ2sRX8gutGNV3EZYs4dYHeTio0mRlb0aeQ5Qf/LPzODLEkFoiK25SN4fZBnzWCPm9u9lLP7elnSJ2uFc68/uEfIFl4uyOW3pk4cssZQE6zGz5b4WjVhkeIjtmGki1HZKa0nLOCSSSCYCP4I6VXDChWuVkPxKRgylwzfOCqctsoMHoQQ+Os2aw95ghkbYoFvJ5d4Q10U0Zu8Blv2Up2iNIMLKcD+VXhrwm4zITSQa6MTS9iK9gRGQkCeJ8saPA9quU14YADpY9Nh92boYnoN2mpnSCandceTI2NQOehIIVHtitSvfN2E8QCidTqOSkGcuab3sHO7AOT9s6snSZrRFXWOd9UVuu8vCLp6KaMnJMsNy5QUy3b7ZsCmnz5oRwuhXWjqudChs0eTea+YS1BJVAoZKH7Xqr8wB8iZh1WjHhWNpvEz09D9BBkOtz05wxD1Nua6VTg3ZMtwo9temo1iWzYNF4f9gKJJfgGQUnml4oYSdWVFECGhD28v/1hRXMRbD+URA4x00JpyKTGoyIotTgIuvh9fAuUc3C/zS8K9qiSKB4x341rMfLbZGPLUnpVE6vIvUnn8p4p03EW1zeVEPc3J9n2KNpjb0iymnx0ZcADe2O5tZFKs907gRrpU0SmHPeQogDtX9ELiU+bSmzRiLRXXg6SvyaNIR6kBNPalLBkDIAyULLHErcbuDiElpI0hJPgc4PUbtoqTyv60L1dNce+9qhXyn5ufMyd/qIaYkzi4Ww+Oh9wtdSzchripwpoFR/ZhlrkvLwkcD3kJCWBSRbsCQp7Pq4/sCyNygOvjj5F212NT+FAakpnOdZjZejjhATjf+/1f/fXZb3obzh2NWfGiZHBEQFOenpKNEyr2hNANLQdj8QVd6Liq7vCJIrcKz8UtN17tLtqFmVu1f5SL98uz8s2Nj5WUf0xQRZXklJEgQPaIKD+M4U8xhEWRDjN+Y0NfEAxJ/Sx8iZih2fMm1SmPCfF8sY93SNisNgxwbpKVoGMll94ISUWZYqx0hZr2IEgzMchPUtp1TugHbufhn03S6v7z39kCHjbPL36zX/x8d6KjzfGFm3F6WljL9ZLZu1ZRFOhDDjb/8XP+1/8vP/Fz/sz+Hmb/5/z87a4LQe9bEJt4dNp51RHkfm2LkMlA6UHqaY3L5888yjMaSLG+NqiXtQLxP4xCjmLdepTtCnaFthqNQ13u3uIifEAU+2aLpyA4uRMOg6tm9T8MrjZyDDoP0W4jbB63Gnf9hpT2bz+tot/MalLR/IVOQuP46Iv9bT7fu/qVaL/SDuQmEKUY63wJd1Q/N5aY/Sf/wibSND8ca2Gzn5fUlUg6ZGZXgl+Ka56GQj0uY0XiQZwsHMgtjMK7NXTQSts393eUMrxnZP9TQlHggYt2aFLn/ukXoSUOR4TRui0mKTJf/4j2utaUhP6+KmUwPPb3m+2tvM8moU4pXNcX16qKh4Amp5VL/F4UzstylJv/Er4NkIF8zSDVFYJyCKj/H40tuAA5rXWN5Yl0hgk0hwrN/C5Bxd5fHB5QW4jOjFwRmv6hv6UD3Xnvrqekdd59s9/3Ak7E35oihC5jTC7av75D1G17krERr8wniwuLJMuA3UaQvIJwoHQigrCEfTqSJlMx8SZGRWrvzLAY715eHUElWSVbLKo2VElsAMSmOyosnyxHv7GjmN4yqbYAwZz93M7yby1GjkwG3aiKETP/T/GpQVY2itab/qdjaCePGU0kLIAezXUK6jsf75GFSCJcFHNQyfoJu4CmN9oGUVyjs6JXaM854wEVQFkKIlZavcWVcrFjdswMKaFP2kiNNNCC0h7jzemO43JJQiq1jj0/iqY8KQa9voE7BugIng/zBQu+/d1BVzLhTsbSnAd3K6MKfH8YpPN3r7m8r6Gc6AvSJV+78uT5xbMwaEIAs+5njiEj7Bexn7cWYEMxSHyzig6bONI3EgAzWfK1xzdptPkrRPmbq6nbWRWPsuj3Wc7q+I8Xst0JQmYsHmH1uUgDZDqRJtUbT31AOvbm/sFmoVUru45M6sqVxKk8XJmq+2kOFbaHKEOMm+Zj9l00dz0nlaXFWUPPJUErybXT9a7YWfNqbzVpFADOx6BZxegSOK1e/6md1p9WLjRbPm/Ic7wiVgEW1xEYQt07+4PMhP5S1rOnlwXRJRFirxTyVZ6bkRekndS/MCCUq0VwaPgKncbcLVFQrAwMl9lDkfpVewQtmQLR74abVkheTfG5m7gV3pB3jFRythftnD34Nzd4Y3kS0nJUAYjNhlqmJarSnaCRKkj/eGb6ai+96Yc1XJDN1ajyRL8cSuNNntBkJ9sGLyl+3c1pG5CdQjya6vT0GksQ/2szRsuqTVR049en7hGBXajeTa1GmDAqhFa1g3Z8NovEc8u58R5mQMaRI0SQpP8dADtRqgsSzlPgk9nILjQhZprFTI3YsoMbWudSQQQrJZv6GfFuQuuG9mciEfxxuaNcxtoYDyUJ+lQOHU7ti4E6gPNEF8HU4fVz4ufBiOxuoewwEgkHR1OABqEn3PKgeBmVrNf/emrlwo2ENiH7LifPhlDZ2676+xGsf8hzKiXYozcm1FYb4a1QKaqWOJMQj8trb7OdD8+hz9ULrwF+OXyigxNj9EM0PNgtnhHN8SKuBclgmlv81SlayMAF7CjFQaocRaDYg1Jbk6QEWdThKha1OSmrZ3lwKPmbB6No6qsViJD6VA1ONbBPFeNFoGho9fUDI6hz7ll12U9rArlpmKKQ4ZEcD6nQhLCvGy6HQQnHRBWJLs+eNJcd402NjGqmVazWckQjADtziWlEvL2vFTqKB4sWcjNkjzWHJdeNuVqfC98ILgvWI4WY91sbax2CDI3NECibyHvUT1erg5tNUicdIL1RUYn9HBWi4HxKHUUTWEI96gakeeFy4u4TV8Whrdyy2PFzea6LhrLnMnArLW5tTxarN0p03BCiMAKJaw2O06y+vFui3k2C0n3KPZ2gU2pW8P6EaeMCvOAELByjgeprFOT/sdVmPi6qtg+Dll4Cmln34dAqGLevmSYeu3SeK7dKyOc/E2jU8H7rUn4PHWzMOlFbOtJtEVeBazjgT0IehXMD5s1RzcXLgn9LRu2UkgEOINxolRH+mT8gl9+4+7ot8Qq6G+YxKdYNG2ZkTg5uD5A3HByngzrfxRbnUjWgu9CHLbhCj+9cveAx70T5nx8I5NUJBI+23Pi/eGZqZQP+IP+NTaKPR/+MEDRd0AENyfvlyeISyCnnISshxj5WFKNlFaN7xbNdO4aNCV7jHg+IBbl+jaQES3w4NmgoUv4X/ivA+kUFo6fzvf6bTFnNH+slsLJnTvRrfOcKtB8oMnTaSq+WqJpypomJoUfoGnFaJxVTTJ+c+rzGqn9vy6r4buxMheWWqgBfvuAJaymTNmC6OF5CtvJ96keCzenCyWSy1WsFfAViBl8nSFkskhF2+g3EN4R3rPXpeBbSetzLoCUBH2OGiBDhEBwPFHthXSkgBWtaeZ54sfV+RxA0aEYLoVlxF0l+3LGcXSyIr0bseXwt4BSi6UkDhhu5BThbkHser9Gtd9xQt0n13U9kFtsAJ+1Kf7Wk8ps616nw2zQgILCQbIIdklfXtVJINQWd4wg5Dh4FWhSDc+21I6nqMc93Cy4BWqq0Dhxb36rV8KVKVUgPbkCZ+9QltEYeGHEV/SOwj6jWY76gSEnCbzCkuxGTHfNnI7bbfaoijNUCkDIj670nq+hUzHXw6Sr/zCXlU6mH0e6SkphL1yThEUqLuF/7glLzFk1+uPJ0/7ql+31R6PxQCpEyzVxdn5zRu/LBDhI0uNno0wwFK65kVLwnsMcUudzzfS6uccIrVlRzVddY55z0Z4VoTf27sMoH+oO8khz25p/dndVd2Q43AOoBsBWSfsw6ulYMzYahpflksU2eB8TyUhfLpNZ0VK906tpd/thOzcgVeJWpCv1EI1TlCLJUzW/+JJPFP+QLW5zPgD8silaz2wWw6rrclyfu56I5lEiEz57djVWky8pwZ2RzXQqzLrZ3ycr0fJy5TzG8ErQSSMiidysd7vArZ9THSwhYwH56YynoQG/rFTxZzfqeiedkgjb0bdCKtaKD9DHpeAembEtEDKJYIobyc7gqZBk67XqC6Sy+4VM9Kmk4PMA5Iz6PGr+fJ3F3ITkbVDFjnzs3OKRU90CLBR0mdRaMaG6CGoKgSruxN7GuyvGYblHocuH4lyxTqCe8sj3NZW0ksQvorOyCvxZzgH5rGOi4o6GtvhImjwC8/uwtMYto7kD8+U08mGvzNeL9B5tbEmuH2PUtHYanpaw2rxWMmmx3Nakdegut7WQlvAZjjht020OLg2ykYzMcU510cm02Sw8VeG096a+3qKsmYTaCSzhm/LVMDADJp5f1zCR4mYzd4+tyJBaYJt2Ch9ZI1hlkTgZ16ZPp+D6l4yOxjm7JuqUK1ghG3YpGsJQqPzivjlNzCmxlKTEQVAOQIpy0zLCdiMaRFu/ZRgBei2VHZbygiQ9fJas/ZtK4RFdsG2yVSONHrTRzNyPmBrbKpak2qeSGZa18vOYCtZKwZQdjgQVKXCpNaQVvYVDXpNrtAUv5QGLChxsUZHdcUc+0Y+O1gSuHKQ0hAyWdkzca9W03GLGSEmwtAarb964ukRghQLmSVw7/uE4ktwmgRH6WtvWtX7xGBHb0QEbYe/VU6K+nklJMrRqJlSI2HfqeX0kDMeVgs45EozkdZa8K/rqEulSrwd0oHr4OKrnTfuOVluZkFs+PaX/nISnIDtEnPV5V5NvVMgYbBZxa93CBGs8g98XyoQKK34XO1OFcRAIdkl0LI1edOUxJyPoP+VDbZOY+6HiuBvVdLlFQXcOd/XeV4wHiFjOGN81reMT7r1/HV23kFKgIRf3U8gBFzGD8o+1RWvDMSOFi6e5qVyxTXJ2xlZUpWpSC2Ibpdh82iOmfJZvOJfN75T4LV9uy0LuRbGH4hDKlWtEHBB8PvS9CAwT9+g07qL3zkkQSHkLQ1NJtsVHRqJ/k95//P1/jUbe/tSn/uPv/5sm1315lv82330C8pHiMaZL5RG+BMMz+1xI1eh4HfU7Gz6P6MEUwGYK5yltTnAM+PTaWspeYGq3VzYIpZDQUIuQ5MR1azC5cYk7rj3FsYH1zbpFnBc9twMovkPZ06amAd0O7PPtgUXQ/dd2JbKfQ6xUrCHMKPH1TqWqT9DkcqOBC1nMgFDsVOVxlnxtVQl4YDyhamw4rZReNZ9Vw3dUAU0QVJxoDvu8NODNtWtuqvGxaaJ6QeFFpQFdPndy8IJKN817p8VFMa/WDzbIfFt2JEkjl3bXt0ZQUc3ZxCCZKyoALqUifK6lLIzIt3q4vbfhj4wrj6NffM2o4iMKakY/fLC9u+P55unPFm92yN2MOFkVojAvDUsCMwEQlSbx6Bcz4WSVP3CzUHwjrwt78tdCO2oE+tN4xjopd0vw0bbFEZby3N2Z71RCGU+JT0XeyG6L9yJ24nNlUwl/hcgek3LE22Yd9sI3E6EaVLhBajAQGxNjXGtX9aRsR9IVyXrsc7m5ALjwmDGmzxcK8+BVgUcn6CxGV1L5tPdR+TTiFkOrbFeCuyy7tR50GpARF+MFHyriKhRPSTkiHuciCWkVxqMhFwFFT7biuIAhvLGfqs22KpwveG/3eNgz92gLMjftnLvNvenRSlO5yb0YMwA6K7UWTIYQ99ZTxiH4ymqh1LMEa/LJ9ogWNP5cAEMlGNZaq4midJdoe2yk8G1YNZL1LgP15Q+Azebkf66p6nZiPIpoGlq0wvz2VKg9LulOcyl+DXL54IYEvqZ6D/YYDvyhbK1wHNnuOurTHP4Unv7dwd4D4unfOzw+2L9tAZO9naOHR/umhsnhL0nTH/PY/1ro+ffcP9zajgZqLQz48gdZ/4OUrH8/kPWDNSCh6u9uLEvcf+Qef1Y0FbEnS5opEEdg8Uf1qNhvHxBzsEKybP279/eO9pWtf7990kMeSset7Mz8FiKdVZfv/x3YnEp5ZCPXStR4dCeFvJYRqnkpNms5u5wXnPjEFUOFlsIXJ0iZxyNmu+zZbSEj1CvAHXjsFFMBuGa2BBkmuDRBzyib8Ly4/J2pppAdR4t0MLLsWBJP1P8jtMW5OWvVrIOtTDsB4scXIWuCoi7SsJUfSHFvdsByaWjcMEQWG7jPAT7MLl0M3w3DMYUS/YUcl0qUkbFfLky6b6FrOrtXzybRISPLAh96yFSL6pO6e76oxrnppf4DSoZSVaLZjbfH2hFHG6DN7Z5Z0Fx3Uu7MbLpnHyh6yi4bus6E4kdUVU0yrTcfWyuAxb5Gp/IxS3YjVKwTW4levXziWGMfNneacc8EL0tw07ifJczu3G/RqlRMjZ48Vd+oLkA919gjpgsqhl1mwToKO0qmH/Aa+br14KqVN9CE1AtmofKSFyityZalhUCtbKFaBaH7+nM7b3G3BHIJD2pqlucSvYGLibF+bD7SNrmnv7hHh9u7Jlf1XU/bPet7S9ZuM2MveRK3D3AqVrm3AJlezrSQOFAapLWufHXr+TA5sLjfOfGJh8T7WZY23u/rhQGEDZf3CSlzoTP5JhybzuqgiYwhw0TmSs4bi7fraljaw5bW1lnfdO6Y0nyGvXuMCFuolK1rpvZ9Td7+QEWpPn/llhcDyaNF5eRS0+tHh7vBiCO6XMRwySYiM02xRANwr9HAOCrJsCFbZ+IGd95lvfC1hjZeC7N5w9lYXNfqtJpeu2MdoeB0A/6EXWWXf2xpP9VfHs15G2ieLq8HwvNwYP6vObpmDUw+A0IVJgAUw3x1y9jxr+kmXW+mAgC4Ul6VxHYVSvS23s1wnIbCSJe+vs3tXjPZ2ri5dSFI5mhNCyv5PafKJvpTWu/6QiLUTdhcGXm94Y7hTRhOLEsOZYkqRykVlKf25aNLN8BCXIabndbMzSJ7IMwhTo6npoH84u6gOHinu/g43Z6y+gbfTXJYdQNq3cMel0bfjGI6rhQOrhnUfLG82Fod2xnTK9XCExVt0fsH4IlKPCkqgTPn7lQf7Ko360ac0nzyMlPdurJe5oVL5vaT+zcEbqfLyXkJDcQ/DV505s3YfLSZyyb3S0J/Lfi16MZINgSrHKRw+ePJm8TXBJcqaFVgz1g/Fs2ElmXREfAuFd8eeimCir/xFKxizFU1U3+f3tk4ljDcj+2vAu6SyD8nILdAzaI4UzFd2/hb9gGRZcvZx24m6ET50Il9GrqM2m08S/bt6D+pTmvDdVpPkqPQMqG15HK1xVh0IFlLt5FGeNk0dCnOLMPoQJk3qBhGDMm45mkIZeFMEXGtdXeWGJxh+m1s1R9TwLyksAJtiXPQUwHYdWPxdMn2qiKKibV3g/4acDXxH0pLrOrwPBhGjczO29vezZAX/vzKeXu5inySYYt5C8aDjXeTP5YznviplDQ9Myk46quME8qvIlYclsAN12Evbja6e+n8Ef0P6lFj1cUX4Oumm1zQUhNANNo9iQxUTRriAE5S9Y8cb1l5NC9sFq56JuRqy0i9/FqkK/FGCv/xQQq2h8DBxZOVRKCddC/FzT3maL6azhzYS0uF5SYVzY6Lc+K1CSbO9Zwq0kPcsGZuPSYgDNRqAjlGyqyzjj197GjSAphFfCVK3h3Re84hK+c3DLiH31ygp1y21r0v8vnIhbHRxlGkBqSFnGh+FYE/XtWeyhqSjNFm9TznJOzwfoj05B0pZiP14IVV1nPhDXHDvMqiLMqME1EWBB/8Zk7cGPvAc9ZI79n+OBBehxPdlFpeY2UHbc+etsiYxIEIeCjvmjtpKQXRn6SqFhLsQj3mIrhszIH0CWHFsK2bR5dBByCFhPt5icxxY349en2yfsMUH+ppPbkxF0ER7kADaFBXkP9BqPjNWdbrz4W/H9uOlrFQNfCardeOQo7xuLwshjdRk+prp9cAnoY4BhQP0Vghbe0H9/mFEJgukEIdNRkN6Y0ywGHRqNpoFLSMHW0hRI30wfGNWsCZ05a5EP3OEwVQtw/ThwlmjHjP/nJ68t1fvvQe0bX+vajFq0o8T8KTVGv+eoioFhs0qGA827QSjiJfSoS2F/ZEBZIZeVcf4MgvlNuVhsPe9Ohlt2LqTYPKIAqy/NADtQXjb1jdEHqLWEcMOMwkMiNyHoeHN2AIOHS407XEgdzEChi0fK3Bp9yxb7d6UiMdx7S6vFr0LjlfxF7Q629HdUGbOc4b2uagFEzYHLQl6/DueOcknHMValy5E1NeEo+Vj2Z5C0q82fTPKYekkXm09q3io9j2oIibE8a+Qahij94YPqoI8LBhb0n7mEzumW5fyyjWKLBDAdebvFjAOIvoXqJ6Gd+nmlmLO342G99YHxVv5E26GGzQBdVMobAxwTk1TuBFnpSA9VBofbhD+mXkXyr+0bbyfvhN+30A/IT9u/4akcvDBAaD+RI2yaJeQO1UXMYPnaPvMDsoIzxAIfymthetmPIRsX09D05SXYinRXOFqhD55TPdGCKHwv/cv6kXWPbUdgmKJJ9X5LUstsXQed82y6oiLNCjPz36MydX5KeubQdSbuYienezTEZfVHh5hCkgIldPp83a0JffnHTrVShmM5WDy0A6Xv+QJiSWl3bziKvWV1zBj6dBUH+JGzfqCIl3V6iDgV74ojCvA7aV5Zz9e9bvCiERm+0r3gf7QO8TY5WICCdhN78Jt5bNRKI/puGWI3/v+k3hNYeQPCIwV+6VzTR1mRhLlqgt5B4QDyHnlF4xFwkzFmjrub2T7pyvpeRUHCpW7cKzcPtnI4+veunhpL5x4/8A1pYxXavGi8FblAsZNkN3HxLcSnzJYqBImcPI5CHPGJn1IZyacV1Ls+aavIAHsnPh8z9ou1FzPzIuPdCEzOQXXhMxCeh59SPXanQPbvFsntsOPSVThRa/V/wZZZhHaxx78U7oxiHCy1EkF/g+CoR+mUoK7Tlye26zCy7vS8fGUp2fiyKOq3el10m3OBqzRSV476p29Nlnz1+9eXn29NHbR5991orjx6pJmMD1h48qWZQaQCGdmrGzPwRTl8N+fzolYQXyL+WeWSy4QGt+L3aHZMsZXenT4Y2y007Oz6SI9RnSG9Xe4gt7Ar2UK0yllcm1k+DUl+6aXNiG1+kCUeBysKgH7j9b+u8JpdVzVd/pjXy5wo5bHyWCq4HzRrQoejCUU9AHwzi9mqUlPjgWR0SsIoPJYl8/jliZDJFqVVbptkfAT9hNmHtLhF2IBPrgiYwqeA2hBv4S40hqHt+2y4tKaq0xndiHWaV5capde+WdCXrm5bCaVV1RlhVMJQzA38/cMjvbGVeYseM0xqeYGEl0y8UDVWhYfICzUMu5vaZZAun3HQPq0DZN8FvddOHQAMRlvY6YVFzaba8MF8ol/9KqCrkZmluP9Vbggjht43s5XuZVKJ10D8rOczpyCNz4fdix3TqJx4wjQDT8nJvNhGHIElh4O6F9E7Xdh3HypId5cyJSiMCqsnx+E1ib/LSdPCVn7kX1YaXmz0nwdE4A4xMW+MQI7ohxhf28BoMVcz9DVZQIxGVtqjLQvxRo29GR7FUUEGp1CefoCtdJK0zsh8XXE3ZFb16MqjrWn1TKBIRElyzE7Id7mudzVsBawq3fwtUhlzjjk8xtwxYhCaWGnBN6mxD0dk/l3Y+YQRPT1FKcBHBJPKLRqm8Jx5l6uiYp20bjqdAuxDXWBlCRlF8urlIO3ikHOSGNAXjgKUmMXjcEBCO2SCGJR9pSQtqxWxnelqSS6Pj8iLiMRzhf4iArvOxtlaTVDPnWsVeDnBW0DmgDgMFaD65dY/gWjXvmJ7DriSGYBdlk/IqBCakI0XjvGTSvnvghjHOtMPdB0K96QduChmVHs34EKjn0kp6JSSoxQCnCOGE2uq2M07H18uv7lPQmvgoA/uWDbwElOG0dotCCIEDg5ySUCCXfuEyb1zVbU9MS7JkuUOY9DjgGlzs0d2Vrg2qxyVTQU++LCQU1M7bpRXLgVrw8446aRTnTtALGqXNYg+/f7BnvatKe4bxWvSEAg3s1UcTcoZyOMioNu48QYxRTtLuXuJazv4gDcsqDOMDaoilnZa7jFd3IdRK1rRPRKGShRsnOev5Oaf9L5u9dddXEXcVvgxFHGLBW9UusBvx2AdBw3BuOiRd+OQt3J9NX6rPMFd2U5jYeFsRDe1560mBoLCAb3+IyE0hMI3Oc0x0LzRoNNZfJc8QmlsBNyN3s3rouqCh8yNdPqKSlLpG74a7Ad66sZWT8kqJnaIxvG0xom+yZaALHY1gv1aDCNDLP1uCNVwzAq8GjEUW3SjbOOB3Z439DBFf+xMUyc+aI1eZNj9xdHM2krpjvALhNemlVfmLNF4mx/HZfr3Nh6JvBPxDIqS9Cwst0OYHOxnqg1twQ2BvPtXc426IVnSI337N4lLQWLxRpY7NzVbGKkyORb7XwmHY6hZO9CVAbzVpHQ1oayOv4xZhkGApiq+dcSKewkOH4da4X5stE7iL/b+KjILEtlLXQjijCWShovGaPbIfK3sJCQ2ixTGV5m71vczjRiLzAb7aMHPcUMvpa3FWzhAN+86aNSpHpxefNoeo57TUtKEs7fVMziQsteWB5cP4yl3Tyfp6PXEVpy0YgSq6jTghVVqdkCJseyzj50JNwCniuUc87ZVYTK7bkPDdXBVonVEx+TGvytcjtlwJLLgKczrvcC5TqidwUBnxOj3aB07SniH0/BsgJpk8GUgXQOmlB/C91Yy7Ui+nj16mBsDbl8w0DZKZNpSWcaMb7UDIfuV0xourATV/CwEywQHVkfZ3z5Wx9CoDsUmIvlTcwKYVeBLpL5r9TBu0ZnvkfRr9ck4HkRvGalZGOVKjeqBbieY0KWMZYVpeZD5Nee+2dFuMn5uWAzyiuSC9dOF5l6HMaaLiSUoYJ3CA8D/wRolC2mXjrMOHC1CSLbnQry1SPyzNewjMJW525ubmkm/mMYF94A0ZOuBaeV2Ov8/KvVnumO9FFNsgGXz4bC+bWHyM7cFJQlWkAJVGL8eTp7bY3FtT7K61YFdUgzjGZ9l7BpZkl+crNpERDneLIMHlBFESZJrot1q0KtxVSVW16apiubIwlknKt9OhYbTepGER2WWg2wLwMUkT0TGLd/uBETUPIlb9qBjiNC/i07tyjVd5qVHE3gvz1V6+zr9HKrta29YYzeoPqzfWUt7V7p/HojC74s+ARZoPljA7PmdOLrgplxscnLfdH7swwlzXLGuBeT9Xw0ZIMAMA6jYg3mtzLylBmf+k2d9WAAjVof0TpTFi0Se/Ov8aj/ePdtWNT7tZI8VPTla/qM64vGNBSpXzSop6L9w0vvd05XKfEzIafCCZjFp/Aa9iC5zcRK7f4SnS8ML8qrmO9XtAHGhp9RU5uITqq18rQyCxVryRAq5ppYhN2Ok6sy5i9hlu9/pc1O4cD5yRdtdvb/S1PSwsrAkM7TdgLOtfMdSuISOWAdAcC5x6rSJqWCGfkpFj213Ph5uP8yzO2ujfBk4exPmH95blcyaHC+rmUAom2EuHNi7lu1UhjHEVohPWvzQ5j4Q20RWujTHRUfOMCty/BbZZruH+KYh3q3u27/XipSc5234gHT7/yZcS4DrLqUWFu6JBgP2F2sHUJNRaXBllF8bK/fXR7ipeDwd5DonjZuX+8cxRTvBw8XEfxsvvw4d6RYXiREfwyDC+r6E9+FXwvGDFd6FQgGAwvQvBy7q4y+vuQ/m5TqtzfUUaVgwE9mo/AJX7cpdCJBQyvwD85wUzptXFzccaZD857npcub6QgUsKD5h68gPVsWoSE8BV4soOw/r+uPlM3Ndc2+KG02Vckuta8zZap4SUqsPx4y2t9jELRZANiEoQu6K7GToGtt7/3zyZsG3o3G+lyEZlNxCW6qHPc6bqQLd2tU6dSrl/OZUOprlCoolpwcC+kOHvwiEYdOUmPSX66Hcn1/B0x19MPQwzEGwNJ1i+Xl8EPH43e0yhHXVmsHVw0Ab3AaYDComKzY+lZfQfvhOJWqkn5A3FomExYlH765u2TtUPIoDY14VrMxhwDxiZ0HVG03bbsbUPQSGzcvjriLDWiciVsWTdOPfdH1v3lqfOjvLQkI0cJDqCCwBqkUjObrZ/TMN12kXT1vNiIAeasMMEFfkEu0RARX41Rbqfhx5karVQNAVyy6rNJzCzXUb2MUt+4BoIWVcBOJL+agpri6hijJVyibAW4O6OYSVQfWrGQ4a51xRpxIY6A2GOkG4POAZRhsFB6ogf+iWhDUvopiU0bcgHk0NCWocQUyuXXVGKncy5n4OEFop3OPSAwGprKMBDFUqZDmXlAygxfffKlXKJ0Z+91KTKHg/3d3u7B8c7u8WGiyBzu3VaR0d5//PFH14f7OZjxB5xMhav8fkrWdhDI2h7JYxFbW7uVPEube6E3FHLip3zyQAJaDXItEPez1BVvYp6ubX9//0iVi/tdrGZ8pbbw3AUvpjhh5CnJy3jMiY14LuB/Wlgo04kWsmdx0JX6420fdG2HxIHGaj4aRORxGfDI/U67PhHPxajVw5tnp2+RFEf2aJXcj6/NHSyBtYlEmqTaPGeG6VVMp3Gt643qg84n7HgJVfEk6UH4R8nML2ZFXI0wcli0ao2IcTfj+gvqZLd7Z64JRzDGBLTvjzBztYSQPqtBOO5QtLPzvo6szDjH9PZJF8CMUF7hPcc/SaBOLcFtpWwxbieQ7KODucGdnFn0RzbVl9E3axtijVfc87ZuhHh/+/IVVqMvG8M6/7W4cVsNa+0SKt0ZwoCcqow9R8mSGgynDQNr8ssosBStTwuN2LGj1769nUGzqMA/hxLFHLLmWxebRvwbFVcv6QgkxHc8S9gzEY4BossxtWQxY/pqNbypMqwtU7MyUmgK86byMIZ75ua3XbQ1d5n7U0m2mS/LKxkyjTgT5Dxe18sx3cjECeu072KhYVgeEmuT03JB2voAAytMtCwag804npdpts5r+7aZGeRdFrAGQcmjqgnZ7ZZutpfF98i+GJEgcKqT8EOhQrW7Dp2x19b7gm3YP104veWmd+UWvXQnir0xWFx+g2gjUJRhHc7GHyTIGK8kg8Vpu/eaqgJjGjTrlC054HW1AO1CqxRCyeP9nrRkbGNNjFLVcbt3wnwTW2S1QcdrJEqp0cnQqiGE4HbPS7qJpYjttOw5EaTPcpePusLAib/TlH4SocUdMDx+PG4fhyF2JXIWNBhFCSJjejsGv45G7cLK60ciGkdoXtOCuIdqypeQ93hAC/HVCy78CS2Bk8m5eq3l5EVxctLnZTwPYTjCmus6gxI94DRBH0XtMKZz3TQ1byqIbSpkXAsi6Loaj6UvBepCJJkf57t52VLiDJt4dprTFU+XlbROfmGofvluBdmUKQDmH0mv2zRlrWN55LH2z83aZMTOUWeibHSxHOwc9OwVHTuJE8Ent1fXVd1nkIvS/ITx9lkQqTqthFVoDFVMGHqlys0Ybrf8S2XSQH82HVALq+BzuIy0EqtR3C/i3vvyG1X5E7YRZaXJ7wRLzdNAzcaIQRORGd9hhgSJPZP0U0AcMV7gTT/wP9sjF0BOJ56xYwoZtqX+hXxnLdKGaeJMyr5Up5YQ3e9+PzpN/PIShnkgiRQyLXN2/eO2LEKkytox5E+IMz0vxsS8jUn4y6tHzhZKKoyqpmuPTu5IxE39m/splRStG83lUROJivRJIE9WTcMgXTirpOmQ2yju0GTARZvA2o59rQLKVm9IDl+jFa419xrPl5cxRGRk7dJ8Zu0O2tbtG3i0/W7kuFqS9o3yAd+c5NqL2c55R/6hmRXTbng+OUuiCDsnMdONA1m43XtLvlr3FDrG7cB3ksTJ4KtNLAcPkUmyHjhsSXOBQeVf4aD1Ct8ETGGwbDy77Vh5OuJbYBwKixHQ0NhoeZ06LjJpy3P0+k/IrBr3jQQdlnNUuVKNtZ4N3E3QVY+GX2x/5dpkUho0daJITileKuhOvgIy50FNB1pXrzRl9FZM+N46W8fTANexIyf4FHTBo5lV8L+gCDwwz+ApsYQZrR/FSfnmzjQ5KporS6KlHDbqW21uJufuwGCdpMCW+lyqpDB6ZDWyE0d4Wuxe4olNTzrJCrdM+UntSL5rh/0mhr6XNAepOSxRKKT0NFlBF3fYWsM4BATCvMLbiL5HmmiUVEkmOv9rt4RcvX0UzShnyAGtmTtaidtGLr1x+b4cx80woahRCrMHVUFIiedNWa0SQvqTpyuHBKgPRxVNalCKxKOvc7PePjk40XwX/rF/QYb1dUnw+GOnpu78S9+wxHnuAYR+vTdOvS6b+vmSo73ZKFaG7+C1jFiaSBlxUp8yUaWOIkd9ovzNKPdKHYsfZ2h6JsPw1t/dH6fnwgOPiBx2QEEHTyMarAleso/WaWolepZOLnjvZL6bDA9rDveA8deF8l6eoVGq2PuaML2vqXpx0iZsVhanVDfJc0QbrwlbnGTuxNWli4+7HdsBg7LXp7ukj3fo623Sd4bM++oyjkV8nCGYQ9nab60dT9vyc6lb7CUHVm0GhlH1dq+6itc6HXlmgrgSELaMIat3/EQJpQmwi0gC2RWHOXznZSqPtnpfkbSgaUivy6LRtNhvGvF26ck29HWJNn33Jy1nXCo51D6PrxuUeq3GiwEln7KjjCkcBfYAvvPICfURRqIAmLZGFyZ6y0gXSWQOm/HjinyfihtsTZYUUTHX91G5Sx2rrW+tlcqn7PWUZoMGU6Q6zMd7BXGaxzyvUgKYQy50genVhdz1mpLH8Tyka8t37wHTH2eUghzOCRGm4gMEpxwF5AE7Ef/5D6eFAdEkdsvHGU7W9GdLSU2JGMlvRAD51D6qEhK8AMbmAn2P1EJ0tud1GcwEBBly+T8fbXo8Rkqrq2VErc8vZRcn7XV5IvHvfmTljK8jBW547SyCwhpHx8/cNmkyXzW1mUahHi8N75REPpkqnuBS0NB+q3sZE/S46hNsqDiPyCdIeJOHgUCk3oA4iZnffnZvnI/RUgqpWoEw34B3lb2NaWhcE4A/3TyQW+BFJu7O0QJl9vl4iuytp8Md7DHd/TfRVWTNObTzseYjFn28S+IatVWg5vsoq8DxGmWH5uqgFFBgEgzxJfqUMuOBUz4HU+XwIy0P8zeFevbkaTQ9fryOVkfhf456le3O24udiJRuLXx/Qy086/W9tKiEjvojaHLFG23oQQh+pHJO0e2WY2c6imOfoRSV1NXMzffPHlccsHGjgzt5q+W65wEGtf+RKh4S4PkUYyusGr7Wv6rYFs5dzQ72UwzSknSzdHSDOedSxQYfFAYD0ManGMm8uDZl/0QYd6J4EJH4BGsWsBJu13rGCdxa1pYT34dTilTnJy8GQRncKyBrJPEBf/yhpoCUoMzLofy4nUYe2keZ5TDVerh0jk/c+CRn7PbjsaRyJpgcaHzE7/VI64V+3AGzVM+OVPBVatPyoMMjqvET8p8G+nHHRQnIBYsc4TzVeEaoRkHHbyYcFEp0Q66nTzFDnLWTcKO24ps+wmZJwMnpIjH3z7+uveW0nI4+F/PgUw+YwFkSbi8/qClgwJXq5v2dTPL/kfHQUgdDJb6KBEAjflgNfFNWCMdpP8lV1MJSelGW+vQ4gLLWnvtU05pYODlkMbRMWWyfp/ml1GX75KNKPabMuTMhLB5nh4IBb7yEv+nTjsdsPRF67BRtQl1P1jjOSMM4k8gAMsxRdScHa/jIOmR2CmO3XkunnwMoy7LlE58CY51xcaSGqL18cg58CpyZOId3FPWTGga7JoQtE64ORmwPYM+S9j7JfFqzl6gOJAgUp6DkAk6cXUgK5kce11PlvMeMBv56c1psVQA1qzpMtk7W4gzRhwjUoD4fbN/PIH1adx6kSFDo2F/Lid8QPPXlpQL61yPhKaQ+G16IEn126fRpcXKcIWbtzttVPTJGsgCiyCVRtqDhq/LK728f3j6v/Giw+7C3c3R8uP9T8sp3H9y36Vgygl8mrzyXqPWryCf/kR+4ruuh0MsMcH9n89H2DkM+miXQ/pZ/Eaem5VvN56e5oTxiaDpK8KB600B/apNwba+0xdFzPi1tZ4fS3jRt4uEmgN2/LovpAieSSJ5C2ddROXOrghCAwjClHgMlZTIuLZRYWX/O3hfzCiqyVCZvMqXJ6Ucb9BHlhjxYV77HnPL3A2c9EHHqsJgvBoqq8KZEFhZpE8Sj2nLnxG9EH2ldOP9iK8h1WoOKKs14LJb3jTBUi0u5x0XBxPHgt0Z2clq5IgHdZndVQvnD8o0TQpyidLnV4xSjfSfcYy7wTiAjrBJRaFxbvJR720cmTNHBEfYNSFGyeY0cDq2E6zIIvOyrt0DYney35wRoXQH6PiUsFcz13mtZilOn1KqtkPnaEJm4DZemFrQdFOl6nC7PvaxouImohWdT96thZiF5nsVZBm4xRVrqyL567e0WuNpgwDAWABFZqVYTA4M7CaH+UlMiyumzVynmlDYPAmO0fxqk4YwMbHuz1kHrUozdteBm+4fyZPHfZG+ubye54N3CMLov3ipZFPSKZv4sEMGIPlIR0URjJGcGGSJ1vVhTBE9DcSSY3LUxkEUaML0GxSJQsi1op/WUubl9knoA0HZ2UKB5kiwDqnVjHSfageQeF36XxLWJsserA+qeYHbaWzMcPSbK1QKprbJjtkCVupx6blDzm+x4LLSGhvN1eX3ci0+aWy1mw/ouXNEc/pKLli9Ws7fQSFxJQdqqL6iVxdVyct4w3paFpmK3t3t3nDJ7uL3T+33vrmnRg6ePey+Ld2XHARa3M8fqJLuFbP0BGTXb+eae1kR5rGmyrAbXM79VzXTWKo8Bxr5ZXLHJVPhf+6pZ9I93ZcbXvtEYVvSvvn6qDZSmEcQjgRmn3n+5YDfqvV3sJD+UpG2cXf/6504DImRwtfhcCXmylfhsirY/DMe9V9PGiS+3c0eXKKvJPFwQFsy2W1LWPe6KMtzz8eS70c7MOe/MO/b79dVUgcywi1D2gHQHkqKjzGZTf0O4FoBZnAC4sEiUg9bpeOVrv4spBJQBUYxN3L+HICJ0/ztc8kUzHkcjkI2eJPVo26eWvF0mB8AhFs6y0ls9eH+paColSun6k7PJKs4a0vp+CR3rHQRpQLy19SgvRFhJD0UfOoZje/O5iar7tG6s4953T76N398DD5aiAtXToPsV78tMGzn9q86opk70PT8Rr+ZPHsvEcpfAPsm09GSMwizQW92ymIaViUY7IGqla/IY1XOJnUo+SQC6ZNp/w9Q7XBaANGRyUaDOveelFTco6+30cDAkMg0+D7lhTQ6BLguAC+JxWVD54MdcMjUrB/IVkqJueiOmzGmdm6ARuEuROvLct8ikHhLHJEqowCfTmYzrrhah2RSuX0pkUJliKj5998Tv/6DFuLM0k1KURSaz+Lj3eF6/A8jfl2MzdYBio4I4H09Pc408TxPuffpWFOaslWoMjV9SocsWeUh0EiQ/M1ez/IkzX3a293FZf89cImTaumsVLsOVjb82dfN4QE31g4hxbvj32TER0aK7N4ltjdu/0SWpw5LkfukdDq8fCa3tY4VwkRufN3RFassUPBBc1dpaECQ3z+UA/V/SeEuoqqxkbcb/mCZlNJw73cZoi3YTtcmHdPvvtOAalu3tD+7Y1tPLL66H8Iycua1+ptfOmUTM+AlxDAQRkCTC5FbYvAGG8vt8wkqXgt/6veJXbFVbXcbM+q3CiLMM8VvHZHIIDeosYmNf3xS8KcyUOWnz7WsaFqRMV45dywtKZ0+Of4gzSGt+5XKmSlg1v13+4+//byONre88vIxxzyhqRV4s2woYlUnUFLBjzm+yYz1f3gzq+YBzEzNjXTVO7YG3wndPzsTEPz6m+T0L7LsKdIBX2HvOnJx1PxajgHdV5tgcdXjqEgXyT6eSHDZH2YDWAdCrWiytTiLbY2LV7nDFP65riMPf9R7N4GoBFO0131Sc6LjK43TU4Y477n3/7zC9eIwsfKieh/c+wqsVRfgpT4D2QRA8GaKA6E2O85GEaHz3W+Av6A1/7M92NVIiHzS7fS//5dQ9UTSt3EqRwSE3K6N+i/ZvRAPtBrsdqc9K/jrMaffqHltpWodtqamNYuUIhIGTkgho2uRlqdpniQNABxHvH9kWb9kYHvQeXZfw3+oMnNBkzW+6fDertiMnzAZYLisuHhQqmbV0tpLG7ay28rrxDm+Z/0uIM9IJ0At4b3v39ysULHZLKs1ksOHMauRGtN/trIj8k+6dL5cKBs17iZgaC451sLj1Iha3ezKBV3Ks69goQhPZBeEkAK9Dig4v6uN5TZhtJLxNZFnCvZP4peyuGTs570v10a4k7tQl0l3DxMV2W3ZBo0TPnjVjjGOHD4XQe6Xql3LZavZgbHkLzLC6kP3mrcQnwUj2t4Xt/41nJjXBHurklI+fnoiZ12nbx1h7yHZw4svF2B9a9fTE6xiNNVS1vlGtSkioVs0dtHTDFbup/FAOl1p8VphL7Hg+NzGws/PStVaekRvjjDxCZ1Qb63PsyF94BFiDM5mQs2Y5mRTzm86RnFAZ2QlTw7FnoZq+ByPGjeeSNAZ6vHWQvTMa+TtMdJk44Ka10LJ7fDfyJwVHhBcDbKSyv0o/k6tosCjOG6mZvJQyqYv6siTAQ+tUvgHbXTuUoO0T0BOnPtuJsQ8a7Ys7klyrZLStWNtm4q/u6F6MGCf+mPuDO0FizHnbn8RGh2vEbQJS6iqwgr5nB7SH2zPZrq8EBtZIVN1rbsgzoSXetGCpP2BULpqabVqOuqN23dXWZtcLZynVTAnnQQ4R3oNtArcN7rDYoDncPvz97VsI6tRhTpF8Y3POnxqZ99btGhSjKSbBDzgp3pkqs5b5d6qU0JmzcGi048Tj+5w9S6alOIGnLKYLew64oktQxHJe5J/QJom1Lqe0oLfLwHrHdVRzTriuOICWjlKfeMUV1VI6m2jOHhhV8tBovR39ITQExRd5+xg03Zxc/mc6iL3pFDYQScfeevVTweWfc9Pb/eLEszzyuVt5urTa+QjLmBUep7DIBB9UQf/qtVhqgmhVHxtXGGFosCXrGmcjROz4FujnvQAJzSjbUf6az30shu9I172nH5xwAmtG7N6+Y/jTfna/txMZ4kOJdhYbKf+3mfnvivk0OBdHZQFpzNmbk9niRuIRQXf67W/052/5Pme6suryioI9RFXsmviB7Wd3Z6vKuz27mvmDqFTyw/pyimeLpve5Klg+mETputufmw4jZla2NGSrXFSU1xDNOGGLnKVhfn6SM7yf1u+cWGEj+bj3DEgOq+lVejhQbM2MxexaKn9Uo3y0Sb4Tehf6ScbuaonoA8mMsWt4sL3rLBhZunzQ9rj35ZgiRSRXrufFbJbuvCeS++u+b5N+leNx7mZ4ymU8iY19ScF7e6vnSxbFP1SrOlVLYrhSqF7rlHXvZiMaSNQ5HVXvq9GS7p72zRfPpRNz6bw9+H1AW/V23TS2mtD7GxAlq+5dLKdDzpPx6+THzeqFOO87Ncj2eIN+ZOvQa0/HPVJroGTLzJ1VzZlk/1Zlc+duq8GXlS8sys6Zb05S+1D8zFzwOCwgp/d0jNBE27XWCFynZnpA0Z+6dVLvEqPCXYOvk+vkk3X4TGCNrR5XYzof/pRaQTsPiGJ/f+d47/6tMZ1H+4eHEabz4S+I6exCOP5qgJ37UsxIh5gHde4FUCfT+D3xj8eIznZzWTTnAaE5R2St3sBgGVI1rqEyKWtXXH8kh9zc2z8Q4Obu9oMV5VeL3jnH34ipkyxXcTtfIoxArweZspvgqP3vtQBfwWOrhgIwD7hTVTAu6vmqeiwcuwuOd/aUFNb5DYVFBVRLsd9tu4rVt+lrtAvKMUu8eBvQ4Cqs4G4bJHmrUBEY+zITZFOgbeFHU6rytWwWAXY+iUpWmgFmWGo7gZeYK6nB2GpnE8yWUyYm1XLCpdTeoHqJuFipalFmM5AW8zW0mONe75upUtK527f8cMzQmzMnccg/lfn1huG4Q4u5A0RfdLMzJzdxT+NDJ+zxQSsEsxfsVzMhnXytG637bgjmrAfD+nXZjeqU95iyqe0D2s2QRbnR8SE7X4p63X/r9sy73l/qZe8lo5n7VntyT8dRrZfVFDRLlyCwztUgbVMXJke+kuKRUHN93URJztTQm9vKc6oQJhtcZqGCVJn4ENw//yEhbQqEJnAGM6RWPklGDZbpfQBKC3IZVoQ4miesKFwaWaucZ7ric/ZY50fAsBHQtBU2RU6IqU2kVHBPZIcydwSt04Co5LVCeqZ39hLFdW/dpwxQbiJjUWa2SVOhtt2RLUa9PxS9KydF/9i/96+zP+4f3T862Ot/IXN0GHsj/nCvcAuB6nMkr6spQz+kthQWjZROAaQ7U+S3v3lLH2pQsxg3nsO5kUrolhdW2dLDZMqNxG7HP5BG+cXf/obarwRyfecm6Uwm6ccf/3AP3ycFKooMgprOgZlf1vk0rbVTPof94SvX44daUepWEGEbfhCW7XiJd3wh88wWplmOSZQCE3DMeHDAOHxpkIXYqVSqwlQz30TnKdn3vz3Q/e5+ptvCf8miQPEbUDbg19YyhnAXwVvZAA6mv9szv0t4dMWUiCGAcG4lZaZ75aSoxo0fCx/M50jlk3FmFXJoT7dUyB84bRwK+SFp3zsPbquQP3h4+DAkWfkR/EIKeU5B/dUo45QBxnM2mBSzjoJfRhd/iYfa5b6iNrIK+KH7ybOiqcYeFwonJRyHTiAnYu3LuqZ4HHWXVccf7u09UHU8U/ZK1c2np6SH51TKdskm/Y2tYpdRHxLS6Ukxf0dxV+jBoxs3Z9XQCdklIK2jEcSBFnWHBv5UnjnFM40dH3o5pcpBdMpQcQW5z+4ou4mQOgN/OtXSepXFWgH3mX3R1u2sAuP6CjwIFNApgc9VwnFqnDoM9c3QdTTMCHQvec5PK3KPBdSw5+YlA4hqfVyBqMFUsKGAA20H/tmQgnniTUdpjQo1KIlMel0Nlam3b2bsUfZjkXABE0ppMVJiNPSKTY0Cc+JOry56zGzILkHgPEcM3/vq7dvXGbBkSloF6lUG0zizK8wJszUbUlgdRD9U32gAAjg9fdGqZ8KJEZ54FonR42sKNvS/rnsni9KZyM/Jsd7PprW5a5S2YsUFjCZkfwomaTotCYRccOvsmqHK8V9/KXubbdC16YNcLY8LykIaKfzS34r+sjx0evku3oo8ylgc2iEwnN3+fvU150JzW1KFL+r/abAeiOFjsJzCyoWbjyJZ8dPfFnMQqTOPQLh/Iy1I0qLiEpdRM/82BZ0xvfFxOI+NcLqPeBZIYGFy3Sajw7cb6tow6SayJwGyEggVjuh276v6mhQEp6aX5BzVkzWv3S85xQFaK+ovwW6dSo+q5qEdSWyaXzudaYsf9/1z9S0IXVIks7Kiw4wd10ygfBsB8UYqXbmf99+UtIb9gBiEXFCJMHWW6bz3TVZMd6JVk66h+OC2yMNRT7/9MgOKUuGNiZQrx8ljppAtJc4x5mdPaFNMnWR59sHtyLkb8e5uR2fVtFogQKJmjbsWPZFtNfX3gvDDonfelnSpkIJejsC+28hOna2uVtfrOupa0ykjdJTK+g6fPZG2DQu5u1m5CPAQyUYWtfTkaugoeqd3HyUXg1yIkGIE83F3wTVAnDgdaeXoSFhr1cisIdqRUhpdOfPSbeFpoAVfLpBbJzbhvBhVS3jUqTwZKyb43i1bcqXkdANjBnEALwQCVOk5LwSLlb7emvYUEcWlBmUkVMVhGusZXIPjsnoPppkqqWnI7VIWpGbHzhBZigGJbqchKONaRjZOs3BK8ALwjNUaEedxiTqQkKWf35h9QHeQX1eOFPLjSb7EWqXMH7pvTo5ZEfiPv/+vb5y4nNz4Dv7j7/8bUBIqDVw6uahHkbYmBdOjXCgB6Wbuu29OsKh4RxqwfaEBZdBOy5JXbcbcP7gQ7br1H1EejP5IS/nl/F7rK7l6XSNsbZ59OywcY0rQK947a60ItQjMCDNvmpxXxhv792b2eqdrsGUfqn3H+m6mXci2CVxc1h/DYd4ON7ZKQqltkEgSIeg3um+ngtgUUj2K4BLlB4k06ZjR+qMfKGEp1cgfmUryrEPQTiB5vWUvCXbSn2teeWgwu6HflTesJilEKnothq8gn2tAgYTCXehlft+bu+FYy0m6j52ZQHNDzNBSciq7zVpWUKhvh7mAPkMjUL6DWTH33gpjpNEzx1HJy5nNvDaa1nHkFnImYj0eu/Upx3/suwunv0XXzVxyXt2U9qmlH2oqCkwuE1gIfScrhpzHWC6G0bS8lBtd+xBRxGGUaeIe54epGhGxXZE6oj/76u3LF5pknUo8LiLkZAaZXVwWcdq+4ZQ80OyruGQSbaD47IWKXlo8SOQUHu3aUM+XpNTGq5MoGFVASsabIBegCWljFvXGyDtQTOwkah67CWmP0J7GAgGtQSJeq3lC3NzRZN3rkKbNqsQe/RwrcDfbeOwp89crR7//QLQV2707gcIC5ZBIzlST5URVG19QHNvVacHOeLq7UmhE8sZLP5TTeFFRXXn656uLCzc/viprmk66xgg7NEqSrnZIOmLEHYrOEt0TFzlSR25672eP90YVIfMuQNC5i87inRyMmrVODbc0frWndA3Nq/cVpZ+yeyM7qnwK5upREZrTTSFNbnTDpdqOpvkY5ic0hR/OPO3HJrGmNgLslPWg9grLo1ZZK6cNnchImkGThEGGfFFNuBV2WPcj0QmbVUqh34kVjP47UiSEi9n+LmQ2k57c3LWTtVkwLD7y7rz37rjb5YbSvui/cZG6u5k2jQghoKkW56snE4R8z+fka4AmTsJgyJ+36H1sYRW3n/bcPAULDaLGYDw1tYdsuUIL0zutleok4P7UAsRyp46cwlcRtcBi2enoc4o6ufLM8pPqBptouggX46D3snKXWFNfLMydmb+ri9ztQTuYQjRimJyTSKSHyP3aVblT/SttEc0Uaws23uBvTG4mZ8i99fWx4HRq12/0HYUrKd4og/SKYmHVkCBrPGdUVvFJlAbvv1AcvGYIsxG4JZcfNMcsE02T3Bje62BUH9WnANAUogWIrtm4ou0C1WJcFtMsH0x6t7O6GkfLTjlZgWNTLIHEPUfKP+l7E8I/LqdVrE88iUylwKWrTKvfFwmfkyeoiFypVSjZ+J4ZxPleqRj6S1lw5H5KXg5vE6CaWvs35MnFqQJvynH53mntTSXjjYQo/SedObrW3HXVIDOJ7n7qxtlnz2unl/UQXJ+RceZxIBf6BVh3UAYmWP+e3w/VXqNda6PymTJzIuvo1PAllm5CqoVejlF24XJaN2VYBoNqMHZBpuqfkDnASCg85J69l6Unl9ebVH3fyNAiARPKJXsaYBZSJNMbN/RJ0eXbysjwK2ZAf1zXC0KHzGCwzUfem2yzLzLvkgMeY+JBf6CWWyDfpV0f6o5BBkg+2opO4I4qP8woqX8qzHnDlosucndcRI6XXnricT0JGySkJ98DQLRbP7cTWoyu8HCIE0C7nSg4DunHTlBSuJpvaqp7pW8bg0dhes+2nKqLkD3bdO1JrNHavOcZsdk7ewcO2yUp73e9KHTP2nhbzsmGPGNx1QvgTC6XMvt8W7eK2G7oQhr4G0kI7ExYJb1EuJXr2mZh3KH6MApKw2rqB+IBurt6YN6h4U88I4jZq0Vnflw3fOmJkDgtLtzwszJgfT1RjjWlgoD0ilFFCXwoeBMbMOw6UTqQxOXAHfQT11M/2S0497M0b9c0cDpzOuL84sYrSiznizGCzQupLlpLojkCU2Nax5GKlu3ek2Jqkl+8I5MOUyTPRTJnPZmm/De8V5ggypN0QxiPK+bUJtMcRd9qrmuduTsXN049pR/6mAqERfaWRTFg2UFuhbfUg0ZbiTwAA8LqKNUlc1Mid1QBw+JMyLSdrrJRC6SsrKodDQtiPYl39rf3d7Y/3M3tsY5bRv39l2XtN7Ka5wMNqQ2J75fmtdPXfUeCvO5wX5OgnC/H4DBwt3ij5ZiEg5SP6Onpi+SAhfGkGsyAor+8j+QTGrHeTcLS0GlidfXCDIXBYqP3c+95h5wpA0T0Rnc9+sfpSOPST1bVpF6q1Y3/8x8wHfROnWk5dcK5zvzqXtloYpNrOZD1mP1pXM04r2QxOMHo+YzzAlZcg7ThNWs5DiZGG3+1bIY4Rv5/wMq6E0zn7Xc98VqdPF2HDryNmUe00PdvZR6qu2WfUHHp7+gl7KFjU1VirM+FX8rnbkRHXx1nONHnTOSUe9MOGusmACHrqdXEcpIeN5zn6iGRIgUNKUpQvK8r0Pp9L8WS3bVYgcHIWY2Cc6PoM//Fd+aWDSw3XboUhkNRYzcV8/Kato1b3SdX1bTIvuiuTxX0WEsGQ0bf8L+/K8dDspUMGlti0rtbvUf/9qj3eL50SsK48ThBioAIa6viDhMFZEu8Tgh6KPRyi20yAz3kJW0E52Z9vtsWPhlhxCT4ST5M7TGasK0Q6Fb3KRtruLqgADEJ63YH2uz+9sFPofTeOaD0D2L1TtI/DnfWoc32D4/uH+4buJkM4Rfk9E7QWL8WtNmeHVs9cjfagFml52tzQF7icQVjJwi0Ve1msWh7h/c9tzdKR8HFE+qK9LiVwBnETtd2GZctcYNuiRQBkjjKJaEEymT0kmbtbHOkrHtPmP7QDba6nIZKnsHpxPc9ALbkMdItB+pROOioGRl7m7D1pXzxgjXLfJrLA7ftfZrLUSf8IoKCCo0tdxygBEWv028oDhk24kmVnHCu24isrhroL+Nk7CFal0tQ6WS57cYA833H1kayLuDbnTJVS+23gn0HrHw0tuyoUq7b05vp8MpdbIjMccmLcenrRpST8xLTqlqnvyScAeWfgow0FiKUohZhD6eocCegWoye/DyQibKRU2fIeukFusOC0NjYxEY8AuAsueiY+ESg0SiLDqIlXy4421XrFs92VZtgqUcGqnFGKAjZfdkuuoxB5Q7D/qUsGaqtW10uJZ3GJ81PyOkPdEgIJWWhoYps8tqvFIe/aI+ZGSucbOked2ZiPOEJpZnB1euu30TNVK+JbG497Rk/fZSLxeV7J3VwxpFeIsIk8+s0asSnBS0kgdNOhFm3EhzKO0UpZRkNXnab08nGpdcwZ8pNEIhCRThBEc00wy+NUHxrVsYko/Bi0ry0JRZ6h8ECXC3jgL1jLPe7VXluOSWcGqO2X+69jCVRLi3tYYcAX1t8L5vk9iC/dlnu1JQ0NeFGFXXbZFkHVtWMjXTsKcXIq6+6OjaJOqzJ2aQgrlKij/SkJFRmG/3TacQrKxDiycxJWbfwtni2wDySYlmyoFGkhjtA+vO3ZDCQz8Y+J/CZcrYQZM7gB6eYD/6frd7O4OFW7+pm5obCam8zK0ByoF1munhBpdmrH8TNULXM3Hgc7nKVocgR5SgQGzZKMj8NE/tDNWOChtxuaGMzveRO7lWqvS1wuMbJQ4oMdviFZXTluDTJUwVdezewtbw8xTn25aSqBcd2VJ9CGfJydR/UApqzrbgGKobfuKmYOhXnxih2K1jW7bwcGZusgyPQ8grZrKLGLXU50hJS/lK/DVuNHclBNJL96K+96C+xHeFcCkz7hCm2wMru7/ktNcSHqCTULIyCgUia2XSwbf1n/JPGwDl4cMaZ8U1gpAxP7FqbN9fIfpwkdSrGI6P7VqYtdVmSTh2+vSW5P9g7orylPfd/O7fNW7q//3D3IMpbOvrlDMnVRtWvxqTcD6MsRu/JXzkasD2Xtyn3g035SJ4nRDeej43KVS3nrcqHbgrhUlHicLYwKYqUtTLfa2JCVIVaCFyUrfa3v6G7bkiO/tIz6AZR9OeXL6RlNjVny/msZhdOV8VMCjz99jdgd61U0auvBT6hcSqZpAHDlYUfiCzVYUnqEDnZPhSoRDILwS1S8n/7G633eiXON06U0gp1ii3Omp+Hu2p8tgjZThhUH5IgjcBrn9h9OrE7tzyv9wc7u4O9g97eDq3+3mFyXh+sO68H9w/3d3fNgd35BY/r6u36qzmvbtbF1h8o3dRgzLrd2upuqgMyMY4Se5gju7Lx7JndP9iVM7tcRMW1GKVFmADkLAsVjzTGpi99ock/aQn0LbUV6HpXTiYZ/zboAKD8EWKcA8Fas5CDzhxvLjjdIiL8pVvgQw/G43xcCQKafgKaV5NXxHl5El0KbgNtR1wH5AW2uehu7GfV6I+HO7t793f7X3xFwPXavz7D9rmFgdOSBzNhuE3ekFLWc8f7YOdB5/l+zk5kJuUPcHz2L2jBrIY8Y27KfD8m0pf/PS9Q48WqriDDU8k+dBKY1HBtmh/YoGWOwDZxvGiiWzPbwBPCGDVUrK2QpCxJGWBh7J3s5AHjcSTJCQX7ISg+oo4dhp1ku3sFNHhTSvJgANBUip/5NEJ0f7B71Nt5SKJk7+C2QtRtvaP9o/9DQnSNAPm1SFGa6gsqAEDh4IHGrDq86PcNk5L+JvAPpsncXS1nped995YvygWrON4b7XEknibIOK6lSQY+OZHEegPb/VmNYP/hHssM4nPZADvMvmgITkouDM5zn34qJwc82DGfw53mbogAbve+rq+3ItemylE9Pyz6yXho2V8Yrbex6K/OJHXqAbhBBnjbUhHyNnI5eIck/OHeaWI8q5EzMvhO58wuxbNCsuYcoTep70avKw4EpnRY2RYKGyI9uWCnmaA00Fq84vQuYTozzU6V5gpj5HQprozlWTR5AjZoN5r5lv86W97THwJu9V1507bo90OUdYXPEtEEHlprPkXuWlb3TvjiftRX3l+XzoXtUItAge0jOBByZ6SaVmcIUwk+STYe++OqjD98XXvqNJKLiy5cwBeZ0b39pjvxvPaY2ruXPc8ecpUTYXyXs8Ohxauq7YrLu2iuzmsqs7Zw9+rc2RPCzy1Rc0WnSJHbDfZaS48JNJBfhpTmXi/jwadnPIdDOGAqIRPp2W4qREmuuUSQh4W3og30jr7yYfoSe9u7nqXGbnIU24g70pgYD7a9GxMuZnao2hgk3EA+bNVRZ2PXE99kvYu+uoQdTMdbtdmy1rxPsKyvq9Flma1pvOs5dOK9m4tkfPPmRaOuVUXLQsSZwlvx73MEt0JTyz7JKlvZbNd7s+JBtQWI9TgCGyLXi8I48sMSLl6Dh5aNyhsu3gUEziQSi3m9QN0k/lhR6cNyTqJBgi7IAkciApKNSyk1Sunl1EvEuqFDsmHORB5KZTYD7UMLGEs9rMca07/oeCtVY3TndhzDeOa7d1kByB4x88Uc0quK9dmmH2QXNbfTmlk1nRKRwpsXViJXWl8v3/xGO0YLF+mu2WRO7hsXM/+dexH1hLf4OOj2TJGzclqdwVVNM7suO4pMnycZmSstR8pHsudOwvBI2AIKIAUbcz0fZS/yIF7mkoOvfjEZAk33E8Pb5X0G5vrlprya7u8nBC+5PLmABjjA7dfHDC+FKOTFBBN7dsz3dksjaNdBa0x+STUdNDfTIeAedvOXgdt0bbOPJFVO2a3H0V3AP42WoX0B5N80Kg6qLyxSSy8cuUFzQNK0uZcE6pgD6pLM2prmVFElnF1SIVWEZ1TiyohPmWRRw1a2imX1e14K3ZUf1P2ArzXZIcrl747YB6p0GYiz3y7Vglkl9f75D4yAhDX1G/e0hoVPfMFNSP492N7hpPC7UTv+yNu8Ca+xwidC2YJkccDdNUUWvQSHV+Sw8JXFEotfe1KMygzNPqZUfDmlOuO9YpA6CDcdO/3xxm+vU1y9lNaIK9BXFJoOZsvzcTXsPf36VL9buT04u4t8JVS3KHrJC1MQmkcbou0dw/YFZN2wTeU/AlScubOBTXDmnnAqyBm5IUIGjhiHIDZENoPQTbhR0ZtDtWJNPS2cayVAVw40k7SinmwxD67BwPy1iBpP8z16thn3akrcrKebCBjMz3MTbmETdaZM888qN7tKOjkB977stDD49cRET7Zs1NQzCrc/L6bDG4rwy/CN6Y4sSJJO7OS8YNoP6TkLCNtLrO38eoXNX/A1zJUsiBHUPfh9Q9gtcqguG2axgT6ZPVsrinykhzL281ZJteVUAY7q4K3rM/Hx4rh5te1eq/bKlqGTheIEBA//uYlAWW0RqGGc3IK5/esJflhOxPoaAG6yJNYIouXx2sz6VQgK0+mzV92bq/UWawcvmj9lHk+1DAPBM/39yhEBTxuBNHshtj2/cXdGj5MGS9A153ZyomEpmYUO8ZnCPl+Lka4T4PZWxsuxJuDp/hIH6U+Bu+8e9HYeHB8eHe8nQU8KyK6tdnDwwLvrzRh+Ibx7t8P61+Gt/5FXA2V0yEG/R/556lCjtW7EtIvgvD9MqVdN9PNUn+uAtLtZfcRZ7BAKlJg3NynAUSSfIeZs8Pog52WJ/Le5JzOMnePOBmEAENkW1zU6aI4DWDmOLBoH+Z1pjZKxwuRgi4Kqo+quT/OgG9jbPCfyKNTc8dhQehu1WLxJ2XjjkccTHESIp4Moc8bipPbVmJe/HkR/3Y/+Oor+Ooz+itvcj/7ai/6yI7HP8VNgCwf2G5zpY61YgKABreVxwiW+s7vz8EH/i2TXHPce9b528vG5O25c04mW/kv/QLLiIpIojmuBVusH889/fNrRdGCz3OrquRBGijMNOIoAc/Lrwqmpixsn6472dwbni8He9qhqAKxx0gdSDW1QNGzoBjZ1h3qhzRwd5eXg9WwgkeV7QlR6z8nUw3s7B/eS8709m16KaHb3vZMX2tmrqZuBL+vTm4YwjfoppvMM8fjkTdIhXNWTMu3sXmds9pAALk7W7x8c7z1MZP3a1Ka9hw8f7t83sVmd919G1OeEZhy9zD1BqJPd1ueD4VU1HmWFLj2dbFhKzhuPOkTv7j5E77i6vFpcl/S/PTQustZytGhz+GZbcaAN4ADqCPJ5O2KWcCsAopeLzznWqnWUwPCBEOp1kUdU7e/5fB4VNHtfPC0XiEzx6eXn3fFy3/z2N+xaJSHPzP+q1TVU3E3Y/n/7G6f3lsSA4k6b+6u66N1htvkzhCabO73Pv3v99OmZSPLPe3d7vysms3/B//T+m7YZnpYMq7PRaHw2Dj+62/sbaTzcy1CdvnXSs1Q0uYM+X5x9++zN6cmrrz//+X1aqEoHPGL308qd+x14ic3lDm/0Ae+4X4EMotzKwe5uz2lVuzvHB3u3xYfs7x/sPbAgu19Q2VwhR2IgWvdzP5JCuOvabZbnXoo0ZxN3IiGMoB3u0IhmlYLc8HHl1POHD7wCuUcTe9OcXXNpR6uPOiEon2qZDqONCun/2OQNUAf71KgblRSqhKZ6nzrdP3y4e7Sj3XopWbh//g0H4oergTuX2DN7rg/40gbgWpbKuPMbfEfrs8FDo3KDh8o13f2YkdPZEcuU+cGFv0dl/HfZmEmsKE/y4YPDzabF/fUiYIh8X62PR2X247LVyMavd+S29lOo+kR3Us1j70TBxZWnFd0yo3lxOXCXzGA0r2eGAT0a8sdrj9/147VXfrz3xfIe7h7sbLjrnTDlqEQ8Vcmn8sLJp2XawsZLe+he9YlUOb9GiV8PdGIg9xDoGqakmgZ4drygP7cVfquf20r5c99Ilmz/4cPNlsxJSOQTxnMRfzgqMx+Wyc83Xq77VDwQcIfHRGkh3jokRc2VPZk458lKJl4t8d9BFwQlxkA5MRrFTcTC5JO1L1Lpk7Vffrr58dvi/sbb4lstl2m3hf3Qbwv7YZn8fPNtceAFli++HDGv6osSPGPsNFewxBGtoPpKruc8I6+/eh0f7U/StGyGT9F0+UkmhLfAztHehsKc/G0EJEu3gP3QbwH7YZn8fOMtsHvk/v7OE8LNbUFHMvV8xo0niYWxuCTYW2lyXS1JS6ACxTPsfOS0A+Q1gD2C+BeE6oA8f3ADulllkrrJhKgqb6xTfjmJN9h/woHzyv0nHHj5n3Cr6NHbfbCxmixuklRNjj/2anL8cdlqZPMjeOD+5ntH1Mbr8pw1R++MCXGoYjSppllx0+PkPzfHV4Sv9lTdb5kq5ltmZoXqsCVIlq00V5pWQv3f8XH7dQ9Sjtave5Dlr3y5YZ6TFS7gKZj+O7Rh952NwE6/AYiHBupe0EDnYOhOY1P2NztrVA1bqIdZAPzH3/9nYITT2OkTadLswp/wQ94ZP+GH5U8Y6qe2/MUxpomWl8RlsOGc0w996rH8MDrfHV/ryer4uuxs/BeYi4dhLmBCc1rDphPyMIz5xP7azsrKZ0bl+mfK1X19+kkiN5VOEooTCrfMhrNEP/eBsOjniVNtxUPBqbbioXJNd7/ATO1D9A3YNz2wHtJNt5Rr6/W8pkxN8W6HnZT7SjZQ7qsy2+Avc6Z++gSQK6n97umnwRnVfmPz6S/0shBXP/Vl24I0/TS8bFtsmk9/gZflaEI1/Cnv6izLx/Tb1DC1H3rD1H5YJj//Zd7zejYZC6G498pvdoIfiFN/2BlBWPmInOhVj5QrO9rcaiCdjFWS3ysuHTaULY7GPYwrMMYFq8oYVJyg7nODmJ0wEBUqmkaYQcg5KubdzNB2JabCr3Bksi6/wpGVv8bVpHNEYAZ2Jm12cgy1TduH1fWtrkv+27Kr5VvY1hST0dRwwywTzcg2mUmeLhnJ4x58xhFJJkRjF4MvttC49cmwV9zfCYgj/bmgKwhDlNrVv9oBqub/qx1g+Ste4h9Vv4gC7QNQpqUhdY66P7BR94EPrH/My1HD76DaJ0fC2XBGPTgbX75R05/ImzHMhxibNe98AJFgHP6PXcOWTPhw+sz9ygmkUXqGfUTLfm96eIzC1tLDuf9jt03FQx+7iTEUGatJm6mXDENzTvoE6Rc/4OMu7oH3+m/78i+F9Zq6kn9uwIHhNkoEHt57KP0PeIrv2T8ICtVagP1dns2BUtgPuMjHPdn/8hsz5/uGs4mn+V78p+knLAPNsEz4vdFI6Un00Xg1bA/xvCej6liYA5mEe9ez4YU+a1eGkC7XswEW4p7+wzzoV4iuV8tLfs/+MUCRpLmZIl25g/0svPte5jP9dbySP6K5q6K5wijc3O3uHe4ePiz2dveGR7s7D3d2y/PycOf8weHeUXk+uv9QRAfh5sZFszgjSBCKc1Rlc8aZsAQd2j082t3dvX//4d6/MAb8zBn3Z7tnO2fAYJ8R7vz8ePdffvz/AAogwtg=","yes");
INSERT INTO `wp_options` VALUES("6461","widget_woof_widget","a:2:{i:2;a:8:{s:5:\"title\";s:27:\"WooCommerce Products Filter\";s:22:\"additional_text_before\";s:0:\"\";s:8:\"redirect\";s:0:\"\";s:24:\"woof_start_filtering_btn\";s:1:\"0\";s:11:\"ajax_redraw\";s:1:\"0\";s:12:\"btn_position\";s:1:\"b\";s:15:\"dynamic_recount\";s:2:\"-1\";s:10:\"autosubmit\";s:2:\"-1\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6462","woof_first_init","1","yes");
INSERT INTO `wp_options` VALUES("6463","woof_set_automatically","0","yes");
INSERT INTO `wp_options` VALUES("6464","woof_autosubmit","1","yes");
INSERT INTO `wp_options` VALUES("6465","woof_show_count","1","yes");
INSERT INTO `wp_options` VALUES("6466","woof_show_count_dynamic","0","yes");
INSERT INTO `wp_options` VALUES("6467","woof_hide_dynamic_empty_pos","0","yes");
INSERT INTO `wp_options` VALUES("6468","woof_try_ajax","0","yes");
INSERT INTO `wp_options` VALUES("6469","woof_checkboxes_slide","1","yes");
INSERT INTO `wp_options` VALUES("6470","woof_hide_red_top_panel","0","yes");
INSERT INTO `wp_options` VALUES("6471","woof_sort_terms_checked","0","yes");
INSERT INTO `wp_options` VALUES("6472","woof_filter_btn_txt","","yes");
INSERT INTO `wp_options` VALUES("6473","woof_reset_btn_txt","","yes");
INSERT INTO `wp_options` VALUES("6474","woof_settings","a:46:{s:11:\"items_order\";s:0:\"\";s:8:\"by_price\";a:8:{s:4:\"show\";s:1:\"0\";s:12:\"tooltip_text\";s:0:\"\";s:11:\"show_button\";s:1:\"0\";s:10:\"title_text\";s:0:\"\";s:6:\"ranges\";s:0:\"\";s:17:\"first_option_text\";s:0:\"\";s:15:\"ion_slider_step\";s:1:\"0\";s:9:\"price_tax\";s:1:\"0\";}s:8:\"tax_type\";a:5:{s:18:\"product_visibility\";s:8:\"checkbox\";s:11:\"product_cat\";s:5:\"radio\";s:11:\"product_tag\";s:5:\"radio\";s:11:\"pa_plotnost\";s:5:\"radio\";s:16:\"pa_product_color\";s:8:\"checkbox\";}s:14:\"excluded_terms\";a:5:{s:18:\"product_visibility\";s:0:\"\";s:11:\"product_cat\";s:0:\"\";s:11:\"product_tag\";s:0:\"\";s:11:\"pa_plotnost\";s:0:\"\";s:16:\"pa_product_color\";s:0:\"\";}s:16:\"tax_block_height\";a:5:{s:18:\"product_visibility\";s:1:\"0\";s:11:\"product_cat\";s:1:\"0\";s:11:\"product_tag\";s:1:\"0\";s:11:\"pa_plotnost\";s:1:\"0\";s:16:\"pa_product_color\";s:1:\"0\";}s:16:\"show_title_label\";a:5:{s:18:\"product_visibility\";s:1:\"0\";s:11:\"product_cat\";s:1:\"0\";s:11:\"product_tag\";s:1:\"0\";s:11:\"pa_plotnost\";s:1:\"0\";s:16:\"pa_product_color\";s:1:\"1\";}s:18:\"show_toggle_button\";a:5:{s:18:\"product_visibility\";s:1:\"0\";s:11:\"product_cat\";s:1:\"0\";s:11:\"product_tag\";s:1:\"0\";s:11:\"pa_plotnost\";s:1:\"0\";s:16:\"pa_product_color\";s:1:\"0\";}s:12:\"tooltip_text\";a:5:{s:18:\"product_visibility\";s:0:\"\";s:11:\"product_cat\";s:0:\"\";s:11:\"product_tag\";s:0:\"\";s:11:\"pa_plotnost\";s:0:\"\";s:16:\"pa_product_color\";s:0:\"\";}s:13:\"dispay_in_row\";a:5:{s:18:\"product_visibility\";s:1:\"0\";s:11:\"product_cat\";s:1:\"0\";s:11:\"product_tag\";s:1:\"0\";s:11:\"pa_plotnost\";s:1:\"0\";s:16:\"pa_product_color\";s:1:\"0\";}s:7:\"orderby\";a:5:{s:18:\"product_visibility\";s:2:\"-1\";s:11:\"product_cat\";s:2:\"-1\";s:11:\"product_tag\";s:2:\"-1\";s:11:\"pa_plotnost\";s:2:\"-1\";s:16:\"pa_product_color\";s:2:\"-1\";}s:5:\"order\";a:5:{s:18:\"product_visibility\";s:3:\"ASC\";s:11:\"product_cat\";s:3:\"ASC\";s:11:\"product_tag\";s:3:\"ASC\";s:11:\"pa_plotnost\";s:3:\"ASC\";s:16:\"pa_product_color\";s:3:\"ASC\";}s:16:\"comparison_logic\";a:5:{s:18:\"product_visibility\";s:2:\"OR\";s:11:\"product_cat\";s:2:\"OR\";s:11:\"product_tag\";s:2:\"OR\";s:11:\"pa_plotnost\";s:2:\"OR\";s:16:\"pa_product_color\";s:2:\"OR\";}s:16:\"custom_tax_label\";a:5:{s:18:\"product_visibility\";s:0:\"\";s:11:\"product_cat\";s:0:\"\";s:11:\"product_tag\";s:0:\"\";s:11:\"pa_plotnost\";s:0:\"\";s:16:\"pa_product_color\";s:0:\"\";}s:23:\"not_toggled_terms_count\";a:5:{s:18:\"product_visibility\";s:0:\"\";s:11:\"product_cat\";s:0:\"\";s:11:\"product_tag\";s:0:\"\";s:11:\"pa_plotnost\";s:0:\"\";s:16:\"pa_product_color\";s:0:\"\";}s:3:\"tax\";a:1:{s:16:\"pa_product_color\";s:1:\"1\";}s:11:\"icheck_skin\";s:4:\"none\";s:12:\"overlay_skin\";s:7:\"default\";s:19:\"overlay_skin_bg_img\";s:0:\"\";s:18:\"plainoverlay_color\";s:0:\"\";s:25:\"default_overlay_skin_word\";s:0:\"\";s:10:\"use_chosen\";s:1:\"1\";s:17:\"use_beauty_scroll\";s:1:\"0\";s:15:\"ion_slider_skin\";s:8:\"skinNice\";s:16:\"woof_tooltip_img\";s:0:\"\";s:25:\"woof_auto_hide_button_img\";s:0:\"\";s:25:\"woof_auto_hide_button_txt\";s:0:\"\";s:26:\"woof_auto_subcats_plus_img\";s:0:\"\";s:27:\"woof_auto_subcats_minus_img\";s:0:\"\";s:11:\"toggle_type\";s:4:\"text\";s:18:\"toggle_opened_text\";s:0:\"\";s:18:\"toggle_closed_text\";s:0:\"\";s:19:\"toggle_opened_image\";s:0:\"\";s:19:\"toggle_closed_image\";s:0:\"\";s:16:\"custom_front_css\";s:0:\"\";s:15:\"custom_css_code\";s:0:\"\";s:18:\"js_after_ajax_done\";s:0:\"\";s:12:\"init_only_on\";s:0:\"\";s:8:\"per_page\";s:2:\"-1\";s:17:\"optimize_js_files\";s:1:\"0\";s:25:\"listen_catalog_visibility\";s:1:\"0\";s:23:\"disable_swoof_influence\";s:1:\"0\";s:16:\"cache_count_data\";s:1:\"0\";s:11:\"cache_terms\";s:1:\"0\";s:19:\"show_woof_edit_view\";s:1:\"1\";s:22:\"custom_extensions_path\";s:0:\"\";s:20:\"activated_extensions\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("6476","woof_version","1.2.2.1","yes");
INSERT INTO `wp_options` VALUES("6477","woof_alert","a:2:{s:29:\"woocommerce_currency_switcher\";s:0:\"\";s:23:\"woocommerce_bulk_editor\";s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES("6555","fs_active_plugins","O:8:\"stdClass\":3:{s:7:\"plugins\";a:1:{s:45:\"premmerce-woocommerce-product-filter/freemius\";O:8:\"stdClass\":4:{s:7:\"version\";s:5:\"2.3.0\";s:4:\"type\";s:6:\"plugin\";s:9:\"timestamp\";i:1561549611;s:11:\"plugin_path\";s:57:\"premmerce-woocommerce-product-filter/premmerce-filter.php\";}}s:7:\"abspath\";s:20:\"C:\\xampp\\htdocs\\TES/\";s:6:\"newest\";O:8:\"stdClass\":5:{s:11:\"plugin_path\";s:57:\"premmerce-woocommerce-product-filter/premmerce-filter.php\";s:8:\"sdk_path\";s:45:\"premmerce-woocommerce-product-filter/freemius\";s:7:\"version\";s:5:\"2.3.0\";s:13:\"in_activation\";b:1;s:9:\"timestamp\";i:1561549611;}}","yes");
INSERT INTO `wp_options` VALUES("6556","fs_debug_mode","","yes");
INSERT INTO `wp_options` VALUES("6557","fs_accounts","a:6:{s:21:\"id_slug_type_path_map\";a:1:{i:1519;a:3:{s:4:\"slug\";s:36:\"premmerce-woocommerce-product-filter\";s:4:\"type\";s:6:\"plugin\";s:4:\"path\";s:57:\"premmerce-woocommerce-product-filter/premmerce-filter.php\";}}s:11:\"plugin_data\";a:1:{s:36:\"premmerce-woocommerce-product-filter\";a:18:{s:16:\"plugin_main_file\";O:8:\"stdClass\":1:{s:4:\"path\";s:57:\"premmerce-woocommerce-product-filter/premmerce-filter.php\";}s:17:\"install_timestamp\";i:1561124628;s:16:\"sdk_last_version\";s:5:\"2.2.4\";s:11:\"sdk_version\";s:5:\"2.3.0\";s:16:\"sdk_upgrade_mode\";b:1;s:18:\"sdk_downgrade_mode\";b:0;s:19:\"plugin_last_version\";s:5:\"3.2.3\";s:14:\"plugin_version\";s:5:\"3.2.4\";s:19:\"plugin_upgrade_mode\";b:1;s:21:\"plugin_downgrade_mode\";b:0;s:21:\"is_plugin_new_install\";b:0;s:17:\"connectivity_test\";a:6:{s:12:\"is_connected\";b:1;s:4:\"host\";s:9:\"localhost\";s:9:\"server_ip\";s:3:\"::1\";s:9:\"is_active\";b:1;s:9:\"timestamp\";i:1561124628;s:7:\"version\";s:5:\"3.2.3\";}s:17:\"was_plugin_loaded\";b:1;s:15:\"prev_is_premium\";b:0;s:12:\"is_anonymous\";a:3:{s:2:\"is\";b:1;s:9:\"timestamp\";i:1561124847;s:7:\"version\";s:5:\"3.2.3\";}s:20:\"is_network_activated\";b:0;s:21:\"trial_promotion_shown\";i:1561549409;s:16:\"uninstall_reason\";O:8:\"stdClass\":3:{s:2:\"id\";s:2:\"15\";s:4:\"info\";s:0:\"\";s:12:\"is_anonymous\";b:0;}}}s:13:\"file_slug_map\";a:1:{s:57:\"premmerce-woocommerce-product-filter/premmerce-filter.php\";s:36:\"premmerce-woocommerce-product-filter\";}s:7:\"plugins\";a:1:{s:36:\"premmerce-woocommerce-product-filter\";O:9:\"FS_Plugin\":22:{s:16:\"parent_plugin_id\";N;s:5:\"title\";s:40:\"Premmerce Product Filter for WooCommerce\";s:4:\"slug\";s:36:\"premmerce-woocommerce-product-filter\";s:12:\"premium_slug\";s:44:\"premmerce-woocommerce-product-filter-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";b:0;s:19:\"is_wp_org_compliant\";b:1;s:22:\"premium_releases_count\";N;s:4:\"file\";s:57:\"premmerce-woocommerce-product-filter/premmerce-filter.php\";s:7:\"version\";s:5:\"3.2.4\";s:11:\"auto_update\";N;s:4:\"info\";N;s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:9:\"bundle_id\";N;s:10:\"public_key\";s:32:\"pk_20f16471b14ab029cbbc55d432950\";s:10:\"secret_key\";N;s:2:\"id\";s:4:\"1519\";s:7:\"updated\";N;s:7:\"created\";N;s:22:\"\0FS_Entity\0_is_updated\";b:0;}}s:9:\"unique_id\";s:32:\"b9cd4332bba06cda0e30f67f1576044e\";s:13:\"admin_notices\";a:1:{s:36:\"premmerce-woocommerce-product-filter\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES("6560","fs_api_cache","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("6562","fs_gdpr","a:1:{s:2:\"u1\";a:1:{s:8:\"required\";b:0;}}","yes");
INSERT INTO `wp_options` VALUES("6565","widget_premmerce_filter_filter_widget","a:3:{i:2;a:1:{s:5:\"title\";s:0:\"\";}i:3;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6566","widget_premmerce_filter_active_filters_widget","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6656","wpf_template","a:1:{s:17:\"wpf_5d0f6faadf175\";a:2:{s:6:\"layout\";a:1:{s:16:\"pa_product_color\";a:22:{s:11:\"field_title\";a:1:{s:2:\"ru\";s:0:\"\";}s:7:\"show_as\";s:4:\"link\";s:5:\"logic\";s:2:\"or\";s:5:\"order\";s:10:\"term_order\";s:7:\"orderby\";s:3:\"asc\";s:7:\"display\";s:10:\"horizontal\";s:6:\"column\";s:1:\"2\";s:11:\"color_bg_26\";b:0;s:13:\"color_text_26\";b:0;s:7:\"text_26\";a:1:{s:2:\"ru\";s:0:\"\";}s:11:\"color_bg_27\";b:0;s:13:\"color_text_27\";b:0;s:7:\"text_27\";a:1:{s:2:\"ru\";s:0:\"\";}s:11:\"color_bg_25\";b:0;s:13:\"color_text_25\";b:0;s:7:\"text_25\";a:1:{s:2:\"ru\";s:0:\"\";}s:11:\"color_bg_23\";b:0;s:13:\"color_text_23\";b:0;s:7:\"text_23\";a:1:{s:2:\"ru\";s:0:\"\";}s:11:\"color_bg_24\";b:0;s:13:\"color_text_24\";b:0;s:7:\"text_24\";a:1:{s:2:\"ru\";s:0:\"\";}}}s:4:\"data\";a:13:{s:4:\"name\";s:17:\"wpf_5d0f6fb5c77a9\";s:5:\"empty\";s:1:\"1\";s:5:\"group\";s:1:\"1\";s:4:\"type\";s:8:\"vertical\";s:4:\"page\";s:2:\"56\";s:4:\"sort\";s:1:\"1\";s:10:\"pagination\";s:1:\"1\";s:6:\"result\";s:1:\"1\";s:12:\"out_of_stock\";s:1:\"1\";s:11:\"result_type\";s:9:\"same_page\";s:12:\"tax_relation\";s:3:\"and\";s:15:\"pagination_type\";s:10:\"pagination\";s:4:\"date\";i:1561305054;}}}","yes");
INSERT INTO `wp_options` VALUES("6694","woocommerce_shop_page_display","","yes");
INSERT INTO `wp_options` VALUES("6695","woocommerce_category_archive_display","","yes");
INSERT INTO `wp_options` VALUES("6721","color_image_swatches_check","1","yes");
INSERT INTO `wp_options` VALUES("6807","_transient_as_comment_count","O:8:\"stdClass\":7:{s:8:\"approved\";s:1:\"8\";s:14:\"total_comments\";i:8;s:3:\"all\";i:8;s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("6899","WC_VAR_SETTINGS","a:6:{s:17:\"ed_wc_pa_plotnost\";a:11:{s:11:\"button_type\";s:1:\"1\";s:12:\"button_style\";s:1:\"1\";s:5:\"wdith\";s:0:\"\";s:6:\"height\";s:0:\"\";s:9:\"text_size\";s:0:\"\";s:10:\"text_color\";s:0:\"\";s:16:\"text_color_hover\";s:0:\"\";s:2:\"bg\";s:0:\"\";s:8:\"bg_hover\";s:0:\"\";s:6:\"border\";s:0:\"\";s:12:\"border_hover\";s:0:\"\";}s:24:\"color_button_pa_plotnost\";a:2:{i:29;s:0:\"\";i:28;s:0:\"\";}s:28:\"ed_images_button_pa_plotnost\";a:2:{i:29;s:0:\"\";i:28;s:0:\"\";}s:22:\"ed_wc_pa_product_color\";a:11:{s:11:\"button_type\";s:1:\"2\";s:12:\"button_style\";s:1:\"1\";s:5:\"wdith\";s:0:\"\";s:6:\"height\";s:0:\"\";s:9:\"text_size\";s:0:\"\";s:10:\"text_color\";s:0:\"\";s:16:\"text_color_hover\";s:0:\"\";s:2:\"bg\";s:0:\"\";s:8:\"bg_hover\";s:0:\"\";s:6:\"border\";s:0:\"\";s:12:\"border_hover\";s:0:\"\";}s:29:\"color_button_pa_product_color\";a:5:{i:26;s:7:\"#ffffff\";i:27;s:7:\"#eeee22\";i:25;s:7:\"#81d742\";i:23;s:0:\"\";i:24;s:0:\"\";}s:33:\"ed_images_button_pa_product_color\";a:5:{i:26;s:0:\"\";i:27;s:0:\"\";i:25;s:0:\"\";i:23;s:0:\"\";i:24;s:0:\"\";}}","yes");
INSERT INTO `wp_options` VALUES("6928","wpf_plugin_activation_errors","","yes");
INSERT INTO `wp_options` VALUES("6929","widget_wpfwoofilterswidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6930","wpf_opts_data","a:5:{s:10:\"send_stats\";a:1:{s:5:\"value\";s:1:\"0\";}s:18:\"count_product_shop\";a:1:{s:5:\"value\";s:0:\"\";}s:12:\"move_sidebar\";a:1:{s:5:\"value\";s:1:\"0\";}s:11:\"start_usage\";a:2:{s:5:\"value\";i:1561553649;s:10:\"changed_on\";i:1561553649;}s:17:\"plug_welcome_show\";a:2:{s:5:\"value\";i:1561553649;s:10:\"changed_on\";i:1561553649;}}","yes");
INSERT INTO `wp_options` VALUES("6931","wpf_plug_was_used","1","yes");
INSERT INTO `wp_options` VALUES("6962","nm_color_filters","installed","yes");
INSERT INTO `wp_options` VALUES("6963","widget_nm_color_filters","a:2:{i:2;a:1:{s:5:\"title\";s:7:\"Filters\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("6964","EWD_UWCF_WC_Color_Attribute_WC_Field_ID","3","yes");
INSERT INTO `wp_options` VALUES("6965","EWD_UWCF_WC_Size_Attribute_WC_Field_ID","4","yes");
INSERT INTO `wp_options` VALUES("6966","EWD_UWCF_Full_Version","No","yes");
INSERT INTO `wp_options` VALUES("6967","EWD_UWCF_Enable_Colors","Yes","yes");
INSERT INTO `wp_options` VALUES("6968","EWD_UWCF_Color_Filters_Display","List","yes");
INSERT INTO `wp_options` VALUES("6969","EWD_UWCF_Color_Filters_Show_Text","Yes","yes");
INSERT INTO `wp_options` VALUES("6970","EWD_UWCF_Color_Filters_Show_Color","Yes","yes");
INSERT INTO `wp_options` VALUES("6971","EWD_UWCF_Color_Filters_Hide_Empty","Yes","yes");
INSERT INTO `wp_options` VALUES("6972","EWD_UWCF_Color_Filters_Show_Product_Count","Yes","yes");
INSERT INTO `wp_options` VALUES("6973","EWD_UWCF_Display_Thumbnail_Colors","No","yes");
INSERT INTO `wp_options` VALUES("6974","EWD_UWCF_Colors_Product_Page_Display","No","yes");
INSERT INTO `wp_options` VALUES("6975","EWD_UWCF_Colors_Used_For_Variations","No","yes");
INSERT INTO `wp_options` VALUES("6976","EWD_UWCF_Enable_Sizes","Yes","yes");
INSERT INTO `wp_options` VALUES("6977","EWD_UWCF_Size_Filters_Display","List","yes");
INSERT INTO `wp_options` VALUES("6978","EWD_UWCF_Size_Filters_Show_Text","Yes","yes");
INSERT INTO `wp_options` VALUES("6979","EWD_UWCF_Size_Filters_Hide_Empty","Yes","yes");
INSERT INTO `wp_options` VALUES("6980","EWD_UWCF_Size_Filters_Show_Product_Count","Yes","yes");
INSERT INTO `wp_options` VALUES("6981","EWD_UWCF_Display_Thumbnail_Sizes","No","yes");
INSERT INTO `wp_options` VALUES("6982","EWD_UWCF_Sizes_Product_Page_Display","No","yes");
INSERT INTO `wp_options` VALUES("6983","EWD_UWCF_Sizes_Used_For_Variations","No","yes");
INSERT INTO `wp_options` VALUES("6984","EWD_UWCF_Enable_Categories","No","yes");
INSERT INTO `wp_options` VALUES("6985","EWD_UWCF_Category_Filters_Display","List","yes");
INSERT INTO `wp_options` VALUES("6986","EWD_UWCF_Category_Filters_Show_Text","Yes","yes");
INSERT INTO `wp_options` VALUES("6987","EWD_UWCF_Category_Filters_Hide_Empty","Yes","yes");
INSERT INTO `wp_options` VALUES("6988","EWD_UWCF_Category_Filters_Show_Product_Count","Yes","yes");
INSERT INTO `wp_options` VALUES("6989","EWD_UWCF_Display_Thumbnail_Categories","No","yes");
INSERT INTO `wp_options` VALUES("6990","EWD_UWCF_Enable_Tags","No","yes");
INSERT INTO `wp_options` VALUES("6991","EWD_UWCF_Tag_Filters_Display","List","yes");
INSERT INTO `wp_options` VALUES("6992","EWD_UWCF_Tag_Filters_Show_Text","Yes","yes");
INSERT INTO `wp_options` VALUES("6993","EWD_UWCF_Tag_Filters_Hide_Empty","Yes","yes");
INSERT INTO `wp_options` VALUES("6994","EWD_UWCF_Tag_Filters_Show_Product_Count","Yes","yes");
INSERT INTO `wp_options` VALUES("6995","EWD_UWCF_Display_Thumbnail_Tags","No","yes");
INSERT INTO `wp_options` VALUES("6996","EWD_UWCF_Enable_Text_Search","No","yes");
INSERT INTO `wp_options` VALUES("6997","EWD_UWCF_Enable_Autocomplete","No","yes");
INSERT INTO `wp_options` VALUES("6998","EWD_UWCF_Enable_Ratings_Filtering","No","yes");
INSERT INTO `wp_options` VALUES("6999","EWD_UWCF_Ratings_Type","WooCommerce","yes");
INSERT INTO `wp_options` VALUES("7000","EWD_UWCF_Enable_InStock_Filtering","No","yes");
INSERT INTO `wp_options` VALUES("7001","EWD_UWCF_Enable_OnSale_Filtering","No","yes");
INSERT INTO `wp_options` VALUES("7002","EWD_UWCF_Access_Role","administrator","yes");
INSERT INTO `wp_options` VALUES("7003","EWD_UWCF_Reset_All_Button","Np","yes");
INSERT INTO `wp_options` VALUES("7004","EWD_UWCF_Color_Filters_Color_Shape","Circle","yes");
INSERT INTO `wp_options` VALUES("7005","EWD_UWCF_Install_Time","1561555664","yes");
INSERT INTO `wp_options` VALUES("7006","elm_color_filters_version","2.1.0a","yes");
INSERT INTO `wp_options` VALUES("7010","product_color_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("7139","rewrite_rules","a:161:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:7:\"88-2/?$\";s:27:\"index.php?post_type=product\";s:37:\"88-2/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"88-2/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"88-2/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:49:\"plotnost/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?pa_plotnost=$matches[1]&feed=$matches[2]\";s:44:\"plotnost/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?pa_plotnost=$matches[1]&feed=$matches[2]\";s:25:\"plotnost/([^/]+)/embed/?$\";s:44:\"index.php?pa_plotnost=$matches[1]&embed=true\";s:37:\"plotnost/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?pa_plotnost=$matches[1]&paged=$matches[2]\";s:19:\"plotnost/([^/]+)/?$\";s:33:\"index.php?pa_plotnost=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=88&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("7150","_site_transient_timeout_browser_9d59740c39e50ca5ca18fb8902525cb9","1562239226","no");
INSERT INTO `wp_options` VALUES("7151","_site_transient_browser_9d59740c39e50ca5ca18fb8902525cb9","a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"67.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("7152","_site_transient_timeout_php_check_03b757470e94c3bf37ab9d7408701106","1562239228","no");
INSERT INTO `wp_options` VALUES("7153","_site_transient_php_check_03b757470e94c3bf37ab9d7408701106","a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("7329","BeRocket_Framework_plugins_version_check","a:2:{s:12:\"BeRocket_LMP\";s:7:\"1.1.6.2\";s:10:\"pagination\";s:7:\"3.5.0.3\";}","yes");
INSERT INTO `wp_options` VALUES("7330","berocket_admin_notices","a:1:{i:20;a:1:{i:0;a:1:{i:0;a:1:{s:9:\"subscribe\";a:15:{s:5:\"start\";i:0;s:3:\"end\";i:0;s:4:\"name\";s:9:\"subscribe\";s:4:\"html\";s:136:\"Subscribe to get latest BeRocket news and updates, plugin recommendations and configuration help, promotional email with discount codes.\";s:9:\"righthtml\";s:43:\"<a class=\"berocket_no_thanks\">No thanks</a>\";s:10:\"rightwidth\";i:80;s:13:\"nothankswidth\";i:60;s:12:\"contentwidth\";i:400;s:9:\"subscribe\";b:1;s:6:\"closed\";s:1:\"0\";s:8:\"priority\";i:20;s:6:\"height\";i:50;s:6:\"repeat\";b:0;s:11:\"repeatcount\";i:1;s:5:\"image\";a:4:{s:5:\"local\";s:132:\"http://localhost/tes/wp-content/plugins/load-more-products-for-woocommerce/berocket/includes/../assets/images/ad_white_on_orange.png\";s:5:\"width\";i:239;s:6:\"height\";i:118;s:5:\"scale\";d:0.423728813559322;}}}}}}","yes");
INSERT INTO `wp_options` VALUES("7331","berocket_current_displayed_notice","a:15:{s:5:\"start\";i:0;s:3:\"end\";i:0;s:4:\"name\";s:9:\"subscribe\";s:4:\"html\";s:136:\"Subscribe to get latest BeRocket news and updates, plugin recommendations and configuration help, promotional email with discount codes.\";s:9:\"righthtml\";s:43:\"<a class=\"berocket_no_thanks\">No thanks</a>\";s:10:\"rightwidth\";i:80;s:13:\"nothankswidth\";i:60;s:12:\"contentwidth\";i:400;s:9:\"subscribe\";b:1;s:6:\"closed\";s:1:\"0\";s:8:\"priority\";i:20;s:6:\"height\";i:50;s:6:\"repeat\";b:0;s:11:\"repeatcount\";i:1;s:5:\"image\";a:4:{s:5:\"local\";s:132:\"http://localhost/tes/wp-content/plugins/load-more-products-for-woocommerce/berocket/includes/../assets/images/ad_white_on_orange.png\";s:5:\"width\";i:239;s:6:\"height\";i:118;s:5:\"scale\";d:0.423728813559322;}}","yes");
INSERT INTO `wp_options` VALUES("7332","berocket_admin_notices_rate_stars","a:2:{i:3;a:2:{s:4:\"time\";i:1562335409;s:5:\"count\";i:0;}i:6;a:2:{s:4:\"time\";i:1562427414;s:5:\"count\";i:0;}}","yes");
INSERT INTO `wp_options` VALUES("7334","berocket_framework_option_global","a:2:{s:28:\"fontawesome_frontend_disable\";s:0:\"\";s:28:\"fontawesome_frontend_version\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("7343","berocket_key_activated_plugins","a:2:{i:3;b:0;i:6;b:0;}","yes");
INSERT INTO `wp_options` VALUES("7354","BeRocket_selector_wizard_status","ended","yes");
INSERT INTO `wp_options` VALUES("7356","berocket_multisite_import_ready","1","yes");
INSERT INTO `wp_options` VALUES("7362","product_cat_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("7399","_transient_timeout_wc_product_loope90c1561731046","1564323805","no");
INSERT INTO `wp_options` VALUES("7400","_transient_wc_product_loope90c1561731046","O:8:\"stdClass\":5:{s:3:\"ids\";a:0:{}s:5:\"total\";i:0;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:12;s:12:\"current_page\";i:1;}","no");
INSERT INTO `wp_options` VALUES("7603","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:8;s:3:\"all\";i:8;s:8:\"approved\";s:1:\"8\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("7605","_transient_timeout_wc_term_counts","1564391275","no");
INSERT INTO `wp_options` VALUES("7606","_transient_wc_term_counts","a:5:{i:21;s:1:\"3\";i:45;s:1:\"1\";i:35;s:1:\"1\";i:36;s:1:\"1\";i:15;s:2:\"10\";}","no");
INSERT INTO `wp_options` VALUES("7730","_transient_timeout_wc_low_stock_count","1564414440","no");
INSERT INTO `wp_options` VALUES("7731","_transient_wc_low_stock_count","0","no");
INSERT INTO `wp_options` VALUES("7732","_transient_timeout_wc_outofstock_count","1564414440","no");
INSERT INTO `wp_options` VALUES("7733","_transient_wc_outofstock_count","0","no");
INSERT INTO `wp_options` VALUES("7751","br-pagination-options","a:6:{s:16:\"general_settings\";a:5:{s:13:\"use_next_prev\";s:1:\"1\";s:13:\"pos_next_prev\";s:14:\"around_central\";s:13:\"page_end_size\";s:1:\"3\";s:13:\"page_mid_size\";s:1:\"3\";s:8:\"use_dots\";s:1:\"1\";}s:14:\"style_settings\";a:13:{s:5:\"style\";s:7:\"default\";s:10:\"use_styles\";a:0:{}s:7:\"buttons\";a:5:{s:4:\"prev\";a:4:{s:18:\"ul_li_a-span_style\";a:6:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";s:11:\"padding-top\";s:0:\"\";s:14:\"padding-bottom\";s:0:\"\";s:12:\"padding-left\";s:0:\"\";s:13:\"padding-right\";s:0:\"\";}s:11:\"ul_li_style\";a:13:{s:16:\"border-top-width\";s:0:\"\";s:19:\"border-bottom-width\";s:0:\"\";s:17:\"border-left-width\";s:0:\"\";s:18:\"border-right-width\";s:0:\"\";s:22:\"border-top-left-radius\";s:0:\"\";s:23:\"border-top-right-radius\";s:0:\"\";s:26:\"border-bottom-right-radius\";s:0:\"\";s:25:\"border-bottom-left-radius\";s:0:\"\";s:10:\"margin-top\";s:0:\"\";s:13:\"margin-bottom\";s:0:\"\";s:11:\"margin-left\";s:0:\"\";s:12:\"margin-right\";s:0:\"\";s:12:\"border-color\";s:0:\"\";}s:24:\"ul_li_a-span_hover_style\";a:2:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";}s:17:\"ul_li_hover_style\";a:1:{s:12:\"border-color\";s:0:\"\";}}s:4:\"next\";a:4:{s:18:\"ul_li_a-span_style\";a:6:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";s:11:\"padding-top\";s:0:\"\";s:14:\"padding-bottom\";s:0:\"\";s:12:\"padding-left\";s:0:\"\";s:13:\"padding-right\";s:0:\"\";}s:11:\"ul_li_style\";a:13:{s:16:\"border-top-width\";s:0:\"\";s:19:\"border-bottom-width\";s:0:\"\";s:17:\"border-left-width\";s:0:\"\";s:18:\"border-right-width\";s:0:\"\";s:22:\"border-top-left-radius\";s:0:\"\";s:23:\"border-top-right-radius\";s:0:\"\";s:26:\"border-bottom-right-radius\";s:0:\"\";s:25:\"border-bottom-left-radius\";s:0:\"\";s:10:\"margin-top\";s:0:\"\";s:13:\"margin-bottom\";s:0:\"\";s:11:\"margin-left\";s:0:\"\";s:12:\"margin-right\";s:0:\"\";s:12:\"border-color\";s:0:\"\";}s:24:\"ul_li_a-span_hover_style\";a:2:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";}s:17:\"ul_li_hover_style\";a:1:{s:12:\"border-color\";s:0:\"\";}}s:4:\"dots\";a:2:{s:18:\"ul_li_a-span_style\";a:6:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";s:11:\"padding-top\";s:0:\"\";s:14:\"padding-bottom\";s:0:\"\";s:12:\"padding-left\";s:0:\"\";s:13:\"padding-right\";s:0:\"\";}s:11:\"ul_li_style\";a:13:{s:16:\"border-top-width\";s:0:\"\";s:19:\"border-bottom-width\";s:0:\"\";s:17:\"border-left-width\";s:0:\"\";s:18:\"border-right-width\";s:0:\"\";s:22:\"border-top-left-radius\";s:0:\"\";s:23:\"border-top-right-radius\";s:0:\"\";s:26:\"border-bottom-right-radius\";s:0:\"\";s:25:\"border-bottom-left-radius\";s:0:\"\";s:10:\"margin-top\";s:0:\"\";s:13:\"margin-bottom\";s:0:\"\";s:11:\"margin-left\";s:0:\"\";s:12:\"margin-right\";s:0:\"\";s:12:\"border-color\";s:0:\"\";}}s:7:\"current\";a:2:{s:18:\"ul_li_a-span_style\";a:6:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";s:11:\"padding-top\";s:0:\"\";s:14:\"padding-bottom\";s:0:\"\";s:12:\"padding-left\";s:0:\"\";s:13:\"padding-right\";s:0:\"\";}s:11:\"ul_li_style\";a:13:{s:16:\"border-top-width\";s:0:\"\";s:19:\"border-bottom-width\";s:0:\"\";s:17:\"border-left-width\";s:0:\"\";s:18:\"border-right-width\";s:0:\"\";s:22:\"border-top-left-radius\";s:0:\"\";s:23:\"border-top-right-radius\";s:0:\"\";s:26:\"border-bottom-right-radius\";s:0:\"\";s:25:\"border-bottom-left-radius\";s:0:\"\";s:10:\"margin-top\";s:0:\"\";s:13:\"margin-bottom\";s:0:\"\";s:11:\"margin-left\";s:0:\"\";s:12:\"margin-right\";s:0:\"\";s:12:\"border-color\";s:0:\"\";}}s:5:\"other\";a:4:{s:18:\"ul_li_a-span_style\";a:6:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";s:11:\"padding-top\";s:0:\"\";s:14:\"padding-bottom\";s:0:\"\";s:12:\"padding-left\";s:0:\"\";s:13:\"padding-right\";s:0:\"\";}s:11:\"ul_li_style\";a:13:{s:16:\"border-top-width\";s:0:\"\";s:19:\"border-bottom-width\";s:0:\"\";s:17:\"border-left-width\";s:0:\"\";s:18:\"border-right-width\";s:0:\"\";s:22:\"border-top-left-radius\";s:0:\"\";s:23:\"border-top-right-radius\";s:0:\"\";s:26:\"border-bottom-right-radius\";s:0:\"\";s:25:\"border-bottom-left-radius\";s:0:\"\";s:10:\"margin-top\";s:0:\"\";s:13:\"margin-bottom\";s:0:\"\";s:11:\"margin-left\";s:0:\"\";s:12:\"margin-right\";s:0:\"\";s:12:\"border-color\";s:0:\"\";}s:24:\"ul_li_a-span_hover_style\";a:2:{s:5:\"color\";s:0:\"\";s:16:\"background-color\";s:0:\"\";}s:17:\"ul_li_hover_style\";a:1:{s:12:\"border-color\";s:0:\"\";}}}s:14:\"pagination_pos\";s:4:\"left\";s:12:\"default_show\";a:2:{s:14:\"after_products\";s:1:\"1\";s:15:\"before_products\";s:1:\"1\";}s:14:\"fixed_position\";a:4:{s:3:\"top\";s:0:\"\";s:6:\"bottom\";s:1:\"0\";s:4:\"left\";s:0:\"\";s:5:\"right\";s:0:\"\";}s:10:\"buffer_top\";s:3:\"700\";s:15:\"bottom_position\";s:2:\"10\";s:8:\"ul_style\";a:14:{s:16:\"background-color\";s:7:\"#d9d7d9\";s:12:\"border-color\";s:7:\"#696368\";s:16:\"border-top-width\";s:1:\"1\";s:19:\"border-bottom-width\";s:1:\"1\";s:17:\"border-left-width\";s:1:\"1\";s:18:\"border-right-width\";s:1:\"0\";s:11:\"padding-top\";s:1:\"0\";s:14:\"padding-bottom\";s:1:\"0\";s:12:\"padding-left\";s:1:\"0\";s:13:\"padding-right\";s:1:\"0\";s:22:\"border-top-left-radius\";s:1:\"0\";s:23:\"border-top-right-radius\";s:1:\"0\";s:26:\"border-bottom-right-radius\";s:1:\"0\";s:25:\"border-bottom-left-radius\";s:1:\"0\";}s:11:\"ul_li_style\";a:14:{s:12:\"border-color\";s:7:\"#d3ced2\";s:16:\"border-top-width\";s:1:\"0\";s:19:\"border-bottom-width\";s:1:\"0\";s:17:\"border-left-width\";s:1:\"0\";s:18:\"border-right-width\";s:1:\"1\";s:22:\"border-top-left-radius\";s:1:\"0\";s:23:\"border-top-right-radius\";s:1:\"0\";s:26:\"border-bottom-right-radius\";s:1:\"0\";s:25:\"border-bottom-left-radius\";s:1:\"0\";s:10:\"margin-top\";s:1:\"0\";s:13:\"margin-bottom\";s:1:\"0\";s:11:\"margin-left\";s:1:\"0\";s:12:\"margin-right\";s:1:\"0\";s:5:\"float\";s:4:\"left\";}s:17:\"ul_li_hover_style\";a:1:{s:12:\"border-color\";s:7:\"#d3ced2\";}s:18:\"ul_li_a-span_style\";a:6:{s:5:\"color\";s:7:\"#fafafa\";s:16:\"background-color\";s:7:\"#8f8f8f\";s:11:\"padding-top\";s:2:\"30\";s:14:\"padding-bottom\";s:2:\"30\";s:12:\"padding-left\";s:2:\"30\";s:13:\"padding-right\";s:2:\"30\";}s:24:\"ul_li_a-span_hover_style\";a:2:{s:5:\"color\";s:7:\"#6e5ae0\";s:16:\"background-color\";s:7:\"#ebe9eb\";}}s:13:\"text_settings\";a:14:{s:14:\"dots_prev_icon\";s:13:\"fa-ellipsis-h\";s:14:\"dots_prev_text\";s:3:\"…\";s:14:\"dots_next_icon\";s:13:\"fa-ellipsis-h\";s:14:\"dots_next_text\";s:3:\"…\";s:9:\"prev_icon\";s:20:\"fa-angle-double-left\";s:9:\"next_icon\";s:21:\"fa-angle-double-right\";s:9:\"prev_text\";s:2:\"«\";s:9:\"next_text\";s:2:\"»\";s:12:\"current_page\";s:6:\"%PAGE%\";s:4:\"page\";s:6:\"%PAGE%\";s:15:\"first_page_icon\";s:0:\"\";s:10:\"first_page\";s:1:\"1\";s:14:\"last_page_icon\";s:0:\"\";s:9:\"last_page\";s:6:\"%LAST%\";}s:19:\"javascript_settings\";a:2:{s:9:\"page_load\";s:0:\"\";s:10:\"custom_css\";s:0:\"\";}s:28:\"fontawesome_frontend_disable\";s:0:\"\";s:28:\"fontawesome_frontend_version\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("7860","_site_transient_timeout_browser_aac05479bed18537c5dfef880670f570","1562510887","no");
INSERT INTO `wp_options` VALUES("7861","_site_transient_browser_aac05479bed18537c5dfef880670f570","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"75.0.3770.100\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("7895","_transient_timeout_pagination_paid_info","1562511802","no");
INSERT INTO `wp_options` VALUES("7896","_transient_pagination_paid_info","a:13:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:29:\"WooCommerce Pagination Styler\";s:4:\"slug\";s:29:\"woocommerce-pagination-styler\";s:10:\"plugin_url\";s:58:\"https://berocket.com/product/woocommerce-pagination-styler\";s:7:\"version\";s:7:\"3.5.0.3\";s:5:\"about\";s:101:\"With WooCommerce Pagination Styler you can customize pagination as you want without editing the code.\";s:10:\"difference\";a:0:{}s:7:\"related\";a:2:{i:0;s:1:\"3\";i:1;s:1:\"1\";}s:5:\"image\";s:61:\"https://berocket.com/img/2931d9d6039a46a3b827db61cfbbd40e.png\";s:10:\"mini_image\";s:61:\"https://berocket.com/img/d93c4f0372d1898dc1076fd783f3071c.png\";s:10:\"shop_image\";s:61:\"https://berocket.com/img/3b2f87613b8a1056f51d7ffa4c76e4bc.png\";s:5:\"price\";s:1:\"0\";s:7:\"buy_url\";s:36:\"https://berocket.com/add_to_cart/137\";}","no");
INSERT INTO `wp_options` VALUES("7898","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:5:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.2\";s:7:\"version\";s:5:\"5.2.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.2\";s:7:\"version\";s:5:\"5.2.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.2\";s:7:\"version\";s:5:\"5.2.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.1.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.1.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.1\";s:7:\"version\";s:5:\"5.2.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:4;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:63:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:63:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"5.2\";s:7:\"version\";s:3:\"5.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1562161510;s:15:\"version_checked\";s:5:\"5.1.1\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("7921","_transient_timeout_external_ip_address_::1","1562760941","no");
INSERT INTO `wp_options` VALUES("7922","_transient_external_ip_address_::1","130.180.220.26","no");
INSERT INTO `wp_options` VALUES("7942","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1562161511;s:7:\"checked\";a:4:{s:10:\"tkani-shop\";s:5:\"1.0.0\";s:14:\"twentynineteen\";s:3:\"1.3\";s:15:\"twentyseventeen\";s:3:\"2.1\";s:13:\"twentysixteen\";s:3:\"1.9\";}s:8:\"response\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.4.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.2\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.2.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:13:\"twentysixteen\";a:6:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.2.0.zip\";s:8:\"requires\";s:3:\"4.4\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("7943","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1562173917;s:7:\"checked\";a:10:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:7:\"4.3.8.3\";s:22:\"cyr3lat/cyr-to-lat.php\";s:3:\"3.5\";s:21:\"imsanity/imsanity.php\";s:5:\"2.4.2\";s:33:\"kama-spamblock/kama-spamblock.php\";s:7:\"1.7.5.1\";s:55:\"pagination-styler-for-woocommerce/pagination-styler.php\";s:7:\"3.5.0.3\";s:31:\"query-monitor/query-monitor.php\";s:5:\"3.3.4\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.5.7\";s:32:\"woo-better-usability/wbulite.php\";s:6:\"1.0.26\";s:73:\"variation-swatches-for-woocommerce/variation-swatches-for-woocommerce.php\";s:5:\"1.0.4\";s:24:\"wordpress-seo/wp-seo.php\";s:6:\"10.0.1\";}s:8:\"response\";a:5:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:7:\"4.3.9.4\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:5:\"3.3.6\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/query-monitor.3.3.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/query-monitor/assets/icon-256x256.png?rev=2056073\";s:2:\"1x\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";s:3:\"svg\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=1731469\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.2\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.6.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.6.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2075035\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2075035\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2075035\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2075035\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:32:\"woo-better-usability/wbulite.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:34:\"w.org/plugins/woo-better-usability\";s:4:\"slug\";s:20:\"woo-better-usability\";s:6:\"plugin\";s:32:\"woo-better-usability/wbulite.php\";s:11:\"new_version\";s:6:\"1.0.28\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/woo-better-usability/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/woo-better-usability.1.0.28.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:73:\"https://ps.w.org/woo-better-usability/assets/icon-128x128.png?rev=1745476\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.4\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:4:\"11.5\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wordpress-seo.11.5.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"5.2.2\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:5:{s:22:\"cyr3lat/cyr-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/cyr3lat\";s:4:\"slug\";s:7:\"cyr3lat\";s:6:\"plugin\";s:22:\"cyr3lat/cyr-to-lat.php\";s:11:\"new_version\";s:3:\"3.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr3lat/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/cyr3lat.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:21:\"imsanity/imsanity.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/imsanity\";s:4:\"slug\";s:8:\"imsanity\";s:6:\"plugin\";s:21:\"imsanity/imsanity.php\";s:11:\"new_version\";s:5:\"2.4.2\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/imsanity/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/imsanity.2.4.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/imsanity/assets/icon-256x256.png?rev=1094749\";s:2:\"1x\";s:61:\"https://ps.w.org/imsanity/assets/icon-128x128.png?rev=1170755\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/imsanity/assets/banner-772x250.png?rev=900541\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"kama-spamblock/kama-spamblock.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/kama-spamblock\";s:4:\"slug\";s:14:\"kama-spamblock\";s:6:\"plugin\";s:33:\"kama-spamblock/kama-spamblock.php\";s:11:\"new_version\";s:7:\"1.7.5.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/kama-spamblock/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/kama-spamblock.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/kama-spamblock/assets/icon-256x256.png?rev=1626940\";s:2:\"1x\";s:67:\"https://ps.w.org/kama-spamblock/assets/icon-128x128.png?rev=1626940\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:55:\"pagination-styler-for-woocommerce/pagination-styler.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:47:\"w.org/plugins/pagination-styler-for-woocommerce\";s:4:\"slug\";s:33:\"pagination-styler-for-woocommerce\";s:6:\"plugin\";s:55:\"pagination-styler-for-woocommerce/pagination-styler.php\";s:11:\"new_version\";s:7:\"3.5.0.3\";s:3:\"url\";s:64:\"https://wordpress.org/plugins/pagination-styler-for-woocommerce/\";s:7:\"package\";s:84:\"https://downloads.wordpress.org/plugin/pagination-styler-for-woocommerce.3.5.0.3.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:86:\"https://ps.w.org/pagination-styler-for-woocommerce/assets/icon-128x128.png?rev=1891129\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/pagination-styler-for-woocommerce/assets/banner-772x250.png?rev=1891129\";}s:11:\"banners_rtl\";a:0:{}}s:73:\"variation-swatches-for-woocommerce/variation-swatches-for-woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:48:\"w.org/plugins/variation-swatches-for-woocommerce\";s:4:\"slug\";s:34:\"variation-swatches-for-woocommerce\";s:6:\"plugin\";s:73:\"variation-swatches-for-woocommerce/variation-swatches-for-woocommerce.php\";s:11:\"new_version\";s:5:\"1.0.4\";s:3:\"url\";s:65:\"https://wordpress.org/plugins/variation-swatches-for-woocommerce/\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/plugin/variation-swatches-for-woocommerce.1.0.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:87:\"https://ps.w.org/variation-swatches-for-woocommerce/assets/icon-256x256.png?rev=1580467\";s:2:\"1x\";s:87:\"https://ps.w.org/variation-swatches-for-woocommerce/assets/icon-128x128.png?rev=1580467\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:90:\"https://ps.w.org/variation-swatches-for-woocommerce/assets/banner-1544x500.png?rev=1580467\";s:2:\"1x\";s:89:\"https://ps.w.org/variation-swatches-for-woocommerce/assets/banner-772x250.png?rev=1580467\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("7950","_transient_timeout_wc_report_sales_by_date","1562263464","no");
INSERT INTO `wp_options` VALUES("7951","_transient_wc_report_sales_by_date","a:32:{s:32:\"7b0da2002189a4987a60b504f2b225d3\";a:0:{}s:32:\"d6741f46ad97dc1101f1ea3744f397d5\";a:0:{}s:32:\"9199a6085248f9a23f68f5b887b7d653\";a:0:{}s:32:\"064bf68272902b08a7f091882912ba1d\";N;s:32:\"c6d7157a8d6e3a6b35a21ec99f84e5d8\";a:0:{}s:32:\"39f081c1af20e13f5ea3edb5fc56fb7e\";a:0:{}s:32:\"35d7b7e56cb80a830d24ad08b4ad72aa\";a:0:{}s:32:\"95f92e88df2b8725bdeefd39efce8236\";a:0:{}s:32:\"bdb347605ae661402533a7851eba59df\";a:0:{}s:32:\"0aad5471aed9c116db7d428795049fef\";a:0:{}s:32:\"d57641df189cd4467e04d8812c1c5352\";a:0:{}s:32:\"7c5b25f20e840890b3341a5b3af027f5\";N;s:32:\"6ab446b6a6c4f251574883f7c0eb7787\";a:0:{}s:32:\"1ad6fb1e1cf3f7853705641797dfa68b\";a:0:{}s:32:\"e151df99d60de160c1a03e07bb8d50f2\";a:0:{}s:32:\"703486db8cd92fcf2695ec2ee5aeaf83\";a:0:{}s:32:\"48390b5334ec7d8dd2f8b6f02e9be6df\";a:0:{}s:32:\"bc2fd96f992f738e643226173797dd58\";a:0:{}s:32:\"9bb191e25c463a61f0515589ee98f81d\";a:0:{}s:32:\"8d2859cb2a9ab3732cce9aed65b54546\";N;s:32:\"7fc9c854e2c5c1a8b4d417f37b445149\";a:0:{}s:32:\"3682402a6050523a4f9e14bcb21f8e1c\";a:0:{}s:32:\"106daf7a5151bdc7dfaefe480ec91cc9\";a:0:{}s:32:\"b243338383b4045e0369cf425842f882\";a:0:{}s:32:\"15e7b7f5271ef06ae2d81c9256cdded2\";a:0:{}s:32:\"817af8217ce2534276293c1624e8356f\";a:0:{}s:32:\"d2eb8e43d243418764af08e49cc35727\";a:0:{}s:32:\"2c31ae2b8649f99c560d8f8b5aa80033\";N;s:32:\"6025d331ccb46b1d412ef7a51c0922c7\";a:0:{}s:32:\"b928922285b07d7c33d844364fd5ad8e\";a:0:{}s:32:\"4cd82120422ee69e319ef8dbb9bbbece\";a:0:{}s:32:\"6458982561eccd7cf22895ac0b4301e6\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("7952","_transient_timeout_wc_admin_report","1562248008","no");
INSERT INTO `wp_options` VALUES("7953","_transient_wc_admin_report","a:1:{s:32:\"a2cc41b797c5df9489d2609391ebe867\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("7954","_transient_timeout_wpseo-statistics-totals","1562248012","no");
INSERT INTO `wp_options` VALUES("7955","_transient_wpseo-statistics-totals","a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:85:\"Записи <strong>без</strong> фокусного ключевого слова\";s:5:\"count\";s:1:\"3\";s:4:\"link\";s:97:\"http://localhost/tes/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}","no");
INSERT INTO `wp_options` VALUES("7956","_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e","1562220631","no");
INSERT INTO `wp_options` VALUES("7957","_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e","a:2:{s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("7958","_transient_timeout_feed_126d1ca39d75da07beec8b892738427b","1562204816","no");
INSERT INTO `wp_options` VALUES("7959","_transient_feed_126d1ca39d75da07beec8b892738427b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Блог | Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ru.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 May 2019 14:19:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"ru-RU\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.3-alpha-45591\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WordPress Translation Day 4 — Санкт-Петербург\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:152:\"https://ru.wordpress.org/news/2019/05/wordpress-translation-day-4-%d1%81%d0%b0%d0%bd%d0%ba%d1%82-%d0%bf%d0%b5%d1%82%d0%b5%d1%80%d0%b1%d1%83%d1%80%d0%b3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 May 2019 11:53:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2099\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:685:\"Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках https://wptranslationday.org/ в Петербурге очная часть пройдет по адресу 9-я Советская, 18 (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое время. В программе &#8212; философия WordPress полиглотов, инструктаж, практическая часть, где мы переводим непереведенные плагины, темы, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1478:\"
<p>Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках <a href=\"https://wptranslationday.org/\">https://wptranslationday.org/</a>  в Петербурге очная часть <a href=\"https://www.meetup.com/St-Petersburg-WordPress-Meetup/events/261316455/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"пройдет (opens in a new tab)\">пройдет</a> по адресу 9-я Советская, 18  (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое  время.</p>



<p>В программе &#8212; философия WordPress полиглотов, инструктаж,  практическая часть, где мы переводим непереведенные плагины, темы, и  т.д. Заочно можно участвовать присоединившись в Телеграм-группу @wcspb  <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>Берем свои ноутбуки, знание русского языка (и немного английского), и отличное настроение!</p>



<p>Полиглоты, лингвисты, программисты объединяйтесь!</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WP Moscow #6. Собственная тема на Elementor, кейс по WordPress + React JS\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:222:\"https://ru.wordpress.org/news/2019/02/wp-moscow-6-%d1%81%d0%be%d0%b1%d1%81%d1%82%d0%b2%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%82%d0%b5%d0%bc%d0%b0-%d0%bd%d0%b0-elementor-%d0%ba%d0%b5%d0%b9%d1%81-%d0%bf%d0%be-wordpress-react-js/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Feb 2019 05:10:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2081\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:563:\"Очередной митап по WordPress состоится в четверг 28 февраля. Запланировано два доклада: «Создание собственной темы для WordPress сайта при помощи плагина Elementor»Леонид Лукин «Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»Андрей Панферов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:742:\"
<p>Очередной митап по WordPress состоится в четверг 28 февраля.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Создание собственной темы для WordPress сайта при помощи плагина Elementor»</strong><br>Леонид Лукин</p>



<p><strong>«Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»</strong><br>Андрей Панферов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258755820/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WP Moscow #5 | Тонкости продаж, Gutenberg и ACF\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:157:\"https://ru.wordpress.org/news/2019/01/wp-moscow-5-%d1%82%d0%be%d0%bd%d0%ba%d0%be%d1%81%d1%82%d0%b8-%d0%bf%d1%80%d0%be%d0%b4%d0%b0%d0%b6-gutenberg-%d0%b8-acf/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Jan 2019 16:14:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2074\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:424:\"Очередной митап по WordPress состоится в четверг 31 января. Запланировано два доклада: «Как продавать услуги по разработке сайтов»Андрей Панферов «ACF PRO + Gutenberg»Николай Миронов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:603:\"
<p>Очередной митап по WordPress состоится в четверг 31 января.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Как продавать услуги по разработке сайтов»</strong><br>Андрей Панферов</p>



<p><strong>«ACF PRO + Gutenberg»</strong><br>Николай Миронов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258124643/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WP Moscow #4 | Обсудим настройки тем и дизайн\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://ru.wordpress.org/news/2018/11/wp-moscow-4-%d0%be%d0%b1%d1%81%d1%83%d0%b4%d0%b8%d0%bc-%d0%bd%d0%b0%d1%81%d1%82%d1%80%d0%be%d0%b9%d0%ba%d0%b8-%d1%82%d0%b5%d0%bc-%d0%b8-%d0%b4%d0%b8%d0%b7%d0%b0%d0%b9%d0%bd/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Nov 2018 13:22:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2065\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:467:\"Очередной митап по WordPress состоится в четверг 15 ноября. Запланировано два доклада: «Настройки темы: Customizer или Advanced Custom Fields?»Денис Янчевский «В чем отличие UX дизайна от UI дизайна?»Фёдор Гребенников Вход свободной по предварительной регистрации. Начало в 18.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:646:\"
<p>Очередной митап по WordPress состоится в четверг 15 ноября.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Настройки темы: Customizer или Advanced Custom Fields?»</strong><br>Денис Янчевский</p>



<p><strong>«В чем отличие UX дизайна от UI дизайна?»</strong><br>Фёдор Гребенников</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/255766420/\">предварительной регистрации</a>.</p>



<p>Начало в 18.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WP Moscow #3 | Доклады, живое общение, пицца\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:198:\"https://ru.wordpress.org/news/2018/10/wp-moscow-3-%d0%b4%d0%be%d0%ba%d0%bb%d0%b0%d0%b4%d1%8b-%d0%b6%d0%b8%d0%b2%d0%be%d0%b5-%d0%be%d0%b1%d1%89%d0%b5%d0%bd%d0%b8%d0%b5-%d0%bf%d0%b8%d1%86%d1%86%d0%b0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 14 Oct 2018 23:14:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2057\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:666:\"Очередной митап по WordPress состоится в субботу 20 октября. Запланировано три доклада: «SEO? Изучить не надо игнорировать — где ставить запятую веб-разработчику?» Павел Карпов «Перевод проекта с премиум-темы на чистый код» Владимир Скляр «Видите ли вы хаос в коде плагинов и тем? А он есть!» Николай Коробочкин Вход свободной по предварительной регистрации. Начало в 12.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:870:\"<p>Очередной митап по WordPress состоится в субботу 20 октября.</p>
<p>Запланировано три доклада:</p>
<p><strong>«SEO? Изучить не надо игнорировать — где ставить запятую веб-разработчику?»</strong><br />
Павел Карпов</p>
<p><strong>«Перевод проекта с премиум-темы на чистый код»</strong><br />
Владимир Скляр</p>
<p><strong>«Видите ли вы хаос в коде плагинов и тем? А он есть!»</strong><br />
Николай Коробочкин</p>
<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/Moscow-WordPress-Meetup/events/255225381/\">предварительной регистрации</a>.</p>
<p>Начало в 12.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"Электронная коммерция с WordPress, как создать интернет-магазин?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2018/09/meetup-moscow-1809/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 17 Sep 2018 19:41:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2048\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:583:\"Первый тематический митап про WooCommerce (и не только) состоится в Москве 20 сентября. Обсуждаем особенности создания интернет-магазинов на WordPress, плагины, темы, оптимизацию работы сайта. Приглашаем всех, кто интересуется электронной коммерцией, имеет опыт или планирует открыть свой интернет-магазин. Подробности по ссылке\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:697:\"
<p>Первый тематический митап про WooCommerce (и не только) состоится в Москве 20 сентября. Обсуждаем особенности создания интернет-магазинов на WordPress, плагины, темы, оптимизацию работы сайта.</p>



<p>Приглашаем всех, кто интересуется электронной коммерцией, имеет опыт или планирует открыть свой интернет-магазин.</p>



<p><a href=\"https://www.meetup.com/ru-RU/Moscow-WordPress-Meetup/events/254204545/\">Подробности по ссылке</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:54:\"
		
		
				
		
				
		
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Конференция WordCamp Москва 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://ru.wordpress.org/news/2018/07/wordcamp-moscow2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Jul 2018 17:06:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2017\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:446:\"В этом году WordCamp Moscow впервые будет длиться два дня! Мероприятие пройдет 18 и 19 августа в центре Digital October! Посетите сайт конференции, чтобы ознакомиться с подробностями, стать спикером, спонсором или зарегистрироваться для участия в конференции!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:568:\"<p>В этом году WordCamp Moscow впервые будет длиться два дня! Мероприятие пройдет <strong>18 и 19 августа</strong> в центре Digital October!</p>
<p><a href=\"https://2018.moscow.wordcamp.org/\" target=\"_blank\" rel=\"noopener noreferrer\">Посетите сайт конференции</a>, чтобы ознакомиться с подробностями, стать спикером, спонсором или зарегистрироваться для участия в конференции!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:54:\"
		
		
				
		
				
		
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Конференция WordCamp Санкт-Петербург 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://ru.wordpress.org/news/2018/05/wordcamp-stpetersburg2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 02 May 2018 07:03:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1994\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:575:\"Конференция состоится 26 мая 2018 при поддержке компании SEMrush. Хотите поучаствовать, поделиться сообществом своим опытом или просто рассказать что-то интересное из мира WordPress? Приходите, будет интересно! Полезные знакомства, новые доклады, футболка с символикой WordPress, пицца и after-party. Подробности на сайте конференции.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:706:\"<p>Конференция состоится 26 мая 2018 при поддержке компании SEMrush.<br />
Хотите поучаствовать, поделиться сообществом своим опытом или просто рассказать что-то интересное из мира WordPress?<br />
Приходите, будет интересно!<br />
Полезные знакомства, новые доклады, футболка с символикой WordPress, пицца и after-party.<br />
Подробности <a href=\"https://2018.saintpetersburg.wordcamp.org/\" target=\"_blank\" rel=\"noopener noreferrer\">на сайте конференции.</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"Выпуск WordPress 4.9.4 (требуется ручное обновление)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://ru.wordpress.org/news/2018/02/%d0%b2%d1%8b%d0%bf%d1%83%d1%81%d0%ba-wordpress-4-9-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 16:46:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:22:\"Исправления\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:12:\"Релизы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1886\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:661:\"Доступна версия WordPress 4.9.4, исправляющая внесенную в выпуске 4.9.3 ошибку с автообновлением. Если вы успели (возможно автоматически) обновить свой сайт (или сайты) до 4.9.3, то вам нужно обновить WordPress  до версии 4.9.4, используя кнопку в Консоль &#62; Обновления, либо иным удобным вам способом (wp-cli, через ftp или ssh). Скачать архив дистрибутива можно здесь. Детали ошибки [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:905:\"<p>Доступна версия WordPress 4.9.4, исправляющая внесенную в выпуске 4.9.3 ошибку с автообновлением. Если вы успели (возможно автоматически) обновить свой сайт (или сайты) до 4.9.3, то вам нужно обновить WordPress  до версии 4.9.4, используя кнопку в <em>Консоль &gt; Обновления, </em>либо иным удобным вам способом (wp-cli, через ftp или ssh). Скачать архив дистрибутива можно <a href=\"https://ru.wordpress.org/releases/\">здесь</a>.</p>
<p>Детали ошибки <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\" target=\"_blank\" rel=\"noopener\">доступны</a> в блоге Make WordPress.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"Всемирный день перевода WordPress 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://ru.wordpress.org/news/2017/09/wp-translation-day-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 Sep 2017 18:55:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1841\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:655:\"Всемирный день перевода — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык. Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4393:\"<p><a href=\"https://wptranslationday.org/\">Всемирный день перевода</a> — это мероприятие, которое проходит по всему миру в один день в формате вебинаров или митапов, когда каждый может принять участие в переводе плагинов, тем, документации и ядра WordPress на свой родной язык.</p>
<p><a href=\"https://wptranslationday.org/\"><img class=\"alignnone wp-image-1842 size-full\" src=\"https://ru.wordpress.org/files/2017/09/4by3.jpg\" alt=\"\" width=\"1024\" height=\"768\" srcset=\"https://ru.wordpress.org/files/2017/09/4by3.jpg 1024w, https://ru.wordpress.org/files/2017/09/4by3-300x225.jpg 300w, https://ru.wordpress.org/files/2017/09/4by3-768x576.jpg 768w, https://ru.wordpress.org/files/2017/09/4by3-440x330.jpg 440w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></p>
<p>Быть разработчиком для этого совсем не обязательно, участвовать может любой желающий. Если вы давно хотели внести свой вклад в развитие WordPress — сейчас самое время!</p>
<p>В России в рамках мероприятия планируется встреча в Ростове-на-Дону, а также вебинар для тех, кто будет переводить у себя дома.</p>
<p><strong>Когда</strong></p>
<p>День перевода WordPress пройдёт в субботу, 30 сентября.</p>
<p><strong>Где</strong></p>
<ul>
<li>Ростов-на-Дону: ул. Большая Садовая, д. 81/31 (кафе Starbucks). Начало в 12:00.</li>
<li>Вебинар: <a href=\"https://www.crowdcast.io/e/gwtd3/22\">https://www.crowdcast.io/e/gwtd3/22</a>, начало в 20:00 по московскому времени. Вы узнаете, как переводить WordPress, плагины и темы на русский язык, сможете выбрать проект и приступить к переводу.</li>
</ul>
<p>Расписание всех вебинаров мероприятия: <a href=\"https://wptranslationday.org/#primary\">https://wptranslationday.org/#primary</a>.</p>
<p><strong>Полезные ресурсы</strong></p>
<ul>
<li><a href=\"https://ru.wordpress.org/support/topic/%D0%BA%D0%B0%D0%BA-%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%B5%D1%81%D1%82%D0%B8-%D1%82%D0%B5%D0%BC%D1%83-%D0%B8%D0%BB%D0%B8-%D0%BF%D0%BB%D0%B0%D0%B3%D0%B8%D0%BD/\">Как перевести тему или плагин?</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\">Рекомендации по стилю перевода</a></li>
<li><a href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\">Как сделать хороший перевод</a></li>
<li><a href=\"https://translate.wordpress.org/locale/ru/default/glossary\">Словарь терминов</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\">Первые шаги переводчика</a></li>
<li><a href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li>
</ul>
<p>Для координации и обсуждения вопросов стоит зарегистрироваться в <a href=\"https://ruwp.slack.com/\">Slack-группе русскоязычного сообщества WordPress</a> и зайти на канал <code>#translations</code>. При регистрации введите адрес вида <code>username@chat.wordpress.org</code> (он же используется и в <a href=\"https://make.wordpress.org/chat/\">английском Slack</a>), где <code>username</code> — ваш логин на WordPress.org.</p>
<p>Да пребудут с нами понятные интерфейсы и качественная локализация!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ru.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 03 Jul 2019 13:46:56 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Wed, 03 Jul 2019 13:43:41 GMT\";s:4:\"link\";s:61:\"<https://ru.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("7960","_transient_timeout_feed_mod_126d1ca39d75da07beec8b892738427b","1562204816","no");
INSERT INTO `wp_options` VALUES("7961","_transient_feed_mod_126d1ca39d75da07beec8b892738427b","1562161616","no");
INSERT INTO `wp_options` VALUES("7962","_transient_timeout_plugin_slugs","1562263841","no");
INSERT INTO `wp_options` VALUES("7963","_transient_plugin_slugs","a:10:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:22:\"cyr3lat/cyr-to-lat.php\";i:2;s:21:\"imsanity/imsanity.php\";i:3;s:33:\"kama-spamblock/kama-spamblock.php\";i:4;s:55:\"pagination-styler-for-woocommerce/pagination-styler.php\";i:5;s:31:\"query-monitor/query-monitor.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:32:\"woo-better-usability/wbulite.php\";i:8;s:73:\"variation-swatches-for-woocommerce/variation-swatches-for-woocommerce.php\";i:9;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `wp_options` VALUES("7964","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1562204818","no");
INSERT INTO `wp_options` VALUES("7965","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"HeroPress: I Am Cookie Dough\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2911\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"https://heropress.com/essays/i-am-cookie-dough/#utm_source=rss&utm_medium=rss&utm_campaign=i-am-cookie-dough\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12111:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2019/07/070319-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: I can finally acknowledge that I am worth being a part of a team.\" /><p>I was always told I had to go to college. I was “gifted” so learning came easy and I enjoyed it.  From ages 6 to 18, I went to competitive accelerated schools designed to churn out college students. It was a narrow path I’d been set on, without encouragement to explore beyond.</p>
<p>Majoring in theater was a no-brainer. It was the only thing I’d done my whole life, so I figured I wouldn’t get bored. My mom was a stage manager so it has always been easy to bring me to rehearsals with her when working a show. I ended up in close to 20 different productions between 5 and 13. Plus, Florida State University had a great theatre program and in-state tuition was cheap. So I went.</p>
<p>But I wasn’t there because I wanted to be. I’d gone simply because I felt I <i>had</i> to go to college, regardless of what I did when I got there. I liked theater a lot, but I didn’t love it the way my classmates did. Self-doubt crept in. Depression overcame me. Anxiety and self-hatred took root. I stopped going to class. I isolated myself from my friends who &#8211; going through their own stuff &#8211;  were too busy to notice.</p>
<p>At 19, I dropped out.</p>
<h3>Straying from the path</h3>
<p>With me, I took thousands in debt, a diagnosis of bipolar disorder, and a bruised ego. I wandered, directionless for the first time in my life.</p>
<p>I felt like a failure. I did not know who or what I was anymore, I had no community and I belonged nowhere. I was crippled by my concurrent depression and lack of a diploma. What was my path now?</p>
<p>My mother spent her whole life working in the arts and that made her happy. I wanted the same thing. But we were always pinching pennies. I didn’t want that for myself, and I didn’t want my kids to grow up with that burden. So I thought to myself, “What can I do that’s creative, won’t be boring, and can earn me an income?”</p>
<p>I don’t remember if there was a lightbulb moment where I realized web design checked all my boxes. But that was there I landed.</p>
<p>I started getting my toes wet with HTML and CSS, but coding didn’t come easily to me. I didn’t have a computer, so I would write out lines of code by hand in order to memorize syntax. It didn’t click and just swam in front of my eyes. It was difficult, so I gave up.</p>
<p>For a year and a half, I lived in a few different cities, from Ft Lauderdale all the way to Los Angeles, working some retail and food service jobs. I learned about customer service, the balance between maintenance and growth, and found myself more than a little bit fascinated by marketing.  I began to learn how to juggle the depression and anxiety that lived in my head.</p>
<p>No matter where I went, web design was sitting in the back of my brain. I was shut down when I tried to suggest changes to the booking system of a salon I worked at. I found myself sketching redesigns of the website of the bar where I picked up shifts. I started learning again after moving back to Florida. This time, I found online resources like Udemy and CodeSchool and it all began to click.</p>
<h3>Finding a new path</h3>
<p>While I still didn’t love code itself, I loved the idea of building something from nothing. It all hearkened back to theater: rallying the knowledge and experience of multiple people, laying out a plan, inventing some creative solutions along the way, iteration after iteration until it functions and yields a result, then presenting it as a living and breathing product. I had learned about story-telling via script analysis classes in college as well as spacing and color psychology. I had always been academic, so I found ease and comfort in things like databases and content writing. My intellectual and creative side were merging, dancing together in one elegant performance.</p>
<p>In 2015, I applied for a web design internship at a small agency. It was here where WordPress and I first met. I was amazed that I could easily build websites with limited coding knowledge. I attended my first WordCamp in Miami, where I watched people like Morten Hendricksen and Michelle Schlup live what I wished I could be doing.</p>
<p>I was promoted to a full employee in a poisonous environment. I had to work long hours and was accused of not being a team player if I didn’t. I was guilt-tripped with gifts and compliments. I was asked to do tasks I hadn’t been trained in and was berated when I struggled. I left one day after about a year, in tears. The despair, loneliness and frustration were unassailable.  I had failed, yet again, to move forward on the path I felt I belonged on.</p>
<h3>Setting my own path</h3>
<p>I had no savings and no car, so I was left with a choice: apply to work at the Wendy’s that was walking distance up the street, or find a way to make money out of thin air. Taking inventory of my skills:</p>
<ol>
<li>I knew WordPress</li>
<li>I knew how <i>not</i> to run a business</li>
</ol>
<p>So I started building small sites for friends and family. I scrambled to learn how to invoice properly, how to handle contracts, how to get taxes paid. I googled a lot and failed often. But it was rewarding and creative, so I stuck to it.</p>
<p>In 2017, I felt confident enough to apply to speak at WordCamp Miami. It had been 2 years since I had attended the first and I was floored when I was accepted.</p>
<p>In the three years that I ran my business, I worked with clients from all over the world. I used WordPress daily to build and break, support and scale websites for other business owners like me. I wore every hat I could balance: CEO, CFO, designer, developer, marketer, and support staff in one.</p>
<p>While I appeared “successful” (whatever that means) I was paddling like crazy beneath the surface and was constantly stretched to my limit. I achieved decent work-life boundaries and found satisfaction in the work, but being depressed while running a business is easier said than done.</p>
<p>In early 2019, as my bank account began to dry up, I began to seriously consider throwing in the towel.</p>
<h3>A fork in the path</h3>
<p>I spoke at WordCamp Miami that year. The entire camp buoyed my spirits; this time, there were faces and topics I recognized. I went with my friend, Louise Treadwell, who made the entire experience less frightening.</p>
<p>And the universe was looking out for me. The very first person I met that day was Adam Warner.</p>
<p>He saw my talk and I suppose he saw something in me that he liked. By the end of the conference, my head was swimming with the opportunity he had presented to me: to travel as a GoDaddy Pro Speaker Ambassador.</p>
<p>I felt that electric sensation again of my two halves &#8211; academic and creative &#8211; merging. It was the first time the community had reached out and taken a firm, confident grasp of my hand. And I was in exactly the right spot to accept it.</p>
<p>The idea of attending more WordCamps was thrilling. I vowed to myself that I would up my Twitter game. After all, all my WordCamp heroes were active on Twitter and I was desperate to be where the action was.</p>
<p>I grabbed as many opportunities as I could to remain visible. I wrote blog posts and made YouTube videos to prove what I knew, to myself as much as others. I wanted to earn my place at the table by giving back into the community that had plucked me out of my despair.</p>
<h3>Time to merge</h3>
<p>I’d done a podcast episode with Michelle Ames and I noticed she worked for the plugin, GiveWP. Out of curiosity, I wandered over to their careers page and saw an opening for a support tech. I had the job within 3 days.</p>
<p>I’ve done a lot of things out of fear that many people find brave. I was told I was brave for majoring in theater, but I’d done it because I didn’t want to fail at something unfamiliar. I was told I was brave for moving to Los Angeles after I dropped out, but I was afraid to be stagnant. I was told I was brave to start my own business, but I was afraid to work for someone else.</p>
<p>I do feel fear. Fear that I don’t know enough, that I’m too young or inexperienced, that I’ll let down the people who have cheered me on, that I’ll end up vulnerable the way I was in my last job. That I’ll get hurt. That being a black, queer, woman in the tech space will be too challenging.</p>
<p>I’m comforted by the knowledge that most WordPress people don’t care what gender/color/sexuality you are… as long as you keep your plugins updated. Open-source means you’re not here to out-do the next person, but to contribute toward a common goal. I can dive into support at Give with WordPress as my base, my constant. I can finally acknowledge that I am worth being part of a team. It means all the difference in the world.</p>
<h3>Who invented this path nonsense anyway?</h3>
<p>I don’t have to be on a path anymore. I can let myself remain open to possibilities and say “yes” more. I don’t have to decide what I’m going to be, <i>I can just become it,</i> because I can trust myself and the foundation that WordPress has given me. WordPress, with it’s limitless contributors, versions, and possibilities, reminds us that we should be excited by change, not afraid.</p>
<p>I believe that giving up what I worked for 3 years to build is the bravest thing I’ve done so far. At first, I was furious at myself that I couldn’t make my own business as sustainable as I’d wanted. Moving to Give felt like failing. But Louise called it “failing up” which I think is pretty apt. It was a step forward into something I could grow into and really succeed at, rather than sticking with the familiar like I had always done.</p>
<p>I often remind myself of a quote from Buffy the Vampire Slayer which, ironically, I watched for the first time while in some the deepest throes of my depression: <i>“</i><i>I&#8217;m cookie dough. I&#8217;m not done baking. I&#8217;m not finished becoming who ever the hell it is I&#8217;m gonna turn out to be.” </i></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: I Am Cookie Dough\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=I%20Am%20Cookie%20Dough&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fi-am-cookie-dough%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: I Am Cookie Dough\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fi-am-cookie-dough%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fi-am-cookie-dough%2F&title=I+Am+Cookie+Dough\" rel=\"nofollow\" target=\"_blank\" title=\"Share: I Am Cookie Dough\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/i-am-cookie-dough/&media=https://heropress.com/wp-content/uploads/2019/07/070319-150x150.jpg&description=I Am Cookie Dough\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: I Am Cookie Dough\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/i-am-cookie-dough/\" title=\"I Am Cookie Dough\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/i-am-cookie-dough/\">I Am Cookie Dough</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jul 2019 12:00:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Allie Nimmons\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: Walking 718km to WCEU, an Interview With Marcel Bootsman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91357\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/walking-748km-to-wceu-an-interview-with-marcel-bootsman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2209:\"<p>I have a hard time walking a mile or two let alone 718km, but that&#8217;s what <a href=\"https://twitter.com/mbootsman\">Marcel Bootsman</a> did on his journey to <a href=\"https://walktowc.eu/\">WordCamp EU</a> to generate funds for <a href=\"https://donatewc.org/\">DonateWC</a>. </p>



<p>In this interview, Bootsman explains how he prepared for the journey, what he experienced during his trip, and why he chose DonateWC as the charity to raise funds for. </p>



<p>One of the things that I was curious about was what Bootsman thought about during those long stretches where he had plenty of time to think to himself. </p>



<blockquote class=\"wp-block-quote\"><p>The thing that I noticed is that my thinking had changed during the month. In the beginning, I was thinking about my work, my company, and my family a lot. After about a week my family met me and it was very emotional. </p><p>After that week I found a how do you call it, peace or something like a Zen mode. Nothing was on my mind for large parts of the route. While I was walking, I was just looking around at the scenery and checking out the animals that I saw.</p><p>Sometimes I got an idea about my work and what I wanted to do differently. I&#8217;d write it down on my phone and the trip was mostly calm and relaxing.</p><cite>Marcel Bootsman </cite></blockquote>



<p>The interview is 31 minutes long and is available in video and mp3 formats. There&#8217;s also a transcript available below. In the end, Bootsman was able to raise €8590 for DonateWC and inspire a lot of people. To learn more about his journey, check out his <a href=\"https://walktowc.eu/2019/06/29/wrapping-up-walk-to-wordcamp-europe/\">Walk to WordCamp EU summary</a>. </p>



<h2>Watch and Listen:</h2>



<div class=\"wp-block-embed__wrapper\">

</div>



<h2>Listen:</h2>



Interview with Marcel Bootsman



<h2>Transcript:</h2>



<div class=\"wp-block-file\"><a href=\"https://wptavern.com/wp-content/uploads/2019/07/Interview-With-Marcel-Bootsman-Transcript.rtf\">Interview-With-Marcel-Bootsman-Transcript</a><a href=\"https://wptavern.com/wp-content/uploads/2019/07/Interview-With-Marcel-Bootsman-Transcript.rtf\" class=\"wp-block-file__button\">Download</a></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jul 2019 23:57:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: msgWP to Launch Plugin Enabling WordPress Microblogging with Telegram\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91315\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wptavern.com/msgwp-to-launch-plugin-enabling-wordpress-microblogging-with-telegram\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6742:\"<p><a href=\"https://msgwp.com/\" rel=\"noopener noreferrer\" target=\"_blank\">msgWP</a> piqued public interest this week with a demo of its new microblogging product that allows users to publish text messages and photos to WordPress sites using <a href=\"https://telegram.org/\" rel=\"noopener noreferrer\" target=\"_blank\">Telegram</a>. Although the plugin hasn&#8217;t officially launched yet, a <a href=\"https://msgwp.com/demo/\" rel=\"noopener noreferrer\" target=\"_blank\">live demo</a> on the website allows people to anonymously publish a post to msgWP&#8217;s demo blog from their own Telegram accounts by launching a Telegram bot.</p>
<p>The plugin&#8217;s creator, <a href=\"https://github.com/meszarosrob\" rel=\"noopener noreferrer\" target=\"_blank\">Róbert Mészáros</a>, said he plans to launch it in late summer or early fall, after collecting more feedback from beta testers and polishing the website. Mészáros is a developer who mainly works on a contract or freelance basis. Although msgWP isn&#8217;t is first WordPress plugin, it is the first one he has created as a product to promote.</p>
<p>&#8220;It&#8217;s highly unlikely that I&#8217;ll make msgWP available on the WordPress.org Plugin Directory, but it&#8217;s going to be GPL licensed,&#8221; Mészáros said.</p>
<p>&#8220;Support, automatic updates, and restricted content will be available only for those who buy a plan. Since I&#8217;m using msgWP myself and I plan to donate a part of profit back to the community, to the WordPress Foundation.&#8221;</p>
<p>Most of the plugins available that integrate Telegram with WordPress either broadcast to a channel or display the feed of a public channel in a widget. This is the first plugin that sends Telegram user-generated content into WordPress.</p>
<p>I tested the demo last night and successfully posted a text to the demo blog. Images do not yet appear to be working on the demo or may be disabled for now. Mészáros said the demo implementation unhooks some of the checks that are enabled by default on the plugin.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/07/Screen-Shot-2019-07-02-at-12.36.31-PM.png?ssl=1\"><img /></a></p>
<p>When the msgWP plugin is used on a site, administrators need to allow a Telegram account to create posts explicitly. This setting is available in the admin screen where you can enter the username of a Telegram account. Adding multiple usernames to the whitelist opens up some interesting possibilities for group blogging.</p>
<p>&#8220;Since every Telegram message contains information about the Telegram account, we can filter out those who are not whitelisted,&#8221; Mészáros said.</p>
<p>&#8220;Also, the fact that users are explicitly whitelisted opens up the way to have user level settings. For example, you can set a specific category for a Telegram account or only give them the option to create draft posts.</p>
<p>&#8220;If you whitelist yourself you have a microblog; if you whitelist 20 users with various settings, you can cover a live event with Telegram and msgWP.&#8221;</p>
<p>The msgWP plugin also checks the IP of the request. If it falls outside a particular IP range, msgWP can recognize that it&#8217;s not from Telegram and block it.</p>
<p>Mészáros&#8217; inspiration for the plugin came from his principles regarding centralized social media. While he maintains a private blog where his friends follow him, Mészáros&#8217; doesn&#8217;t use platforms like Twitter and Facebook.</p>
<p>&#8220;I feel strongly about blogging and microblogging,&#8221; he said. &#8220;It’s not all rainbows – if you have one, you know that it takes a certain kind of commitment and effort.&#8221;</p>
<p>Mészáros said he was also inspired &#8220;by an almost forgotten history of WordPress,&#8221; wherein many took advantage of its support for XML-RPC to blog from desktop blog editors, like MarsEdit, BlogJet, and BlogDesk, without ever logging into the admin. He contends that third-party tools like this demonstrate that <a href=\"https://msgwp.com/what-is-wordpress-without-its-editor-we-are-not-sure/\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress is more than the editor</a>.</p>
<p>Since msgWP is already integrated into the messaging workflow for Telegram users, it may inspire some to blog more often. Posting is faster than using Twitter, Facebook, or even the WordPress mobile apps, albeit with far fewer features.</p>
<p>&#8220;Paradoxically we want to encourage people to use WordPress by not reminding them that they run their sites/microblogs on WordPress,&#8221; Mészáros said. &#8220;A messaging app has some informality to it, and that will help a lot. All you need is to write and press send. After all, you are sending texts, and not publishing structured articles on your blog after too many glasses of wine. For this reason, we don&#8217;t see msgWP with Telegram as a replacement for the WP Mobile Apps.&#8221;</p>
<p>Despite the convenience promised through various apps, the concept of microblogging on one&#8217;s own website does not seem to have taken off yet. Services like <a href=\"https://micro.blog/\" rel=\"noopener noreferrer\" target=\"_blank\">micro.blog</a>, which integrate with existing WordPress blogs, are still used by a fervent few and have not yet gained mainstream adoption. Even the “Press This” feature that was included in WordPress core prior to 2017, was <a href=\"https://wptavern.com/press-this-removed-from-wordpress-4-9-in-favor-of-a-plugin\" rel=\"noopener noreferrer\" target=\"_blank\">retired in favor of a canonical plugin</a>, with discontinued support for the bookmarklet feature. It hasn&#8217;t been updated for two years and is only installed on approximately 10,000 sites.</p>
<p>Postcard, a social sharing and microblogging app that integrated with WordPress, is another tool that was aimed at fundamentally changing how people use social networks. It was <a href=\"https://wptavern.com/postcard-project-discontinued-ios-and-android-apps-now-open-source\" rel=\"noopener noreferrer\" target=\"_blank\">discontinued due to the development burden</a> of supporting multiple apps.</p>
<p>There are many different solutions that have popped up over the years for enabling quick posts or microblogging, all with vastly different approaches. msgWP has an advantage in that Mészáros can leverage the power and speed of Telegram, along with all of its mobile and desktop clients, without having to maintain that aspect of the publishing interface. Even if it doesn&#8217;t spark a wildfire of microblogging across the web, it may offer users a convenient alternative to posting content inside social media silos, especially for niche use cases like group microblogging for live events.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jul 2019 22:36:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"Matt: Just Write with David Perrell\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=49754\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://ma.tt/2019/07/just-write-with-david-perrell/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:595:\"<p>I had an <a href=\"https://www.perell.com/podcast/matt-mulleweg\">interesting conversation with David Perrell on his North Star Podcast that I recommend checking out</a>. He&#8217;s also leading a really interesting program <a href=\"https://www.perell.com/write-of-passage\">called Write of Passage</a> which is an online course which helps people grow their career by writing and sharing online, which I think is brilliant and a big source of my career growth over the years. I&#8217;ve heard he has another coming soon around information organization. David is someone to watch and follow.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jul 2019 12:56:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: CMS Backend Opener: A Firefox Extension to Quickly Locate the Login Page to Popular CMS Backends\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91312\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"https://wptavern.com/cms-backend-opener-a-firefox-extension-to-quickly-locate-the-login-page-to-popular-cms-backends\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1342:\"<p>If you use Firefox and manage multiple websites that use different Content Management Systems and have a hard time keeping track of the various URLs to their backends, consider using the <a href=\"https://addons.mozilla.org/en-US/firefox/addon/cms-backend-opener/\">CMS Backend Opener</a> Firefox extension created by Andy R.</p>



<p>Once installed, you can use either a keyboard shortcut (Alt + Y) or press a button within the browser and it will automatically open the login page for the detected CMS in a new window. </p>



<p>The extension uses the CMS meta-tag: Generator to detect which CMS is being used. The following CMS&#8217; are supported:</p>



<ul><li>Typo3</li><li>Typo3 Neos</li><li>Joomla</li><li>WordPress</li><li>Django</li><li>Shopware (beta)</li><li>Magento (beta)</li><li>Drupal</li><li>Contao</li><li>Weblication</li><li>WebsiteBaker</li><li>CMSQLite</li><li>Oxid</li></ul>



<p>Although the extension has not been updated in two years, I tested it on Firefox 67.0.4 on my MacBook Pro and it worked without any issues. I typically use a bookmark to browse to WP-Admin but this is more convenient, especially on WordPress.com. </p>



<p>I&#8217;ve also learned that if you have Pretty Permalinks enabled in WordPress, you can type /login or /admin after your domain and it will typically load the login page. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jul 2019 22:53:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"WPTavern: Lessons from the GraphQL Documentary: Never Underestimate the Power of Open Source Communities\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91081\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"https://wptavern.com/lessons-from-the-graphql-documentary-never-underestimate-the-power-of-open-source-communities\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5631:\"<p><a href=\"https://www.honeypot.io/\" rel=\"noopener noreferrer\" target=\"_blank\">Honeypot</a>, a tech-focused job platform based in Europe, has produced a <a href=\"https://youtu.be/783ccP__No8\" rel=\"noopener noreferrer\" target=\"_blank\">documentary</a> that offers a fascinating look at the origins of <a href=\"https://graphql.org/\" rel=\"noopener noreferrer\" target=\"_blank\">GraphQL</a>. The 28-minute video explores how quickly the project began to have an impact on the wider tech industry after Facebook publicly released it as an open source project.</p>
<p>GraphQL co-founder Nick Schrock, who was interviewed along with fellow co-creators Lee Byron and Dan Schafer, said the documentary &#8220;captured both the urgency and joy of the early months of the GraphQL.&#8221; It was filmed over two months in San Francisco and Berlin, where Honeypot runs the <a href=\"https://www.graphqlconf.org/\" rel=\"noopener noreferrer\" target=\"_blank\">GraphQL Conf</a> in cooperation with <a href=\"https://www.prisma.io/\" rel=\"noopener noreferrer\" target=\"_blank\">Prisma</a>.</p>
<p>GraphQL began as an internal project at Facebook that was born out of necessity as the tech industry began to shift towards providing better mobile experiences for users. At that time, Facebook&#8217;s native apps were just a thin wrapper around the mobile website.</p>
<p>&#8220;The inability of a large technology company to adjust to a technology shift as big as the mobile shift is the type of thing that will consign a seemingly unstoppable empire to the grave in a matter of a few years,&#8221; Schrock said.</p>
<p>Facebook decided to re-write the Facebook iOS app but the APIs they had at that time were inadequate for creating the Newsfeed. A new Newsfeed API was written simultaneously to be used with the new mobile app. Facebook for iOS 5.0, released in 2012, was a native re-write of the app and also the first time GraphQL was deployed in the wild. Following that release, its use was expanded beyond just the Newsfeed to encompass most of the functionality offered in Facebook&#8217;s iOS app.</p>
<p>Facebook shared GraphQL with the world at React Europe 2015 and published the GraphQL spec later in 2015. They explained that their goal was to design what they thought was the ideal API for frontend developers and work backwards with the technology.</p>
<p>GraphQL&#8217;s creators were surprised at how fast the uptake was after making the project public. Engineers at Airbnb, Twitter, and Github were early adopters and their experiences are shared in the documentary with interviews from the community. The problems GraphQL&#8217;s creators encountered in scaling their mobile experience were not specific to Facebook. Other companies had similar problems and the demand for GraphQL in the industry was already there. Within six months, the team saw implementations of GraphQL in many of the major programming languages. They realized how important the project was to the industry after <a href=\"https://github.blog/2016-09-14-the-github-graphql-api/\" rel=\"noopener noreferrer\" target=\"_blank\">GitHub announced in 2016 that its public API would be a GraphQL API</a>:</p>
<blockquote><p>Using GraphQL on the frontend and backend eliminates the gap between what we release and what you can consume. We really look forward to making more of these simultaneous releases. GraphQL represents a massive leap forward for API development. Type safety, introspection, generated documentation, and predictable responses benefit both the maintainers and consumers of our platform.</p></blockquote>
<p>The documentary tells the story of how GraphQL began the first three years as a solution to internal problems at Facebook but expanded to become a community tool that was initially adopted by hobbyists and then incorporated into the products of large tech companies. GraphQL co-founder Lee Byron predicts that the project is entering the next phase of its life and &#8220;heading towards becoming an industry standard and one that&#8217;s collaborative.&#8221;</p>
<p>There&#8217;s no way to measure the number of APIs that are being built around GraphQL, but the query language is now used  in both internal and external APIs at major companies like Pinterest, Intuit, Coursera, Walmart, Shopify, PayPal, KLM, NBC News Digital, Credit Karma, Wayfair, and Yelp. Since it can be used in combination with REST APIs, GraphQL&#8217;s rapid adoption is not necessarily a good predictor for the end of REST architecture, but it&#8217;s a trend that is worth following. This widespread adoption began with just a handful of engineers who saw GraphQL&#8217;s promise at React Europe 2015, built tools to optimize development, and advocated for using GraphQL at their companies.</p>
<p>&#8220;I totally underestimated the power of these open source communities,&#8221; Schrock said. &#8220;We had to rely on this community of poeple to form spontaneously and then build implementations of this in different languages and then actually productionize it and build an entire tool ecosystem around it. I didn&#8217;t think that was ever going to work, and I was totally wrong. If an idea makes sense to people and it clicks with their mind and they can see the vision, they are actually willing to do a lot of work in order to see it executed and share their work, and it&#8217;s a pretty remarkable thing to see.&#8221;</p>
<p>The energy in the GraphQL documentary is inspiring and the story shares many parallels with other open source projects that have gained widespread adoption through passionate communities. Check out the full documentary below:</p>
<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jul 2019 21:02:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Post Status: WCEU 2019 in Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=64837\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://poststatus.com/wceu-2019-in-review/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9086:\"<p>All the talks and panels at WCEU were planned and executed well, but there were a few standouts we&#8217;ll highlight, in case you weren’t able to watch the entire <a href=\"https://2019.europe.wordcamp.org/2019/06/21/livestream/\">livestream</a>.</p>



<h2><strong>Friday Highlights</strong></h2>



<ul><li><strong>Jenny Beaumont</strong>’s “<a href=\"https://2019.europe.wordcamp.org/session/doing-it-wrong/\">Doing It Wrong</a>” was an encouraging talk that set a good mood for the whole conference. Jenny&#8217;s <a href=\"https://www.youtube.com/watch?v=J7D5p25NyAk\">interview</a> with <strong>Torque</strong> at WCEU is worth a listen too. <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/1f31e.png\" alt=\"🌞\" class=\"wp-smiley\" /></li><li><strong>John Jacoby</strong>’s talk on “<a href=\"https://2019.europe.wordcamp.org/session/advanced-database-management-for-plugins/\">Advanced Database Management For Plugins</a>” explored the pain of dealing with databases when you&#8217;re writing plugins. He also announced a stand-alone open source library for better WordPress database management that will be released in July.</li><li><strong>Josepha Haden</strong>&#8216;s talk entitled “<a href=\"https://2019.europe.wordcamp.org/session/change-your-socks-change-your-mind-a-no-fuss-primer-on-change-management/\">Change your socks, change your mind: A no-fuss primer on change management</a>” focused on the things group and community leaders should attend to most during periods of significant change. That&#8217;s a timely subject, given the events of the past year, and Josepha&#8217;s points apply to many parts of the WordPress community. <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/1f9e6.png\" alt=\"🧦\" class=\"wp-smiley\" /></li></ul>



<p>Matt’s talk after lunch on Friday was more of an update on Gutenberg. Matt presented some Gutenberg stats and then put the spotlight on some new block editor plugins and experiments. Matt reminded everyone that Gutenberg is in phase two, “where we are working with widgets (old school blocks), customization, and menus.”</p>



<h2><strong>Matt&#8217;s Session</strong></h2>



<ul><li>Matt showed off the <a href=\"https://wordpress.org/plugins/grids/\"><strong>Grid</strong> block plugin</a> from <strong>Evolve</strong> that generates any layout style with a slick UI. You have to see it in action.</li><li>Gutenberg is now <a href=\"https://www.drupal.org/project/gutenberg\">available for <strong>Drupal</strong></a><strong>.</strong></li><li>There are about 150k posts published each day with Gutenberg. That&#8217;s about two every second, and ta rate is increasing.</li><li>Gutenberg will soon have:<ul><li>A block directory that&#8217;s accessible from the “top-level navigation” on the .org site.</li><li>Footnotes and improved “micro” animations.</li><li>Special attention placed on the mobile experience. Matt noted that &#8220;Gutenberg for mobile is live, and the ability [to use its features] is increased now in the mobile apps.&#8221; He also mentioned they &#8220;had to write the codebase separately for this experience.&#8221;</li></ul></li></ul>



<p>The initial questions Matt got from the audience were somewhat aggressive and prolonged, so the moderators found it a challenge to keep things moving. At one point, a moderator broke in to say, “This isn’t a question; it’s a blog post.” I’m wondering if in the future at WCEU (or the upcoming WordCamp US) if a different moderation process might be considered.</p>



<p>If I had to choose one question of note, it would be the one asked about Matt&#8217;s (and WordPress’s) commitment to accessibility. Matt replied, “Accessibility is hard. We will get there. I believe we can make every release of WordPress better, but it’s challenging with Gutenberg because there might not be previous examples to work from.” He acknowledged the excellent work that <strong>WPCampus</strong> recently did with its accessibility audit.</p>



<h2><strong>Saturday Highlights:</strong></h2>



<p>Saturday’s talks, like Friday’s, were well done, although the panel on Gutenberg might have had more diversity in its composition, as a few people noted on Twitter.</p>



<p>Two especially notable talks:</p>



<ul><li><strong>Brian Teeman</strong>, one of the Joomla co-founders, defined what counts as truly free software. (<a href=\"https://www.slideshare.net/brianteeman/the-power-of-free-151309934\">Slides</a>) If you have begun to wonder how cloud services and <strong>Jetpack</strong> challenge the concept of &#8220;free,&#8221; check out Brian&#8217;s talk. Brian also has a recent post on his blog with <a href=\"https://brian.teeman.net/web/891-learn-something-new-at-a-conference\">some good advice for conference goers</a>: attend sessions randomly or pick ones with unfamiliar topics if you want to learn the most.</li><li><strong>Marcel Bootsman</strong> gave an inspiring account of his 700km walk to Berlin to attend the conference. It tied in well with <strong>Ines Van Essen</strong>’s talk later that afternoon about bringing peop<a href=\"https://2019.europe.wordcamp.org/session/bringing-people-to-wordcamps/\">https://2019.europe.wordcamp.org/session/bringing-people-to-wordcamps/</a>le to WordCamps and how much it typically costs for someone to attend.</li></ul>



<p>The conclusion of WCEU came with the usual display of conference statistics:</p>



<ul><li>3,260 tickets were sold. (800 more than last year!) <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/1f39f.png\" alt=\"🎟\" class=\"wp-smiley\" /></li><li>2,734 attendees. (610 for contributor day!)</li><li>1,722 or 56% were attending WCEU for the first time.</li><li>11,700 meals were served. <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/1f37d.png\" alt=\"🍽\" class=\"wp-smiley\" /></li><li>60 speakers gave talks.</li><li>60 interviews took place.</li><li>60 sponsors — and 150 micro-sponsors helped make it all possible.</li><li>2k photos / 1m Tweets — YOU ARE WELCOME! <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/1f60a.png\" alt=\"😊\" class=\"wp-smiley\" /></li><li>97 countries were represented by attendees. <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/1f30d.png\" alt=\"🌍\" class=\"wp-smiley\" /></li><li>166 square meters of printed banners and materials were produced this year, which will be repurposed by being made into bags. <img src=\"https://s.w.org/images/core/emoji/11.2.0/72x72/267b.png\" alt=\"♻\" class=\"wp-smiley\" /></li></ul>



<p>Since I was not physically attending WCEU, I asked people who were there in Berlin what they most appreciated — especially if it wasn’t observable through the livestream.</p>



<img src=\"https://cdn.poststatus.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-28-at-1.05.08-PM.png\" alt=\"\" class=\"wp-image-64838\" />



<p>I got <a rel=\"noreferrer noopener\" href=\"https://twitter.com/dimensionmedia/status/1142704622911524864\" target=\"_blank\">some good answers on Twitter</a> from <a rel=\"noreferrer noopener\" href=\"https://twitter.com/topher1kenobe/status/1142829013515276289\" target=\"_blank\">Topher</a>, <a rel=\"noreferrer noopener\" href=\"https://twitter.com/JJJ/status/1142784869610770433\" target=\"_blank\">JJJ</a>, <a rel=\"noreferrer noopener\" href=\"https://twitter.com/mor10/status/1142804505802739714\" target=\"_blank\">mor10</a>, <a rel=\"noreferrer noopener\" href=\"https://twitter.com/learnwithmattc/status/1142460541409124354\" target=\"_blank\">Matt Cromwell</a>, <a rel=\"noreferrer noopener\" href=\"https://twitter.com/netagence/status/1142774768804012033\" target=\"_blank\">Pierre Mobian</a>, and <a rel=\"noreferrer noopener\" href=\"https://twitter.com/yvettesonneveld/status/1142833983157391360\" target=\"_blank\">Yvette Sonneveld</a>, among others.</p>



<p><a rel=\"noreferrer noopener\" href=\"https://2019.europe.wordcamp.org/2019/04/30/wp-cafe/\" target=\"_blank\">The WP Cafe</a> was a new feature for WCEU that provided “space for our attendees to meet, connect, and chat about a range of topics.” It&#8217;s an evolution of the previous year’s “Tribe Meetups.”</p>



<p>After the event, the WordCamp Europe team <a href=\"https://2019.europe.wordcamp.org/2019/06/24/after-party-apology/\">addressed some issues</a> that came up at the afterparty &#8212; around the entertainment that was provided, and in regard to water availability.</p>



<h2><strong>WCEU 2020</strong></h2>



<p>WordCamp Europe is always held in a different city in Europe every year, and it was announced at the end of the event that the 2020 conference would be held in Porto, Portugal. (There&#8217;s <a rel=\"noreferrer noopener\" href=\"http://youtu.be/gKGA3O3aZy4\" target=\"_blank\">a trailer</a>.)</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>Porto seems to be a popular destination, and WCEU reported that just 24 hours after opening the #WCEU 2020 Call for Organisers, over 30 applications were already received.</p>



<p><a href=\"https://twitter.com/WCEurope/status/1142117820660101120\"><em>Photo credit @WCEurope</em></a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jul 2019 20:45:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"David Bisset\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WordPress.org blog: The Month in WordPress: June 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7009\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2019/07/the-month-in-wordpress-june-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8172:\"<p>June has certainly been a busy month in the WordPress community — aside from holding the largest WordPress event ever, the project has hit a number of significant milestones and published some big announcements this past month.</p>



<hr class=\"wp-block-separator\" />



<h2>A Wrap for WordCamp Europe 2019</h2>



<p>WordCamp Europe 2019 took place on June 20-22. It was the largest WordPress event ever, with 3,260 tickets sold and 2,734 attendees. The attendees came from 97 different countries and 1,722 of them had never attended WordCamp Europe before.</p>



<p>The event featured 60 speakers who delivered talks and workshops on a variety of topics over two conference days, most notably <a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a>’s keynote that included an update on the current status of WordPress Core development, along with a lively Q&amp;A session. The full session from the live stream is <a href=\"https://youtu.be/UE18IsncB7s?t=13033\">available to watch online</a>.</p>



<p>For its eighth year, <a href=\"https://2019.europe.wordcamp.org/2019/06/25/wordcamp-europe-2020/\">WordCamp Europe will take place in Porto, Portugal</a>. The 2020 edition of the event will be held on June 4-6. If you would like to get involved with WordCamp Europe next year, fill out <a href=\"https://2020.europe.wordcamp.org/2019/06/22/call-for-organisers/\">the organizer application form</a>.&nbsp;</p>



<h2>Proposal for XML Sitemaps in WordPress Core</h2>



<p><a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\">A proposal this month</a> suggested bringing XML sitemap generation into WordPress Core. This is a feature that has traditionally been handled by plugins, which has resulted in many different implementations across different sites. It also means that many sites do not have XML sitemaps, which can be a problem because they are hugely important to having your site correctly indexed by search engines.</p>



<p>The proposal details how core sitemaps would be structured and how the team would build them, as well as what aspects of WordPress would not be considered appropriate information to be included.</p>



<p>Want to get involved in building this feature? Comment on <a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\">the proposal</a>, follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Translation Milestone for the Spanish Community</h2>



<p><a href=\"https://twitter.com/wp_es/status/1138015568563441665\">The WordPress community of Spain has worked hard</a> to make <a href=\"https://translate.wordpress.org/locale/es/\">the es_ES locale</a> the first in the world to fully localize all of WordPress Core along with all Meta projects, apps, and the top 200 plugins. This is made possible by having the largest translation team out of any locale, consisting of 2,951 individual contributors.</p>



<p>Want to get involved in translating WordPress into our locale? Find your locale on <a href=\"https://translate.wordpress.org/\">the translation platform</a>, follow <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team blog</a>, and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>WordPress 5.2.2 Maintenance Release</h2>



<p>On June 18, <a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">v5.2.2 of WordPress was released</a> as a maintenance release, fixing 13 bugs and improving the Site Health feature that was first published in v5.2. If your site has not already been automatically updated to this version, you can <a href=\"https://wordpress.org/download/\">download the update</a> or manually check for updates in your WordPress dashboard. Thanks to <a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> for co-leading this release, as well as the 30 other individuals who contributed to it.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Full End to End Tests for WordPress Core</h2>



<p>On June 27, <a href=\"https://make.wordpress.org/core/2019/06/27/introducing-the-wordpress-e2e-tests/\">e2e (end to end) testing was introduced</a> to WordPress and included in the continuous integration pipeline. E2e testing, which has been successfully used by Gutenberg, is used to simulate real user scenarios and validate process flows. Currently, the setup requires <a href=\"https://docs.docker.com/install/\">Docker</a> to run, and a number of e2e test utilities are already available in the&nbsp; <a href=\"https://github.com/WordPress/gutenberg/tree/master/packages/e2e-test-utils/src\">@wordpress/e2e-test-utils</a> package, in the Gutenberg repository.&nbsp;</p>



<p>Want to use this feature? The more tests that are added, the more stable future releases will be! Follow the <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core-js channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Feature Packages from the Theme Review Team</h2>



<p>Following a <a href=\"https://make.wordpress.org/themes/2019/06/07/proposal-theme-feature-repositories/\">proposal for theme feature repositories</a>, an <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">update to the features package was announced</a>. Two new packages have been created that require code review and testing. The first is an Autoload Package, a foundational package for theme developers who are not currently using Composer (although <a href=\"https://getcomposer.org/\">Composer</a> is recommended instead of this package). The second is a Customizer Section Button Package that allows theme authors to create a link/button to any URL.</p>



<p>There are other proposed ideas for packages that require feedback and additional discussion. Want to add your suggestions and thoughts? Join the conversation on the <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">Theme Review team blog</a> and join the #themereview channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>Development continues on the Gutenberg project, with <a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\">the latest release</a> including layouts for the Columns block, Snackbar notices, markup improvements, and accessibility upgrades.</li><li>The Community team <a href=\"https://make.wordpress.org/community/2019/06/26/wordcamp-europe-2019-recap-of-community-team-activities-at-contributor-day-plans-for-the-future/\">published the results of their work</a> at the WordCamp Europe contributor day.</li><li>The Polyglots team <a href=\"https://make.wordpress.org/polyglots/2019/06/26/proposal-for-handling-pte-requests/\">has put together a proposal</a> for a new way to handle PTE requests.</li><li>This year’s recipient of the Kim Parsell Memorial Scholarship for WordCamp US <a href=\"https://wordpressfoundation.org/2019/2019-kim-parsell-memorial-scholarship-recipient-carol-gann/\">is Carol Gann</a>.</li><li>The Amurrio WordPress community <a href=\"http://wpamurrio.es/wordpress-amurrio-mega-meetup-i-edition/\">hosted their first “mega meetup”</a> &#8211; this is a great event format that bridges the gap between regular meetup event and WordCamp.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jul 2019 10:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"WPTavern: Free Online JavaScript for WordPress Conference to Feature “Headless WordPress” Track, July 12\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91260\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"https://wptavern.com/free-online-javascript-for-wordpress-conference-to-feature-headless-wordpress-track-july-12\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2082:\"<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/02/JS-for-WP-conf-2019.jpg?ssl=1\"><img /></a></p>
<p>The second edition of the <a href=\"https://javascriptforwp.com/conference/\" rel=\"noopener noreferrer\" target=\"_blank\">JavaScript for WordPress</a> conference will be streamed online July 11-13, 2019. Based on the success of the 2018 event, which had 1,200 attendees watching live, organizer Zac Gordon decided to expand the event to feature three free days of talks, workshops, and a contribution day focused on JavaScript and WordPress.</p>
<p>The conference will run from July 11-13, and includes educational content for a whole range of Javascript capabilities, from beginner to advanced:</p>
<ul>
<li>Day 1 – Workshops for JavaScript Beginners</li>
<li>Day 2 – Three Tracks of Intermediate and Advanced Talks (plus One Non-Technical Track)</li>
<li>Day 3 – Contributor Day to help improve the JavaScript-related documentation for WordPress</li>
</ul>
<p>Gordon has published the finalized <a href=\"https://javascriptforwp.com/conference/\" rel=\"noopener noreferrer\" target=\"_blank\">schedule</a> for the 36 sessions and speakers that will be streamed on Friday, July 12. This year the event will feature one track devoted to exploring topics surrounding &#8220;headless WordPress,&#8221; an approach that eschews WordPress&#8217; traditional architecture in favor of decoupling the front and backends, allowing developers to integrate different stacks. The track includes presentations like A React Theme in 30 Min, SEO for Headless WordPress Themes, Gatsby &amp; WordPress, and Headless E-Commerce with BigCommerce. Other tracks feature more general JavaScript and Gutenberg topics.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/js-for-wp-conf-schedule-2019.png?ssl=1\"><img /></a></p>
<p>Thanks to more than a dozen sponsors, registration is free, but viewers must <a href=\"https://javascriptforwp.com/conference/\" rel=\"noopener noreferrer\" target=\"_blank\">sign up</a> on the conference website in order to attend online.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 29 Jun 2019 00:16:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"WPTavern: In Case You Missed It – Issue 27\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/?p=91256&preview=true&preview_id=91256\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wptavern.com/in-case-you-missed-it-issue-27\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8950:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png?ssl=1\" rel=\"attachment wp-att-50955\"><img /></a>photo credit: <a href=\"http://www.flickr.com/photos/112901923@N07/16153818039\">Night Moves</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc/2.0/\">(license)</a></p>
<p>There’s a lot of great WordPress content published in the community but not all of it is featured on the Tavern. This post is an assortment of items related to WordPress that caught my eye but didn’t make it into a full post.</p>
<h2 class=\"entry-title\">Carol Gann Awarded the 2019 Kim Parsell Memorial Scholarship</h2>
<p><a href=\"https://carolgann.wordpress.com/\">Carol Gann</a>, who is a Meetup coordinator in the <a href=\"https://wporlando.org/\">WordPress Orlando Community</a>, has been awarded the <a href=\"https://2019.us.wordcamp.org/2019/06/28/carol-gann-2019-kim-parsell-memorial-scholarship-recipient/\">Kim Parsell Memorial Scholarship</a>. The scholarship is named after Kim Parsell who <a href=\"https://wptavern.com/kim-parsell-affectionately-known-as-wpmom-passes-away\">passed away in 2015</a> but her impact on the WordPress community is still felt today.</p>
<p>&#8220;My proudest contribution to the WordPress open source project is training small business owners and bloggers to be comfortable and conversant with their own WordPress websites. WordPress empowers people. Many end users of WordPress are not technically minded. As a WordPress Meetup co-organizer, I contribute to the coffee help desk, assisting others in finding solutions to their WordPress problems. I also host another help desk opportunity, ‘Coffee With Carol,’ to empower WordPress users,&#8221; Gann said.</p>
<p>I can tell from the quote above that Kim and Carol would get along well as Kim was also the type of person who would do what she could to help others.</p>
<h2>GravityView Diversity Grant to Attend PressNomics 6</h2>
<p>The folks over at GravityView are <a href=\"https://gravityview.co/gravityview-diversity-grant/\">offering a grant</a> to recognize the challenges certain groups of people face succeeding in technology fields and to promote inclusivity and diversity. The grant includes a ticket to PressNomics 6, a flight to Tuscon, AZ, lodging, transportation via a Lyft gift card, and a one-on-one business consultation with Zak Katz, Co-founder of GravityView. The deadline to apply is 11:59 PM MDT on June 30, 2019.</p>
<h2>10up OpenSource Project Scaffolding Suite</h2>
<p>10up has released a <a href=\"https://10up.com/blog/2019/project-scaffolds-released/\">project scaffolding suite</a> that includes a WordPress starter theme, starter plugin, and NPM package. The purpose of the suite is to streamline repetitive tasks, encourage community contributions, and provide a starting point that includes 10up&#8217;s engineering best practices.</p>
<h2>End to End Tests Added to Core</h2>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://make.wordpress.org/core/2019/06/27/introducing-the-wordpress-e2e-tests/\">Introducing the WordPress e2e tests</a></p></blockquote>
<p></p>
<h2>WP Tavern Turns 10 Years Old</h2>
<p>I was looking back through the Tavern archives and realized that this past January, WP Tavern turned 10 years old. It&#8217;s been quite a journey and it&#8217;s not over yet. Check out the <a href=\"https://wptavern.com/welcome-to-the-wordpress-tavern\">first post</a> I published on the Tavern announcing its opening.</p>
<h2>Matt Mullenweg Announces That Automattic Is Sponsoring Jill Binder&#8217;s Work</h2>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://ma.tt/2019/06/diversifying-wordpress/\">Diversifying&nbsp;WordPress</a></p></blockquote>
<p></p>
<h2>John James Jacoby Releases A Plugin That Cryptographically Signs Posts</h2>
<p>John James Jacoby <a href=\"https://jjj.blog/2019/06/heidenberg/\">has released</a> a <a href=\"https://github.com/JJJ/Heidenberg\">small plugin on GitHub</a> that cryptographically signs posts. The plugin splits the content of posts in words and then stenographically inserts zero-width characters between them. These characters then form a unique, invisible pattern that can be used to detect plagiarised content. This plugin sounds like it would pair well with <a href=\"https://wptavern.com/new-wordproof-plugin-timestamps-wordpress-content-on-the-blockchain\">WordProof</a>.</p>
<h2>What does DXP Mean?</h2>
<p>I asked on Twitter what does DXP or Digital Xperience platform mean? It comes across as fancy marketing lingo. Here are a few of the responses I received.</p>
<p><a href=\"https://twitter.com/mattmedeiros/status/1143302580057071616\">Matt Mederios</a> &#8211; &#8216;<span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\">DXP&#8217; or in other words, how we want our customers to experience WordPress in our controlled ecosystem. All your solutions in one place, possibly to the point you don’t recognize it’s WordPress.<br />
</span></p>
<p><a href=\"https://twitter.com/StephenCronin/status/1143388011586920448\">Stephen Cronin</a> &#8211; <span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\">DXP is an enterprise thing and has been around for ages in various guises. WordPress is not listed by Gartner, but Drupal and SharePoint are, along with other enterprise CMS&#8217;s. If people want to create DXPs out of WordPress, more power to them.</span></p>
<p><a href=\"https://twitter.com/karimmarucchi/status/1143307026421997571\">Karim Marucchi</a> &#8211; <span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\">Forget the buzz, large sites are moving past &#8216;just&#8217; content, no one product (not </span><span class=\"r-18u37iz\"><a class=\"css-4rbku5 css-18t94o4 css-901oao css-16my406 r-1n1174f r-1loqt21 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\" dir=\"ltr\" href=\"https://twitter.com/hashtag/AEM?src=hashtag_click\">#AEM</a></span><span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\"> not </span><span class=\"r-18u37iz\"><a class=\"css-4rbku5 css-18t94o4 css-901oao css-16my406 r-1n1174f r-1loqt21 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\" dir=\"ltr\" href=\"https://twitter.com/hashtag/Sitecore?src=hashtag_click\">#Sitecore</a></span><span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\">) will ever be perfect for all the existing &amp; new features that are popping up &#8216;monthly&#8217;, so with </span><span class=\"r-18u37iz\"><a class=\"css-4rbku5 css-18t94o4 css-901oao css-16my406 r-1n1174f r-1loqt21 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\" dir=\"ltr\" href=\"https://twitter.com/hashtag/OpenSourse?src=hashtag_click\">#OpenSourse</a></span><span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\"> we all can make the most open easy/most compatible /cheap framework that will help the <span class=\"r-18u37iz\"><a class=\"css-4rbku5 css-18t94o4 css-901oao css-16my406 r-1n1174f r-1loqt21 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\" dir=\"ltr\" href=\"https://twitter.com/hashtag/enterprise?src=hashtag_click\">#enterprise</a></span> manage/customize/blend all the ways you need to interact with your clients. And yes, the good Hosts, are staying out of trying to be all things.</span></p>
<p>Thanks to these three, the meaning of DXP is a bit more clear.</p>
<h2>WordCamp EU Organizing Team Issues Apology</h2>
<p>There were some things that took place during the WordCamp EU afterparty that didn&#8217;t sit well with some people. The WordCamp EU organizing team explained what happened and <a href=\"https://2019.europe.wordcamp.org/2019/06/24/after-party-apology/\">issued an apology</a> for the mistakes that were made.</p>
<h2>Torque Interviews Marcel Bootsman</h2>
<p>Doc Pop of Torque <a href=\"https://twitter.com/TheTorqueMag/status/1141715724685185024\">caught up</a> with Marcel Bootsman to talk about his walking journey to Berlin. Ironically, the interview occurs as they&#8217;re walking around.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">.<a href=\"https://twitter.com/mbootsman?ref_src=twsrc%5Etfw\">@mbootsman</a> just finished his 718km walk to <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a>, so we thought it would be fun to do a <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f4ac.png\" alt=\"💬\" class=\"wp-smiley\" /> and <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f6b6-1f3fc.png\" alt=\"🚶🏼\" class=\"wp-smiley\" /> about his <a href=\"https://twitter.com/hashtag/walktoWCEU?src=hash&ref_src=twsrc%5Etfw\">#walktoWCEU</a> project. <a href=\"https://t.co/5qSlVZYuiv\">pic.twitter.com/5qSlVZYuiv</a></p>
<p>&mdash; Torque (@TheTorqueMag) <a href=\"https://twitter.com/TheTorqueMag/status/1141715724685185024?ref_src=twsrc%5Etfw\">June 20, 2019</a></p></blockquote>
<p></p>
<p>That&#8217;s it for issue twenty-seven. If you recently discovered a cool resource or post related to WordPress, please share it with us in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Jun 2019 20:55:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: BuddyPress 5.0 to Introduce BP REST API, First Beta Due Mid-August\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91063\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://wptavern.com/buddypress-5-0-to-introduce-bp-rest-api-first-beta-due-mid-august\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3010:\"<p>BuddyPress 5.0 is on track to introduce a new BP REST API, which has been in <a href=\"https://wptavern.com/buddypress-rest-api-feature-plugin-now-in-development\" rel=\"noopener noreferrer\" target=\"_blank\">development as a feature plugin</a> on <a href=\"https://github.com/buddypress/BP-REST\" rel=\"noopener noreferrer\" target=\"_blank\">GitHub</a> since 2016. Contributors plan to merge the API with 14 endpoints for popular components like activity updates, groups, members, private messages, and extended profile fields. Another eight endpoints for blogs, friends, and other features, are planned to ship in BuddyPress 6.0.0.</p>
<p>The first major use of the BP REST API inside BuddyPress is a <a href=\"https://buddypress.trac.wordpress.org/changeset/12405\" rel=\"noopener noreferrer\" target=\"_blank\">new group management interface</a> that enables administrators to quickly search for specific members to promote, demote, ban, or remove. BuddyPress contributor Mathieu Viet shared a demo of what users can expect from the new interface on both the frontend and the backend.</p>
<p><div class=\"wp-video\"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<a href=\"https://wptavern.com/wp-content/uploads/2019/06/5zJCxp2ARb.mp4\">https://wptavern.com/wp-content/uploads/2019/06/5zJCxp2ARb.mp4</a></div></p>
<p>Contributors are still discussing how to include the BP REST API into the BuddyPress plugin package, whether they should continue maintaining it on GitHub until all the endpoints are finished and include it during the BuddyPress plugin’s build process, or merge it into BuddyPress core and use Trac. GitHub is more convenient for development but some expressed concerns about fragmenting the history of the API&#8217;s development on two platforms.</p>
<p>BuddyPress lead developer Boone Gorges said in a recent dev chat that shipping the BP REST API without documentation is a blocker. Contributors are now working on a new documentation site. Since version 5.0.0 will be more of a developer-oriented release, Viet suggested contributors take the opportunity to set up developer.buddypress.org with similar resources as WordPress has on its <a href=\"https://developer.wordpress.org/\" rel=\"noopener noreferrer\" target=\"_blank\">DevHub</a> project. He is looking for feedback on his <a href=\"https://bpdevel.wordpress.com/2019/06/24/bp-devhub/\" rel=\"noopener noreferrer\" target=\"_blank\">proposal</a> for automatically generating the documents from the REST schemas of the API&#8217;s endpoints and further customizing it for integration into the broader developer.buddypress.org site.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/bp-rest-api-reference.png?ssl=1\"><img /></a></p>
<p>BuddyPress contributors are targeting August 15 for releasing 5.0.0 beta 1 and will discuss a date for RC further down the road. Regular dev chat meetings have resumed and are now happening every other Wednesday at 19:00 UTC in the #BuddyPress Slack channel.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Jun 2019 18:52:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: WordPress for iOS 12.6.1 Revamps Stats, Acknowledges Third-Party Libraries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91217\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"https://wptavern.com/wordpress-for-ios-12-6-1-revamps-stats-acknowledges-third-party-libraries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2991:\"<p>WordPress for iOS 12.6.1 is now available in the <a href=\"https://apps.apple.com/us/app/wordpress-1-website-builder/id335703880\">iTunes App Store</a>. The User Interface as well as the backend that powers stats has been revamped and more closely resembles what you see on the Jetpack Stats module. There are now date selectors and individual stats contain more detail. </p>



<div class=\"wp-block-image\"><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/img_2783.png?ssl=1\"><img /></a>Revamped Stats in the WordPress for iOS App</div>



<p>More often than not over the years, when I&#8217;ve tried to view stats, they don&#8217;t load. In 12.6.1, the stats are cached making them not only quicker to load, but they&#8217;re available to view offline as well. </p>



<p>This version also improves the block editor by fixing an issue where the setting to open links in new tabs was always set to off. Also, when users attempt to put invalid content into blocks, there&#8217;s a more descriptive error message. </p>



<p>Those who share photos into WordPress from other apps can now share an unlimited number of photos and if an image fails to upload, the error message will contain more detailed information. </p>



<p>The WordPress for iOS app uses libraries from third-party&#8217;s. To see who these parties are, the team has added an acknowledgments section in the app. You can view this page by browsing to Me &gt; App Settings &gt; About WordPress for iOS &gt; Acknowledgements. Fair warning, this page is quite lengthy. There&#8217;s also a variety of bug fixes in this version as well. </p>



<div class=\"wp-block-image\"><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/img_2784.png?ssl=1\"><img /></a>WordPress for iOS Third-party Library Acknowledgements </div>



<p>One change that I noticed that doesn&#8217;t make sense and that I&#8217;ve been unable to find an explanation for is the labeling change. The app is now labeled on the app store as <strong>WordPress #1 Website Builder</strong>. </p>



<p>I don&#8217;t view the app as a website builder, it&#8217;s more of a website manager. I&#8217;ve asked in the WordPress Mobile Slack channel why this change was made <s>but as of publishing, have not received a response</s>.</p>



<p>WordPress for iOS is free and <a href=\"https://apps.apple.com/us/app/wordpress-1-website-builder/id335703880\">available on iTunes</a>. There&#8217;s also a mobile app for Android devices and a desktop application that be found on the <a href=\"https://apps.wordpress.com/mobile/\">WordPress Mobile Apps</a> site. </p>



<h2>Updated June 28th, 2019</h2>



<p>I received a response from Elisa Budelli, Mobile Developer at Automattic, regarding the label change. </p>



<p>&#8220;The title is describing WordPress as a full product, not only the mobile apps. The switch is based on a recommendation from a SEO specialist, and we will evaluate how it works and revert if we see no impact.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Jun 2019 23:48:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: EditorsKit 1.6 and 1.7 Add Tools for Writers, Drag and Drop Block Export/Import\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90711\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://wptavern.com/editorskit-1-6-and-1-7-add-tools-for-writers-drag-and-drop-block-export-import\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4444:\"<p>Recent <a href=\"https://editorskit.com/\" rel=\"noopener noreferrer\" target=\"_blank\">EditorsKit</a> releases have introduced a set of new tools that some writers may have found missing from Gutenberg. The plugin&#8217;s creator, Jeffrey Carandang, said <a href=\"https://jeffreycarandang.com/editorskit-1-6/\" rel=\"noopener noreferrer\" target=\"_blank\">version 1.6</a> was targeted at improving the writing flow for writers, bloggers, and content creators.</p>
<p>Gutenberg has decent support for copying and pasting Markdown. It will automatically convert links, blockquotes, code snippets, and other formatting into the proper Gutenberg blocks. However, the editor does not offer full support for users who who want to write with Markdown.</p>
<p>EditorsKit 1.6 adds basic markdown capabilities for things like <em>bold</em>, <em>italic</em> and ~strikethrough~ and these can also be used alongside other available editor markdowns and their keyboard shortcuts. These are integrated directly into the RichText editor so you don&#8217;t have to use a dedicated Markdown plugin with a custom block, like <a href=\"https://wordpress.org/plugins/wp-githuber-md/\" rel=\"noopener noreferrer\" target=\"_blank\">WP Githuber MD</a>, or <a href=\"https://jetpack.com/support/markdown/\" rel=\"noopener noreferrer\" target=\"_blank\">Jetpack&#8217;s Markdown module</a>.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">EditorsKit 1.6  is now available <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f680.png\" alt=\"🚀\" class=\"wp-smiley\" /> Comes with Gutenberg Editor Markdown Support, Clear Formatting, Subscript &amp; Superscript Formats, Toggle Title and more. Here\'s a quick preview on how these features were integrated on WordPress Gutenberg block editor <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f3ac.png\" alt=\"🎬\" class=\"wp-smiley\" /> <a href=\"https://t.co/apB4uMjuqg\">pic.twitter.com/apB4uMjuqg</a></p>
<p>&mdash; Jeffrey Carandang (@phpbits) <a href=\"https://twitter.com/phpbits/status/1135895882216329216?ref_src=twsrc%5Etfw\">June 4, 2019</a></p></blockquote>
<p></p>
<p>Version 1.6 introduced an expanded &#8220;clear formatting&#8221; option as a response to requests Carandang received on the plugin&#8217;s <a href=\"https://www.facebook.com/groups/1306393256173179/\" rel=\"noopener noreferrer\" target=\"_blank\">Facebook community</a> and Slack. It clears formatting on specific text, removes formatting on selected text, and clears all paragraph and heading block formatting using the “Clear Block Formatting” option in the block settings. This version also added subscript, superscript, and uppercase text formats, along with a title visibility toggle that removes titles from the frontend on a per-post basis.</p>
<p>While these tools may provide features that some users find to be critically missing from Gutenberg, for many others they simply add to the clutter of the block toolbar and the overall interface. Gutenberg is still sorely in need of a distraction-free UI that will enable users to ditch dedicated writing apps and embrace WordPress as their go-to app for writing.</p>
<p>EditorsKit seems best suited as a playground for features that may or may not have widespread appeal. For example, the most recent <a href=\"https://jeffreycarandang.com/editorskit-1-7/\" rel=\"noopener noreferrer\" target=\"_blank\">1.7 release</a> enables exporting and importing blocks without the requirement of first converting them to reusable blocks. Users can click on the “block settings” icon and export as JSON on a per-block basis. It&#8217;s also possible to select multiple blocks and export them in one file.</p>
<p>Importing blocks back into the editor is as easy as dragging and dropping the .json file. It automatically generates the blocks in an almost magical way an does not require users to navigate to the separate admin dashboard for managing reusable blocks.</p>
<p><a href=\"https://cloudup.com/cLTgwKHjATO\"><img src=\"https://i2.wp.com/cldup.com/WTnhlb_CI9.gif?resize=627%2C353&ssl=1\" alt=\"Import json\" width=\"627\" height=\"353\" /></a></p>
<p>Carandang is working on making the import/export work with media attachments. He is also currently working with the Gutenberg team and other contributors to bring the plugin&#8217;s <a href=\"https://github.com/WordPress/gutenberg/pull/16014\" rel=\"noopener noreferrer\" target=\"_blank\">Text and Highlight colors feature</a> to the core editor.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Jun 2019 22:55:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: WPWeekly Episode 358 – Interview with Dan Maby, Founder of WP&amp;UP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/?p=91203&preview=true&preview_id=91203\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/wpweekly-episode-358-interview-with-dan-maby-founder-of-wpup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2475:\"<p>In this episode, <a href=\"https://www.presstitan.com/\">Malcolm Peralty</a> and I are joined by Dan Maby, Founder of WP&amp;UP. <a href=\"https://wpandup.org/\">WP&amp;UP</a> is a non-profit charity based in England that supports and promotes positive mental health in the WordPress Community.</p>
<p>Dan explains why he started the charity, what he&#8217;s learned and how he manages his own mental health, and how the donation funds are spent. He also shared some startling statistics from a <a href=\"https://wptavern.com/take-the-2019-wpup-mental-health-and-well-being-survey\">recent mental health</a> survey they conducted. The results of this survey are being put into a white paper that will be published later this year.</p>
<p>We finished up the show covering the news of the week. If you&#8217;re interested in supporting WP&amp;UP, please <a href=\"https://wpandup.org/give/\">consider donating</a>.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/matt-mullenwegs-summer-update-at-wordcamp-europe-2019-gutenbergs-progress-and-a-preview-of-upcoming-features\">Matt Mullenweg’s Summer Update at WordCamp Europe 2019: Gutenberg’s Progress and a Preview of Upcoming Features</a></p>
<p><a href=\"https://wptavern.com/free-event-post-status-to-live-stream-publish-online-july-8-9\">Free Event: Post Status to Live Stream Publish Online July 8-9</a></p>
<p><a href=\"https://wptavern.com/contribution-time-sponsored-and-teams-fields-added-to-wordpress-org-user-profiles\">Contribution Time, Sponsored, and Teams Fields Added to WordPress.org User Profiles</a></p>
<p><a href=\"https://wptavern.com/wp-engine-acquires-flywheel\">WP Engine Acquires Flywheel</a></p>
<h2>Transcript:</h2>
<p><a href=\"https://wptavern.com/wp-content/uploads/2019/06/Episode358Transcript.rtf\">Episode358Transcript</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 3rd 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #358:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Jun 2019 20:53:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"WPTavern: The Theme Review Team Releases Two Feature Packages, an Autoloader and a Customize Section Button\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91189\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:117:\"https://wptavern.com/the-theme-review-team-releases-two-feature-packages-an-autoloader-and-a-customize-section-button\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2111:\"<p>Two weeks ago, Justin Tadlock <a href=\"https://wptavern.com/justin-tadlock-proposes-idea-to-solve-common-theme-issues\">published a proposal</a> on behalf of the Theme Review Team to create a set of standardized packages that theme authors can drop-into their themes.  This week, the team has released two feature packages that illustrate what the project is trying to accomplish. </p>



<p>The first is an <a href=\"https://github.com/WPTRT/autoload\">Autoloader</a> that provides the means necessary for theme authors to autoload PHP classes. While <a href=\"https://getcomposer.org/\">Composer</a> is recommended, the team has created a PSR-4 compliant autoloader as an alternative for those not ready for Composer. </p>



<p>&#8220;This is a foundational package that will allow you to use any other  packages that we create,&#8221; Tadlock explained.  &#8220;You could even use it for autoloading your own  theme classes if you choose to do so (assuming they follow the <a href=\"https://www.php-fig.org/psr/psr-4/\">PSR-4 autoloading standard</a> for class and folder names).&#8221;</p>



<p>The second package provides a <a href=\"https://github.com/WPTRT/customize-section-button\">Customizer Section Button</a> that enables theme authors to create a link or button that points to a URL. This feature was originally developed to allow developers a standard way to display a Pro/Upsell link within the customizer. However, the package is generic enough that developers can use it to link to any URL. </p>



<p>Tadlock also provided feedback on a number of ideas that were proposed. Packages up for consideration include, Breadcrumbs, Sliders and Sections, Mobile Navigation, Color Control with Transparency, Appearance > Theme Name Page, and Standard Template Hooks. </p>



<p>To read his feedback and learn more about the project, including how to get involved, read the <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">feature package update</a> and the <a href=\"https://make.wordpress.org/themes/2019/06/07/proposal-theme-feature-repositories/\">initial proposal</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Jun 2019 01:01:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: Gutenberg 6.0 Adds Layout Picker to Columns Block\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91159\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wptavern.com/gutenberg-6-0-adds-layout-picker-to-columns-block\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2325:\"<p><a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\" rel=\"noopener noreferrer\" target=\"_blank\">Gutenberg 6.0</a> was released today with a major update to the Columns block. Users can now select from a set of pre-defined layouts for their columns, with additional features that address many long-standing complaints regarding the block&#8217;s usability.</p>
<p>Although many plugins are already doing more advanced things with columns and grid layouts, WordPress core&#8217;s current implementation of the Columns block is so confusing that it is barely usable. It has a sliding control for selecting the number of columns but it is difficult to see the column boundaries. </p>
<p>Gutenberg 6.0 gives users the ability to select from multiple pre-defined column options, which include some commonly-requested layouts with variable widths. Users can also elect to skip the layouts and start from scratch. Below is a video demo Gutenberg phase 2 lead Riad Benguella shared in the release post:</p>
<p><div class=\"wp-video\"><a href=\"https://wptavern.com/wp-content/uploads/2019/06/12-columns.mp4\">https://wptavern.com/wp-content/uploads/2019/06/12-columns.mp4</a></div></p>
<p>The column settings also include a sliding percentage width control, so users can further customize it, whether starting from a template or from scratch.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-26-at-1.07.16-PM.png?ssl=1\"><img /></a></p>
<p>In adding pre-defined layouts to columns, the Gutenberg team <a href=\"https://github.com/WordPress/gutenberg/pull/16129\" rel=\"noopener noreferrer\" target=\"_blank\">enhanced the InnerBlocks component</a>, allowing developers to extend it to create their own sets of template options to appear upon inserting a block. The Columns block serves as an example implementation of this.</p>
<p>This release also incorporates more than a dozen smaller enhancements and fixes, including <a href=\"https://github.com/WordPress/gutenberg/pull/16020\" rel=\"noopener noreferrer\" target=\"_blank\">snackbar notice support for the widgets screen</a>. Check out the <a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\" rel=\"noopener noreferrer\" target=\"_blank\">changelog</a> for a full list of changes.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 26 Jun 2019 21:45:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:122:\"WPTavern: State of CSS 2019 Survey Results: Top Frameworks Rank Low in Satisfaction, JavaScript Proficiency is on the Rise\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91037\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"https://wptavern.com/state-of-css-survey-2019-results-top-frameworks-rank-low-in-satisfaction-javascript-proficiency-is-on-the-rise\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3833:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-21-at-4.31.09-PM.png?ssl=1\"><img /></a></p>
<p>The first ever <a href=\"https://2019.stateofcss.com/\" rel=\"noopener noreferrer\" target=\"_blank\">State of CSS</a> survey results have been published. The data includes responses from more than 11,000 developers in 135 countries. Respondents identified themselves as male (84.71%), female (9.9%), non-binary/third gender (0.86%), and &#8220;prefer not to say&#8221; (2.62%).</p>
<p>Sacha Greif and Raphaël Benitte, creators of the survey, said it&#8217;s skewed towards early adopters, since the sample size is a fairly small selection of the overall CSS developer community. Greif and Benitte also created the State of JS survey, which is where 31.5% of respondents heard about the CSS survey, so the data is also slanted towards the “back of the front-end,” developers who use JavaScript in their front-end work. They concluded that this data is a good preview of where the mainstream side of the ecosystem will be a few years from now. </p>
<p>The majority of respondents indicated that they are fairly confident about their <a href=\"https://2019.stateofcss.com/demographics/backend-proficiency\" rel=\"noopener noreferrer\" target=\"_blank\">back-end proficiency</a>, with 62.49% identifying themselves as possessing intermediate or advanced backend skills. This trend sets the bar higher for developers who are looking to present a competitive skill-set in the CSS workforce.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-21-at-5.10.10-PM.png?ssl=1\"><img /></a></p>
<p>The results seem clearly bent towards the JavaScript-proficient segment of CSS developers, with a whopping 80.54% rating their <a href=\"https://2019.stateofcss.com/demographics/javascript-proficiency\" rel=\"noopener noreferrer\" target=\"_blank\">JavaScript proficiency</a> at Intermediate to Expert level.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-25-at-8.24.13-PM.png?ssl=1\"><img /></a></p>
<p>The summary includes a highly detailed look at different CSS-related technologies, such as preprocessors, methodologies, frameworks, and CSS-in-JS, with differently colored segments representing whether developers have favorable or negative opinions on each. </p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-25-at-8.33.12-PM.png?ssl=1\"><img /></a> </p>
<p>The results contain data visualizations showing which CSS features and technologies developers know about and/or have used in their work. Flexbox (94.4%) and Grid (54.4%) are among the most widely used layout tools. The frameworks section revealed some surprising results, with a few of the lesser-known frameworks, like Tailwind, Bulma, PureCSS, and Tachyon ranking highest in interest and satisfaction. The most well-known frameworks, Bootstrap and Foundation, fall at the bottom of the satisfaction scale.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-25-at-8.43.58-PM.png?ssl=1\"><img /></a></p>
<p>These results are fairly representative of early adopters of new technologies in the CSS ecosystem, covering features and frameworks that are not yet mainstream. Greif and Benitte predict that even though CSS seems to be evolving slowly, mastering the newer technologies will become more important for developers who want to remain competitive. </p>
<p>For a more detailed look at other areas, such as typography, interactions, animations, and even what pseudo CSS selectors and form-related selectors developers use in their work, check out the full range of results at <a href=\"https://2019.stateofcss.com/\" rel=\"noopener noreferrer\" target=\"_blank\">2019.stateofcss.com</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 26 Jun 2019 14:05:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"HeroPress: How The WordPress Community Helped Me Face My Fears And Do It Anyway\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2898\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:210:\"https://heropress.com/essays/how-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway/#utm_source=rss&utm_medium=rss&utm_campaign=how-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14209:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/062619-min-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Be ruthless about self care.\" /><h3>Your comfort zone is a muscle. If you don’t stretch it, it will shrink.</h3>
<p>It still feels unreal. Two days ago, I was standing on a stage, sharing my expertise. And not just any stage. One of the stages of WordCamp Europe 2019 in Berlin. A conference with over 3200 registrants, over 2700 attendees. A conference room with a capacity of 1100, 60-70% full. And lots of positive feedback.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/yvette-sonneveld-wceu.jpg\"><img /></a></p>
<h3>Never judge by appearances</h3>
<p>Getting to this point hasn’t been a walk in the park. Not even remotely. Had you asked me about something like this five years ago, I would have smirked. Statistically, I am much more likely to be depressed, chronically anxious or abusing substances. You see, I have been a victim of <a href=\"https://www.medicinenet.com/bullying/article.htm#what_are_the_effects_of_bullying_what_are_the_effects_of_hazing\">(relational) bullying</a> several times during my elementary school years. I changed schools because of it, yet it happened again.</p>
<p>Bear with me here, this is not going to be a “I feel so sorry for myself” sob story. There is lots of hope, encouragement and empowerment in this story. Yes, I have struggled with feelings of insecurity and feelings of “not being worthwhile”. And yes, every time I think I have finally dealt with it, it does pop up again in another shape or form. But every single time, I have been able to turn it around into an opportunity to grow. I may still depend a bit more on validation than average. But people who know me, will confirm that I am known to be one to encourage others.</p>
<h3>A little bit of context</h3>
<p>I won’t wear you out with the whole back story. Instead, let me take you back about 5 years. Me, my husband, and my two kids had been living in the Caribbean for a number of years. Unfortunately, I had hit another rough patch. I had been working with a wonderful local psychologist, but I was not getting the results I hoped for. And then it hit me: I would not be growing without intentionally seeking out opportunities to grow. So I decided to send myself out on an experiment. And, thankfully we were able to afford an experiment like that.</p>
<h3>Being intentional about personal development</h3>
<p>One of the goals I set, was to be able to present myself as a digital marketing expert more comfortably. And I felt that it would be easier to do this outside my local area since I was running a pattern of playing small there. So I purchased a ticket to WordCamp Miami (a short flight away). As I started to freak out about what I had done, an email came in. The organization was looking for volunteers. Perfect timing. That would help me focus on helping others rather than feeling lost and not knowing whom to talk to. Or getting all hyper from butterflying around.</p>
<p>This turned out to be a great decision. I had never encountered a community more inviting and inclusive. I had a blast during the weekend. And even got invited over for a home-cooked dinner by one of my co-volunteers. Some first lasting friendships were born that weekend.</p>
<p>Having this first volunteer experience under my belt landed me several volunteer gigs in the US over the following years. Not only for WordCamps, but also for a much more expensive internet marketing conferences and coaching programs.</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/mynams-2015.jpg\"><img /></a>One of the events I got to volunteer at, was MyNAMS 2015. I was first timer, volunteer and (assistant) trainer at the same time.
<h3>Starting all over again</h3>
<p>Then, three years ago, we moved back to The Netherlands, and I had no professional network in my home country at all. So, once our family had found a new routine, I signed up as a volunteer for WordCamp Europe in Paris (2017). That made me stretch far out of my comfort zone since about 2000 people would attend, and I did not know one single soul. Signing up as a volunteer was a no-brainer already by that time. To help myself get over some anxiety about the number of people attending, I decided to sign up for contributors day for the first time. After all, “only” some 300 people would attend that event.</p>
<p>The friendly people at the marketing team adopted me right away and gave me something useful to do. I teamed up with another volunteer to set up several Trello boards to manage the many ongoing projects. Over the weekend I got connected to more warm, welcoming and encouraging people than I could ever imagine. Some of them noticed that I had a way of expressing myself that could point to a talent for speaking. They kept encouraging me to the point that I submitted my very first talk proposal. Looking back, I never really expected to be picked. You should have seen my face when I received the e-mail stating I had been selected&#8230;</p>
<h3>Another leap of faith</h3>
<p>So two months later, I was standing in front of some 50 people. At WordCamp Nijmegen, I shared my story about growing my self-confidence to a much healthier level by volunteering during WordCamps and other events. You can view the recording on <a href=\"https://wordpress.tv/2017/10/14/yvette-sonneveld-voluntourism-how-being-a-wordcamp-volunteer-gets-you-places/\">WordPress.tv</a>. I received some great feedback. This gave me the confidence to apply for the next WordCamp, this time with a topic within my field of expertise: How to create buyer persona.</p>
<p>Over the course of 2 years, one opportunity led to another: First, I became part of the organizing team of WordCamp Utrecht and helped organize that event twice. Then, I became a team rep for the #MakeWordPress marketing team. Next, I got to lead a workshop at WordCamp Europe 2018. And as a result of all of this, I landed several freelance gigs, training virtual assistants and writing copy for a renowned WordPress agency, Level Level. Ultimately, by making myself stretch my comfort zone a bit further out every single time, I ended up landing my dream job. I’m now in charge of marketing for Level Level.</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/WCEU2018.jpg\"><img /></a>Contributing to WordPress will help you make friends from all over the world. I warmly recommend it!
<h3>Lessons learned along the way</h3>
<p>Do I still have my moments of not feeling enough? Totally. But let me share some of the most valuable lessons I learned along the way.</p>
<h4>People who were never bullied have the same insecurities</h4>
<p>Ha, you didn’t see that one coming, right? And until you are ever ready to open up about your feelings of insecurity, others will probably not feel safe sharing their feelings about it, either. Because being vulnerable IS scary. And people may abuse it. But it can be amazingly empowering, too. Blaming the bullying and staying in my ever-shrinking comfort zone would probably have been easier, but I’m so happy I ended up discovering that it turned out I was telling myself a lie.</p>
<h4>Your comfort zone is a muscle. It is made to stretch.</h4>
<p>This has become one of my pet peeves. Work your comfort zone like a muscle. If you don’t, it will shrink right back. You’ll keep playing small. Stretching it will be painful at first. But imagine that feeling of victory, that intense satisfaction when you look back and notice how much you have grown. Needless to say, it takes quite a bit of energy. You will be exhausted at times, and your comfort zone muscles will be sore. It’s the circle of life, after all. You will survive and grow stronger every day, which is exactly what I want for you.</p>
<h3>Find your kind of crazy</h3>
<p>We WordPress people, as unique as we all are, have lots in common, too. When helping my son through a rough patch several years ago, I did a lot of online research. I took a deep dive into everything from ADD to giftedness, and from visual learning to being highly sensitive. The “symptoms” of all of these are very much alike. And the biggest lesson: if you’re able to focus for a long time on something that you really enjoy, it’s not ADD.  You may recognize some of these “symptoms”:</p>
<ul>
<li>not being able to sit still;</li>
<li>easily distracted when working on routine matters;</li>
<li>being able to hyperfocus when working on something that intrigues you;</li>
<li>having a wide variety of interests;</li>
<li>tend to get into power struggles with authoritative personalities;</li>
<li>highly creative;</li>
<li>mastering new skills by understanding and applying a concept rather than mastering it step by step (Once you know the concept of addition in math, for instance, it doesn’t matter whether you add 2+4 or 19574+274503. This in contrast to others who need to start with 1 digit numbers, then to 2 digit numbers etc).</li>
</ul>
<p>(see, <a href=\"https://www.sengifted.org/post/adhd-and-children-who-are-gifted\">https://www.sengifted.org/post/adhd-and-children-who-are-gifted</a> and <a href=\"https://www.davidsongifted.org/Search-Database/entry/A10226\">https://www.davidsongifted.org/Search-Database/entry/A10226</a> if you’d like to learn more about this.)</p>
<p>Over the past two years, I had lots of conversations with community members, and have learned along the way that many recognize these. I think this is one of the reasons we feel so connected. But whether this sounds like you, or not at all…. I strongly recommend you to find and connect to a group of people that you resonate with and who love you for who YOU are. Encourage each other.</p>
<h4>Be ruthless about self-care</h4>
<p>I can see a huge difference in how I feel, both physically and mentally, depending on how well I take care of myself. Purely in simple things like eating lots of fruits and veggies. Drinking no-sugar drinks like herbal infusions and water. Getting enough sleep. Being out in nature. Exercising regularly. Hanging out with friends and family instead of working all the time. This by itself won’t get you out of a depression, but I am confident it will help improve things. It helps me from getting burned out, for sure.</p>
<h3>If you’re employing one of us</h3>
<p>You may be reading this and leading a team of WordPress people. And you may, or may not recognize yourself in parts of my story. Either way, I may have some valuable tips for you, too.</p>
<h4>We’re precious. We’re valuable. And, we need more validation than average</h4>
<p>We may not always notice that we’re burning the midnight oil. We may need you, or our co-workers to notice. We’re sprinters, not marathon runners. So we’ll have bouts of brilliance, and bouts where nothing may seem to come out of our hands. Know that. Appreciate that. And help us know that it’s ok that we’re wired like that. We may need that wee bit more of validation, of encouragement. We need to know you believe in us and that we’re valuable. And we may need a hug every once in a while.</p>
<p>Disclaimer</p>
<p>I’m not a psychologist. I’m just sharing what I what I learned while trying to turn my life around. Also, the highs and the lows keep coming and going. Over the past five years, though, the trend has been upwards. And getting through my lows has become easier as I have become more confident about my ability to get through.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: How The WordPress Community Helped Me Face My Fears And Do It Anyway\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=How%20The%20WordPress%20Community%20Helped%20Me%20Face%20My%20Fears%20And%20Do%20It%20Anyway&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fhow-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: How The WordPress Community Helped Me Face My Fears And Do It Anyway\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fhow-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fhow-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway%2F&title=How+The+WordPress+Community+Helped+Me+Face+My+Fears+And+Do+It+Anyway\" rel=\"nofollow\" target=\"_blank\" title=\"Share: How The WordPress Community Helped Me Face My Fears And Do It Anyway\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/how-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway/&media=https://heropress.com/wp-content/uploads/2020/06/062619-min-150x150.jpg&description=How The WordPress Community Helped Me Face My Fears And Do It Anyway\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: How The WordPress Community Helped Me Face My Fears And Do It Anyway\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/how-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway/\" title=\"How The WordPress Community Helped Me Face My Fears And Do It Anyway\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/how-the-wordpress-community-helped-me-face-my-fears-and-do-it-anyway/\">How The WordPress Community Helped Me Face My Fears And Do It Anyway</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 26 Jun 2019 00:00:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Yvette Sonneveld\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"WPTavern: WP Engine Acquires Flywheel\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91142\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wptavern.com/wp-engine-acquires-flywheel\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5552:\"<p>In a move that caught <a href=\"https://twitter.com/biancawelds/status/1143239752554037256\">some</a> <a href=\"https://twitter.com/jnovakfl/status/1143239160167370752\">people</a> by surprise, WP Engine <a href=\"https://wpengine.com/blog/wp-engine-to-acquire-flywheel/\">has announced</a> that it has reached a definitive agreement to acquire Managed WordPress host, <a href=\"https://getflywheel.com/\">Flywheel</a>. </p>



<p>While financial terms of the deal were not disclosed, Heather Brunner, WP Engine&#8217;s CEO <a href=\"https://techcrunch.com/2019/06/24/wordpress-management-site-wp-engine-acquires-flywheel-as-it-moves-to-a-1b-valuation-and-ipo/\">confirmed to TechCrunch</a> that the company needed to raise a small round of funding to finance the deal. </p>



<p>Dusty Davidson, Tony Noecker, and Rick Knudtson founded Flywheel in 2012 in Omaha, Nebraska. In 2012, there were already a handful of players in the Managed WordPress Hosting space but Flywheel was able to carve out a niche by focusing on Designers and Agencies. </p>



<p>In 2016, Flywheel became one of the few hosting companies added to the <a href=\"https://wordpress.org/hosting/\">WordPress.org recommended hosting</a> page. However, their listing was removed a few months later without an explanation. </p>



<p>Also in 2016, <a href=\"https://wptavern.com/flywheel-acquires-wordpress-local-development-tool-pressmatic\">Flywheel acquired Pressmatic</a>, a local WordPress development application for OS X from Clay Griffiths and rebranded it to Local by Flywheel. Representatives from both companies have stated that there are no plans to merge <a href=\"https://wptavern.com/wp-engine-launches-devkit-open-beta\">WP Engine Devkit</a> with Local by Flywheel.</p>



<p>According to a frequently asked questions document, nothing much is changing in the foreseeable future for Flywheel customers. </p>



<blockquote class=\"wp-block-quote\"><p>Business will continue as usual! There will be no immediate changes to the Flywheel platform, plans, or experience. We’ll be spending the coming weeks and months on strategic innovation and integration planning, and are super excited to figure out how we can leverage all of our collective strengths, products, and brand assets in the best possible way. </p><cite><a href=\"https://getflywheel.com/flywheel-is-joining-wpengine/\">Acquisition FAQ</a></cite></blockquote>



<p>Flywheel has generated a loyal following of happy customers over the years and some of them took to Twitter to express their concerns regarding Monday&#8217;s announcement. </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Please, please, please don\'t have this be the beginning of the end!  Flywheel rocks and I hope you continue to do so!  I\'ve been down this acquisition road before (remember when Host Gator got bought?) and it usually doesn\'t end well.</p>&mdash; samsonmedia (@samsonmedia) <a href=\"https://twitter.com/samsonmedia/status/1143239375280594944?ref_src=twsrc%5Etfw\">June 24, 2019</a></blockquote>
</div>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">I’m sure you’ll are very excited and feel this is nothing but a positive thing but as someone who has found flywheel to be a saving grace in a sea of disappointment, I am very concerned to lose the only hosting service I ever loved. <br /><br />Especially to one i don’t&#8230; <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f615.png\" alt=\"😕\" class=\"wp-smiley\" /></p>&mdash; Jay Mutzafi (@JayMutzafi) <a href=\"https://twitter.com/JayMutzafi/status/1143239802382237696?ref_src=twsrc%5Etfw\">June 24, 2019</a></blockquote>
</div>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">There\'s a reason that I chose Flywheel over WP Engine years ago. My heart sank when I read your announcement. <br /><br />These acquisitions always end poorly for customers at some point. It will be fine for awhile, then things will change. <br /><br />Time to look for my next hosting platform.</p>&mdash; Larry Cornett (@cornett) <a href=\"https://twitter.com/cornett/status/1143247795266080768?ref_src=twsrc%5Etfw\">June 24, 2019</a></blockquote>
</div>



<p>Seeing these types of responses from customers is a testament to the level of service Flywheel provides. Many of them explained why they chose to host their clients with Flywheel over WP Engine. </p>



<p>Both companies have vowed to keep customers in the loop of any potential changes to plans, services, or products. While each company will operate independently as things are sorted out, it will be interesting to see how the two companies are integrated over time and how customers respond. </p>



<p>If you&#8217;re a Flywheel customer, please let us know what you think about the acquisition in the comments below. </p>



<p>To learn more about the deal, check out the following links.</p>



<ul><li><a href=\"https://getflywheel.com/flywheel-is-joining-wpengine/\">Flywheel is joining WP Engine!</a></li><li><a href=\"https://wpengine.com/blog/wp-engine-to-acquire-flywheel/\">WP Engine to Acquire Flywheel</a></li><li><a href=\"https://getflywheel.com/layout/big-news-flywheel-and-wpengine/\">Big news: Flywheel is joining WP Engine! From Dusty Davidson</a></li><li><a href=\"https://wpengine.com/blog/realizing-vision-to-build-most-relied-upon-dxp-for-wordpress/\">Realizing Our Vision To Build the Most Relied Upon DXP for WordPress from Heather Brunner</a></li></ul>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 25 Jun 2019 22:42:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: WordPress AMP Plugin Version 1.2 Introduces Gutenberg-powered AMP Stories Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90892\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"https://wptavern.com/wordpress-amp-plugin-version-1-2-introduces-gutenberg-powered-amp-stories-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7959:\"<p>Google released <a href=\"https://amp-wp.org/amp-plugin-version-1-2-release/\" rel=\"noopener noreferrer\" target=\"_blank\">version 1.2</a> of its official AMP plugin for WordPress ahead of WordCamp Europe in Berlin. This release introduces a new AMP Stories editor that is powered by Gutenberg. </p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/AMP-stories-editor.png?ssl=1\"><img /></a></p>
<p>AMP Stories are separate from the capabilities that enable AMP for the rest of the website, and they can be used together or independently. The Stories feature has its own post type that uses the block editor and comes with custom blocks that enable the following: </p>
<ul>
<li>Multiple story pages can be added in a horizontal editing interface</li>
<li>Page reordering with drag and drop</li>
<li>Text block (the default instead of Paragraph) allows for text to automatically resize to fit the container</li>
<li>40 font families for styling the Text block</li>
<li>Blocks can be dragged and rotated anywhere on a page, with ability to move in front of or behind other blocks</li>
<li>Select from blank pages or pre-made page templates</li>
<li>Text block can have varying background color opacity</li>
<li>Blocks on a given page are listed in a persistent table of contents (with drag and drop)</li>
<li>Story pages can have background video or image (with focal point)</li>
<li>Pages can have a solid background color or gradient, including opacity for overlaying background image/video</li>
</ul>
<p>The stories created in the editor can also be embedded in other posts and pages using the regular embed block or the Latest Stories block. </p>
<p>Stories are a mobile-focused format that have become increasingly popular with social networking apps like Snapchat, Instagram, and Facebook. Stories on these platforms are usually created as ephemeral bits of content that are not easy to embed without using a third-party application. Google is marketing AMP stories as &#8220;visual storytelling for the open web.&#8221; </p>
<p>&#8220;I like to position it as Web Stories,&#8221; Google Developer Relations Program Manager <a href=\"https://twitter.com/tweetythierry\" rel=\"noopener noreferrer\" target=\"_blank\">Thierry Muller</a> said. &#8220;It is powered by AMP, but there are none of the challenges developers might face when making a website AMP compatible. With Web Stories, users are now able to create stories accessible via a simple URL, content that they own and can use open source tools such as the Story editor for WordPress to create stories.&#8221;</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/washpo-amp-stories.jpg?ssl=1\"><img /></a>Muller said the target audience for AMP stories includes publishers, travel bloggers, food bloggers, and anyone who wants to create immersive content. Some well-known publishers, such as <a href=\"https://www.telegraph.co.uk/visual-stories/\" rel=\"noopener noreferrer\" target=\"_blank\">The Telegraph</a>, <a href=\"https://www.washingtonpost.com/pr/wp/2018/02/13/the-washington-post-launches-custom-story-presentation-with-googles-amp-stories/\" rel=\"noopener noreferrer\" target=\"_blank\">Washington Post</a>, and <a href=\"https://edition.cnn.com/ampstories\" rel=\"noopener noreferrer\" target=\"_blank\">CNN</a>, have partnered with Google as early adopters, using AMP stories to cover news and events. The Stories also show up in a carousel in mobile search results.</p>
<p>WordPress users who want to start using the AMP plugin&#8217;s Stories feature will need to have Gutenberg 5.8+ installed, because it requires some of the newer features in the block editor that haven&#8217;t yet be merged into core. </p>
<p>The addition of AMP Stories to the official AMP plugin may make it more appealing to those who have been hesitant to install it simply for the website capabilities. It gives the plugin another entry point with users who are more interested in the visual storytelling aspect. </p>
<p>In a recent <a href=\"https://adactio.com/journal/15357\" rel=\"noopener noreferrer\" target=\"_blank\">post</a> examining the web standards community&#8217;s confusion surrounding how Google Chrome seemed to be unilaterally implementing a new element called toast, Jeremy Keith made a good observation regarding developers&#8217; skepticism about AMP.</p>
<p>&#8220;I certainly don’t think this is a good look for Google given the debacle of AMP’s &#8216;my way or the highway&#8217; rollout,&#8221; Keith said. &#8220;I know that’s a completely different team, but the external perception of Google amongst developers has been damaged by the AMP project’s anti-competitive abuse of Google’s power in search.&#8221; Google Web Advocate Das Surma lent credibility to Keith&#8217;s take on the matter, <a href=\"https://twitter.com/DasSurma/status/1141627540282494977\" rel=\"noopener noreferrer\" target=\"_blank\">saying</a> it offered &#8220;a pretty accurate representation of our intentions, but also of the problems and mistakes we made.&#8221;</p>
<p>It&#8217;s not easy to quantitatively measure how developers&#8217; anti-AMP sentiment has affected the adoption of Google&#8217;s official AMP plugin for WordPress, especially given the rocky start it had in the official plugin directory. XWP and Google engineers had  a lot to overcome after <a href=\"https://wptavern.com/amp-for-wordpress-plugin-to-introduce-user-friendly-theme-support-settings-in-upcoming-1-0-release\" rel=\"noopener noreferrer\" target=\"_blank\">taking over the plugin&#8217;s development</a> from Automattic when <a href=\"https://wptavern.com/amp-project-turns-2-automattic-partners-with-google-to-improve-wordpress-plugin\" rel=\"noopener noreferrer\" target=\"_blank\">users began to wonder if it had been abandoned</a>. </p>
<p>The first version of the AMP plugin was released in October 2015 and initially had 400 active installs. Over the past four years, that number has grown to more than 400,000 active installs. The plugin has had a 33% increase in its user base from December 1, 2018 (300,000+) to today (400,00+). This is likely due to some of the more user-friendly improvements that have been introduced in the past six months. Google and XWP&#8217;s involvement seems to have successfully dug the plugin out of its previous trend towards negative ratings from users who couldn&#8217;t get any support. </p>
<p>Nevertheless, Google is still struggling with the challenge to convince WordPress users that the AMP plugin is a must-have addition to their sites. Convincing the wider WordPress ecosystem to build <a href=\"https://amp-wp.org/ecosystem/\" rel=\"noopener noreferrer\" target=\"_blank\">AMP-ready plugins and themes</a> that provide the compatibility for functionality that users&#8217; websites rely on in order to be anything more than a basic blog. Adding AMP stories to the plugin may help to get more WordPress users on board to further explore AMPing up their websites.</p>
<p>Approximately 410/500 issues and pull requests in version 1.2 were dedicated to the new AMP Stories feature. This release introduces the notion of &#8220;AMP experiences,&#8221; a fancy industry buzz word that divides the Stories and Website features into separate functionality. The website framework improvements include a renaming of the template modes: Native, Paired, and Classic are now Standard, Transitional, and Reader, a strategic and notably less clear way of identifying the modes that seems intended to drive users towards adopting the native AMP approach. The editor has also been updated to display a warning when a featured image is too small for Google Search&#8217;s requirements, as well as provide better block-level warnings and improvements to validation requests.</p>
<p>Check out the <a href=\"https://github.com/ampproject/amp-wp/releases/tag/1.2.0\" rel=\"noopener noreferrer\" target=\"_blank\">v1.2 changelog</a> for a full list of everything that is new in this release.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 25 Jun 2019 19:06:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WordCamp Europe 2020 to be Held in Porto, June 4-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91060\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wptavern.com/wordcamp-europe-2020-to-be-held-in-porto-june-4-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12251:\"<p>Another successful edition of WordCamp Europe concluded this weekend in Berlin. The event was the largest WordCamp in history, with 3,260 tickets sold and 2,734 attendees present on the ground. WCEU sold 800 more tickets than the previous year in Belgrade. Contributor Day gathered 611 attendees into 25 teams, and approximately 28% of them (169 attendees) were new WordPress contributors.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Smiling faces of awesome people at Contributor Day <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a> 2019  <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f601.png\" alt=\"😁\" class=\"wp-smiley\" />We had 25 teams, and 611 signed up to give back to <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> today, of which 169 said they were new contributors. Thank you! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f499.png\" alt=\"💙\" class=\"wp-smiley\" /> <a href=\"https://t.co/P7W7Ocl0lw\">pic.twitter.com/P7W7Ocl0lw</a></p>
<p>&mdash; WordCamp Europe (@WCEurope) <a href=\"https://twitter.com/WCEurope/status/1141729922588692480?ref_src=twsrc%5Etfw\">June 20, 2019</a></p></blockquote>
<p></p>
<p>To cap off the conference, attendees enjoyed a lively celebration Saturday night, donning vintage outfits for an 80&#8217;s themed after party at the venue. The party included a controversial show that some attendees found <a href=\"https://twitter.com/zodiac1978/status/1142515008309538816\" rel=\"noopener noreferrer\" target=\"_blank\">offensive</a> and <a href=\"https://twitter.com/schlessera/status/1143182472303325185\" rel=\"noopener noreferrer\" target=\"_blank\">unwelcoming</a>. WCEU organizers have addressed this issue in a <a href=\"https://2019.europe.wordcamp.org/2019/06/24/after-party-apology/\" rel=\"noopener noreferrer\" target=\"_blank\">post</a>. According to WordPress community organizer <a href=\"https://twitter.com/andmiddleton/status/1142699425871142912\" rel=\"noopener noreferrer\" target=\"_blank\">Andrea Middleton</a>, &#8220;that part of the show did not match the expectations that they had set with the venue, and was a disappointing surprise.&#8221;</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">A glimpse of swiss <a href=\"https://twitter.com/hashtag/WordCamp?src=hash&ref_src=twsrc%5Etfw\">#WordCamp</a> \'s organisers in 80ies look for the <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a> after-party yesterday. With <a href=\"https://twitter.com/neverything?ref_src=twsrc%5Etfw\">@neverything</a> and <a href=\"https://twitter.com/andrew_liyanage?ref_src=twsrc%5Etfw\">@andrew_liyanage</a> <a href=\"https://twitter.com/wp_switzerland?ref_src=twsrc%5Etfw\">@wp_switzerland</a> upcoming <a href=\"https://twitter.com/hashtag/wczrh?src=hash&ref_src=twsrc%5Etfw\">#wczrh</a> and <a href=\"https://twitter.com/wpgva?ref_src=twsrc%5Etfw\">@wpgva</a> <a href=\"https://t.co/yzBgxndopK\">pic.twitter.com/yzBgxndopK</a></p>
<p>&mdash; Patricia BT (@PatriciaBT70) <a href=\"https://twitter.com/PatriciaBT70/status/1142737968031047680?ref_src=twsrc%5Etfw\">June 23, 2019</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">For those in the US that are wondering what an sfterparty in Europe looks like.. <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a> <a href=\"https://twitter.com/hashtag/WCUS?src=hash&ref_src=twsrc%5Etfw\">#WCUS</a> <a href=\"https://t.co/BXZpZHyQpt\">pic.twitter.com/BXZpZHyQpt</a></p>
<p>&mdash; Pieter Daalder (@w1zz) <a href=\"https://twitter.com/w1zz/status/1142530170622005249?ref_src=twsrc%5Etfw\">June 22, 2019</a></p></blockquote>
<p></p>
<p>Despite the controversial after party show, the event received mostly positive feedback and many attendees reported that it was &#8220;best WCEU&#8221; they had ever attended.</p>
<p>In addition to breaking records as the largest WordCamp in history, organizers report that the majority of ticket holders (56%) were first time WCEU attendees.  </p>
<p>&#8220;Berlin is an amazing city and by far one of the most popular locations for remote work in Europe,&#8221; 2019 global lead Milan Ivanovic said. &#8220;When we add on top the strong German community, with WordCamps across the country and four monthly WordPress meetups in Berlin alone, it was a no brainer that we would have a sold-out event. We also had an amazing line-up of speakers with 3 tracks and 3 workshops, along with on-time information shared to our attendees.&#8221;</p>
<h3>WordCamp Europe 2020 to be Held in Porto, Portugal</h3>
<p>At the conclusion of the event, organizers announced that next year WCEU is coming to Porto, June 4-6. Porto is Portugal&#8217;s second largest city, known for its beautiful beaches, port wine exports, bridges, vineyards, charming cobblestone streets, and affordability. It also has a vibrant and growing WordPress community. Portugal is home to <a href=\"https://wordpress.tv/2015/07/09/ze-fontainhas-how-wordcamp-europe-came-to-be/\" rel=\"noopener noreferrer\" target=\"_blank\">Zé Fontainhas</a>, one of the original creators of WordCamp Europe. </p>
<p></p>
<p><a href=\"https://profiles.wordpress.org/josefreitas2/\" rel=\"noopener noreferrer\" target=\"_blank\">Jose Freitas</a>, who will be heading up the local team in Portugal, has been working with WordPress since 2008 and has been involved with the community since 2013. He said the Portuguese WordPress community has been working on its application to host WCEU for three years. </p>
<p>&#8220;We are thrilled to have WCEU in Porto next year,&#8221; Freitas said. &#8220;Portugal is indeed a small country but we have a good WordPress community. At Porto we have had a monthly WordPress Meetup since January 2014, without failing a month. WordPress is growing quickly in Portugal and every day we have people joining our community.&#8221; </p>
<p>The greater community is connected on Facebook through the <a href=\"https://www.facebook.com/groups/wpportugal/\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress Portugal</a> group, which has more than 4,400 members.</p>
<p>&#8220;We found that for some people, mostly beginners, it’s difficult to start using the support forums,&#8221; Freitas said. &#8220;So we made a Facebook group and people can ask questions and receive help or feedback related to their projects. Most of the users are people that made their own websites and websites for non profit organizations.&#8221;</p>
<p>Up until now, Portugal has hosted one WordCamp per year, alternating between Porto and Lisbon locations. Following 2020, local organizers plan to host two camps per year, and WC Lisboa is expected to be scheduled for October 2020.</p>
<p>The Porto community had formidable competition in its journey to securing the opportunity to host WCEU 2020, beating out Athens, Granada, Manchester, and Torino. Freitas attributes his team&#8217;s success to its dedication to improving Porto&#8217;s application for the past three years, following a disappointing attempt in 2016.</p>
<p>&#8220;First it was only a dream,&#8221; Freitas said. &#8220;After, it was <em>what if…</em> We applied the first time in 2016 to WCEU 2017. We were in the final decision but the event went to Paris, as we all know. So we started right then the application to 2020.</p>
<p>&#8220;We made it better, stronger, complete with all the new requirements. Each WCEU was getting something new and in each one we added the new thing to our documentation. We made a strict budget, with realistic numbers in all parameters. I think that was important for the people who made the selection.&#8221;</p>
<p>WCEU 2020 sessions will be held in English. Freitas said the majority of Portuguese people have a good understanding of English and most in the WordPress community are fluent in both languages. </p>
<p>The maximum capacity for the venue is 8,000 people. WCEU&#8217;s arrangement for 2020 allows attendance to go up to 4,000, in case the event has another record-breaking year.</p>
<p>&#8220;We have a wonderful venue in the city center and surrounded by a garden and a balcony with amazing views of the river and part of the city,&#8221; Freitas said.</p>
<p>WCEU 2019 local lead Bernhard Kau will be joining the 2020 team as one of the global leads to provide a smooth transition from one year to the next. Attendees can expect some of the successful aspects of the 2019 event to make a return at next year&#8217;s WCEU.</p>
<p>&#8220;The additions of WP Cafe and Wellness at WCEU were a big success and I would love to have more space for them at WordCamp Europe 2020 in Porto,&#8221; Kau said. &#8220;There are also some other ideas helping attendees staying healthy, both physically and mentally.</p>
<p>&#8220;As I have never been to Portugal, I am very excited to visit another country. I have met some members of the Portuguese Community on WordCamps throughout Europe and they are some of the most friendly people you can find.&#8221;</p>
<p>For those who are considering adding WCEU 2020 in Porto to their calendars, Freitas offered a preview of what attendees can expect:</p>
<blockquote><p>Imagine yourself… it is June, 3, 2020. There’s one day to go before WCEU.</p>
<p>You go to the city center to know a little of the city. You walk in small and narrow streets and find that some of those have a history of more that a thousand years. You ask some directions, because you don’t want to use smartphone maps, and people are nice and even offer to take you to the place that is only 500 meters way.</p>
<p>You go to the very old part of the city and realize that it wasn’t changed for many, many years. It was not changed because people didn’t want to and because now it’s a UNESCO World Heritage site.</p>
<p>You sit near the river and look at the bridge designed and build by a student of Eiffel (yep, that Eiffel). The sun has made the Douro river look like silver and you finally get why the Romans gave the name of Porto (port) to the place.</p>
<p>It’s time to lunch some tasty and delightful Portuguese food. Don’t skip the dessert. To burn some calories you’ll go to the check the venue.</p>
<p>You pass the old Reitoria building (the place were the university principal used to work) &#8211; Porto has the biggest Portuguese university &#8211; and see a garden with trees, flowers and even some peacocks.</p>
<p>You enter there and find the way to the venue: it looks like the top of a spaceship, like the ones in the movies. There’s a banner: &#8220;WordCamp Europe 2020.&#8221;</p>
<p>Now you feel that you’re only a few hours away from the moment you have been waiting for. But, let’s go because you have to see other parts of the city.</p>
<p>The next day, you join hundreds of WordPress people who are helping the community in Contributor Day. There is a lot to do before the two conference days and workshops, before visiting the sponsors area, before meeting some of the nice folks that you didn’t see since last year, before making new friends.</p>
<p>After all, it’s possible to make new friends in an event of thousands of people.</p></blockquote>
<p>WordCamp Europe is made possible every year by a massive team of organizers and volunteers who help keep costs low, in addition to sponsors. </p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">The organising team would like to thank all of the volunteers for contributing to an amazing <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a>! <a href=\"https://t.co/1um7usNZqT\">pic.twitter.com/1um7usNZqT</a></p>
<p>&mdash; WordCamp Europe (@WCEurope) <a href=\"https://twitter.com/WCEurope/status/1142455860683333632?ref_src=twsrc%5Etfw\">June 22, 2019</a></p></blockquote>
<p></p>
<p>The 2020 team put out the <a href=\"https://2020.europe.wordcamp.org/\" rel=\"noopener noreferrer\" target=\"_blank\">call for organizers</a> after announcing the host city. In the first 24 hours, the team has already received 30 applications. The deadline to apply is July 15, 2019. Calls for sponsors, volunteers, and speakers will come after organizers are selected, as the year-round work of organizing WCEU continues again for 2020.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 24 Jun 2019 19:20:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: Contribution Time, Sponsored, and Teams Fields Added to WordPress.org User Profiles\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91027\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"https://wptavern.com/contribution-time-sponsored-and-teams-fields-added-to-wordpress-org-user-profiles\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2544:\"<p>A new section named Contribution <a href=\"https://make.wordpress.org/updates/2019/06/19/updates-to-wordpress-profiles-and-jobs-wordpress-net/\">has been added</a> to WordPress.org user profiles. This section contains fields that enable users to share how much time they contribute to WordPress on a weekly basis, which teams they contribute to, and whether or not those contributions are sponsored. </p>



<div class=\"wp-block-image\"><img />New WordPress.org User Profile Fields</div>



<p>Each field is optional and will only appear if the Hours and Teams fields are filled in. The sponsored tag will only appear next to the Contributions heading if you answer Yes to being sponsored and the other fields are filled in. </p>



<p>Andrea Middleton describes these fields as a step towards a possible version one of the <a href=\"https://make.wordpress.org/updates/2018/11/05/proposal-five-for-the-future-acknowledgement-page/\">Five for the Future program</a> that was published last year. </p>



<p>&#8220;I think it will also help with transparency, and might facilitate how teams set internal expectations for how much time different contributors might have to spend on a project or ongoing task,&#8221; she said. </p>



<p>In addition to the profile fields, the official <a href=\"https://jobs.wordpress.net/\">WordPress Jobs Board</a> has also been updated to include a new <a href=\"https://jobs.wordpress.net/job_category/contributor/\">Contributor position</a>. The goal is to make it easier for companies to find and hire people interested in becoming sponsored contributors. </p>



<p>These changes are the first iteration with plans to enhance them in the future. If you have any suggestions or ideas on improving these fields, you&#8217;re encouraged to <a href=\"https://make.wordpress.org/updates/2019/06/19/updates-to-wordpress-profiles-and-jobs-wordpress-net/\">leave a comment</a>.</p>



<p>One question I have regarding potential additions is whether or not it makes sense to provide a text field where users can name the company that is sponsoring them. This may aid in transparency and avoiding conflicts of interests. </p>



<p>On the other side of the coin, does it make sense for the company&#8217;s name to be public information, or should contributors only share that information with team leads or reps on a 1-on-1 basis? </p>



<p>I feel as though knowing someone&#8217;s contributions are sponsored is only half of the equation. Without knowing who the sponsor is, that information is practically irrelevant. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 22 Jun 2019 01:17:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:125:\"WPTavern: Matt Mullenweg’s Summer Update at WordCamp Europe 2019: Gutenberg’s Progress and a Preview of Upcoming Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=91000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:129:\"https://wptavern.com/matt-mullenwegs-summer-update-at-wordcamp-europe-2019-gutenbergs-progress-and-a-preview-of-upcoming-features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11361:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/matt-wceu-2019.jpg?ssl=1\"><img /></a>image credit: <a href=\"https://www.facebook.com/WCEurope/photos/a.345903435550204/1343533289120542/\">WCEU Photography Team</a></p>
<p>Matt Mullenweg took the stage at WordCamp Europe in Berlin this afternoon to give a summer update on the progress of the block editor. He attributed much of its continued success to the availability of the Gutenberg plugin, which allows for quick iteration and testing. More than 150,000 posts are published per day using the block editor, which Mullenweg said is &#8220;a testament to the long development period&#8221; that gave the team an opportunity to work out bugs and make it usable for a large number of people.</p>
<p>Since its initial release, the block editor has added a host of notable improvements, including block management capabilities, a cover block with nested elements, widgets as blocks, block grouping, and snackbar style notices. </p>
<p>Mullenweg highlighted a few beautiful and innovative examples of Gutenberg in the wild. Two projects from <a href=\"https://humanmade.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Human Made</a> showcase Gutenberg-powered designs (<a href=\"https://www.artefactgroup.com/\" rel=\"noopener noreferrer\" target=\"_blank\">artefactgroup.com</a>) and an AI integration that analyzes a user&#8217;s writing in the editor (<a href=\"https://ingenuity.siemens.com/\" rel=\"noopener noreferrer\" target=\"_blank\">ingenuity.siemens.com</a>.) </p>
<p>Election season is ramping up in the U.S. and Gutenberg-powered sites, like <a href=\"https://hurst4delegate.com/\" rel=\"noopener noreferrer\" target=\"_blank\">hurst4delegate.com</a>, are starting to pop up. Mullenweg noted that 21/24 of the current democratic candidates for President are using WordPress for their sites. <a href=\"https://www.whitehouse.gov/\" rel=\"noopener noreferrer\" target=\"_blank\">Whitehouse.gov</a> also switched from Drupal to WordPress earlier this year. </p>
<p>Mullenweg also gave a quick preview of some of the upcoming Gutenberg features that are currently being developed on GitHub. Most of them are still in the prototype stage. The team is creating a system to install new blocks online, which will tie into the planned block directory. Mullenweg said Blocks could become a new top-level menu item in the WordPress admin, with screens dedicated to block discovery. </p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">\"A block directory is coming that will take over other “top level navigation” and brings a “playfulness” to discovering <a href=\"https://twitter.com/hashtag/Gutenberg?src=hash&ref_src=twsrc%5Etfw\">#Gutenberg</a> blocks.” <a href=\"https://twitter.com/photomatt?ref_src=twsrc%5Etfw\">@photomatt</a> <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a> <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> <a href=\"https://t.co/wsiHcPaVuL\">pic.twitter.com/wsiHcPaVuL</a></p>
<p>&mdash; David Bisset (@dimensionmedia) <a href=\"https://twitter.com/dimensionmedia/status/1142044607800369153?ref_src=twsrc%5Etfw\">June 21, 2019</a></p></blockquote>
<p></p>
<p>He showed demos of the navigation block in progress, a prototype for adding realistic motion to block movement, an experimental footnotes block, and a demo of resizing images with &#8220;snap to grid&#8221; capabilities. Mullenweg said one of the goals with Gutenberg is to &#8220;make it possible to create beautiful experiences, because that’s part of what the web needs to win.” </p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">New footnotes feature being tested in <a href=\"https://twitter.com/hashtag/Gutenberg?src=hash&ref_src=twsrc%5Etfw\">#Gutenberg</a>. <a href=\"https://twitter.com/photomatt?ref_src=twsrc%5Etfw\">@photomatt</a> <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a> <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> <a href=\"https://t.co/b8yhn2X71w\">pic.twitter.com/b8yhn2X71w</a></p>
<p>&mdash; David Bisset (@dimensionmedia) <a href=\"https://twitter.com/dimensionmedia/status/1142045330969640961?ref_src=twsrc%5Etfw\">June 21, 2019</a></p></blockquote>
<p></p>
<p>Mullenweg also gave an update on Gutenberg&#8217;s progress in the mobile apps. He said the new editor is operational but development is slow moving because the mobile engineers essentially have to duplicate all of the work that has been done by hundreds of Gutenberg contributors thus far. </p>
<h3>Q&#038;A Highlights Governance, Core Maintenance, and the Future of WordPress Themes</h3>
<p>The Q&#038;A portion of the session featured a variety of topics, ranging from an aggressive tirade about licensing and Envato, to more relevant inquiries about the future of WordPress themes. While this format of interaction has its shortcomings, it gives community members the opportunity to check on the status of issues where they have a particular interest. </p>
<p>One attendee asked if WordPress.org plans to implement a more democratic structure for decision making. Mullenweg seemed to interpret the question as referencing a system where tens or hundreds of millions of WordPress users would participate in making decisions on features through a vote or some other form of feedback. In contrast, he said WordPress&#8217; current approach is for leadership to try to get a sense for what the most common issues are through polls and public channels and allow those issues to help shape the project&#8217;s roadmap. </p>
<p>Mullenweg shared that one particular issue on his mind right now is the problem of &#8220;how do I make my theme look like the demo?&#8221; He said contributors are experimenting with different types of models for making decisions that move WordPress in the direction to solve these types of problems. </p>
<p>He said that the project&#8217;s decision making is fairly transparent, without a lot of mystery, and that the community has tons of feedback mechanisms. This is a somewhat controversial claim, as <a href=\"https://make.wordpress.org/updates/2019/04/26/5-0-release-retrospective-wrap-up/\" rel=\"noopener noreferrer\" target=\"_blank\">regular project contributors have expressed frustration with the lack of communication</a> surrounding important planning and decisions, such as release dates and project timing, as it pertained to how WordPress 5.0 landed. The community was frustrated by a lack of effective ways to communicate critical issues and complaints to project leadership. As a followup to this specific feedback, Josepha Haden, the new Executive Director of the WordPress project, has been diligent to track and communicate how leadership is working to improve communication.</p>
<p>Another attendee asked if WordPress themes will become obsolete after Gutenberg gains more site-building capabilities. Mullenweg predicted they will always be a part of WordPress but seemed inclined to let the market decide the fate of themes.</p>
<p>“I don’t know,&#8221; he said. &#8220;They are going to change for sure. I don’t think they ever go away.” He said he could see developers offering an array of different designs that could be used as a starting point. Although a WordPress theme has a very specific definition right now (as far as what types of files are included), Mullenweg said he can see that  definition evolving over time. He said he could see themes becoming like a starter template or a library of patterns to choose from, or even a set of complex layouts that could work across different themes. </p>
<p>“I think we’re going to decouple themes a little bit but I don’t know how or what that will look like,” Mullwenweg said. He also noted that a lot of themes right now represent a similar aesthetic, often business minimalist that use white and blue colors. Design trends have the potential to shift dramatically as Gutenberg and themes evolve to allow users more control over how their sites are designed.</p>
<p>It is no secret that the WordPress development community is eager to switch to GitHub or another Git-based infrastructure for core development. Most of the recent feature projects have successfully matured on GitHub, with the majority of work and discussion taking place outside of Trac. One attendee asked about the possibility of moving away from Trac in the near future. Mullenweg said that this year the team that works on WordPress.org is prioritizing changes to the directory, but in the meantime anyone with Python knowledge is welcome to contribute to tweaking Trac for improvements in the interim before WordPress moves to Git-based development.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">I’d love to move off of Trac as much as the next person. In the interim I’m working some cool tools to make life easier using the Elasticsearch cluster I built for it. Let me know if you want to help! <a href=\"https://t.co/E26P66ebmQ\">https://t.co/E26P66ebmQ</a> <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a></p>
<p>&mdash; William Earnhardt (@earnjam) <a href=\"https://twitter.com/earnjam/status/1142057095044444160?ref_src=twsrc%5Etfw\">June 21, 2019</a></p></blockquote>
<p></p>
<p>In response to a question about blockchain technology and WordPress, Mullenweg said he has long been an enthusiast in this area and loves the idea of open source applying to money, as well as having a distributed ledger. </p>
<p>&#8220;But I can’t think of any problem in core WordPress right now that the overhead of a blockchain would really improve,&#8221; he said. &#8220;Everything I could think of right now would probably be plugin territory.&#8221; However, he said that the <a href=\"https://wptavern.com/new-wordproof-plugin-timestamps-wordpress-content-on-the-blockchain\" rel=\"noopener noreferrer\" target=\"_blank\">WordProof plugin&#8217;s timestamping WordPress content</a> on the blockchain is among one of the best ideas he has seen for this technology so far.</p>
<p>When asked how he plans to &#8220;balance chasing the new and shiny with all of WordPress&#8217; existing legacy APIs,&#8221; Mullenweg said that &#8220;PHP is going to be crucial to us for many years to come.&#8221; He recognized that the project has fallen behind in maintenance with some of its older APIs but that work on Gutenberg can be done in parallel. </p>
<p>The new triage team is currently going through all the tickets, refreshing patches, and working on taking them to resolution. Mullenweg noted that WordCamp Europe hosted the first ever triage table at its contributor day and said that this new area is ripe for contribution.</p>
<p>The REST API, despite its broad support and noteworthy contributors, is one area that Mullenweg said has held Gutenberg back. He said it still does not have the demonstrated use that its advocates predicted when working to get it merged into core and cautioned that WordPress should always use an API first before shipping it to the world.</p>
<p>Mullenweg concluded the Q&#038;A by estimating that Gutenberg is only 10% of the way down the road towards solving the problems that WordPress contributors set out to tackle. He predicts that building on this initial effort will carry into the next decade.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 21 Jun 2019 18:48:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Free Event: Post Status to Live Stream Publish Online July 8-9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90922\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/free-event-post-status-to-live-stream-publish-online-july-8-9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1674:\"<p><a href=\"https://poststatus.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Post Status</a> will be live streaming <a href=\"https://poststatus.com/publish/\" rel=\"noopener noreferrer\" target=\"_blank\">Publish Online</a> on July 8-9, 2019. The event, which is geared towards WordPress professionals, has traditionally been limited to club members. This year Post Status creator Brian Krogsgard is opening up the live stream for anyone to watch for free.</p>
<p>&#8220;I debated so strongly on this,&#8221; Krogsgard said. &#8220;But these are great talks &#8212; valuable to the community &#8212; and I want to make them accessible.&#8221;</p>
<p>Publish Online will feature 14 presentations from community leaders who are deeply invested in the WordPress ecosystem in one way or another. The talks are centered around WordPress core processes and vision, mixed with web business topics.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-20-at-6.18.45-PM.png?ssl=1\"><img /></a></p>
<p>Those who want to watch for free will need to <a href=\"https://poststatus.com/publish/\" rel=\"noopener noreferrer\" target=\"_blank\">register for the event</a>. Access to the live stream will be available at <a href=\"http://PostStatus.com/live\" rel=\"noopener noreferrer\" target=\"_blank\">PostStatus.com/live</a>. Post Status members will have access to all the recordings, transcripts, and audio after the event has concluded. The site is currently running an early bird special on club membership, <a href=\"https://poststatus.com/checkout/\" rel=\"noopener noreferrer\" target=\"_blank\">discounted to $79/year</a> ahead of the Publish Online event.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 21 Jun 2019 00:13:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: WPWeekly Episode 357 – CBD E-Commerce, XML Sitemaps, and A Preview of WCEU 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/?p=90978&preview=true&preview_id=90978\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"https://wptavern.com/wpweekly-episode-357-cbd-e-commerce-xml-sitemaps-and-a-preview-of-wceu-2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2093:\"<p>In this episode, <a href=\"https://www.presstitan.com/\">Malcom Peralty</a> and I discuss what&#8217;s new in WordPress 5.2.2, XML Sitemaps possibly landing in core, and WooCommerce clarifying its CDB seller policy. We also provide a preview of what to expect at WordCamp EU and congratulate Marcel Bootsman for successfully walking to Berlin, Germany.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">WordPress 5.2.2</a></p>
<p><a href=\"https://wptavern.com/wordpress-5-2-2-squashes-13-bugs\">WordPress 5.2.2 Squashes 13 Bugs</a></p>
<p><a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">XML Sitemaps in Core?</a></p>
<p><a href=\"https://twitter.com/WCEurope/status/1141317581195874310\">Marcel Bootsman Arrives at WCEU</a></p>
<p><a href=\"https://www.codeinwp.com/blog/wceu-2019-event-guide/\">WordCamp EU Event Guide </a></p>
<p><a href=\"https://twitter.com/WCEurope/status/1135886419052978176\">WordCamp EU Live Stream Link to be announced</a></p>
<p><a href=\"https://10up.com/blog/2019/classifai-ai-machine-learning-wordpress/\">ClassifAI from 10up</a></p>
<p><a href=\"https://docs.woocommerce.com/document/woocommerce-cbd/\">WooCommerce Clarifies its stance on stores selling CBD products</a></p>
<h2>Transcript:</h2>
<p><a href=\"https://wptavern.com/wp-content/uploads/2019/06/EPISODE357Transcript.rtf\">EPISODE357Transcript</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, June 26th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #357:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jun 2019 23:06:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Vast, Unbroken Slabs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=49688\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ma.tt/2019/06/vast-unbroken-slabs/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:455:\"<blockquote class=\"wp-block-quote\"><p>Writing novels is hard, and requires vast, unbroken slabs of time. Four quiet hours is a resource that I can put to good use. Two slabs of time, each two hours long, might add up to the same four hours, but are not nearly as productive as an unbroken four.</p><cite>Neil Stephenson on <a href=\"https://www.nealstephenson.com/why-i-am-a-bad-correspondent.html\">Why I&#8217;m a Bad Correspondent</a></cite></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jun 2019 19:54:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Jason Bahl Joins the Gatsby Team to Work on WPGraphQL Full-Time\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90566\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wptavern.com/jason-bahl-joins-the-gatsby-team-to-work-on-wpgraphql-full-time\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6498:\"<p><a href=\"https://twitter.com/jasonbahl\" rel=\"noopener noreferrer\" target=\"_blank\">Jason Bahl</a>, creator of <a href=\"https://www.wpgraphql.com/\" rel=\"noopener noreferrer\" target=\"_blank\">WPGraphQL</a>, is joining the <a href=\"https://www.gatsbyjs.org/\" rel=\"noopener noreferrer\" target=\"_blank\">Gatsby</a> team to work on WPGraphQL (and its immediate ecosystem) full-time. </p>
<p>Gatsby, the immensely popular static site generator for React.js, lets users pull data into pages from WordPress, Drupal, Contentful, Google Docs, AirTable, markdown, and any other data sources. It is used by tens of thousands of developers and downloaded nearly 500,000 times each month.</p>
<p>Gatsby founder Kyle Mathews created <a href=\"https://www.gatsbyjs.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Gatsby Inc</a>. as a company to further the project&#8217;s goals, and <a href=\"https://www.gatsbyjs.org/blog/2018-05-24-launching-new-gatsby-company/\" rel=\"noopener noreferrer\" target=\"_blank\">received $3.8M in seed funding</a> in May 2018. The investment is being used to build cloud services for Gatsby and improve Gatsby&#8217;s core open source software. As the company has grown, Gatsby is beginning to invest more heavily in the open source ecosystem that surrounds the project.</p>
<p>With WordPress powering <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\" rel=\"noopener noreferrer\" target=\"_blank\">34% of the top 10 million websites</a>, it&#8217;s only natural that Gatsby would look to WPGraphQL, one of the most promising projects in the WP ecosystem, for its next investment in open source. The more WordPress developers Gatsby can get using GraphQL and JavaScript, the more it benefits the greater Gatsby ecosystem.</p>
<p>&#8220;The number of developers using Gatsby to build sites where the content is managed by WordPress is growing,&#8221; Bahl said. &#8220;The current `gatsby-source-wordpress` plugin pulls data into Gatsby using the WordPress REST API, but the REST API has a lot of pain points that are proving to be very difficult to get past.</p>
<p>&#8220;WPGraphQL solves many of those pain points already, and has potential to solve even more. The more robust WPGraphQL is, the better it is for all JavaScript consumers, whether it be Next.js, Gridsome (a Vue static site generator) or Gatsby.&#8221;</p>
<p>Bahl followed the Gatsby project from afar before striking up a relationship with the team through the various Slack channels where the community is active. A year and a half ago, he moved the <a href=\"http://docs.wpgraphql.com\" rel=\"noopener noreferrer\" target=\"_blank\">docs.wpgraphql.com</a> site from WordPress to Gatsby, where the content is stored in Markdown files on Github. This allows users in the community to contribute to the docs by submitting pull requests.</p>
<p>In February 2019, Bahl gave a presentation at WordCamp Phoenix on &#8220;<a href=\"https://wordpress.tv/2019/03/08/jason-bahl-building-static-sites-with-wordpress-gatsby-and-wpgraphql/\" rel=\"noopener noreferrer\" target=\"_blank\">Building Static Sites with WordPress, Gatsby and WPGraphQL</a>&#8221; After that he saw more growth in the  crossover ecosystems &#8211; more people in the Gatsby Slack asking about WordPress, and more developers in the WPGraphQL Slack asking about Gatsby.</p>
<p>&#8220;I&#8217;ve been following all things GraphQL for a few years, so Gatsby has been on my radar for a while as Gatsby uses GraphQL to create a &#8216;content mesh&#8217; where data can be pulled from many sources into one Gatsby site,&#8221; Bahl said.</p>
<p>&#8220;The more I followed Gatsby from afar, the more intrigued I was. The development experience of Gatsby is great, especially if you enjoy React, which I do.&#8221;</p>
<p>Bahl is active in both Slacks, on both GitHub repos, and on Twitter, helping people build Gatsby sites with WordPress and GraphQL, which is how he developed a relationship with the team.</p>
<p>&#8220;In mid April I made it known to a few people that I would love to work on WPGraphQL full-time if I had the opportunity,&#8221; he said. &#8220;On May 30, Kyle Matthews direct messaged me on Twitter saying Gatsby is planning on investing in WordPress more and they&#8217;d love to chat. The following week I had some video calls with Kyle, Sam, and some other folks on the Gatsby team, and they made me a formal offer to join the Gatsby teams to make WPGraphQL the best it can be.&#8221;</p>
<p>The WPGraphQL project already has a <a href=\"https://wptavern.com/wpgraphql-project-gains-momentum-with-growing-library-of-extensions-for-popular-wordpress-projects\" rel=\"noopener noreferrer\" target=\"_blank\">rapidly growing library of extensions</a> for popular WordPress plugins, despite the fact that the project has not yet reached a stable 1.0 release. Bahl&#8217;s new opportunity with the Gatsby team will enable him to work with the community&#8217;s momentum to get WPGraphQL further on its roadmap.</p>
<p>&#8220;Working on WPGraphQL full time will allow me to work on features and bugs that I’ve not had adequate time to focus on while also maintaining a full time job,&#8221; Bahl said.  </p>
<p>&#8220;WPGraphQL is used in production by many already, but it’s still pre 1.0 because of some breaking changes I foresee but haven’t had adequate time to dedicate to addressing.&#8221;</p>
<p>Bahl will also be available to provide better resources for the community, such as documentation, example codebases, and courses and tutorials, in addition to attending more WordCamps and other conferences, participating in podcasts, and interacting on GitHub issues, Slack, and other communication channels.  </p>
<p>&#8220;It will also provide more time to focus on conversations on whether GraphQL should be part of WordPress core (or not), and educate the community and core maintainers on the tradeoffs,&#8221; Bahl said. </p>
<p>In hiring Bahl to work on WPGraphQL, Gatsby is making a significant investment in the WordPress community that depends on this project. The improved support and quicker pace of development should bring peace of mind to those who are already using WPGraphQL in production. </p>
<p>&#8220;I’ll also be working closely with other members of the Gatsby team to make the experience of using Gatsby with WordPress a great experience,&#8221; Bahl said. &#8220;We have a lot of ideas about how WPGraphQL can make the Gatsby + WordPress experience a fantastic one for developers and users alike.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jun 2019 19:52:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: WooCommerce.com Clarifies Its Policy on Selling CBD Products\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90955\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/woocommerce-com-clarifies-its-policy-on-selling-cbd-products\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6948:\"<p>Last week, a member of the <a href=\"https://www.facebook.com/groups/woohelp/\">WooCommerce Help and Share Facebook</a> group who sells Cannabidiol or CBD products submitted a post that included an email exchange with WooCommerce support. </p>



<p>In the exchange, the support rep explained to the store owner that when their WooCommerce.com account was connected to a WordPress.com login, it then fell under the <a href=\"https://en.support.wordpress.com/store-guidelines/\">WordPress.com store guidelines</a>.</p>



<p>According to the guidelines, controlled substances (including marijuana, cannabidiol or CBD, and other cannabis-derived products) are not allowed to be sold. </p>



<p>The support rep goes on to say that this included but was not limited to sites using WordPress.com, the Jetpack plugin, and any extensions from WooCommerce.com.&#8221; </p>



<p>The store owner is then informed that their store will be disconnected from Automattic hosted services if they continue to sell CBD products.</p>



<h2>Legal Document Becomes a Source of Confusion</h2>



<p>The support rep provided the store owner with a link to the most <a href=\"https://docs.woocommerce.com/document/woocommerce-cbd/\">frequently asked questions</a> on selling CBD products using WooCommerce. </p>



<p>The wording of the document made it seem as though there was a difference between downloading the plugin from the WordPress plugin directory or WooCommerce.com. It also appeared to apply limits on how the GPL licensed software could be used. Here is a cached version of the original document. </p>



<blockquote class=\"wp-block-quote\"><p><strong>Can WooCommerce be used to sell cannabis-derived products such as CBD oil? </strong></p><p><strong>Yes</strong>, if you download the WooCommerce plugin directly from WordPress.org or install the WooCommerce plugin via the Plugins page of your site from WordPress.org.</p><p><strong>No</strong>, if you download and install the WooCommerce plugin directly from WooCommerce.com.</p><p>It is the same WooCommerce plugin, but the location of download makes a difference?<strong><br />What’s the difference?</strong> <br />The difference is ownership.</p><p>WooCommerce from <strong>WordPress.org</strong> is open-source software and is hosted through a third-party company.</p><p>WooCommerce from <strong>WooCommerce.com and WordPress.com</strong> is hosted through Automattic. Sites cannot sell cannabis-derived products if they are connected to Automattic servers, which includes and is not limited to WordPress.com, the Jetpack plugin, and any plugin or extension downloaded directly from WooCommerce.com. </p><p><strong>Can I use WooCommerce software from&nbsp; (x company)&nbsp; to sell cannabis-derived products? </strong><br />If you use open-source WooCommerce software from a third-party company, note that there may be additional limitations and regulations imposed by shipping and payment companies.</p><p><strong>Can I get support for a WooCommerce store selling CBD products? </strong><br />No, not from us at WooCommerce.com or WordPress.com.</p><p>Many of our store owners and customers reside in countries where CBD  products and other cannabis-derived products are fully legalized, but the production and sale of cannabis-derived products in the US – where our company is registered – is highly regulated.</p><p>As a result, we are currently unable to offer support for any  WooCommerce site that sells CBD oil or other cannabis-derived products,  whether the CBD oil is over or under 0.3% THC and whether it is derived from hemp or cannabis.</p><cite>Original WooCommerce and CBD Products FAQ</cite></blockquote>



<p>Taking note of the confusion, Paul Maiorana, Acting General Manager of WooCommerce, <a href=\"https://twitter.com/pmaiorana/status/1138584618846699525\">responded to the discussion</a> and admitted in the Facebook thread that the policy was not as clear as it could be. </p>



<p>Earlier this week, the WooCommerce team <a href=\"https://twitter.com/pmaiorana/status/1141057173650362368\">revised the policy</a> and made it much clearer on what is and is not allowed.</p>



<blockquote class=\"wp-block-quote\"><p><strong>Can WooCommerce be used to sell cannabis-derived products such as CBD oil?</strong></p><p>Yes, you can use WooCommerce for your site. As our software is open source, we do not limit its use. </p><p>However, while you can use the code of our WooCommerce plugin to sell products derived from cannabis and hemp, you cannot use <strong>services</strong> offered directly by Automattic to support those stores. This is the case whether the products are over or under 0.3% THC, and whether they are derived from hemp or cannabis. Automattic’s direct services include, but are not limited to, WordPress.com, WooCommerce.com, and the Jetpack plugin.</p><p>This means that you can use the open source WooCommerce plugin to sell cannabis-derived products, but you cannot:</p><p><s>Connect your site to Automattic’s servers in </s><em><s>WooCommerce > Extensions > WooCommerce.com Subscriptions</s></em><s> for automatic extension updates or at WordPress.com.</s></p><p>Use WooCommerce services that depend on a Jetpack connection, such as <a href=\"https://woocommerce.com/products/shipping/\">WooCommerce Shipping</a> or <a href=\"https://woocommerce.com/products/tax/\">WooCommerce Tax</a>. </p><p>Host your site on WordPress.com. </p><p><strong>Can I get help for my WooCommerce store?</strong><br />Yes. Our WooCommerce.com help desk can assist you with your site if you would normally qualify to receive support. You might also receive help from others in the WordPress.org  forums or the WooCommerce community.</p><cite>Revised WooCommerce and CBD Products FAQ</cite></blockquote>



<p>In the last two years, WooCommerce has increasingly relied on Jetpack and its connection to WordPress.com&#8217;s infrastructure to provide services. These include <a href=\"https://woocommerce.com/products/shipping/\">WooCommerce Shipping</a>, the <a href=\"https://woocommerce.com/mobile/\">WooCommerce app</a>, and <a href=\"https://blog.taxjar.com/woocommerce-services-automated-tax-calculations-powered-taxjar/\">Automated Tax Calculations</a>. In 2017, <a href=\"https://woocommerce.com/posts/wooconf-state-of-the-woo/\">Todd Wilkens made it clear</a> that WooCommerce would continue to make extensive use of Jetpack to provide cloud services.</p>



<p>While the policy makes things clearer, CBD store owners will need to determine if they can live without the conveniences provided by Jetpack, WooCommerce.com, and WordPress.com. This situation is also a reminder to all store owners to double check a service&#8217;s policies before connecting any sites. </p>



<h2>Updated on June 25th, 2019. </h2>



<p>WooCommerce has <a href=\"https://twitter.com/pmaiorana/status/1143590019849949184\">updated its policy</a> to allow automatic updates from WooCommerce.com </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jun 2019 01:02:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: Watch the Free WordCamp Europe 2019 Live Stream June 21-22\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90487\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/watch-the-free-wordcamp-europe-2019-live-stream-june-21-22\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2026:\"<p><a href=\"https://2019.europe.wordcamp.org/\" rel=\"noopener noreferrer\" target=\"_blank\">WordCamp Europe 2019</a> kicks off tomorrow, June 20, with Contributor Day. If you have been following the event on Twitter, hundreds of WordPress enthusiasts and professionals have been descending upon Berlin this week in preparation for the world&#8217;s largest WordCamp. For those who cannot attend in person, WCEU will be live streaming the main conference on June 21-22 for free.</p>
<p>Unlike previous years, no tickets or registration will be required for live stream viewers. Removing this logistical hurdle makes the conference more accessible to viewers who may want to pop in for a session or two. </p>
<p>Matt Mullenweg will be giving an address at 2PM in Berlin on Friday, June 21, and his presentation usually includes some newsworthy announcements. Whether you&#8217;re interested in Gutenberg development, community relations, design, or business, there&#8217;s a session for a wide range of WordPress users. Those who are viewing from afar can <a href=\"https://2019.europe.wordcamp.org/schedule/\" rel=\"noopener noreferrer\" target=\"_blank\">check out the schedule</a> and plan which sessions to watch online. </p>
<p>As it was last year, the <a href=\"https://wptavern.com/wceu-team-is-working-on-pwa-support-for-all-wordcamp-websites\" rel=\"noopener noreferrer\" target=\"_blank\">WCEU website is a Progressive Web App (PWA)</a> that allows users to favorite the talks they want to attend. Presentations last 30 minutes with 10 minutes added at the end for Q&#038;A. There are 20 minutes scheduled in between sessions to allow attendees to change tracks or have conversations in the hallway.</p>
<p>WordCamp Europe plans to announce the live stream link on its <a href=\"https://twitter.com/WCEurope\" rel=\"noopener noreferrer\" target=\"_blank\">Twitter account</a>. Follow the<a href=\"https://twitter.com/hashtag/WCEU?src=hash\" rel=\"noopener noreferrer\" target=\"_blank\"> #WCEU</a> hashtag to join in the conversation online.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Jun 2019 23:20:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Google Announces Site Kit Plugin Now in Developer Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90896\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wptavern.com/google-announces-site-kit-plugin-now-in-developer-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3296:\"<p>Google is churning out updates to its WordPress products ahead of WordCamp Europe in Berlin this weekend, with the <a href=\"https://amp-wp.org/amp-plugin-version-1-2-release/\" rel=\"noopener noreferrer\" target=\"_blank\">AMP Plugin 1.2</a> release and Site Kit&#8217;s <a href=\"https://sitekit.withgoogle.com/news/site-kit-developer-preview/\" rel=\"noopener noreferrer\" target=\"_blank\">developer beta launch</a> landing the same day.</p>
<p><a href=\"https://sitekit.withgoogle.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Site Kit</a> is a new addition to Google&#8217;s WordPress plugin lineup that was <a href=\"https://sitekit.withgoogle.com/news/introducing-site-kit-by-google-for-wordpress/\" rel=\"noopener noreferrer\" target=\"_blank\">announced at WordCamp US 2018</a>. It provides a dashboard that displays how well a site is doing with various Google tools, such as Search Console, Analytics, AdSense, and PageSpeed Insights, packaged as a one-stop solution.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-19-at-4.08.49-PM.png?ssl=1\"><img /></a></p>
<p>The developer preview announced today includes the following features:</p>
<ul>
<li>Seamless site verification with Search Console</li>
<li>Provisioning and configuration of Analytics, AdSense, Tag Manager and Optimize</li>
<li>Simple aggregate and per-page reporting from Search Console, Analytics, and AdSense, to help you understand the full acquisition and monetization funnel</li>
<li>Continuous site performance auditing and monitoring with PageSpeed Insights</li>
<li>Insights we derive from across the products you’ve connected and surface on your dashboard, to help you make sense of the stats</li>
</ul>
<p>Site Kit will give WordPress users access to information and stats from Google tools directly inside the dashboard. Instead of having to log into multiple Google services to hunt down site performance and page traffic information, this plugin aggregates the most data and puts it at your fingertips inside the WordPress admin where it is most relevant. </p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/06/site-kit-admin-bar-page-stats.png?ssl=1\"><img /></a></p>
<p>The Site Kit plugin is still under active development on <a href=\"https://github.com/google/site-kit-wp\" rel=\"noopener noreferrer\" target=\"_blank\">GitHub</a> and beta testers will need to be familiar with the Google Cloud Platform and OAuth in order to get started. </p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-19-at-5.00.56-PM.png?ssl=1\"><img /></a></p>
<p>The setup experience is not user-friendly but rather geared towards getting feedback on the plugin&#8217;s current features. Google isn&#8217;t planning on putting Site Kit on WordPress.org until the setup process has been improved to be a better experience for WordPress users who are not developers. The goals for the developer beta are to gather feedback on the plugin&#8217;s functionality and compatibility with other plugins. </p>
<p>A contingency of engineers from Google&#8217;s Developer Programs team will be available at the Google booth during WordCamp Europe to answer questions from the community on Site Kit and any of the company&#8217;s other products. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Jun 2019 22:36:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Matt: Diversifying WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=49695\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://ma.tt/2019/06/diversifying-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:876:\"<p>WordPress is about democratizing publishing, removing barriers to getting your words on the web. <a href=\"https://en.blog.wordpress.com/2019/06/19/want-to-see-a-more-diverse-wordpress-contributor-community-so-do-we/\">There’s a cool effort underway right now to remove some barriers that people from groups underrepresented in tech might face when becoming a WordCamp speaker</a>. Automattic is supporting this by sponsoring Jill Binder’s work on the WordPress <a href=\"https://make.wordpress.org/community/handbook/meetup-organizer/event-formats/diversity-speaker-training-workshop/\">Diverse Speakers Training Group</a>. </p>



<p>I would love to see the WordPress contributor base become more diverse, and training people from marginalized communities to speak at WordCamps is a great way to help that along. Check out that effort if you’d like to get involved.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Jun 2019 21:42:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"HeroPress: It’s never too late to start the right career path\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2882\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:172:\"https://heropress.com/essays/its-never-too-late-to-start-the-right-career-path/#utm_source=rss&utm_medium=rss&utm_campaign=its-never-too-late-to-start-the-right-career-path\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:20945:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/061919-min-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull quote: Most late achievers will discover that they have more significant opportunities to succeed on alternative paths.\" /><h3>WordPress &#8211; Life changing experience</h3>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/IMG_8983.jpg\"><img /></a>Recently I had an enjoyable experience with a team of WPTranslationDay4 where I took the challenge to be a Live Streaming Host for the first time. And it was a fantastic talk with Speakers.</p>
<p>By the time you read this, I would have experienced my first international talk in<a href=\"https://2019.europe.wordcamp.org/sessions/\"> WordCamp Europe 2019</a> at<a href=\"https://2019.europe.wordcamp.org/2019/04/30/wp-cafe/\"> WPCafe</a>. And would have moved to the next :). In this essay, I will be sharing how I found my career path, how WordPress changed my life, why I took challenges. I am a non-technical person, if you are a newbie, struggling with your career, stopped taking challenges, gave up and lose hope, especially women’s, then this may be your compelling decision to be here. I am sharing my short story towards WordPress and putting some points that make me take these decisions.</p>
<h3>Who am I?</h3>
<p>My name is<a href=\"https://afsanamultani.com/about-afsana/\"> Afsana Multani</a>, an artist by hobby and a WordPress enthusiast. You must think, why and how I work with WordPress? WordPress wasn’t the first choice in my life. My very first choice was painting. I didn&#8217;t even know I will be starting working with WordPress. :) To learn and work with WordPress, became the dream of my life, to follow this, I started working as a Customer Support Executive at theDotstore, which is a Venture of MULTIDOTS.</p>
<p>I was born &amp; brought up in a reserved middle-class family, residing in Bhavnagar, a small city of Gujarat, India. Currently, I live in Ahmedabad. The family thinking is one which follows age-old customs and traditions and has stayed away from innovations. Where, most of the time, children do not have the freedom to dream, to develop, or to choose their life, to do something new. As a child, I had everything needed to live a better life &#8211; food, shelter, and clothes. But one thing was missing &#8211; “freedom.” I am the second one of four kids in my family and was lucky enough to study further.</p>
<p>Though I never had a chance to talk with my father about my career, and what I want to do in life or how life will be after studies. I was sure I have to do something and make my parents proud.</p>
<blockquote><p>Besides all the strict rules and conventional thinking, my parents trusted me and allowed me to study further.</p></blockquote>
<p>My mother never pushed me to cook or do household chores, as she spends her entire life doing this stuff. She loved to study, but due to this old thinking pattern, she had to drop her studies after her 3rd Standard. She starts cooking at home, with all household chores, preparing to get married one day.</p>
<p>You would say, it’s not an age to do this. But it was her childhood, where other children were playing with toys, she continued playing with real-life. She determined never give up; whatever I am today because of her if she does not do that I would never have the courage to study further. I was good in studies, and get 1st in every Curriculum activity; the reason was my parents. I wanted to see them happy and proud. I learned one thing from her &#8211;</p>
<blockquote><p>Never give up on your dreams, work harder for what you want, and help others.</p></blockquote>
<p>I always have struggled for my future path, I wasn’t sure what to do and what not to, but I learned not to be afraid of taking challenges. During the time, I was about to step into the new phase of life &#8211; “Marriage.”</p>
<h3>Everything changed</h3>
<p>In my sweet 16, my wedding fixed already. And my father asked me to drop studies after 10th and plan for marriage. But my mother wanted me to study; so, she convinced him. Fortunately, my life partner was also so understanding and carrying. We never met before our engagement day, but I still remember, as soon as we had our first phone call, we fell in Love. Just like that &#8211; like a Fairy Tale.</p>
<p>Suddenly everything changes when the day came to leave my parents home. I got married early after my Higher Secondary School at the age of 18. I was a child with no idea how everything goes after marriage but has to take the responsibilities. It was a new challenge &#8211; family and household chores. Understanding new families make them happy and still living in a joint family was a challenge to decide on a career. I remember one my Grandpa says,</p>
<blockquote><p>“life will never be better, but we have to make it better”</p></blockquote>
<h3>Can a Hobby be a Profession?</h3>
<p>So, the answer is yes. If your hobby wakes you up in the middle of your sleep, it does. But if you let someone entering into your hobby, then it may be challenging for you to continue further. For me, the painting was my hobby, since childhood. I never found a tutor to polish my skills and learned it myself as an inspiration from my elder sister. It was a dream to be a great artist one day; I decided to join the institute after my marriage. I initiated my first painting classes name “<a href=\"https://afsanamultani.com/my-studio/\">AKSA</a>,” I enjoy with kids; my motto was to encourage them to develop their skills.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/Studio.jpg\"><img /></a></p>
<p>I did not have a better teacher in my childhood, so I wanted them to have one and not to struggle much to follow their path. Destiny has some other plans.</p>
<h3>Introduction to the computer world</h3>
<p>I also have learned PHP for a couple of months. But that was not something I am happy with so I continued my journey, finding some more opportunities.</p>
<p>In 2012, I found my first job out of my hobby with a full-service WordPress agency &#8211;<a href=\"https://www.multidots.com/\"> MULTIDOTS</a> as a front-end developer; I had picked up quite a bit of Photoshop designing as well as HTML. Work with photoshop was fun to play with computer. I did not have a computer at home, so this job was fascinating. I decided it quickly and started building websites and learning HTML responsive coding, on my own &#8211; Google was my teacher. I love learning new things which match to my nature and interest :).</p>
<p>I was perfectly happy as a front-end developer, yet I always felt as if there were some other types of work that I would adore more. “I just didn&#8217;t know what it was,” in 2017, I started working with WordPress.</p>
<p>The decision to start working with WordPress comes with challenges. It feels like going back to the first-level of schooling, taking classes to pick up necessary qualification.</p>
<p>For me, everything changed in my early 20’s. At 25, my brain woke up &#8211; it certainly feels like that. And I managed to win a job as a “Customer Support Executive” at<a href=\"https://www.thedotstore.com/\"> thedotstore</a>. I am a talkative person, and chatting with people around the world was amazing. As my Mom says, &#8211; help, support, and make people happy. Working freely with fun was one of my visions that comes true.</p>
<p>Thedotstore develops free and premium plugins for WooCommerce, with a focus on scalability, performance, and security. Customer satisfaction is the key success to thedotstore or any businesses. While working with IT company being a frontend developer, I came into contact with WordPress and found we can create a blog easily. But it was way far knowing about its vast community.</p>
<h3>My first WordPress Blog</h3>
<p>It was an enjoyable experience working on my first WordPress painting blog in 2014. :) I do not have an active link, because it was on a local server for practice.</p>
<p>But I have recently created a new Blog “<a href=\"https://afsanamultani.com/\">afsanamultani.com</a>” &#8211; which is live and active :) Where I have shared my journey being with Painting Studio as well as my experiences in contribution to WordPress.</p>
<h3>My First interaction with WordPress Community</h3>
<p>WordPress Ahmedabad community already started Organizing<a href=\"https://www.meetup.com/ahmedabad-wp-meetup/\"> WPMeetups</a> and also planning for the first WordCamp in 2017. I participated as Volunteer in my first<a href=\"https://2017.ahmedabad.wordcamp.org/\"> WordCamp Ahmedabad 2017</a>, Also have created a beautiful Selfie Booth with the team. During the day, for the first time in my life, I took the initiative to talk to different people about WordPress, got an opportunity to meet WordPress lovers, Automattician &#8211;<a href=\"https://automattic.com/work-with-us/happiness-engineer/\"> Happiness Engineer</a>, Nomad, people working remotely. Those words were new to me, and I was like- what are you saying! For me, it was a dream, “I was born for this man.” At the same time, I decided to be a Happiness Engineer one day. WordPress is not only a platform for a techie guy; it also helps a person like me to select their career path with WordPress. Doesn&#8217;t sound interesting?</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/WCAhmedabad2017.jpg\"><img /></a></p>
<h3>A break that got me where I am today</h3>
<p>It was my first day when I started learning more about WordPress and its community. In November 2017, WordPress was at version 4.9.1, and I was getting in. I spend days tweaking and learning about customer support, forums, and how to get involved. I wanted to be a part of the WordPress team.</p>
<h3>Steps I followed</h3>
<p>Step one:- with understanding the code of conduct and how the<a href=\"https://wordpress.org/about/\"> community</a> works.</p>
<p>Step two:- How to get involved &#8211;<a href=\"https://make.wordpress.org/\"> make.wordpress.org</a></p>
<p>Step three:- What are the channels and how it works.</p>
<p>Step Four:- Go to the team channels and start surfing.</p>
<p>Step Five:- Join the<a href=\"https://make.wordpress.org/chat/\"> slack channels</a>, where you get the support and knowledge. It’s easy to join the public slack channel #forums #community-events #community-team and more.</p>
<p>As we know, it is not easy to get started and understand everything overnight. At first, when I joined these slack channels, I found lots of people chatting and sharing information, some asking for help and some are staff who helped people to solve their problems.</p>
<h3>First Week with WordPress</h3>
<p>My very first week went only on reviewing those chat conversations and how to get involved. So if you are new and want to get into this, be there for a while, don&#8217;t try to understand everything at first. Please go through all the chat conversations, and gradually, you will know how it works.</p>
<p>It’s a great platform to work; if you ask me how long I can work with WordPress, I would like to work with WordPress forever. It’s like I never think to change the platform since WordPress helps me to work freely and who does not love Freedom? :)</p>
<blockquote><p>Dedication, Hard work, Patience, and Reading will always make you successful in any Career you choose.</p></blockquote>
<p>I was a newbie, and I didn&#8217;t even imagine it will be a fantastic journey. It took me a year to understand the community. I am now working as a customer support executive, still learning and exploring new ways of contributing to WordPress.</p>
<h3>Volunteer work</h3>
<p>During this time, I have attended several WordCamps, and I got opportunities in organizing, speaking, and volunteering.</p>
<h3>WordCamp Organizing Experience</h3>
<p>After WordCamp Ahmedabad 2017, it was time for our second WordCamp. We started planning for the next Lead Organiser for the event. By the time of deciding for the woman candidate. Everyone asked me if I am ready to take this challenge. My first expression was &#8211; What? Are you kidding me? It&#8217;s a dream, someone, please wake me up, :D I asked many questions at the same time. I asked myself for a while, Am I ready for the big challenge? What if I could not make it? And I recall those words &#8211; never give up, take a challenge, and try harder than what you want.</p>
<p>I accepted the challenge, started reading<a href=\"https://make.wordpress.org/community/handbook/wordcamp-organizer/become-an-organizer/\"> WordCamp Organizer HandBook</a> from WordPress.org site. There’s each and everything mentioned very clear from Applying Application to the<a href=\"https://central.wordcamp.org/schedule/\"> WordCamp Central,</a> where you find all the upcoming WordCamp lists and the End of the event process. It was a fantastic experience of<a href=\"https://2018.ahmedabad.wordcamp.org/organizers/\"> WordCamp Ahmedabad 2018</a>. There is one thing that I learn from this event, if you are ready to take the challenge, everyone will help you to fulfill that challenge. And it was never possible without my team and Aditya Kane, who was the mentor for the event. We are an excellent team of organizers.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/Organisers.jpg\"><img /></a></p>
<h3>WordCamp Speaking Experience</h3>
<p>After volunteering, organizing, it was my dream to be a speaker. And I was fortunate to speak in<a href=\"https://2019.kolkata.wordcamp.org/speakers/\"> WordCamp Kolkata 2019</a>. I was so happy when I got an Email with “Congratulations.” Now, what? Let us prepare.</p>
<p>Sharing<a href=\"https://speakerdeck.com/afsana/20-effective-ways-to-build-a-better-customer-experience\"> “20 Effective Ways to Build a Better Customer Experience”</a> was a great experience in my life; I never imagined such a huge audience and a great team. By this time I have also contributed to upload WordCamp video on<a href=\"https://wordpress.tv/2019/04/10/afsana-multani-20-effective-ways-to-build-a-better-customer-experience/\"> WordPress.tv</a>. Learning Never Ends!</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/Speaker.jpg\"><img /></a></p>
<p>If you are reading this, and also have a dream to be a speaker, the first thing you need to do is, write your topic and send it over. Do not think much; push that Share Button, that’s all. Sometimes, we’re afraid to push that button and miss the excellent opportunity. If you think next time, write everything, and I would be happy to push that button for you. :D Especially women, it would be so lovely to see you, take this challenge and start living your dreams. Do not be afraid of making mistakes, remember &#8211; “every successful person made mistakes” even Gandhiji, but he learned from his mistakes and promised never to repeat.</p>
<h3>“Take new challenges, make mistakes, learn, and improve.”</h3>
<p>Moving further to contributions, it is always fun working with your love. I believe &#8211; “Love what you do and do what you Love,” and it works.</p>
<ul>
<li>WordPress Support Forums</li>
<li>WordPress TV Contributor</li>
<li>WordPress Polyglots Editor</li>
<li>WordPress Polyglots Contributor</li>
<li>WordPress Meetup Organizer</li>
<li>WordCamp Volunteer</li>
<li>WordCamp Lead Organizer</li>
<li>WordCamp Speaker</li>
<li>WordPress Polyglots Translation Team</li>
</ul>
<p>I have done what I love, and what about you?</p>
<p>Most importantly, I am glad to be a contributor. There&#8217;s one more thing &#8211; The<a href=\"https://profiles.wordpress.org/afsanamultanii/\"> badges</a> are the best part of WordPress I have ever seen, and it&#8217;s like a volunteer reward.</p>
<p>So ladies and gentleman, How many badges have you collected? Share your list in comments :)</p>
<h3>My initiative</h3>
<p>After experiencing my contribution to WordPress, people come up with various questions, &#8211; how you have done this, and how to get involved in the community, what steps to be followed to contribute. So that makes me start this initiative <a href=\"https://iamwplearner.com/\">iamwplearner</a> as a knowledge sharing activity with a dream of helping the local as well as WordPress community through different channels and languages.</p>
<p>Good Takeaways – iamwplearner helps beginners, startup, and college students, who are looking for the opportunity and how to involve with WordPress.</p>
<p>Everything was possible only with the help of<a href=\"https://aslam.blog/\"> Aslam Multani</a>. He is my supporter, my backbone, and my reason for life, he is the person who always guides me and motivates me in all situations.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/Afsana-Aslam.jpg\"><img /></a></p>
<p>Like me, most late achievers will discover that they have more significant opportunities to succeed on alternative paths. But, today’s obsessive way for new achievement is the fear of failure for those who do not attain it. They waste our national talent and stunted creativity.</p>
<h3>If I can do this, You can do this even better. :)</h3>
<p>All of us love someone and something, and the thing is we cannot give up on ourselves or others- especially if society has made it harder to catch up. Most people recently born will live in the 22nd century, and they will accept the modernization in the community. This is us; a healthy society needs all of its people to recognize that they can bloom and re-bloom, grow, and succeed throughout their lives.</p>
<p>I like to address this commitment, to all WordPress fans, especially a local womens community, to show your real talent, and break the stereotypes. Let people speak, there will be a doubt, a mistake, but if you are confident in you, no one can stop doing your best. :)<br />
I wish you Good Luck.</p>
<h3>What’s in the Future?</h3>
<p>I would say, the future is yet to come. Be yourself, there are many opportunities, challenges, and learnings. I try myself ready for better today than yesterday. Keep learning is the key to success… After many trial and error, I am here with WordPress, and most important is, I love what I do. :)</p>
<p>Thank you.</p>
<p><b>Thanking Note:-</b> <i>I like to thank Topher and HeroPress for allowing me to write and share my story with you all. There’s always a best in everyone’s story, what’s in you? Share your thoughts, or say &#8211; </i><b><i>Hi</i></b><i> in comments below.</i></p>
<p>&nbsp;</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: It’s never too late to start the right career path\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=It%E2%80%99s%20never%20too%20late%20to%20start%20the%20right%20career%20path&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fits-never-too-late-to-start-the-right-career-path%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: It’s never too late to start the right career path\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fits-never-too-late-to-start-the-right-career-path%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fits-never-too-late-to-start-the-right-career-path%2F&title=It%E2%80%99s+never+too+late+to+start+the+right+career+path\" rel=\"nofollow\" target=\"_blank\" title=\"Share: It’s never too late to start the right career path\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/its-never-too-late-to-start-the-right-career-path/&media=https://heropress.com/wp-content/uploads/2020/06/061919-min-150x150.jpg&description=It’s never too late to start the right career path\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: It’s never too late to start the right career path\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/its-never-too-late-to-start-the-right-career-path/\" title=\"It’s never too late to start the right career path\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/its-never-too-late-to-start-the-right-career-path/\">It’s never too late to start the right career path</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Jun 2019 12:00:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Afsana Multani\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Developers at Yoast and Google Collaborate on Proposal to Add XML Sitemaps to WordPress Core\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90744\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://wptavern.com/developers-at-yoast-and-google-collaborate-on-proposal-to-add-xml-sitemaps-to-wordpress-core\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5027:\"<p>Developers at Google and Yoast are collaborating with other contributors on a <a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\" rel=\"noopener noreferrer\" target=\"_blank\">proposal to add XML sitemaps to WordPress core</a>. This capability has traditionally been handled by plugins, which provide a variety of implementations. The goal of this new feature project is to ship basic XML sitemaps in core while providing an XML Sitemaps API for plugin developers to extend. It would also update WordPress&#8217; robots.txt file to reference the sitemap index. </p>
<p><a href=\"https://twitter.com/TweetyThierry\" rel=\"noopener noreferrer\" target=\"_blank\">Thierry Muller</a>, a Developer Relations Program Manager at Google, published the details of the collaborators&#8217; plans on WordPress.org. The sitemaps included in core would be enabled by default and would index the following content:</p>
<ul>
<li>Homepage</li>
<li>Posts page</li>
<li>Core Post Types (Pages and Posts)</li>
<li>Custom Post Types</li>
<li>Core Taxonomies (Tags and Categories)</li>
<li>Custom Taxonomies</li>
<li>Users (Authors)</li>
</ul>
<p>Although WordPress contributors have had multiple discussions regarding XML sitemaps on trac, Muller said there had not yet been a group to take ownership and get things moving forward. His proposal notes that 4 out of the top 15 plugins in the WordPress plugin directory ship with their own implementation of XML. Despite the demonstrated high demand for XML sitemaps,  the right team for getting this added to core had not been assembled until now.</p>
<p>&#8220;XML Sitemaps is a standard across all search engines these days and any website with content which is intended to be indexed should have one,&#8221; Muller said. &#8220;Having XML Sitemaps in core would speed up content discoverability and indexing. We started discussing this topic last year with Yoast and agreed that it would be great to finally make it happen.&#8221;</p>
<p>So far the initiative has received a favorable response from the community and has already gained the support of WordPress project lead Matt Mullenweg. </p>
<p>&#8220;This makes a lot of sense, looking forward to seeing the v1 of this in core and for it to evolve in future releases and cement WordPress’ well-deserved reputation of being the best CMS for SEO,&#8221; Mullenweg commented on the proposal. </p>
<p>Performance is one of the primary concerns that the WordPress development community has expressed regarding adding XML sitemaps to core. </p>
<p>&#8220;As simple and straightforward as XML sitemaps are, they present some relatively significant performance challenges at scale,&#8221; Matthew Boynes, partner at <a href=\"https://alley.co/\" rel=\"noopener noreferrer\" target=\"_blank\">Alley Interactive</a>, said. &#8220;As one for-instance, how many urls are going to be in each paginated (sub-) sitemap? A sitemap index file is limited to 50,000 sitemaps, so even though each sitemap is limited to a maximum of 50,000 urls, generating 50,000 urls in one page request would be extremely difficult and non-performant to do on-the-fly.&#8221;</p>
<p>Muller and other contributors on the project have a strategy for addressing scalability concerns and are planning to keep these considerations on the forefront while building core&#8217;s implementation.</p>
<p>&#8220;As for everything else, engineering new features should always be done with security and performance in mind,&#8221; Muller said. &#8220;It starts at the high level architecture down to the granular details. Each Sitemap entry will only contain ,  and  which should not overload the server request with a paginated approach. The number of entries per Sitemap is still to be defined, performance will definitely be a deciding factor.&#8221;</p>
<p>The XML Sitemaps project has a clearly defined scope. The initial implementation will not include features like image, video, or news sitemaps. It also will not include a UI for controls to exclude individual posts, pages, or custom post types from the sitemap. This is somewhat controversial but plugins can always extend core to offer these features until a more sophisticated version of sitemaps lands in core.</p>
<p>Plugin authors who offer XML sitemaps will need to re-architect their plugins with the new API in order to avoid conflicts and indexing errors. </p>
<p>&#8220;I can confidently say that we will make it as smooth as possible and work with plugin authors to avoid conflicts,&#8221; Muller said. &#8220;If anything else, having XML Sitemaps as well as a Core API to extend it will make their lives easier &#8211; plugin authors will have a standard way to extend it.&#8221; </p>
<p>This effort to get sitemaps added to WordPress core is not limited to those working at Google and Yoast. Muller encouraged authors of other XML sitemaps plugins to get involved or at least follow the project&#8217;s development to ensure their plugins are compatible once it is merged into core.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Jun 2019 03:49:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: WordPress 5.2.2 Squashes 13 Bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90869\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wptavern.com/wordpress-5-2-2-squashes-13-bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1305:\"<p>WordPress 5.2.2 dubbed a short-cycle maintenance release is <a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">available for download</a>. This release addresses 13 bugs and improves the Site Heath features introduced in 5.2. </p>



<p>One of the changes in 5.2.2 affects the theme update link in the Customizer of multisite installs. The update link for themes on multisite installs in the Customizer <a href=\"https://core.trac.wordpress.org/ticket/46997\">has been removed</a>. This is because updates can not be performed from within the Customizer in this situation. </p>



<p>Other changes include, <a href=\"https://core.trac.wordpress.org/ticket/47070\">adding a exit recovery mode button</a> in the responsive view, making the <a href=\"https://core.trac.wordpress.org/ticket/46957\">Site Health page access filterable</a>, and updates to the <a href=\"https://core.trac.wordpress.org/ticket/47429\">page editor packages</a>. </p>



<p><a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a> and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> co-led the release with guidance from Executive Director, Josepha Haden. Thirty people contributed to WordPress 5.2.2. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Jun 2019 21:24:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WordPress.org blog: WordPress 5.2.2 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6993\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3947:\"<p>WordPress 5.2.2 is now available! This maintenance release fixes 13 bugs and adds a little bit of polish to the Site Health feature&nbsp;<a href=\"https://wordpress.org/news/2019/05/jaco/\">that made its debut in 5.2</a>. </p>



<p>For more info, browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&resolution=fixed&milestone=5.2.2&order=priority\">full list of changes on Trac</a> or check out <a href=\"https://wordpress.org/support/wordpress-version/version-5-2-2/\">the Version 5.2.2 documentation page.</a></p>



<p>WordPress 5.2.2 is a short-cycle maintenance release. The next major release will be version 5.3; check <a href=\"https://make.wordpress.org/core/\">make.wordpress.org/core</a> for details as they happen.  </p>



<p>You can&nbsp;download&nbsp;<a href=\"https://wordpress.org/download/\">WordPress 5.2.2</a>&nbsp;or visit&nbsp;<strong>Dashboard → Updates</strong>&nbsp;and click&nbsp;<strong>Update Now</strong>. Sites that support automatic background updates have already started to update automatically.</p>



<p><a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a> and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> co-led this release, with invaluable guidance from our Executive Director, Josepha Haden Chomphosy, and contributions from 30 other contributors. Thank you to everyone who made this release possible!</p>



<p><a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/jankimoradiya/\">Janki Moradiya</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991/\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">palmiak</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly/\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shashank3105/\">Shashank Panchal</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">vaishalipanchal</a>, <a href=\"https://profiles.wordpress.org/vrimill/\">vrimill</a>, and <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Jun 2019 18:14:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"marybaum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"WPTavern: In Case You Missed It – Issue 26\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/?p=90840&preview=true&preview_id=90840\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wptavern.com/in-case-you-missed-it-issue-26\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7430:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png?ssl=1\" rel=\"attachment wp-att-50955\"><img /></a>photo credit: <a href=\"http://www.flickr.com/photos/112901923@N07/16153818039\">Night Moves</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc/2.0/\">(license)</a></p>
<p>There’s a lot of great WordPress content published in the community but not all of it is featured on the Tavern. This post is an assortment of items related to WordPress that caught my eye but didn’t make it into a full post.</p>
<h2>Birgit Olzem Could Use the Community’s Help</h2>
<p><a href=\"https://coachbirgit.com/\">Birgit Olzem</a> has encountered some financial hard times due to multiple illnesses and paying for acupuncture treatments and osteopathic therapy which are not covered by her insurance. Olzem fell ill earlier this year which prevented her from generating income as a self-employed person.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Dear <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> community! </p>
<p>Today I turn to you with a request that I find very difficult to make. <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f974.png\" alt=\"🥴\" class=\"wp-smiley\" /></p>
<p>Over the last 7 years, I\'ve invested a lot of time and money in the contributions for WordPress. Despite five children, part-time jobs and chronic diseases. <a href=\"https://twitter.com/hashtag/Thread?src=hash&ref_src=twsrc%5Etfw\">#Thread</a></p>
<p>&mdash; Birgit Olzem (@CoachBirgit) <a href=\"https://twitter.com/CoachBirgit/status/1139091195949387776?ref_src=twsrc%5Etfw\">June 13, 2019</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">If my contributions to <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> have helped in any way over the years, or you just like me as a person, I\'d be happy if you would help me become healthy again.<a href=\"https://t.co/wfmJ3WOXMn\">https://t.co/wfmJ3WOXMn</a></p>
<p>My eternal thanks will come to you. <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f64f.png\" alt=\"🙏\" class=\"wp-smiley\" /></p>
<p>7/7 <a href=\"https://t.co/i98dU1EC1S\">pic.twitter.com/i98dU1EC1S</a></p>
<p>&mdash; Birgit Olzem (@CoachBirgit) <a href=\"https://twitter.com/CoachBirgit/status/1139091214869901312?ref_src=twsrc%5Etfw\">June 13, 2019</a></p></blockquote>
<p></p>
<p>Olzem has translated WordPress, compiled release packages for de_DE, organized Meetups, WordCamps, answered support questions and has been part of different make/WordPress teams, some of them as a team-rep. She&#8217;s also contributed to WordCamps as a Speaker, Volunteer and Contributor day team-lead.</p>
<p>To learn more about her story and to donate, please read her <a href=\"https://birgits.blog/donations/support-my-contributions/\">request to the community</a>.</p>
<h2>Liam Dempsey&#8217;s Take on Gutenberg</h2>
<p>Liam Dempsey <a href=\"https://liamdempsey.com/using-gutenberg-on-wordpress-what-i-like-and-what-i-dont/\">describes</a> what he likes and doesn&#8217;t like about the new WordPress editor.</p>
<h2>Defending the Right to Publish Open Source Software in the UK</h2>
<p>The EFF and Open Rights Group have <a href=\"https://www.eff.org/deeplinks/2019/06/eff-and-open-rights-group-defend-right-publish-open-source-software-uk-government\">submitted </a>comments to the UK government defending the right to publish open source software.</p>
<blockquote><p>Moreover, source code is a form of written creative expression, and open source code is a form of public discourse. Regulating its publication under anti-money-laundering provisions fails to honor the free expression rights of software creators in the United Kingdom, and their collaborators and users in the rest of the world.</p></blockquote>
<h2>Why Is It Important to Give Back to Open Source?</h2>
<p>JC Mae Palmes on Twitter asked, w<span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\" dir=\"auto\">hy is it important to give back to the </span><span class=\"r-18u37iz\">WordPress</span><span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\" dir=\"auto\"> community? Here are a few responses. To see all of the responses, check out <a href=\"https://twitter.com/jpalmes/status/1138909591515701249\">this Twitter thread</a>. </span></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">WordPress powers 34% of the web, it\'s a career advantage, the community is awesome, the product is used by students and enterprises alike, you can directly talk to incredibly knowledgeable people and learn a ton</p>
<p>&mdash; Mario Peshev (@no_fear_inc) <a href=\"https://twitter.com/no_fear_inc/status/1139043365062893568?ref_src=twsrc%5Etfw\">June 13, 2019</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Open Source projects live and die by the willingness of those who benefit from the project giving back to the project.</p>
<p>&mdash; Morten i Danmark <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f1e9-1f1f0.png\" alt=\"🇩🇰\" class=\"wp-smiley\" /> (@mor10) <a href=\"https://twitter.com/mor10/status/1139112853003296768?ref_src=twsrc%5Etfw\">June 13, 2019</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">You realize you’re not alone. The mistakes you make are normal, that everyone’s figuring it out as they go. It gives you access to experience at all levels and people to brainstorm with who have unique perspectives.</p>
<p>&mdash; Cate DeRosia (@mysweetcate) <a href=\"https://twitter.com/mysweetcate/status/1139011927445819392?ref_src=twsrc%5Etfw\">June 13, 2019</a></p></blockquote>
<p></p>
<h2>WordCamp US Speaker Selection Process</h2>
<p>If you&#8217;re wondering how speakers are being selected for WordCamp US this year, check out <a href=\"https://2019.us.wordcamp.org/2019/06/12/past-vs-present-how-were-evolving-the-speaker-selection-process/\">this post</a> by the Programming Team. The team is using a new process that includes, limiting the number of submissions per speaker to two instead of unlimited, reviewing submissions based on the organizer&#8217;s sphere of experience, and using blind reviews. Speakers who are chosen are scheduled to be notified by the end of this month.</p>
<h2>An Easy Way to Make an Impact in The WordPress Community</h2>
<p>David Bisset <a href=\"https://twitter.com/dimensionmedia/status/1139561886071033856\">shared</a> the following idea on Twitter and while a few companies have started doing this, I think it will catch on with individuals more than businesses.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Are you a company that wants to make an impact in the <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> space but doesn’t have alot of $$$?</p>
<p>Buy some tickets for people to attend WordCamps. Especially people (youths, non-profits, not privileged) that wouldn’t normally consider going.</p>
<p>&mdash; David Bisset (@dimensionmedia) <a href=\"https://twitter.com/dimensionmedia/status/1139561886071033856?ref_src=twsrc%5Etfw\">June 14, 2019</a></p></blockquote>
<p></p>
<p>That&#8217;s it for issue twenty-six. If you recently discovered a cool resource or post related to WordPress, please share it with us in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Jun 2019 22:06:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: Justin Tadlock Proposes Idea to Solve Common Theme Issues\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90725\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://wptavern.com/justin-tadlock-proposes-idea-to-solve-common-theme-issues\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2119:\"<p>The Theme Review Team has been discussing ideas in Slack on how to solve the problem of themes in the review queue suffering from common theme issues. Just Tadlock has <a href=\"https://make.wordpress.org/themes/2019/06/07/proposal-theme-feature-repositories/\">proposed a idea</a> he calls Theme Feature Repositories. </p>



<p>The idea is to create standardized packages on the <a href=\"https://github.com/WPTRT\">Theme Review Team GitHub</a> repo that authors could use in their themes. If enough people bought into the idea and worked together, it would lessen the pain points between reviewers and theme authors. It would also decrease the amount of code written by hundreds of different authors to solve a common problem. </p>



<p>Tadlock used Admin notices and Links to &#8216;Pro&#8217; versions as two examples that could benefit from this approach. Packages would handle specific use cases and be installed using Composer. For those who don&#8217;t use composer, an autoloader would be provided as well as a .zip file that could be dropped into a theme.</p>



<p>Tadlock is asking the theme community what packages do they need or what common problems could be solved together. </p>



<p>&#8220;This can literally be any common feature in WordPress themes, not just admin or customizer-related things,&#8221; Tadlock said. &#8220;Nothing is &#8216;out of bounds&#8217;. Every idea is on the table right now.</p>



<p>&#8220;This is an ambitious project.  It’d require cooperation between authors and reviewers for the betterment of the theme directory as a whole. It’ll only work if we have buy-in from everyone.&#8221;</p>



<p>Tadlock also mentioned that due to his schedule, he will be unable to lead or co-lead the project and is seeking people interested in taking on these roles. Those interested should have knowledge of Git, Composer, and Object-oriented programming.</p>



<p>If you&#8217;re interested in this project or want to provide feedback, you can leave a comment on <a href=\"https://make.wordpress.org/themes/2019/06/07/proposal-theme-feature-repositories/\">the proposal</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Jun 2019 21:07:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: WordPress Spanish Translation Team Now has Meta Sites, Apps, and Top 200 Plugins 100% Translated\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90804\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"https://wptavern.com/wordpress-spanish-translation-team-now-has-meta-sites-apps-and-top-200-plugins-100-translated\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5640:\"<p>The Spanish WordPress community hit a remarkable milestone with translations this week. Polyglots volunteers have now translated the meta sites, WordPress apps, and the top 200 plugins at 100% completion, with no pending translations to review.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"es\" dir=\"ltr\">La comunidad <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> España <a href=\"https://twitter.com/wp_es?ref_src=twsrc%5Etfw\">@wp_es</a> sigue batiendo récords.</p>
<p>No solo no hay traducciones pendientes de revisar, sino que tiene siempre traducido al 100% WordPress, sitios meta, aplicaciones y, ahora, también al 100% el Top 200 Plugins. </p>
<p>Únete al equipo: <a href=\"https://t.co/ymTyKpvt7L\">https://t.co/ymTyKpvt7L</a> <a href=\"https://t.co/6OtoQHwVoA\">pic.twitter.com/6OtoQHwVoA</a></p>
<p>&mdash; WordPress España (@wp_es) <a href=\"https://twitter.com/wp_es/status/1138015568563441665?ref_src=twsrc%5Etfw\">June 10, 2019</a></p></blockquote>
<p></p>
<p>The size of the team is a major factor in reaching this milestone. According to stats Naoko Takano shared at <a href=\"https://wptavern.com/wordpress-translation-day-4-successfully-hosts-77-local-events-in-35-countries-recruits-183-new-translators\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress Translation Day 4</a> last month, Spanish is the locale with the most translation contributors (2,863), followed by German (2,399), Italian (2,190), Dutch (1,584), and Russian (1,515). It is also one of the top non-English locales installed, with 5.0% of all WordPress sites using the translation. WordPress.com <a href=\"https://wordpress.com/activity/\" rel=\"noopener noreferrer\" target=\"_blank\">reports</a> similar numbers, where Spanish is the second most popular language for blogs at 4.7%.</p>
<p><a href=\"https://profiles.wordpress.org/_dorsvenabili/\" rel=\"noopener noreferrer\" target=\"_blank\">Rocío Valdivia</a>, a Community Wrangler at WordCamp Central who lives in Spain, gave us a look at what is behind the team&#8217;s extraordinary growth and momentum. She identified several key factors that have contributed to their success in working efficiently and sharing useful information among team members during the past 2-3 years.</p>
<p>&#8220;We created a Slack instance some years ago, but at the beginning it was common for people to join and ask for support questions,&#8221; Valdivia said. &#8220;Now we have some protocols: the general channel is an only-read channel. If someone ask for support, we send them with a kind predef to the <a href=\"https://es.wordpress.org/\" rel=\"noopener noreferrer\" target=\"_blank\">es.wordpress.org</a> forums, where they get answers in a few hours. There are no questions in the forums waiting for longer than six hours ever, as we have a very active support team that coordinates in the #support channel of our Slack.&#8221;</p>
<p>Valdivia said that removing the noise of support requests has given the team very productive channels for translations, plugin and theme translations, meetups (where Meetup organizers share tips and resources using a shared Google drive folder), and WordCamps (where WC organizers share info, tips, answer questions in Spanish, and share resources like email templates.)</p>
<p>&#8220;Besides all of this, we’ve worked very well passing the philosophy of the project to the new members from the most experienced ones,&#8221; Valdivia said. &#8220;For example, people do very soft transitions from one lead organizer to the next one.&#8221; </p>
<p>Although some WordCamp attendees have complained in the past that not much is accomplished at Contributor Days, the Spanish community has had success using these opportunities to transfer knowledge to new leaders and contributors. The community hosted 10 WordCamps in 2018 and Valdivia estimates they will have 9-10 in 2019. WordCamp Barcelona 2018 and 2019 had 400 attendees and 180 people at their Contributor Days. WC Irun 2019 had 220 attendees and 100 participants at Contributor Day. WordCamp Madrid 2019 sold out with 600 attendees and approximately 200 participated in Contributor Day.</p>
<p>Although the Spanish community has experienced contributors across several WordPress.org teams, such as WPTV, Community, Support, and Polyglots, Valdivia said they are a bit thin on Core contributors.</p>
<p>&#8220;We’re lacking people with experience contributing frequently to Core,&#8221; Valdivia said. &#8220;We have some of them who have contributed several times, but still need more people with more involvement to be able to pass all this info to newcomers.&#8221;</p>
<p>Strong local meetups are another factor in the Spanish community&#8217;s success at keeping translations up-to-date. In addition to the largest team of translators in the world of WordPress, Spain has the <a href=\"https://central.wordcamp.org/reports/\" rel=\"noopener noreferrer\" target=\"_blank\">second highest number of meetup groups</a> and events per month. Spain is running 64 local meetups, with a population of 46 million people, compared to 201 groups in the U.S., which has 7x the population size (327 million).</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-13-at-2.20.46-PM.png?ssl=1\"><img /></a></p>
<p>&#8220;The language barrier has been an issue for years, as not everyone speaks English and not everyone feels confident following conversations in English,&#8221; Valdivia said. &#8220;So, being able to train our own teams of contributors in our own language and having our own shared resources and channels, has been very useful.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Jun 2019 20:22:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: WPWeekly Episode 356 – Gutenberg, Governance, and Contributing to WordPress with Jonny Harris\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/?p=90817&preview=true&preview_id=90817\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"https://wptavern.com/wpweekly-episode-356-gutenberg-governance-and-contributing-to-wordpress-with-jonny-harris\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1955:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by <a href=\"https://www.spacedmonkey.com/\">Jonny Harris</a>. Jonny describes how he discovered WordPress and some of the core projects he&#8217;s been working on including, Site Health Checks, fatal error protection, and Multisite. We discuss WordPress&#8217; focus on users vs developers in recent years, Jonny&#8217;s experience contributing to core, and his thoughts on a WordPress governance model.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://gizmodo.com/wordpress-is-borked-so-enjoy-this-glorious-plant-thats-1835418635\">WordPress Is Borked So Enjoy This Glorious Plant That&#8217;s Taking Over the Internet</a></p>
<p><a href=\"https://wptavern.com/wp-engine-launches-devkit-open-beta\">WP Engine Launches DevKit Open Beta</a></p>
<p><a href=\"https://wptavern.com/drupal-gutenberg-1-0-released-now-ready-for-production-sites\">Drupal Gutenberg 1.0 Released, Now Ready for Production Sites</a></p>
<p><a href=\"https://wptavern.com/buddypress-5-0-to-update-password-control-to-match-wordpress\">BuddyPress 5.0 to Update Password Control to Match WordPress</a></p>
<h2>Transcript:</h2>
<p><a href=\"https://wptavern.com/wp-content/uploads/2019/06/Episode-356-Transcript.rtf\">Episode 356 Transcript</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, June 19th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #356:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Jun 2019 20:08:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Pika Project Launches New JavaScript CDN to Serve Modern, ESM Packages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90762\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wptavern.com/pika-project-launches-new-javascript-cdn-to-serve-modern-esm-packages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7138:\"<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-12-at-2.28.56-PM.png?ssl=1\"><img /></a></p>
<p><a href=\"http://fredkschott.com\" rel=\"noopener noreferrer\" target=\"_blank\">Fred Schott</a>, a software developer and former Google employee on the Polymer team, has <a href=\"https://www.pika.dev/cdn\" rel=\"noopener noreferrer\" target=\"_blank\">launched a new CDN</a> for his <a href=\"https://www.pika.dev/\" rel=\"noopener noreferrer\" target=\"_blank\">Pika</a> project. Schott&#8217;s mission with Pika is &#8220;to make modern JavaScript more accessible by making it easier to find, publish, install, and use modern packages on npm.&#8221; Pika provides a searchable catalog of &#8220;module&#8221; packages available on npm &#8211; packages that use the more compact ES module syntax (ESM), which result in smaller Javascript bundles. </p>
<p>npm currently lists <a href=\"https://www.pika.dev/about/stats\" rel=\"noopener noreferrer\" target=\"_blank\">59,851 ES modules</a>. This makes up approximately 7% of total packages on npm are exporting an ES module, but the number is steadily increasing: </p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-13-at-9.13.09-AM.png?ssl=1\"><img /></a></p>
<p>Pika makes it easy to search for these packages and the results will only include those that have a defined &#8220;module&#8221; entry point in their package.json manifest. Each listing consolidates the relevant information on one page, highlighting the important details.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-13-at-9.26.36-AM.png?ssl=1\"><img /></a></p>
<p>One of the chief advantages of using ES modules is that they run natively on the web, without the need for a bundler. In a post titled &#8220;<a href=\"https://www.pikapkg.com/blog/pika-web-a-future-without-webpack\" rel=\"noopener noreferrer\" target=\"_blank\">A Future Without Webpack</a>,&#8221; Schott contends that JavaScript developers are &#8220;so steeped in the world of bundlers&#8221; that they overlook the possibilities of using ESM dependencies that run directly on the web:</p>
<blockquote><p>Over the last several years, JavaScript bundling has morphed from a production-only optimization into a required build step for most web applications. Whether you love this or hate it, it’s hard to deny that bundlers have added a ton of new complexity to web development – a field of development that has always taken pride in its view-source, easy-to-get-started ethos.</p>
<p>@pika/web is an attempt to free web development from the bundler requirement. In 2019, you should use a bundler because you want to, not because you need to.</p></blockquote>
<p>Schott created <a href=\"https://github.com/pikapkg/web\" rel=\"noopener noreferrer\" target=\"_blank\"> @pika/web</a> to make it easy for developers to use ES modules, even when they don&#8217;t have compatible dependencies. It provides an install-time tool that is not exactly a build tool or a bundler but works to output web-native npm dependencies into a single ESM .js file:</p>
<blockquote><p>@pika/web checks your package.json manifest for any &#8220;dependencies&#8221; that export a valid ESM “module” entry point, and then installs them to a local web_modules/ directory. @pika/web works on any ESM package, even ones with ESM &#038; Common.js internal dependencies.</p>
<p>Installed packages run in the browser because @pika/web bundles each package into a single, web-ready ESM .js file. For example: The entire “preact” package is installed to web_modules/preact.js. This takes care of anything bad that the package may be doing internally, while preserving the original package interface.</p></blockquote>
<p>Here&#8217;s a demo of how that works:</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"es\" dir=\"ltr\">¡OJO con @pika/web! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f440.png\" alt=\"👀\" class=\"wp-smiley\" /><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/26a1.png\" alt=\"⚡\" class=\"wp-smiley\" /></p>
<p><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f4e6.png\" alt=\"📦\" class=\"wp-smiley\" /> Instala tus dependencias npm y úsalas directamente en el navegador.<br /><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" /> Sin bundlers, ni configuraciones de ningún tipo.<br /><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/26a1.png\" alt=\"⚡\" class=\"wp-smiley\" /> Nativo, ESM, optimizado para http2&#8230; ¡y MUY rápido!</p>
<p>¡Muy pronto, vídeo más completo y artículo en <a href=\"https://t.co/uc7bPEkbXB\">https://t.co/uc7bPEkbXB</a> <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f468-200d-1f4bb.png\" alt=\"👨‍💻\" class=\"wp-smiley\" />! <a href=\"https://t.co/cdNWqBnrDc\">pic.twitter.com/cdNWqBnrDc</a></p>
<p>&mdash; Miguel Ángel Durán <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f468-200d-1f4bb.png\" alt=\"👨‍💻\" class=\"wp-smiley\" /> (@midudev) <a href=\"https://twitter.com/midudev/status/1101828172390248448?ref_src=twsrc%5Etfw\">March 2, 2019</a></p></blockquote>
<p></p>
<p>This week Schott announced the availability of a new <a href=\"https://www.pika.dev/cdn\" rel=\"noopener noreferrer\" target=\"_blank\">Pika CDN</a> for delivering modern ES module packages. It uses the <a href=\"https://github.com/pikapkg/web\" rel=\"noopener noreferrer\" target=\"_blank\">pikapkg/web package builder</a> to work with any ESM package and the CDN will automagically  handle any non-ESM dependencies of that package. Pika CDN automatically detects the visitor&#8217;s browser and serves JS that is optimized to the environment, eliminating polyfills and transpiler bloat wherever possible. </p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-13-at-10.12.32-AM.png?ssl=1\"><img /></a></p>
<p>&#8220;Pika CDN leverages your browser&#8217;s natural caching abilities to give your pages faster dependency load times, especially on first visit,&#8221; Schott said. &#8220;0ms first-loads are even possible (for your dependencies at least) if all packages have been seen before.</p>
<p>&#8220;With our CDN, package authors can distribute more modern, unminified packages without worrying about how to serve them directly. Instead, our nifty package-builder automatically resolves each package &#8212; and any legacy sub-dependencies &#8212; into a single, minified, ready-to-import JavaScript file.&#8221;</p>
<p>Schott recently left his position at Ripple to work full-time on Pika, a project that he believes will move the JavaScript ecosystem forward. </p>
<p>&#8220;Leaving my team was one of the hardest decisions I&#8217;ve ever made, but I know that I&#8217;m needed here,&#8221; he said. &#8220;I&#8217;m so excited to be a part of the future of the web, whatever it ends up looking like.&#8221;</p>
<p>Pika is looking for corporate sponsors. For now, Schott is <a href=\"https://www.patreon.com/pikapkg\" rel=\"noopener noreferrer\" target=\"_blank\">funding the server costs using Patreon</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Jun 2019 15:54:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WPTavern: Gutenberg 5.9 Brings Major Improvements to Block Grouping, Introduces Snackbar Notices\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90747\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"https://wptavern.com/gutenberg-5-9-brings-major-improvements-to-block-grouping-introduces-snackbar-notices\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2988:\"<p><a href=\"https://make.wordpress.org/core/2019/06/12/whats-new-in-gutenberg-12th-june/\" rel=\"noopener noreferrer\" target=\"_blank\">Gutenberg 5.9</a> is now available for those who are running the plugin to get the latest features on their sites. This release brings significant improvements to the grouping capabilities, allowing users to <a href=\"https://github.com/WordPress/gutenberg/pull/14908\" rel=\"noopener noreferrer\" target=\"_blank\">group and ungroup blocks</a> inside a container block. Once placed inside a group, the blocks can be moved up or down within the group using simple up/down controls.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/Screen-Shot-2019-06-12-at-10.04.08-AM.png?ssl=1\"><img /></a></p>
<p>Nested blocks have also been improved so that users can <a href=\"https://github.com/WordPress/gutenberg/pull/15537\" rel=\"noopener noreferrer\" target=\"_blank\">click through to each layer</a> to configure each and navigate to the deepest nested block.</p>
<p>Gutenberg 5.9 <a href=\"https://github.com/WordPress/gutenberg/pull/15594\" rel=\"noopener noreferrer\" target=\"_blank\">introduces &#8220;Snackbar&#8221; notices</a> to communicate completed actions in the block editor UI that do not require further action. </p>
<p>The term &#8220;Snackbar&#8221; doesn&#8217;t adequately describe the way these notices behave. The concept was inspired by Material design and is traditionally used for providing brief messages about app processes at the bottom of the screen. Gutenberg&#8217;s new Snackbars pop up and disappear after a short delay, so the notice doesn&#8217;t have to be dismissed. </p>
<p>&#8220;For a distraction-free experience, all the notices used in the editor to inform about the post saving/publishing, reusable blocks creation and updates have been updated to use this new type of notice,&#8221; Gutenberg Phase 2 lead Riad Benguella said. He posted a gif demonstrating Snackbar notices in action:</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/06/snackbars.gif?ssl=1\"><img /></a></p>
<p>This release brings several visual enhancements to blocks and UI components, including a <a href=\"https://github.com/WordPress/gutenberg/pull/15903\" rel=\"noopener noreferrer\" target=\"_blank\">redesign of the Table block placeholder</a>, <a href=\"https://github.com/WordPress/gutenberg/pull/14843\" rel=\"noopener noreferrer\" target=\"_blank\">refactoring and consolidation of dropdown menus</a>, and <a href=\"https://github.com/WordPress/gutenberg/pull/15874\" rel=\"noopener noreferrer\" target=\"_blank\">improvements the output of the Spacer block</a>.</p>
<p>Gutenberg 5.9 contains more than two dozen fixes for bugs found in both desktop and mobile experiences. The editor took a slight dip in performance from the previous version, going from 4.8 to 4.9 seconds in loading time and 62.8ms to 66.3ms for keypress events. More than 40 people contributed to this release and approximately 15% were new contributors.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 12 Jun 2019 18:54:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"HeroPress: My “Hero’s Journey” Through the Dark Underworld of WordPress Hosting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:204:\"https://heropress.com/essays/my-heros-journey-through-the-dark-underworld-of-wordpress-hosting/#utm_source=rss&utm_medium=rss&utm_campaign=my-heros-journey-through-the-dark-underworld-of-wordpress-hosting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:22301:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/06/061219-min-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Make things as simple as possible, while avoiding single points of failure on mission-critical systems.\" /><p><em>The following is an expanded and updated version of <a href=\"https://youtu.be/cFbyeYw9ZHI\">my presentation</a> at WordCamp Salt Lake City 2017.</em></p>
<p>My girls love Moana. Especially when it first came to video and they could watch it every day… or two or three times a day if mom wasn’t feeling good or catching up on sleep from being up with baby brother the night before.</p>
<p>There’s this strange part of that movie where Moana follows Maui to a place under the ocean called “The Realm of Monsters.” It’s where monsters go after being killed. If you have younger kids, you know what I&#8217;m talking about. If you don’t have kids, it’s when the giant crab sings the song “Shiny.”</p>
<p><img /></p>
<p>One common theme in myths, legends, and ancient religious writings, is where the hero visits the underworld, aka “afterlife” or “hell.” There they experience a symbolic or actual death for themselves or a loved one. Often through conquering a monster who is the Lord of the Underworld, they then re-emerge with their loved one, new knowledge and power, and/or some object to help them on their quest.</p>
<p>The film Moana clearly plays out this theme. She and Maui emerge triumphant from the realm of monsters, having defeated the giant crab by flipping it on its back and retrieving Maui’s magical hook.</p>
<p>In Return of the Jedi, Luke descends to the underworld of Jabba&#8217;s Palace. There, he’s able to bring his friend Han Solo back from a virtual death, defeat the Rancor, kill Jabba the Hut (lord of the criminal underworld), save the princess, and retrieve his lightsaber. All this happens before we see even one single, fuzzy, cute, unblinking Ewok…. Unless you believe in the “special editions,” in which case the Ewoks blink.</p>
<p><img /></p>
<p>There are many movies, books, stories, mythologies, etc that all follow similar patterns.</p>
<p>Like Maui’s hook or Luke’s lightsaber, in these stories the hero often emerges from the underworld with newfound knowledge and/or a powerful object. Briefly, I’d like to take you on my own personal “Hero’s Journey” to the dark underworld of WordPress hosting. Along with it my quest of building a business on WordPress and hosting, with its own mythical monsters to slay, trials to be conquered, riddles to be solved, and ultimately new knowledge and weapons gained.</p>
<h3>The Call to Adventure</h3>
<p>In the early days of my business, Fiddler Online (<a href=\"https://wordx.press/what-the-change-to-wordxpress-means-for-our-members/\">now called WordXpress</a>), I envisioned building websites for companies on WordPress, then charging a monthly fee to maintain, support, edit, update, and manage them. I got started with a few clients and wanted to grow.</p>
<p>I’d trusted someone to set me up with a very inexpensive VPS on unmanaged hosting. He was supposed to do the managing and ensure it all ran smoothly. I quickly learned you get what you pay for! Soon our members’ sites started going offline, usually all at once as the VPS crashed from one problem or another. It wasn’t just the server being down that caused problems. It was also corrupting data and other strange and scary things that I’d never encountered before, such as the body content of posts and pages being cut off, starting with the first special character that appeared in the content (a database issue).</p>
<p><img /></p>
<p>These were dark and scary monsters to battle. I knew cPanel pretty well, but the APACHE stack that ran beneath it was mostly a mystery to me. So was database encoding and other advanced technical realms that all have an impact on the server, WordPress, and ultimately our clients’ businesses.</p>
<p>The monsters appeared, seemingly determined to kill my small and struggling business, shortly after the birth of our first child. I was frequently up all night working with “Todd” the server guy (we’ll call him) to try and get the websites back online. We’d vanquish one monster, rest a day or so, and find another had taken some sites down again.</p>
<p>After a few weeks of constant frustration, I said “enough” and signed up for a Hostgator reseller plan. This was back when they were an independent hosting company. On this new plan I could install as many cPanel’s as I needed and manage each separately! I thought it was wonderful and would solve all my problems. Hostgator transferred all our sites from the terrible VPS hosting we’d been on to their servers and I thought perhaps that was it!</p>
<blockquote><p>I thought my quest was over. I’d fought the monsters and won.</p></blockquote>
<p>Scary as it was, it had been relatively brief. I’d learned a lot, but felt like I’d been to the underworld and back!</p>
<h3>The Illusion of Safety</h3>
<p>Unfortunately, the wraiths had cast a spell over me, blinding me to the fact that they were still lurking in the shadows. When transferring our WordPress websites to our new account, Hostgator had copied each entire cPanel over from the VPS. This eliminated the underlying problems in the APACHE stack on that horrible VPS, but brought with it the fiends that had infiltrated cPanel and even our WordPress websites. To be clear: they weren’t infected with any kind of malware, but configuration problems, cruft, and who knows what else, caused some really bad results.</p>
<p>With my new spellbound, but misled confidence, I pushed our business forward. I brought on a business partner, Kurt as the sales guy. Later we acquired another website company. Through all that, we’d learned a lot, and doing okay for that stage, but still struggled financially as we bootstrapped this new business from nothing.</p>
<blockquote><p>When we acquired this other business, they’d been running all their client’s sites on WordPress Multisite. It seemed like a great idea because of how it allowed us to manage all the websites in one place.</p></blockquote>
<p>Despite the progress the business made, the monstrosities emerged again and this time with higher stakes since our business had grown and was now managing many more websites. These monsters emerged partly from what had been transferred over with cPanel, and the difficulties of running a large Multisite where each child site had its own theme, plus the weight of adding more and more websites and traffic to hosting that was really just shared hosting with WHM access and more control.</p>
<p><img /></p>
<h3>The Plunge Into the Underworld</h3>
<p>In each hero’s journey, there’s often a wizard or goddess that helps guide and mentor the hero along his journey. I eventually made friends with a great guy we’ll call Sam. He ran his own hosting company with data centers and a great support staff. Sam was somewhat like Obi-Wan, Merlin, or Maui in these stories: he was my mentor and companion on my adventures into the underworld that followed. He made a great guide, because he’d been there before. Unfortunately, his own journey had never taken him to some of the deepest darkest places we would soon encounter.</p>
<p>So we moved to Sam’s hosting, where he kindly watched things closely and provided a server admin’s perspective and advice at a much lower price than he would have normally charged.</p>
<p>It wasn’t long before the demons, wraiths, monsters, and other ghouls started crawling from the darkness. It started with random downtime. Then followed strange limitations on websites. Next emails were not getting delivered. Then it was slowness. Now we were hacked… or were we? Suddenly all the contents of all pages and posts were cut off (we thought we killed this monster before)! Then email wasn’t being sent. Next our server is sending spam email. Now a hard drive is dying. It just kept going and going. Many of these demons were completely new to Sam and his very experienced team.</p>
<p>It didn’t take long before there were whisperings of “the Fiddler curse.” This curse referred to Fiddler Online the name of our company. The hosting support team joked that we were cursed. All kinds of issues arose that they’d never seen before, and with a frequency they’d never experienced either.</p>
<p>When a car crashed into the data center’s power regulation center during a freak storm, it cut off power from the normal power lines, as well as from their automatic backup power supply! It completely took the data center offline. The “Fiddler curse” was in full force.</p>
<blockquote><p>Or put better, we were in the deepest, darkest, part of the underworld, locked in an all-out battle with the worst demons and wraiths it had to send against us.</p></blockquote>
<p>We tried method after method to defeat the monsters. We tried rebuilding the server stacks. We tried various WordPress optimizations. We bought our own server and had it installed in their data center. We even tried a totally different Linux stack and something called Interworx, a cPanel alternative, that came with load balancing and real-time backup. But no matter how much money, time, and knowledge we threw at it, the issues continued. No matter how many monsters we slew, we were still losing the war.</p>
<h3>The “Real World” Dragons</h3>
<p>When I recently asked my wife Jill about that time of our lives, she said:</p>
<blockquote><p>“From my perspective, it was hard to know when to throw in the towel and say ‘enough’ because it’s just not working. Getting the hosting sorted out totally changed the entire dynamic and perspective of doing our own business. Before that, it felt like we were building a dream on a crumbling foundation.”</p></blockquote>
<p><img /></p>
<p>And don’t get the wrong idea from this image. Jill was no damsel in distress. She’s a warrior too. I’d have never completed this quest without her there, fighting alongside me. She may have not fought the technical fiends, but there were plenty other monsters in the form of financial struggles, moves, and difficult situations that arose from my unavailability, our lack of money, and more.</p>
<p>This was all a lot like battling the Hydra of Lerna: we’d cut off one head, and two would grow back in its place. We’d take a breather for a week, and then here came the wraiths!</p>
<p>The stress of it all exacerbated a gallstone problem I had. Because of a misdiagnosis, I thought it was something there was no solution for. So even when I wasn’t up in the middle of the night battling monsters demons of the hosting underworld with Sam, I was often awake at night in massive amounts of pain as my gallbladder tried to pass gigantic gallstones. So even then, I’d be sleeping the next day when I needed to be designing websites or networking.</p>
<p>Throw in a healthy dose of anxiety and some intermittent depression and you get the picture. Instead of growing, our business stagnated. The quest through this dark underworld seemed to have no end in sight. It ruined vacations, stole away family time, punished me physically, hurt our client’s business, and was pushing myself, Jill, and our finances, to our very limits.</p>
<h3>Death and Rebirth</h3>
<p>It all seemed to come to a head when the pain of my gallstones became so intense I thought I was going to die. After 2 visits to the Emergency Room and 3 days in the hospital, I gave birth to this baby. They actually saw a larger one than this in the ultrasound beforehand, but my body had apparently broken it up before they removed my gallbladder. I returned home with real-world wounds that would turn into scars, and lighter by one gallbladder and several massive gallstones.</p>
<p><img /></p>
<p>I left the hospital with a new lease on life. I felt like I’d been resurrected, fighting my way out of the underworld and back to the land of the living. It helped me open up to a completely different approach to hosting and allowed me to see that tiny speck of light that ended up being the doorway out of this underworld made up of the dark side of WordPress and hosting.</p>
<p>I was able to use my newfound perspective to find some awesome new weapons, and fight my way to that exit. Luckily for you, you can learn from my pain and battles with the underworld.</p>
<h3>The Road Back: Simplify</h3>
<p>Illumination was mine! Of the knowledge I gained, one key principle stood out among the rest: <strong>make things as simple as possible, while avoiding single points of failure on mission-critical systems.</strong> Multisite was great for managing all the websites at once, but if one had a problem, they all went down! The same with having a single server to run all our sites: if the server went down, we had the urgency of 30 or 40 clients (back then) all being negatively impacted at once.</p>
<p>We started by <a href=\"https://wordx.press/how-to-revert-a-wordpress-multisite-to-a-single-site/\">killing our Multisites</a> and traditional hosting setups. Instead of a single Multisite with 1 database where a problem could take down all the sites in the Multisite, we moved to individual WordPress installs for each site. As we pulled each site out of the Multisite and migrated it to our new cloud hosting, we also checked the databases and files thoroughly to ensure they were clean, light, and that we eliminated any cruft that had built up in the database. We also stopped running email and DNS through our web servers. This effectively killed the demons that had moved with us in previous hosting migrations.</p>
<p>Here’s my recommended do’s and don&#8217;ts for any smaller businesses hosting and maintaining WordPress websites:</p>
<p><strong>Don’t:</strong></p>
<ol>
<li>use shared hosting or hosting that uses cPanel</li>
<li>use Multisite (SPoF)</li>
<li>put all your sites on 1 server (SPoF)</li>
<li>use your web server as an email server</li>
<li>send WordPress transactional emails from your webserver</li>
<li>use your web server for DNS</li>
<li>use your hosting company for domain registration</li>
</ol>
<p><strong>Do:</strong></p>
<ol>
<li>use cloud hosting with WordPress-optimized stack and custom control panel</li>
<li>use a bulk-site-management tool</li>
<li>spread your sites across multiple servers</li>
<li>use an email suite (Hover, Zoho, G Suite, Office 365)</li>
<li>use a transactional email service (SendGrid, Postmark, MailGun)</li>
<li>use your registrar for DNS</li>
<li>use a different registrar for registering domains, than your hosting</li>
</ol>
<p>Following these tips eliminates many single points of failure, simplifies things greatly, and gives you the tools and ability to go right to the source of the problem. Since all your important WordPress functionality isn’t in one place with one point of failure, you can go where the problem is.</p>
<p>For example, if a client isn’t receiving WooCommerce new order emails from their website, we can quickly go to SendGrid to see why that is and what needs to be done to fix it in an easy to use interface. Try that on a traditional APACHE/cPanel setup that sends your client’s company emails, WordPress emails, etc. all from one place.</p>
<p><img /></p>
<h3>Cloud Hosting</h3>
<p>We eliminated cPanel and the normal Linux hosting stacks by <a href=\"https://www.cloudways.com/blog/tevya-wordxpress-success-story/\">moving to CloudWays</a>, which has a nice WordPress setup that they run on top of a number of cloud hosting services such as Google, Amazon, Digital Ocean, and Vultr. They have their own in-house customized stack and management dashboard. CloudWays removed all the normal bloat and potential for problems that comes with it, and really took away most of the pain, hassle, and responsibility of the hosting part of WordPress and for quite cheap.</p>
<p>On CloudWays, instead of putting all 40+ sites on one server, we split them up, with about 15 &#8211; 18 sites on one small Digital Ocean (and later Vultr) server. This meant that if one site had issues, it wouldn’t take down all our other sites. And even if the issue was bad enough to affect the whole server, or the server had its own issues, only a small portion of our clients would be affected at once.</p>
<h3>Email Accounts and Transactional Email</h3>
<p>Additionally, we stopped running email through our servers. Part of simplifying is outsourcing to people/services who can just do it better than you (or that old hosting you’re clinging to because it’s cheap). I love that good WordPress hosts like CloudWays, Flywheel, and Kinsta have no options for you to do this or include built-in services like SendGrid. I slew a lot of email monsters. Using something like SendGrid or Postmark for WordPress and G Suite or Office 365 for email accounts, eliminates tons of headaches.</p>
<p>We set up WordPress’s emails to go through SendGrid and all our members’ email accounts we migrated to Hover, Google Apps, or Office 365.</p>
<h3>Bulk-WordPress Management</h3>
<p>In place of Multisite, we found MainWP and chose it over other options like InfiniteWP. It provided us the bulk-control of Multisite, but without the single point of failure issue. The upside is that it’s fairly inexpensive and runs on a WordPress install, so you control it on your hosting.</p>
<p>That’s kinda its downside as well. If something goes wrong, it’s on my team and I to run the problem down and fix it. Or we have to go through the cumbersome process of reporting it to the MainWP support team, then providing them access to both the dashboard site and an affected child site. Eventually we decided to move to ManageWP because it’s a hosted platform. That means when something goes wrong, much of the time, it’s on them to fix, and they have access to fix their own platform, plus the logs, etc from our sites.</p>
<p><strong>MainWP:</strong></p>
<ul>
<li>Inexpensive</li>
<li>Runs on top of your WP install</li>
<li>You maintain control</li>
<li>Familiar interface</li>
<li>Free to use the basics</li>
<li>Lifetime extensions purchase option</li>
<li>GPL licensed</li>
<li>Great support</li>
<li>Good community</li>
</ul>
<p><strong>ManageWP:</strong></p>
<ul>
<li>More expensive</li>
<li>Runs on their servers, so problems are largely theirs to deal with</li>
<li>Less overall responsibility and time drain</li>
<li>Free to use the basics</li>
<li>Great support</li>
</ul>
<h3>Master of Two Worlds of WordPress</h3>
<p>Fortunately today there are many awesome hosting options and bulk-management tools that simply weren’t available to me years ago when I started on this journey. After this last, final push, my team and I stood back and waited and rested, expecting more monsters. And occasionally one crawled out of it’s hole. But by and large the underworld was defeated and left far behind. Moving to cloud hosting and simplifying were finally the spell that broke the Fiddler curse and freed us from the underworld. Our business’s core service was stable and safe and running like it should be. We could start growing again! It was such a relief!</p>
<p>To reiterate some of the illumination gained on my journey: simplify your WordPress websites and hosting through offloading everything you can to experts who do it better, often for cheaper (if you properly calculate the value of your own time). Focus on your super-power whether it be design or development, or just creating solutions on WP with existing plugins and tools. If your super-power isn’t WordPress at all, you can outsource maintenance, content updates, backups and security, plugin and core updates, and much more to a company like <a href=\"https://wordx.press\">WordXpress</a>. I’ve built this company based on the knowledge and tools I learned on my quest.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: My &#8220;Hero&#8217;s Journey&#8221; Through the Dark Underworld of WordPress Hosting\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=My%20%22Hero%27s%20Journey%22%20Through%20the%20Dark%20Underworld%20of%20WordPress%20Hosting&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fmy-heros-journey-through-the-dark-underworld-of-wordpress-hosting%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: My &#8220;Hero&#8217;s Journey&#8221; Through the Dark Underworld of WordPress Hosting\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fmy-heros-journey-through-the-dark-underworld-of-wordpress-hosting%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fmy-heros-journey-through-the-dark-underworld-of-wordpress-hosting%2F&title=My+%26%238220%3BHero%26%238217%3Bs+Journey%26%238221%3B+Through+the+Dark+Underworld+of+WordPress+Hosting\" rel=\"nofollow\" target=\"_blank\" title=\"Share: My &#8220;Hero&#8217;s Journey&#8221; Through the Dark Underworld of WordPress Hosting\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/my-heros-journey-through-the-dark-underworld-of-wordpress-hosting/\" title=\"My &#8220;Hero&#8217;s Journey&#8221; Through the Dark Underworld of WordPress Hosting\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/my-heros-journey-through-the-dark-underworld-of-wordpress-hosting/\">My &#8220;Hero&#8217;s Journey&#8221; Through the Dark Underworld of WordPress Hosting</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 12 Jun 2019 12:00:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Tevya Washburn\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: Drupal Gutenberg 1.0 Released, Now Ready for Production Sites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90376\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/drupal-gutenberg-1-0-released-now-ready-for-production-sites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6201:\"<p>The <a href=\"https://www.drupal.org/project/gutenberg\" rel=\"noopener noreferrer\" target=\"_blank\">Gutenberg module for Drupal</a>, created by <a href=\"https://www.frontkom.no/\" rel=\"noopener noreferrer\" target=\"_blank\">Frontkom</a>, reached the 1.0 milestone earlier this month. It is the first stable release recommended for use in production with Drupal 8.x. </p>
<p>The 1.0 release removes the Gutenberg-JS dependency and uses Gutenberg core files directly. It is based on Gutenberg <a href=\"https://make.wordpress.org/core/2019/05/01/whats-new-in-gutenberg-1st-may/\" rel=\"noopener noreferrer\" target=\"_blank\">version 5.6.1</a>, which was released in early May. The module boasts better handling for media files, adding support for title, caption, and alternative text. It also adds an &#8220;Allowed Blocks UI&#8221; to the content type admin UI, so administrators can restrict which blocks show up in the block selector.</p>
<p>&#8220;We’re now ready for production sites in the sense that we’ll be more careful with structure changes, will try to do update paths when possible, and will create automated tests for crucial functionality,&#8221; Frontkom project manager Thor Andre Gretland said. &#8220;We’ve solved the blockers for a stable release.&#8221;</p>
<p>Upgrading the module from RC-1 may require some extra steps, because it is a big jump, taking the Gutenberg library from 4.8.0 to 5.6.1. Users will need to update the database. It is also necessary to navigate to content types and click save to enable Gutenberg again so that it will begin storing the Allowed blocks in the database. If users get notices about invalid blocks, they are advised to try the Attempt Block Recovery option:</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/05/attempt-block-recovery.png?ssl=1\"><img /></a></p>
<p>&#8220;It’s actually a rather large update,&#8221; Gretland said. &#8220;We were planning to add a couple of last needed features to release our 1.0 version, but ended up using the latest Gutenberg version with several new great features. We’re also using more of the Gutenberg Core, that we’ve been able to use before.&#8221; </p>
<p>The module still has one critical issue that Frontkom is working on. <a href=\"https://www.drupal.org/project/gutenberg/issues/3059167\" rel=\"noopener noreferrer\" target=\"_blank\">Reusable blocks are not working</a> with the latest release. Users are getting a &#8220;this block is unavailable or deleted&#8221; message when attempting to insert a reusable block. In the meantime, those who require this feature can roll back to RC1 to get it working again.</p>
<p>So far the Gutenberg module has been well-received. It has been downloaded more than 12,000 times and 494 sites are reported to be using it.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Setup <a href=\"https://twitter.com/drupalgutenberg?ref_src=twsrc%5Etfw\">@drupalgutenberg</a> on D8 yesterday (following meeting one of <a href=\"https://twitter.com/frontkom?ref_src=twsrc%5Etfw\">@frontkom</a> at the recent Dutch <a href=\"https://twitter.com/hashtag/CiviCRM?src=hash&ref_src=twsrc%5Etfw\">#CiviCRM</a> sprint) and was pretty blown away. Bringing Medium-style editing to all the CMSs &amp; then some. If <a href=\"https://twitter.com/hashtag/Joomla?src=hash&ref_src=twsrc%5Etfw\">#Joomla</a> doesn’t implement a Gutenberg.js integration we/they’ll be left behind. <a href=\"https://t.co/SfieuGfOlf\">https://t.co/SfieuGfOlf</a></p>
<p>&mdash; Nicol (@netribution) <a href=\"https://twitter.com/netribution/status/1133268870112972800?ref_src=twsrc%5Etfw\">May 28, 2019</a></p></blockquote>
<p></p>
<p>Drupal&#8217;s Gutenberg module includes access to the <a href=\"https://gutenbergcloud.org/blocks\" rel=\"noopener noreferrer\" target=\"_blank\">Gutenberg Cloud</a> library of free blocks. Although the library has been slow to gain contributors, it does contain several blocks that are helpful for creating page layouts, such as Content in Columns, Hero Section, Section Wrapper, Section Row, and a Feature Box block. Site administrators can also use the Gutenberg module in combination with Drupal&#8217;s new Layout Builder, which was introduced as a stable module to Drupal 8.7 core.</p>
<p>&#8220;We see a valid use case for mixing Drupal Gutenberg with the Drupal layout builder when you might want to create layout templates with the layout builder, and keep the actual content editing in Gutenberg,&#8221; Gretland said. &#8220;For example you could use the layout builder to define fixed byline elements for author and create date, but leave the actual content creation experience to Gutenberg.&#8221;</p>
<p>There are a few limitations to using the two tools together. The only way to use them on the same project is if they deal with different content types.  </p>
<p>&#8220;Since Drupal Gutenberg takes over the whole node UI, it can have some unexpected effects when used together with Layout Builder,&#8221; Gretland said. &#8220;That doesn’t mean that they won’t ever &#8216;work&#8217; together. One idea could be using the LB data structure to generate Gutenberg fixed layouts/templates and even save Gutenberg data in a structured way handled by Layout Builder.&#8221;</p>
<p>Gretland said his team believes Gutenberg delivers a better editing experience than Layout Builder, as it is a more mature project. However, Layout Builder stores its data in a structured way, which has its advantages and disadvantages over Gutenberg.</p>
<p>WebWash has a good <a href=\"https://www.webwash.net/create-pages-using-gutenberg-wordpress-editor-in-drupal/\" rel=\"noopener noreferrer\" target=\"_blank\">video tutorial</a> for Drupal users who want to learn how to configure the Gutenberg module and use it on the Page content type. It includes a walkthrough for common actions like uploading images, creating reusable blocks, and using the Gutenberg Cloud. If you want to see how Gutenberg can improve Drupal&#8217;s authoring experience without installing the module, check out the <a href=\"https://drupalgutenberg.org/demo\" rel=\"noopener noreferrer\" target=\"_blank\">frontend demo of Drupal Gutenberg</a> created by the team at Frontkom.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Jun 2019 23:03:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"WPTavern: WP Engine Launches DevKit Open Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90715\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wptavern.com/wp-engine-launches-devkit-open-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2627:\"<p>Those who host or manage sites on WP Engine now have a <a href=\"https://wpengine.com/blog/wp-engine-launches-devkit-to-offer-best-developer-experience-in-wordpress-today/\">new tool</a> at their disposal. It&#8217;s called <a href=\"https://wpengine.com/devkit/\">DevKit</a>, developed by Chris Wiegman and Jason Stallings. </p>



<p>DevKit is a WordPress local development environment that includes SSH Gateway access, push and pull deployments to WP Engine, Command Line Interface commands for the Genesis theme framework and other tools.</p>



<p>Although DevKit has tight integration with WP Engine the software can be used independently of the host. With <a href=\"https://localbyflywheel.com/\">Local by Flywheel</a>, <a href=\"https://www.vagrantup.com/\">Vagrant</a>, <a href=\"https://www.apachefriends.org/index.html\">XAMPP</a>, and other tools available, Wiegman explains what motivated him to create a new solution.</p>



<p>&#8220;I&#8217;ve been working on the perfect WordPress developer environment since I learned about Vagrant in 2013,&#8221; he said. &#8220;As it was never my full-time job, I could never take it to the next level. DevKit gives me the power to do that.&#8221;</p>



<p>Stallings added, &#8220;We wanted to build a kick ass set of tools for developers building on WP Engine. That’s been our mission from the start, build something that all developers want to use (including us)!&#8221; </p>



<p>As what for what sets DevKit apart from the others, &#8220;I think our architecture is very different from both tools,&#8221; Stallings said. </p>



<p>&#8220;Similar to Docker Engine, DevKit CLI is the interface to DevKit. So when we build the GUI it will 100% complement the CLI, and the two can be used interchangeably. This will enable us to build other interfaces in the future too.&#8221;</p>



<p>DevKit provides the following features:</p>



<ul><li>Container-based local development environment</li><li>SSH Gateway access</li><li>Push and pull deployments to WP Engine</li><li>Preview your local site with others via ngrok</li><li>PHP version selector</li><li>Email testing client</li><li>MySQL</li><li>Local SSH &amp; WP-CLI</li><li>Genesis Framework WP-CLI commands</li><li>phpmyadmin</li><li>webgrind</li><li>Varnish</li><li>HTTPS Proxy</li><li>xdebug</li></ul>



<p>Currently, DevKit&#8217;s user interface is command line only with plans to add a GUI later this year. It&#8217;s available for free and is in open beta for Mac and Linux. Those interested in participating in the open beta can sign up on the <a href=\"https://wpengine.com/devkit/\">DevKit landing page</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Jun 2019 20:12:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Former npm, Inc. CTO Announces Entropic, a Decentralized Package Registry\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90574\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://wptavern.com/former-npm-inc-cto-announces-entropic-a-decentralized-package-registry\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4561:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/06/entropic-announcement-jsconf-eu.png?ssl=1\"><img /></a></p>
<p><a href=\"https://twitter.com/ceejbot/\" rel=\"noopener noreferrer\" target=\"_blank\">CJ Silverio</a>, former CTO of npm Inc., gave a presentation at <a href=\"https://2019.jsconf.eu/\" rel=\"noopener noreferrer\" target=\"_blank\">JSConf EU 2019</a> in Berlin earlier this month titled &#8220;The Economics of Open Source.&#8221; More specifically, she discussed the economics of package management as it applies to open source software, based on her unique perspective and experience gained in working for the company that runs the world&#8217;s largest JavaScript package registry.</p>
<p>Silverio tells the story of how npm gained official status and characterizes its success as a catastrophe for a centralized package registry and repository. Although centralization has some advantages for usability and reliability, success can be expensive when a centralized service becomes popular. She described the events leading up to npm&#8217;s incorporation in 2013. The registry was down more than it was up in October 2013 and npm needed money.</p>
<p>npm&#8217;s owner took seed funding from a VC firm and the Node project continued to give npm special privileges. Developers perpetuated this by continuing to use npm, as over time it had come to define developers&#8217; expectations in serving JavaScript packages. Silverio discusses some of the consequences of npm coming under private control, how developers now have no input into registry policies or how disputes are resolved. </p>
<p>Presumably speaking from her intimate knowledge of the company&#8217;s inner workings, Silverio describes how VC-funding turned npm Inc. into a financial instrument.</p>
<p>&#8220;Financial instruments are contracts about money,&#8221; she said. &#8220;npm Inc, the company that owns our language ecosystem, is a thing that might as well be a collection of pork bellies, as far as its owners are concerned. They make contracts with each other and trade bits of it around. npm Inc. is a means for turning money into more money.&#8221;</p>
<p>Silverio contends that JavaScript&#8217;s package registry should not be privately controlled and that centralization is a burden that will inevitably lead to private control because the servers cost money. </p>
<p>Her sharp criticism of centralized package management leads into her announcement of a federated, decentralized package registry called <a href=\"https://github.com/entropic-dev\" rel=\"noopener noreferrer\" target=\"_blank\">Entropic</a> that she created with former npm colleague Chris Dickinson and more than a dozen contributors. The project is Apache 2.0 licensed and its creators are working in cooperation with the <a href=\"https://openjsf.org/\" rel=\"noopener noreferrer\" target=\"_blank\">OpenJS Foundation</a>. </p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Warming my heart right now: how many former npm-ers are contributing to entropic &lt;3</p>
<p>&mdash; Ceej is on vacation (@ceejbot) <a href=\"https://twitter.com/ceejbot/status/1136551537835032577?ref_src=twsrc%5Etfw\">June 6, 2019</a></p></blockquote>
<p></p>
<p>Entropic comes with its own CLI, and offers a new file-centric publication API. All packages published to the registry are public and developers are encouraged to use something like the GitHub Package Registry if they need to control access to packages. The project is just over a month old and is not ready for use. </p>
<p>&#8220;I think it’s right that the pendulum is swinging away from centralization and I want to lend my push to the swing,&#8221; Silverio said. The last decade has been about consolidation and monolithic services, but the coming decade is going to be federated. Federation spreads out costs. It spreads out control. It spreads out policy-making. It hands control of your slice of our language ecosystem to you. My hope is that by giving Entropic away, I’ll help us take our language commons back.&#8221;</p>
<p>Silverio&#8217;s <a href=\"https://github.com/ceejbot/economics-of-package-management/blob/master/essay.md\" rel=\"noopener noreferrer\" target=\"_blank\">Economics of Package Management</a> essay is available on GitHub. Check out the video of the presentation from JSConf EU below. If decentralized package management gains momentum and becomes the standard for the industry, this video captures what may become a turning point in the JavaScript ecosystem and a defining moment for the future of the web.</p>
<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Jun 2019 03:41:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: BuddyPress 5.0 to Update Password Control to Match WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90023\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/buddypress-5-0-to-update-password-control-to-match-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3462:\"<p>BuddyPress 5.0 development began in December 2018 after <a href=\"https://buddypress.org/2018/11/buddypress-4-0-0-pequod/\" rel=\"noopener noreferrer\" target=\"_blank\">4.0.0 was released</a> in November. The core BuddyPress team has not published a roadmap for what will be coming in 5.0, but features and fixes added so far can be found on GitHub in the <a href=\"https://github.com/buddypress/BuddyPress/commits/master\" rel=\"noopener noreferrer\" target=\"_blank\">commit log</a>. </p>
<p>One noteworthy addition to the upcoming major release is that the BP Nouveau template pack is being <a href=\"https://buddypress.trac.wordpress.org/changeset/12397\" rel=\"noopener noreferrer\" target=\"_blank\">updated to use the same password control as the one used in WordPress core</a>. BuddyPress users will now be able to set their passwords using WordPress&#8217; interface on the registration page and on the user&#8217;s general settings page. </p>
<p>Here&#8217;s what it will look like in the templates:</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Here\'s how it looks <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f4fd.png\" alt=\"📽\" class=\"wp-smiley\" /> <a href=\"https://t.co/g8DknNpUKl\">pic.twitter.com/g8DknNpUKl</a></p>
<p>&mdash; imath (@imath) <a href=\"https://twitter.com/imath/status/1129668922024845313?ref_src=twsrc%5Etfw\">May 18, 2019</a></p></blockquote>
<p></p>
<p>By default, BuddyPress will generate a strong password, but the user can still edit it, if necessary. If the user selects a password that is too weak, the submit button will be disabled until the user confirms they want to proceed by checking the checkbox.</p>
<p>BP Nouveau <a href=\"https://codex.buddypress.org/releases/version-3-0-0/\" rel=\"noopener noreferrer\" target=\"_blank\">replaced the bp-legacy template packs in 2018</a>, introducing JavaScript-powered templates, integration with the Customizer, and more layout options for BuddyPress navigation and component directories. As a result of the password control update, the src/bp-templates/bp-nouveau/js/password-verify.js template is scheduled to be deprecated and deleted in BuddyPress 6.0.0, so developers will want to take note if using the bp-nouveau-password-verify script as a dependency for custom password control implementations.</p>
<p>BuddyPress 5.0 also <a href=\"https://wptavern.com/buddypress-5-0-to-display-debug-info-in-the-new-site-health-info-screen\" rel=\"noopener noreferrer\" target=\"_blank\">adds BP-specific debug into to the Site Health Info screen</a> that was introduced in WordPress 5.2. This release will <a href=\"https://buddypress.trac.wordpress.org/ticket/8025\" rel=\"noopener noreferrer\" target=\"_blank\">require WordPress 4.7 or greater</a> for <a href=\"https://codex.buddypress.org/getting-started/wordpress-version-compatibility/\" rel=\"noopener noreferrer\" target=\"_blank\">optimal compatibility</a> and older versions will not be supported. Site owners running on older versions of WordPress have time to prepare.</p>
<p>Although the BuddyPress core team and contributors have put out several security and maintenance releases since version 4.0.0, regular project meetings have been sporadic in 2019. BuddyPress 5.0 was <a href=\"https://buddypress.trac.wordpress.org/milestone/5.0.0\" rel=\"noopener noreferrer\" target=\"_blank\">expected at the end of May</a> but a new timeline may be discussed at the next meeting, which is tentatively planned for Wednesday, June 12.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 Jun 2019 19:04:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"WPTavern: In Case You Missed It – Issue 25\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wptavern.com/?p=90643&preview=true&preview_id=90643\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wptavern.com/in-case-you-missed-it-issue-25\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7707:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png?ssl=1\" rel=\"attachment wp-att-50955\"><img /></a>photo credit: <a href=\"http://www.flickr.com/photos/112901923@N07/16153818039\">Night Moves</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc/2.0/\">(license)</a></p>
<p>There’s a lot of great WordPress content published in the community but not all of it is featured on the Tavern. This post is an assortment of items related to WordPress that caught my eye but didn’t make it into a full post.</p>
<h2>Open Call for People Interested in Being Team Leads</h2>
<p>Josepha Haden has <a href=\"https://make.wordpress.org/updates/2019/06/03/team-lead-interest-post/\">published an open call</a> on the Team Updates blog looking for people interested in learning about the Team Lead role. The post includes links to training materials that will be open for two weeks where people can make suggestions.</p>
<p>Once the training materials are complete, interested parties will be sent the team leads training materials and quizzes. Those who pass the quizzes will then be part of a group orientation in which team leads and future leads will be chosen. Even if you&#8217;re not interested in becoming a team lead, the training materials in the post contain a lot of useful information about the inner workings of the project.</p>
<h2>Marcel Bootsman Continues on After Hospital Visit</h2>
<p>Marcel Bootsman who is walking more than 700km to Berlin, Germany for WCEU recently <a href=\"https://walktowc.eu/2019/06/04/day-17-rest-day-and-many-thanks-to-meindl/\">made a hospital visit</a>. &#8220;The doctor asked about what I’m doing, and what the problem is, so I explained everything,&#8221; Bootsman said. &#8220;She examined both legs and found that there was a swelling on my right ankle. She sadly could not diagnose further, since it’s impossible. An expert has to look at it, and an x-ray picture has to be taken.&#8221;</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">YESS! Nothing serious, just an overloaded ankle which is almost healed. <br />Doctor said I can continue with just one more resting day, so I\'m going by train to my next stop. Just to be of extra help he bandaged my ankle.<a href=\"https://twitter.com/hashtag/WalkToWCEU?src=hash&ref_src=twsrc%5Etfw\">#WalkToWCEU</a> <a href=\"https://t.co/VdW7C8m71N\">pic.twitter.com/VdW7C8m71N</a></p>
<p>&mdash; <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f6b6-1f3fc.png\" alt=\"🚶🏼\" class=\"wp-smiley\" /> Marcel Bootsman (@mbootsman) <a href=\"https://twitter.com/mbootsman/status/1136187513251532800?ref_src=twsrc%5Etfw\">June 5, 2019</a></p></blockquote>
<p></p>
<p>The doctor diagnosed him with having an overloaded right ankle. After wrapping his ankle for extra support, Bootsman continued on. Check out <a href=\"https://walktowc.eu/2019/06/06/day-19-meine/\">his description and photos</a> from day 19 of his travels.</p>
<h2>WooSesh is Coming Back</h2>
<p><a href=\"https://woosesh.com/\">WooSesh</a>, a global, virtual conference devoted to WooCommerce, is scheduled to take place on October 9-10th. You can follow <a href=\"https://twitter.com/WooSesh_\">WooSesh_</a> on Twitter or sign up to their email list to be notified of when tickets are available.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">ANNOUNCEMENT: If you use <a href=\"https://twitter.com/WooCommerce?ref_src=twsrc%5Etfw\">@WooCommerce</a> to build ecommerce sites, or do any kind of ecommerce development, you\'ll be thrilled to hear that <a href=\"https://twitter.com/woosesh?ref_src=twsrc%5Etfw\">@WooSesh</a> returns on Oct 9 and 10!</p>
<p>Follow <a href=\"https://twitter.com/WooSesh_?ref_src=twsrc%5Etfw\">@WooSesh_</a> and join the mailing list at <a href=\"https://t.co/Pyev9v2CPv\">https://t.co/Pyev9v2CPv</a> to stay in the loop <a href=\"https://t.co/hPdv8Yu5LU\">pic.twitter.com/hPdv8Yu5LU</a></p>
<p>&mdash; WordSesh (@WordSesh) <a href=\"https://twitter.com/WordSesh/status/1131365096872189953?ref_src=twsrc%5Etfw\">May 23, 2019</a></p></blockquote>
<p></p>
<h2>GitHub Repo Templates</h2>
<p>Earlier this week, GitHub <a href=\"https://github.blog/2019-06-06-generate-new-repositories-with-repository-templates/?utm_campaign=1559837005&utm_medium=social&utm_source=twitter&utm_content=1559837005\">launched Repository Templates</a> to help developers manage and distribute boilerplate code. Web development agency 10UP has a <a href=\"https://github.com/10up/theme-scaffold\">Theme</a> and <a href=\"https://github.com/10up/plugin-scaffold\">Plugin</a> repo template that is available for anyone to use.</p>
<h2>WordPress 5.2.2 Release Date Changed</h2>
<p>WordPress 5.2.2 was <a href=\"https://make.wordpress.org/core/2019/06/01/some-changes-to-the-5-2-2-release-schedule/\">originally scheduled</a> to be released on June 13th, but the release team has decided to <a href=\"https://make.wordpress.org/core/2019/06/06/dev-chat-summary-05-june/\">push the date back</a>. Tickets that are slated for WordPress 5.3 that meet the requirements to be in a minor release will be merged into 5.2.2. The new release date is Tuesday, June 18th, a few days before WordCamp EU.</p>
<h2>WordCamp US After Party Is Now Wordfest</h2>
<p>There won&#8217;t be a big after party at the conclusion of WordCamp US this year. Instead, organizers are <a href=\"https://2019.us.wordcamp.org/2019/06/07/wordfest-will-be-held-at-city-museum/\">hosting WordFest</a> on Friday, November 1, 2019, at <a href=\"https://www.citymuseum.org/\">City Museum in St. Louis</a>. According to organizers, the party doesn&#8217;t always have to be at the conclusion of the event thus the name change.</p>
<h2>How to Use and Create Reusable Block Templates</h2>
<p>Justin Tadlock has <a href=\"https://themehybrid.com/weblog/reusable-blocks-as-templates\">published a tutorial</a> that explains how to create, use, import, and export reusable block templates in WordPress.</p>
<p>&#8220;A lot of this is not intuitive at this point and might take some digging for someone not intimately familiar with all the block editor features. But, this is an extremely powerful feature that I’m sure will become more useful in the future. I can even see things like theme authors sharing reusable blocks to help users build out certain page designs.&#8221;</p>
<p>I&#8217;m looking forward to seeing other people share their reusable blocks or templates. One of the beautiful things about the new editor is that it doesn&#8217;t require a developer to sort blocks into a particular layout and then save it as a reusable block that can be shared.</p>
<h2>C02 May Be the Cause of Feeling Drowsy During Conference Sessions</h2>
<p>I always thought it had something to do with lunch but I&#8217;ve felt drowsy before then. Interesting data shared in a Twitter thread. Hat tip to <a href=\"https://twitter.com/dimensionmedia\">David Bisset</a>.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Ever wonder why you get so sleepy during conference talks? Turns out lots of conference venues aren\'t well-ventilated, causing CO2 to rise to levels that cause drowsiness (&gt;1000ppm). Data from <a href=\"https://twitter.com/keflavich?ref_src=twsrc%5Etfw\">@keflavich</a> shows this steady rise over the first 50min of a conference session. <a href=\"https://t.co/AjFO2eQDrJ\">pic.twitter.com/AjFO2eQDrJ</a></p>
<p>&mdash; Cara Battersby (@battersbot) <a href=\"https://twitter.com/battersbot/status/1135926829813063680?ref_src=twsrc%5Etfw\">June 4, 2019</a></p></blockquote>
<p></p>
<p>That&#8217;s it for issue twenty-five. If you recently discovered a cool resource or post related to WordPress, please share it with us in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Jun 2019 21:33:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Experimenting With Reusable Blocks to Create Post Templates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90636\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://wptavern.com/experimenting-with-reusable-blocks-to-create-post-templates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2177:\"<p>For the past several years, I&#8217;ve used the Post Template plugin developed by Vincent Prat to create and manage post templates. For example, some of the information in the <a href=\"https://wptavern.com/category/wordpress-weekly\">WordPress Weekly</a> and <a href=\"https://wptavern.com/category/icymi\">In Case You Missed It</a> posts never changes and instead of manually entering it each time, it&#8217;s nice to use a template where only a few changes are necessary. </p>



<p>The other day, I was wondering if I could use the reusable block feature in Gutenberg to replace the plugin. Justin Tadlock reached out and provided me a reusable block template JSON file that I imported into Gutenberg. By the way, if you successfully import a block into WordPress, the block won&#8217;t appear until you manually refresh the page. </p>



<p>The reusable block template approach works fairly well. However, I noticed that I was unable to add a block inside the reusable block. When I tried, a red line was displayed and any blocks that were inserted were removed. </p>



<div class=\"wp-block-image\"><img />Red Means No</div>



<p>I understand that reusable blocks are meant to be restricted templates where changes are distributed across a site to wherever the block is displayed. But it&#8217;s still a bummer that I can&#8217;t add a block inside the template for a singular purpose if a need arises. </p>



<p>One other thing I noticed is that reusable blocks are custom post types. While there is a link to manage them within the reusable block selector, there isn&#8217;t a dedicated item within the admin menu. Unless you know the location of the management link, adding and managing them can be a bit more time-consuming. </p>



<p>If you want a quick shortcut to the reusable block management screen, add this to the URL after your domain name. wp-admin/edit.php?post_type=wp_block</p>



<p>I think I&#8217;ll experiment with reusable blocks a bit more but as long as they&#8217;re not changing often, I believe they&#8217;ll make a nice replacement for the Post Templates plugin. What use cases have you encountered where reusable blocks were the solution?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Jun 2019 02:13:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: Branch Continuous Integration Service Selected for TinySeed Startup Accelerator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90611\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"https://wptavern.com/branch-continuous-integration-service-selected-for-tinyseed-startup-accelerator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4298:\"<p><a href=\"https://branchci.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Branch</a>, a Docker-based continuous integration service for WordPress, has been selected for <a href=\"https://tinyseed.com\" rel=\"noopener noreferrer\" target=\"_blank\">TinySeed&#8217;s startup accelerator</a>. The company was founded by Peter Suhm who is also the creator of <a href=\"https://wppusher.com/\" rel=\"noopener noreferrer\" target=\"_blank\">WP Pusher</a>, a plugin that lets developers install and update WordPress themes and plugins directly from GitHub, Bitbucket, and GitLab.</p>
<p>TinySeed, founded by <a href=\"https://robwalling.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Rob Walling</a> and <a href=\"https://www.vollset.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Einar Vollset</a>, is a remote accelerator that focuses on providing enough funding for early-stage SaaS founders to live for a year and focus full-time on their startups. It advertises itself as &#8220;the first startup accelerator designed for bootstrappers.&#8221; TinySeed is unique in that it does not have a bias against single founders. The website states that the majority of successful $1m-$30m SaaS companies that TinySeed is connected with were started by founders working alone. </p>
<p>Branch fits the bill as a SaaS company with a single founder and no employees. As part of the investment terms, TinySeed invests $120k for the first founder (plus $20k per additional founder) in exchange for 8-15% equity. If founders do not need the money for living expenses they are free to spend it on growing the business. Both Branch and WP Pusher are included in Suhm&#8217;s participation in TinySeed.</p>
<p>&#8220;WP Pusher was doing just enough to pay my bills living in a fairly cheap city (Glasgow), but not enough to pay a full time developer salary,&#8221; Suhm said. &#8220;However, I didn&#8217;t spend much time on WP Pusher in the past few years and was working part time for other companies &#8211; mainly <a href=\"https://www.timekit.io/\" rel=\"noopener noreferrer\" target=\"_blank\">Timekit</a> as a backend developer.&#8221;</p>
<p>Suhm said the TinySeed investment will allow him to work full time on Branch and WP Pusher for at least a year or two without having to worry about making a salary.</p>
<p>&#8220;I may also decide to make a hire during the program, but I want the product to be a little bit more mature,&#8221; he said. &#8220;In terms of the roadmap, I&#8217;ll be able to focus more on building the best tool and less about making a lot of money in the beginning.&#8221;</p>
<p>Branch and WP Pusher are fairly unique products in the WordPress space. Suhm said he sees most of his competition coming from continuous integration services that are not tailored to WordPress.</p>
<p>&#8220;However, my biggest competitor at the moment is probably manual labor &#8211; WordPress developers testing and deploying everything manually,&#8221; Suhm said.</p>
<p>TinySeed received approximately 900 applications from which they will select 10-15 companies for participation in 2019. Co-founder Rob Walling has knowledge of the WordPress ecosystem, as he previously <a href=\"https://wpengine.com/blog/wp-engine-closes-1-2m-in-series-a-financing/\">invested in WP Engine&#8217;s 2011 round of funding</a>. </p>
<p>&#8220;Peter has a distinct advantage with Branch in that he&#8217;s building on the audience, customer base, and domain knowledge he&#8217;s developed with WP Pusher,&#8221; TinySeed co-founder Rob Walling said. &#8220;His methodical approach to shipping code and content every week has been a good signal for us that he&#8217;s pushing the product forward, as well as a key factor in building Branch&#8217;s traction in the space.&#8221;</p>
<p>Branch is joining a handful of other SaaS companies that have already been selected for 2019, including <a href=\"https://clientsherpa.com/\" rel=\"noopener noreferrer\" target=\"_blank\">ClientSherpa</a>, <a href=\"https://gatherit.co/\" rel=\"noopener noreferrer\" target=\"_blank\">Gather</a>, <a href=\"https://simsaas.co/\" rel=\"noopener noreferrer\" target=\"_blank\">SimSaaS</a>, <a href=\"https://www.reimbi.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Reimbi</a>, and <a href=\"https://castos.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Castos</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Jun 2019 20:31:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"WPTavern: Automattic Adopts Alex Mills’ Plugins\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=90583\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wptavern.com/automattic-adopts-alex-mills-plugins\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4656:\"<p>Automattic <a href=\"https://developer.wordpress.com/2019/06/06/taking-care-of-alexs-plugins/\" rel=\"noopener noreferrer\" target=\"_blank\">announced</a> today that a team inside the company will be adopting <a href=\"https://alex.blog/\" rel=\"noopener noreferrer\" target=\"_blank\">Alex Mills</a>&#8216; plugins and continuing their development and support. Mills, also known around the web as @Viper007Bond, was a WordPress core contributor and prolific plugin developer who passed away in February 2019 after a battle with Leukemia. </p>
<p>At one time last year, Mills was the primary author for and contributor to <a href=\"https://web.archive.org/web/20181231163744/https://profiles.wordpress.org/viper007bond/#content-plugins\" rel=\"noopener noreferrer\" target=\"_blank\">more than 40 plugins</a> hosted on WordPress.org. The <a href=\"https://profiles.wordpress.org/viper007bond/#content-plugins\" rel=\"noopener noreferrer\" target=\"_blank\">current collection</a> seems to have been pared back to 17 of his most popular plugins. According to <a href=\"http://wptally.com/?wpusername=viper007bond\" rel=\"noopener noreferrer\" target=\"_blank\">stats from WP Tally</a>, these 17 plugins have a cumulative download count of 138,665,603 and a cumulative rating of 4.55 out of 5 stars.</p>
<p>&#8220;Since all of my plugins are open-source, they are free to be forked by reputable authors in the WordPress community. It would mean a lot to have my legacy go on,&#8221; Mills said in his <a href=\"https://alex.blog/2019/02/18/leukemia-has-won/\" rel=\"noopener noreferrer\" target=\"_blank\">farewell post</a> earlier this year. The plugins are all free without any pro versions or monetization efforts attached to them.</p>
<p>“I’d never monetize any of my plugins,” Mills told the Tavern after his popular Regenerate Thumbnails plugin <a href=\"https://wptavern.com/regenerate-thumbnails-plugin-passes-5-million-downloads-rewrite-in-the-works\" rel=\"noopener noreferrer\" target=\"_blank\">passed 5 million downloads</a> in 2017. “I write them for fun not profit. It would be a conflict of interest anyway due to my employment at Automattic.”</p>
<p>Regenerate Thumbnails is active on more than a million WordPress sites and <a href=\"https://alex.blog/2019/01/29/my-regenerate-thumbnails-plugin-passes-10m-downloads/\" rel=\"noopener noreferrer\" target=\"_blank\">passed the 10 million downloads milestone</a> in January 2019. It has already been downloaded more than 7,000 times today and has regularly received 3K-12k downloads per day throughout 2019. </p>
<p>The enduring popularity of <a href=\"https://wordpress.org/plugins/regenerate-thumbnails/\" rel=\"noopener noreferrer\" target=\"_blank\">Regenerate Thumbnails</a> is a testament to Mills&#8217; commitment to writing future-proof plugins. What started as a small plugin to fix a client&#8217;s problem in 2008 quickly became an indispensable utility for millions of WordPress users transitioning between themes with different image sizes. For those users who could never write their own script to generate new thumbnail sizes, Mills&#8217; plugin was a little piece of time-saving magic that exemplifies the significant contributions plugin developers can make when they write and share code that solves a common problem.</p>
<p>Automattic plans to fork each of Mills&#8217; GitHub repositories and will add them to the Automattic Github account. The team behind this effort is also adding the following paragraph to each plugin&#8217;s readme file:</p>
<blockquote><p>In February 2019 Alex Mills, the author of this plugin, <a href=\"https://alex.blog/2019/02/27/from-alexs-family/\" rel=\"noopener noreferrer\" target=\"_blank\">passed away</a>. He leaves behind a number of plugins which will be maintained by Automattic and members of the WordPress community. If this plugin is useful to you please consider <a href=\"https://alex.blog/2019/03/13/in-memory-of-alex-donation-link-update/\" rel=\"noopener noreferrer\" target=\"_blank\">donating to the Oregon Health and Science University</a>.</p></blockquote>
<p>Automattic will also be answering support queries on the forums and the team is open to receiving help from other members of the WordPress community in maintaining and supporting Mills&#8217; plugins. </p>
<p>&#8220;In times gone by authors left works of music, novels, poetry, and letters on their passing,&#8221; Donncha Ó Caoimh said on the Automattic Engineering blog. &#8220;They were static works of art frozen in time. Alex leaves behind his code that will continue to evolve and operate in a living world used by thousands (millions?) of people every day as they go about their online lives.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Jun 2019 16:51:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Wed, 03 Jul 2019 13:46:58 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Wed, 03 Jul 2019 13:30:48 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("7966","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1562204818","no");
INSERT INTO `wp_options` VALUES("7967","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1562161618","no");
INSERT INTO `wp_options` VALUES("7968","_transient_timeout_dash_v2_f69de0bbfe7eaa113146875f40c02000","1562204818","no");
INSERT INTO `wp_options` VALUES("7969","_transient_dash_v2_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2019/05/wordpress-translation-day-4-%D1%81%D0%B0%D0%BD%D0%BA%D1%82-%D0%BF%D0%B5%D1%82%D0%B5%D1%80%D0%B1%D1%83%D1%80%D0%B3/\'>WordPress Translation Day 4 — Санкт-Петербург</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://heropress.com/essays/i-am-cookie-dough/#utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=i-am-cookie-dough\'>HeroPress: I Am Cookie Dough</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/walking-748km-to-wceu-an-interview-with-marcel-bootsman\'>WPTavern: Walking 718km to WCEU, an Interview With Marcel Bootsman</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/msgwp-to-launch-plugin-enabling-wordpress-microblogging-with-telegram\'>WPTavern: msgWP to Launch Plugin Enabling WordPress Microblogging with Telegram</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("7970","_transient_timeout_wc_upgrade_notice_3.6.5","1562248020","no");
INSERT INTO `wp_options` VALUES("7971","_transient_wc_upgrade_notice_3.6.5","","no");
INSERT INTO `wp_options` VALUES("7974","_transient_timeout__woocommerce_helper_updates","1562204835","no");
INSERT INTO `wp_options` VALUES("7975","_transient__woocommerce_helper_updates","a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1562161635;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}","no");
INSERT INTO `wp_options` VALUES("7978","aiowps_temp_configs","a:91:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"y9t13745ja38h0dirf5q\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-06-22 16:46:44\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("7984","_transient_timeout_berocket_framework_plugin_is_active_6","1562184786","no");
INSERT INTO `wp_options` VALUES("7985","_transient_berocket_framework_plugin_is_active_6","3","no");
INSERT INTO `wp_options` VALUES("7988","_transient_wc_attribute_taxonomies","a:2:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"2\";s:14:\"attribute_name\";s:8:\"plotnost\";s:15:\"attribute_label\";s:18:\"Плотность\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"1\";}i:1;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"5\";s:14:\"attribute_name\";s:5:\"tsvet\";s:15:\"attribute_label\";s:8:\"Цвет\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}","yes");
INSERT INTO `wp_options` VALUES("7993","woocommerce_version","3.5.7","yes");
INSERT INTO `wp_options` VALUES("7994","woocommerce_db_version","3.5.7","yes");
INSERT INTO `wp_options` VALUES("7995","_transient_timeout_users_online","1562179386","no");
INSERT INTO `wp_options` VALUES("7996","_transient_users_online","a:0:{}","no");
INSERT INTO `wp_options` VALUES("7997","_transient_doing_cron","1562510910.1738440990447998046875","yes");
INSERT INTO `wp_options` VALUES("7998","_transient_timeout_wc_layered_nav_counts_pa_tsvet","1562597311","no");
INSERT INTO `wp_options` VALUES("7999","_transient_wc_layered_nav_counts_pa_tsvet","a:2:{i:0;b:0;s:32:\"902b1c352e421842aafe6fa628230118\";a:1:{i:50;i:1;}}","no");
INSERT INTO `wp_options` VALUES("8000","_transient_timeout_wc_layered_nav_counts_pa_plotnost","1562597311","no");
INSERT INTO `wp_options` VALUES("8001","_transient_wc_layered_nav_counts_pa_plotnost","a:2:{i:0;b:0;s:32:\"004c31179e57b5243d264afe9c33decf\";a:1:{i:28;i:1;}}","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4085 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("7","1","_wp_old_slug","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80");
INSERT INTO `wp_postmeta` VALUES("13","6","_wp_attached_file","2019/03/cart_img.gif");
INSERT INTO `wp_postmeta` VALUES("14","6","_wp_attachment_metadata","a:5:{s:5:\"width\";i:520;s:6:\"height\";i:346;s:4:\"file\";s:20:\"2019/03/cart_img.gif\";s:5:\"sizes\";a:8:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"cart_img-300x225.gif\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:9:\"image/gif\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"cart_img-400x266.gif\";s:5:\"width\";i:400;s:6:\"height\";i:266;s:9:\"mime-type\";s:9:\"image/gif\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"cart_img-150x150.gif\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/gif\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"cart_img-300x200.gif\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/gif\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"cart_img-100x100.gif\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/gif\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"cart_img-300x225.gif\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:9:\"image/gif\";s:9:\"uncropped\";b:0;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"cart_img-100x100.gif\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/gif\";}s:29:\"woocommerce_thumbnail_preview\";a:4:{s:4:\"file\";s:20:\"cart_img-300x225.gif\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("431","22","_sku","");
INSERT INTO `wp_postmeta` VALUES("432","22","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("433","22","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("434","22","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("435","22","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("436","22","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("437","22","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("438","22","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("439","22","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("440","22","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("441","22","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("442","22","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("443","22","_weight","");
INSERT INTO `wp_postmeta` VALUES("444","22","_length","");
INSERT INTO `wp_postmeta` VALUES("445","22","_width","");
INSERT INTO `wp_postmeta` VALUES("446","22","_height","");
INSERT INTO `wp_postmeta` VALUES("447","22","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("448","22","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("449","22","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("450","22","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("451","22","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("452","22","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("453","22","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("454","22","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("455","22","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("456","22","_stock","");
INSERT INTO `wp_postmeta` VALUES("457","22","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("458","22","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("459","22","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("460","22","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("461","22","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("462","22","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("463","22","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("464","22","_price","");
INSERT INTO `wp_postmeta` VALUES("465","23","_sku","");
INSERT INTO `wp_postmeta` VALUES("466","23","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("467","23","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("468","23","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("469","23","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("470","23","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("471","23","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("472","23","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("473","23","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("474","23","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("475","23","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("476","23","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("477","23","_weight","");
INSERT INTO `wp_postmeta` VALUES("478","23","_length","");
INSERT INTO `wp_postmeta` VALUES("479","23","_width","");
INSERT INTO `wp_postmeta` VALUES("480","23","_height","");
INSERT INTO `wp_postmeta` VALUES("481","23","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("482","23","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("483","23","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("484","23","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("485","23","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("486","23","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("487","23","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("488","23","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("489","23","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("490","23","_stock","");
INSERT INTO `wp_postmeta` VALUES("491","23","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("492","23","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("493","23","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("494","23","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("495","23","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("496","23","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("497","23","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("498","23","_price","");
INSERT INTO `wp_postmeta` VALUES("499","24","_sku","");
INSERT INTO `wp_postmeta` VALUES("500","24","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("501","24","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("502","24","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("503","24","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("504","24","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("505","24","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("506","24","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("507","24","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("508","24","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("509","24","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("510","24","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("511","24","_weight","");
INSERT INTO `wp_postmeta` VALUES("512","24","_length","");
INSERT INTO `wp_postmeta` VALUES("513","24","_width","");
INSERT INTO `wp_postmeta` VALUES("514","24","_height","");
INSERT INTO `wp_postmeta` VALUES("515","24","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("516","24","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("517","24","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("518","24","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("519","24","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("520","24","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("521","24","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("522","24","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("523","24","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("524","24","_stock","");
INSERT INTO `wp_postmeta` VALUES("525","24","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("526","24","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("527","24","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("528","24","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("529","24","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("530","24","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("531","24","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("532","24","_price","");
INSERT INTO `wp_postmeta` VALUES("533","25","_sku","");
INSERT INTO `wp_postmeta` VALUES("534","25","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("535","25","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("536","25","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("537","25","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("538","25","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("539","25","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("540","25","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("541","25","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("542","25","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("543","25","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("544","25","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("545","25","_weight","");
INSERT INTO `wp_postmeta` VALUES("546","25","_length","");
INSERT INTO `wp_postmeta` VALUES("547","25","_width","");
INSERT INTO `wp_postmeta` VALUES("548","25","_height","");
INSERT INTO `wp_postmeta` VALUES("549","25","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("550","25","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("551","25","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("552","25","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("553","25","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("554","25","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("555","25","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("556","25","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("557","25","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("558","25","_stock","");
INSERT INTO `wp_postmeta` VALUES("559","25","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("560","25","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("561","25","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("562","25","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("563","25","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("564","25","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("565","25","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("566","25","_price","");
INSERT INTO `wp_postmeta` VALUES("567","26","_sku","");
INSERT INTO `wp_postmeta` VALUES("568","26","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("569","26","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("570","26","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("571","26","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("572","26","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("573","26","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("574","26","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("575","26","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("576","26","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("577","26","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("578","26","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("579","26","_weight","");
INSERT INTO `wp_postmeta` VALUES("580","26","_length","");
INSERT INTO `wp_postmeta` VALUES("581","26","_width","");
INSERT INTO `wp_postmeta` VALUES("582","26","_height","");
INSERT INTO `wp_postmeta` VALUES("583","26","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("584","26","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("585","26","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("586","26","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("587","26","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("588","26","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("589","26","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("590","26","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("591","26","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("592","26","_stock","");
INSERT INTO `wp_postmeta` VALUES("593","26","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("594","26","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("595","26","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("596","26","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("597","26","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("598","26","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("599","26","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("600","26","_price","");
INSERT INTO `wp_postmeta` VALUES("601","27","_sku","");
INSERT INTO `wp_postmeta` VALUES("602","27","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("603","27","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("604","27","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("605","27","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("606","27","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("607","27","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("608","27","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("609","27","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("610","27","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("611","27","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("612","27","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("613","27","_weight","");
INSERT INTO `wp_postmeta` VALUES("614","27","_length","");
INSERT INTO `wp_postmeta` VALUES("615","27","_width","");
INSERT INTO `wp_postmeta` VALUES("616","27","_height","");
INSERT INTO `wp_postmeta` VALUES("617","27","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("618","27","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("619","27","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("620","27","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("621","27","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("622","27","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("623","27","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("624","27","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("625","27","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("626","27","_stock","");
INSERT INTO `wp_postmeta` VALUES("627","27","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("628","27","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("629","27","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("630","27","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("631","27","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("632","27","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("633","27","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("634","27","_price","");
INSERT INTO `wp_postmeta` VALUES("635","28","_sku","");
INSERT INTO `wp_postmeta` VALUES("636","28","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("637","28","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("638","28","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("639","28","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("640","28","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("641","28","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("642","28","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("643","28","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("644","28","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("645","28","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("646","28","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("647","28","_weight","");
INSERT INTO `wp_postmeta` VALUES("648","28","_length","");
INSERT INTO `wp_postmeta` VALUES("649","28","_width","");
INSERT INTO `wp_postmeta` VALUES("650","28","_height","");
INSERT INTO `wp_postmeta` VALUES("651","28","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("652","28","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("653","28","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("654","28","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("655","28","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("656","28","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("657","28","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("658","28","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("659","28","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("660","28","_stock","");
INSERT INTO `wp_postmeta` VALUES("661","28","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("662","28","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("663","28","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("664","28","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("665","28","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("666","28","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("667","28","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("668","28","_price","");
INSERT INTO `wp_postmeta` VALUES("669","29","_sku","");
INSERT INTO `wp_postmeta` VALUES("670","29","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("671","29","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("672","29","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("673","29","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("674","29","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("675","29","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("676","29","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("677","29","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("678","29","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("679","29","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("680","29","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("681","29","_weight","");
INSERT INTO `wp_postmeta` VALUES("682","29","_length","");
INSERT INTO `wp_postmeta` VALUES("683","29","_width","");
INSERT INTO `wp_postmeta` VALUES("684","29","_height","");
INSERT INTO `wp_postmeta` VALUES("685","29","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("686","29","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("687","29","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("688","29","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("689","29","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("690","29","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("691","29","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("692","29","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("693","29","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("694","29","_stock","");
INSERT INTO `wp_postmeta` VALUES("695","29","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("696","29","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("697","29","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("698","29","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("699","29","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("700","29","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("701","29","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("702","29","_price","");
INSERT INTO `wp_postmeta` VALUES("703","30","_sku","");
INSERT INTO `wp_postmeta` VALUES("704","30","_regular_price","400");
INSERT INTO `wp_postmeta` VALUES("705","30","_sale_price","300");
INSERT INTO `wp_postmeta` VALUES("706","30","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("707","30","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("708","30","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("709","30","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("710","30","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("711","30","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("712","30","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("713","30","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("714","30","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("715","30","_weight","");
INSERT INTO `wp_postmeta` VALUES("716","30","_length","");
INSERT INTO `wp_postmeta` VALUES("717","30","_width","");
INSERT INTO `wp_postmeta` VALUES("718","30","_height","");
INSERT INTO `wp_postmeta` VALUES("719","30","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("720","30","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("721","30","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("722","30","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("723","30","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("724","30","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("725","30","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("726","30","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("727","30","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("728","30","_stock","");
INSERT INTO `wp_postmeta` VALUES("729","30","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("730","30","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("731","30","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("732","30","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("733","30","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("734","30","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("735","30","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("736","30","_price","300");
INSERT INTO `wp_postmeta` VALUES("738","30","_edit_lock","1561570439:1");
INSERT INTO `wp_postmeta` VALUES("750","39","_edit_lock","1559482828:1");
INSERT INTO `wp_postmeta` VALUES("751","39","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("752","39","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("753","30","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("754","30","_thumbnail_id","6");
INSERT INTO `wp_postmeta` VALUES("755","30","_yoast_wpseo_primary_product_cat","");
INSERT INTO `wp_postmeta` VALUES("756","30","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("757","42","_wp_attached_file","2019/04/avangard_logo.jpg");
INSERT INTO `wp_postmeta` VALUES("758","42","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:387;s:4:\"file\";s:25:\"2019/04/avangard_logo.jpg\";s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"avangard_logo-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"avangard_logo-400x310.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:310;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"avangard_logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"avangard_logo-300x232.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:232;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"avangard_logo-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:25:\"avangard_logo-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"avangard_logo-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("759","43","_wp_attached_file","2019/04/avangard_logo.gif");
INSERT INTO `wp_postmeta` VALUES("760","43","_wp_attachment_metadata","a:5:{s:5:\"width\";i:100;s:6:\"height\";i:77;s:4:\"file\";s:25:\"2019/04/avangard_logo.gif\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"avangard_logo-100x77.gif\";s:5:\"width\";i:100;s:6:\"height\";i:77;s:9:\"mime-type\";s:9:\"image/gif\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"avangard_logo-100x77.gif\";s:5:\"width\";i:100;s:6:\"height\";i:77;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("833","54","_edit_lock","1554745642:1");
INSERT INTO `wp_postmeta` VALUES("834","54","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("835","54","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("836","56","_edit_lock","1555356749:1");
INSERT INTO `wp_postmeta` VALUES("837","56","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("838","56","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("840","59","_edit_lock","1554745784:1");
INSERT INTO `wp_postmeta` VALUES("841","59","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("842","59","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("843","61","_edit_lock","1554745950:1");
INSERT INTO `wp_postmeta` VALUES("844","61","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("845","61","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("846","63","_edit_lock","1554745926:1");
INSERT INTO `wp_postmeta` VALUES("847","63","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("848","63","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("849","65","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("850","65","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("851","65","_menu_item_object_id","65");
INSERT INTO `wp_postmeta` VALUES("852","65","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("853","65","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("854","65","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("855","65","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("856","65","_menu_item_url","http://localhost/tes/");
INSERT INTO `wp_postmeta` VALUES("858","66","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("859","66","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("860","66","_menu_item_object_id","56");
INSERT INTO `wp_postmeta` VALUES("861","66","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("862","66","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("863","66","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("864","66","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("865","66","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("867","67","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("868","67","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("869","67","_menu_item_object_id","59");
INSERT INTO `wp_postmeta` VALUES("870","67","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("871","67","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("872","67","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("873","67","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("874","67","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("876","68","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("877","68","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("878","68","_menu_item_object_id","54");
INSERT INTO `wp_postmeta` VALUES("879","68","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("880","68","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("881","68","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("882","68","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("883","68","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("885","69","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("886","69","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("887","69","_menu_item_object_id","61");
INSERT INTO `wp_postmeta` VALUES("888","69","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("889","69","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("890","69","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("891","69","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("892","69","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("894","70","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("895","70","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("896","70","_menu_item_object_id","63");
INSERT INTO `wp_postmeta` VALUES("897","70","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("898","70","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("899","70","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("900","70","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("901","70","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("902","72","_edit_lock","1559482873:1");
INSERT INTO `wp_postmeta` VALUES("903","72","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("904","72","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("906","75","_edit_lock","1554924072:1");
INSERT INTO `wp_postmeta` VALUES("907","75","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("908","75","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("909","1","_edit_lock","1554923286:1");
INSERT INTO `wp_postmeta` VALUES("911","1","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("913","1","_yoast_wpseo_primary_category","");
INSERT INTO `wp_postmeta` VALUES("914","1","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("915","88","_edit_lock","1561029881:1");
INSERT INTO `wp_postmeta` VALUES("916","88","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("917","88","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("918","91","_wc_review_count","1");
INSERT INTO `wp_postmeta` VALUES("919","91","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("920","91","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("921","91","_edit_lock","1557857589:1");
INSERT INTO `wp_postmeta` VALUES("922","91","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("923","91","_sku","");
INSERT INTO `wp_postmeta` VALUES("926","91","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("927","91","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("928","91","total_sales","14");
INSERT INTO `wp_postmeta` VALUES("929","91","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("930","91","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("931","91","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("932","91","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("933","91","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("934","91","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("935","91","_weight","");
INSERT INTO `wp_postmeta` VALUES("936","91","_length","");
INSERT INTO `wp_postmeta` VALUES("937","91","_width","");
INSERT INTO `wp_postmeta` VALUES("938","91","_height","");
INSERT INTO `wp_postmeta` VALUES("939","91","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("940","91","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("941","91","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("942","91","_default_attributes","a:1:{s:16:\"pa_product_color\";s:5:\"sinij\";}");
INSERT INTO `wp_postmeta` VALUES("943","91","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("944","91","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("945","91","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("946","91","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("947","91","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("948","91","_stock","");
INSERT INTO `wp_postmeta` VALUES("949","91","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("950","91","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("952","91","_yoast_wpseo_primary_product_cat","21");
INSERT INTO `wp_postmeta` VALUES("953","91","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("954","91","_thumbnail_id","94");
INSERT INTO `wp_postmeta` VALUES("955","94","_wp_attached_file","2019/04/img1.jpg");
INSERT INTO `wp_postmeta` VALUES("956","94","_wp_attachment_metadata","a:5:{s:5:\"width\";i:750;s:6:\"height\";i:500;s:4:\"file\";s:16:\"2019/04/img1.jpg\";s:5:\"sizes\";a:9:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:16:\"img1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:16:\"img1-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"img1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"img1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:16:\"img1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:16:\"img1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:16:\"img1-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:16:\"img1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_thumbnail_preview\";a:4:{s:4:\"file\";s:16:\"img1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("961","91","_product_attributes","a:1:{s:16:\"pa_product_color\";a:6:{s:4:\"name\";s:16:\"pa_product_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("1383","110","_wp_attached_file","2019/04/WooCommerce-Quantity-Increment-master.zip");
INSERT INTO `wp_postmeta` VALUES("1385","110","_wp_attachment_context","upgrader");
INSERT INTO `wp_postmeta` VALUES("2175","91","_price","399");
INSERT INTO `wp_postmeta` VALUES("2176","91","_price","399");
INSERT INTO `wp_postmeta` VALUES("2177","91","_price","399");
INSERT INTO `wp_postmeta` VALUES("2178","91","_regular_price","400");
INSERT INTO `wp_postmeta` VALUES("2179","91","_sale_price","399");
INSERT INTO `wp_postmeta` VALUES("2195","134","_wc_review_count","3");
INSERT INTO `wp_postmeta` VALUES("2196","134","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2197","134","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("2198","134","_edit_lock","1561569975:1");
INSERT INTO `wp_postmeta` VALUES("2199","134","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("2200","134","_thumbnail_id","94");
INSERT INTO `wp_postmeta` VALUES("2201","134","_sku","");
INSERT INTO `wp_postmeta` VALUES("2202","134","_regular_price","800");
INSERT INTO `wp_postmeta` VALUES("2203","134","_sale_price","750");
INSERT INTO `wp_postmeta` VALUES("2204","134","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("2205","134","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("2206","134","total_sales","2");
INSERT INTO `wp_postmeta` VALUES("2207","134","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("2208","134","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("2209","134","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("2210","134","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("2211","134","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("2212","134","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("2213","134","_weight","");
INSERT INTO `wp_postmeta` VALUES("2214","134","_length","");
INSERT INTO `wp_postmeta` VALUES("2215","134","_width","");
INSERT INTO `wp_postmeta` VALUES("2216","134","_height","");
INSERT INTO `wp_postmeta` VALUES("2217","134","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2218","134","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2219","134","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("2220","134","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2221","134","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("2222","134","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("2223","134","_product_image_gallery","6,42,94");
INSERT INTO `wp_postmeta` VALUES("2224","134","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("2225","134","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("2226","134","_stock","");
INSERT INTO `wp_postmeta` VALUES("2227","134","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("2228","134","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("2229","134","_price","750");
INSERT INTO `wp_postmeta` VALUES("2230","134","_yoast_wpseo_primary_product_cat","21");
INSERT INTO `wp_postmeta` VALUES("2231","134","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("2232","39","_wp_page_template","template/basket.php");
INSERT INTO `wp_postmeta` VALUES("2233","139","_wc_review_count","2");
INSERT INTO `wp_postmeta` VALUES("2234","139","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2235","139","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("2236","139","_edit_lock","1561555832:1");
INSERT INTO `wp_postmeta` VALUES("2237","139","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("2238","140","_wp_attached_file","2019/05/01b2584ded19fbad4577127e404d88ffd35c379c9b.jpg");
INSERT INTO `wp_postmeta` VALUES("2239","140","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2048;s:6:\"height\";i:2048;s:4:\"file\";s:54:\"2019/05/01b2584ded19fbad4577127e404d88ffd35c379c9b.jpg\";s:5:\"sizes\";a:10:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:56:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:54:\"01b2584ded19fbad4577127e404d88ffd35c379c9b-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:9:\"iPhone 4S\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1443268794\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.28\";s:3:\"iso\";s:2:\"64\";s:13:\"shutter_speed\";s:18:\"0.0083333333333333\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("2240","139","_sku","");
INSERT INTO `wp_postmeta` VALUES("2241","139","_regular_price","500");
INSERT INTO `wp_postmeta` VALUES("2242","139","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("2243","139","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("2244","139","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("2245","139","total_sales","1");
INSERT INTO `wp_postmeta` VALUES("2246","139","_tax_status","shipping");
INSERT INTO `wp_postmeta` VALUES("2247","139","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("2248","139","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("2249","139","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("2250","139","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("2251","139","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("2252","139","_weight","");
INSERT INTO `wp_postmeta` VALUES("2253","139","_length","");
INSERT INTO `wp_postmeta` VALUES("2254","139","_width","");
INSERT INTO `wp_postmeta` VALUES("2255","139","_height","");
INSERT INTO `wp_postmeta` VALUES("2256","139","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2257","139","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2258","139","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("2259","139","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("2260","139","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("2261","139","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("2262","139","_product_image_gallery","94,42,6");
INSERT INTO `wp_postmeta` VALUES("2263","139","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("2264","139","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("2265","139","_stock","");
INSERT INTO `wp_postmeta` VALUES("2266","139","_stock_status","outofstock");
INSERT INTO `wp_postmeta` VALUES("2267","139","_product_attributes","a:2:{s:7:\"atribut\";a:6:{s:4:\"name\";s:14:\"атрибут\";s:5:\"value\";s:4:\"1990\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:0;}s:16:\"pa_product_color\";a:6:{s:4:\"name\";s:16:\"pa_product_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("2268","139","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("2269","139","_price","500");
INSERT INTO `wp_postmeta` VALUES("2270","139","_thumbnail_id","140");
INSERT INTO `wp_postmeta` VALUES("2271","139","_yoast_wpseo_primary_product_cat","21");
INSERT INTO `wp_postmeta` VALUES("2272","139","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("2466","148","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2467","148","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2468","148","_menu_item_object_id","75");
INSERT INTO `wp_postmeta` VALUES("2469","148","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("2470","148","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2471","148","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2472","148","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2473","148","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2541","151","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2542","151","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2543","151","_menu_item_object_id","21");
INSERT INTO `wp_postmeta` VALUES("2544","151","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2545","151","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2546","151","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2547","151","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2548","151","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2568","154","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2569","154","_menu_item_menu_item_parent","151");
INSERT INTO `wp_postmeta` VALUES("2570","154","_menu_item_object_id","134");
INSERT INTO `wp_postmeta` VALUES("2571","154","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2572","154","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2573","154","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2574","154","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2575","154","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2577","155","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2578","155","_menu_item_menu_item_parent","151");
INSERT INTO `wp_postmeta` VALUES("2579","155","_menu_item_object_id","91");
INSERT INTO `wp_postmeta` VALUES("2580","155","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2581","155","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2582","155","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2583","155","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2584","155","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2593","157","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2594","157","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2595","157","_menu_item_object_id","33");
INSERT INTO `wp_postmeta` VALUES("2596","157","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2597","157","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2598","157","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2599","157","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2600","157","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2602","158","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2603","158","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2604","158","_menu_item_object_id","21");
INSERT INTO `wp_postmeta` VALUES("2605","158","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2606","158","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2607","158","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2608","158","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2609","158","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2611","159","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2612","159","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2613","159","_menu_item_object_id","45");
INSERT INTO `wp_postmeta` VALUES("2614","159","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2615","159","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2616","159","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2617","159","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2618","159","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2620","160","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2621","160","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2622","160","_menu_item_object_id","34");
INSERT INTO `wp_postmeta` VALUES("2623","160","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2624","160","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2625","160","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2626","160","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2627","160","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2629","161","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2630","161","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2631","161","_menu_item_object_id","35");
INSERT INTO `wp_postmeta` VALUES("2632","161","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2633","161","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2634","161","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2635","161","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2636","161","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2638","162","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2639","162","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2640","162","_menu_item_object_id","36");
INSERT INTO `wp_postmeta` VALUES("2641","162","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2642","162","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2643","162","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2644","162","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2645","162","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2647","163","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2648","163","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2649","163","_menu_item_object_id","39");
INSERT INTO `wp_postmeta` VALUES("2650","163","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2651","163","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2652","163","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2653","163","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2654","163","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2656","164","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2657","164","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2658","164","_menu_item_object_id","40");
INSERT INTO `wp_postmeta` VALUES("2659","164","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2660","164","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2661","164","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2662","164","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2663","164","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2665","165","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2666","165","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2667","165","_menu_item_object_id","41");
INSERT INTO `wp_postmeta` VALUES("2668","165","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2669","165","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2670","165","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2671","165","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2672","165","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2674","166","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2675","166","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2676","166","_menu_item_object_id","37");
INSERT INTO `wp_postmeta` VALUES("2677","166","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2678","166","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2679","166","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2680","166","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2681","166","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2683","167","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2684","167","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2685","167","_menu_item_object_id","42");
INSERT INTO `wp_postmeta` VALUES("2686","167","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2687","167","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2688","167","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2689","167","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2690","167","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2692","168","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2693","168","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2694","168","_menu_item_object_id","38");
INSERT INTO `wp_postmeta` VALUES("2695","168","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2696","168","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2697","168","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2698","168","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2699","168","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2701","169","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2702","169","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2703","169","_menu_item_object_id","43");
INSERT INTO `wp_postmeta` VALUES("2704","169","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2705","169","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2706","169","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2707","169","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2708","169","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2710","170","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2711","170","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2712","170","_menu_item_object_id","44");
INSERT INTO `wp_postmeta` VALUES("2713","170","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2714","170","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2715","170","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2716","170","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2717","170","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2719","171","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2720","171","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2721","171","_menu_item_object_id","47");
INSERT INTO `wp_postmeta` VALUES("2722","171","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2723","171","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2724","171","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2725","171","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2726","171","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2728","172","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2729","172","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2730","172","_menu_item_object_id","48");
INSERT INTO `wp_postmeta` VALUES("2731","172","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2732","172","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2733","172","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2734","172","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2735","172","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2737","173","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("2738","173","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2739","173","_menu_item_object_id","46");
INSERT INTO `wp_postmeta` VALUES("2740","173","_menu_item_object","product_cat");
INSERT INTO `wp_postmeta` VALUES("2741","173","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2742","173","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2743","173","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2744","173","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2746","174","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2747","174","_menu_item_menu_item_parent","173");
INSERT INTO `wp_postmeta` VALUES("2748","174","_menu_item_object_id","30");
INSERT INTO `wp_postmeta` VALUES("2749","174","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2750","174","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2751","174","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2752","174","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2753","174","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2755","175","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2756","175","_menu_item_menu_item_parent","173");
INSERT INTO `wp_postmeta` VALUES("2757","175","_menu_item_object_id","29");
INSERT INTO `wp_postmeta` VALUES("2758","175","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2759","175","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2760","175","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2761","175","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2762","175","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2764","176","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2765","176","_menu_item_menu_item_parent","173");
INSERT INTO `wp_postmeta` VALUES("2766","176","_menu_item_object_id","28");
INSERT INTO `wp_postmeta` VALUES("2767","176","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2768","176","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2769","176","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2770","176","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2771","176","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2773","177","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2774","177","_menu_item_menu_item_parent","170");
INSERT INTO `wp_postmeta` VALUES("2775","177","_menu_item_object_id","139");
INSERT INTO `wp_postmeta` VALUES("2776","177","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2777","177","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2778","177","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2779","177","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2780","177","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2782","178","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2783","178","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2784","178","_menu_item_object_id","134");
INSERT INTO `wp_postmeta` VALUES("2785","178","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2786","178","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2787","178","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2788","178","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2789","178","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2791","179","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2792","179","_menu_item_menu_item_parent","170");
INSERT INTO `wp_postmeta` VALUES("2793","179","_menu_item_object_id","91");
INSERT INTO `wp_postmeta` VALUES("2794","179","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2795","179","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2796","179","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2797","179","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2798","179","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2800","180","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2801","180","_menu_item_menu_item_parent","171");
INSERT INTO `wp_postmeta` VALUES("2802","180","_menu_item_object_id","30");
INSERT INTO `wp_postmeta` VALUES("2803","180","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2804","180","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2805","180","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2806","180","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2807","180","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2809","181","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2810","181","_menu_item_menu_item_parent","168");
INSERT INTO `wp_postmeta` VALUES("2811","181","_menu_item_object_id","29");
INSERT INTO `wp_postmeta` VALUES("2812","181","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2813","181","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2814","181","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2815","181","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2816","181","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2818","182","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2819","182","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2820","182","_menu_item_object_id","28");
INSERT INTO `wp_postmeta` VALUES("2821","182","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2822","182","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2823","182","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2824","182","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2825","182","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2827","183","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2828","183","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2829","183","_menu_item_object_id","27");
INSERT INTO `wp_postmeta` VALUES("2830","183","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2831","183","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2832","183","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2833","183","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2834","183","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2836","184","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2837","184","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2838","184","_menu_item_object_id","26");
INSERT INTO `wp_postmeta` VALUES("2839","184","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2840","184","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2841","184","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2842","184","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2843","184","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2845","185","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2846","185","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2847","185","_menu_item_object_id","25");
INSERT INTO `wp_postmeta` VALUES("2848","185","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2849","185","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2850","185","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2851","185","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2852","185","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2854","186","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2855","186","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2856","186","_menu_item_object_id","24");
INSERT INTO `wp_postmeta` VALUES("2857","186","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2858","186","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2859","186","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2860","186","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2861","186","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2863","187","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2864","187","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2865","187","_menu_item_object_id","23");
INSERT INTO `wp_postmeta` VALUES("2866","187","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2867","187","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2868","187","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2869","187","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2870","187","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2872","188","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("2873","188","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("2874","188","_menu_item_object_id","22");
INSERT INTO `wp_postmeta` VALUES("2875","188","_menu_item_object","product");
INSERT INTO `wp_postmeta` VALUES("2876","188","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("2877","188","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("2878","188","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("2879","188","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("2885","134","_product_attributes","a:2:{s:11:\"pa_plotnost\";a:6:{s:4:\"name\";s:11:\"pa_plotnost\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}s:8:\"pa_tsvet\";a:6:{s:4:\"name\";s:8:\"pa_tsvet\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("2886","190","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("2887","190","_wp_trash_meta_time","1561291429");
INSERT INTO `wp_postmeta` VALUES("2888","191","_edit_lock","1561291518:1");
INSERT INTO `wp_postmeta` VALUES("2889","191","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("2890","191","_wp_trash_meta_time","1561291553");
INSERT INTO `wp_postmeta` VALUES("3539","211","_edit_lock","1561731491:1");
INSERT INTO `wp_postmeta` VALUES("3541","211","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("3543","211","_yoast_wpseo_primary_category","");
INSERT INTO `wp_postmeta` VALUES("3544","211","_yoast_wpseo_content_score","90");
INSERT INTO `wp_postmeta` VALUES("3545","213","_edit_lock","1561731517:1");
INSERT INTO `wp_postmeta` VALUES("3547","213","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("3549","213","_yoast_wpseo_primary_category","");
INSERT INTO `wp_postmeta` VALUES("3550","213","_yoast_wpseo_content_score","90");
INSERT INTO `wp_postmeta` VALUES("3551","215","_edit_lock","1561731649:1");
INSERT INTO `wp_postmeta` VALUES("3552","216","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3553","216","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3554","216","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3555","216","_edit_lock","1561796572:1");
INSERT INTO `wp_postmeta` VALUES("3556","216","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("3557","216","_sku","");
INSERT INTO `wp_postmeta` VALUES("3558","216","_regular_price","200");
INSERT INTO `wp_postmeta` VALUES("3559","216","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3560","216","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3561","216","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3562","216","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3563","216","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3564","216","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3565","216","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3566","216","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3567","216","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3568","216","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3569","216","_weight","");
INSERT INTO `wp_postmeta` VALUES("3570","216","_length","");
INSERT INTO `wp_postmeta` VALUES("3571","216","_width","");
INSERT INTO `wp_postmeta` VALUES("3572","216","_height","");
INSERT INTO `wp_postmeta` VALUES("3573","216","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3574","216","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3575","216","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3576","216","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3577","216","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3578","216","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3579","216","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3580","216","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3581","216","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3582","216","_stock","");
INSERT INTO `wp_postmeta` VALUES("3583","216","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3584","216","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3585","216","_price","200");
INSERT INTO `wp_postmeta` VALUES("3586","216","_yoast_wpseo_primary_product_cat","15");
INSERT INTO `wp_postmeta` VALUES("3587","216","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("3588","217","_sku","");
INSERT INTO `wp_postmeta` VALUES("3589","217","_regular_price","200");
INSERT INTO `wp_postmeta` VALUES("3590","217","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3591","217","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3592","217","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3593","217","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3594","217","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3595","217","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3596","217","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3597","217","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3598","217","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3599","217","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3600","217","_weight","");
INSERT INTO `wp_postmeta` VALUES("3601","217","_length","");
INSERT INTO `wp_postmeta` VALUES("3602","217","_width","");
INSERT INTO `wp_postmeta` VALUES("3603","217","_height","");
INSERT INTO `wp_postmeta` VALUES("3604","217","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3605","217","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3606","217","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3607","217","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3608","217","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3609","217","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3610","217","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3611","217","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3612","217","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3613","217","_stock","");
INSERT INTO `wp_postmeta` VALUES("3614","217","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3615","217","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3616","217","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3617","217","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3618","217","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3619","217","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3620","217","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3621","217","_price","200");
INSERT INTO `wp_postmeta` VALUES("3622","217","_yoast_wpseo_primary_product_cat","15");
INSERT INTO `wp_postmeta` VALUES("3623","217","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("3624","217","_edit_lock","1561798662:1");
INSERT INTO `wp_postmeta` VALUES("3625","218","_sku","");
INSERT INTO `wp_postmeta` VALUES("3626","218","_regular_price","500");
INSERT INTO `wp_postmeta` VALUES("3627","218","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3628","218","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3629","218","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3630","218","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3631","218","_tax_status","shipping");
INSERT INTO `wp_postmeta` VALUES("3632","218","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3633","218","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3634","218","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3635","218","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3636","218","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3637","218","_weight","");
INSERT INTO `wp_postmeta` VALUES("3638","218","_length","");
INSERT INTO `wp_postmeta` VALUES("3639","218","_width","");
INSERT INTO `wp_postmeta` VALUES("3640","218","_height","");
INSERT INTO `wp_postmeta` VALUES("3641","218","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3642","218","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3643","218","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3644","218","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3645","218","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3646","218","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3647","218","_product_image_gallery","94,42,6");
INSERT INTO `wp_postmeta` VALUES("3648","218","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3649","218","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3650","218","_thumbnail_id","140");
INSERT INTO `wp_postmeta` VALUES("3651","218","_stock","");
INSERT INTO `wp_postmeta` VALUES("3652","218","_stock_status","outofstock");
INSERT INTO `wp_postmeta` VALUES("3653","218","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3654","218","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3655","218","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3656","218","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3657","218","_product_attributes","a:1:{s:7:\"atribut\";a:6:{s:4:\"name\";s:14:\"атрибут\";s:5:\"value\";s:4:\"1990\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:0;}}");
INSERT INTO `wp_postmeta` VALUES("3658","218","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3659","218","_price","500");
INSERT INTO `wp_postmeta` VALUES("3660","218","_yoast_wpseo_primary_product_cat","21");
INSERT INTO `wp_postmeta` VALUES("3661","218","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("3662","219","_sku","");
INSERT INTO `wp_postmeta` VALUES("3663","219","_regular_price","800");
INSERT INTO `wp_postmeta` VALUES("3664","219","_sale_price","750");
INSERT INTO `wp_postmeta` VALUES("3665","219","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3666","219","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3667","219","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3668","219","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3669","219","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3670","219","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3671","219","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3672","219","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3673","219","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3674","219","_weight","");
INSERT INTO `wp_postmeta` VALUES("3675","219","_length","");
INSERT INTO `wp_postmeta` VALUES("3676","219","_width","");
INSERT INTO `wp_postmeta` VALUES("3677","219","_height","");
INSERT INTO `wp_postmeta` VALUES("3678","219","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3679","219","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3680","219","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3681","219","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3682","219","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3683","219","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3684","219","_product_image_gallery","6,42,94");
INSERT INTO `wp_postmeta` VALUES("3685","219","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3686","219","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3687","219","_thumbnail_id","94");
INSERT INTO `wp_postmeta` VALUES("3688","219","_stock","");
INSERT INTO `wp_postmeta` VALUES("3689","219","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3690","219","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3691","219","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3692","219","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3693","219","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3694","219","_product_attributes","a:2:{s:11:\"pa_plotnost\";a:6:{s:4:\"name\";s:11:\"pa_plotnost\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}s:8:\"pa_tsvet\";a:6:{s:4:\"name\";s:8:\"pa_tsvet\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}");
INSERT INTO `wp_postmeta` VALUES("3695","219","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3696","219","_price","750");
INSERT INTO `wp_postmeta` VALUES("3697","219","_yoast_wpseo_primary_product_cat","21");
INSERT INTO `wp_postmeta` VALUES("3698","219","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("3699","220","_sku","");
INSERT INTO `wp_postmeta` VALUES("3700","220","_regular_price","400");
INSERT INTO `wp_postmeta` VALUES("3701","220","_sale_price","399");
INSERT INTO `wp_postmeta` VALUES("3702","220","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3703","220","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3704","220","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3705","220","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3706","220","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3707","220","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3708","220","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3709","220","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3710","220","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3711","220","_weight","");
INSERT INTO `wp_postmeta` VALUES("3712","220","_length","");
INSERT INTO `wp_postmeta` VALUES("3713","220","_width","");
INSERT INTO `wp_postmeta` VALUES("3714","220","_height","");
INSERT INTO `wp_postmeta` VALUES("3715","220","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3716","220","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3717","220","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3718","220","_default_attributes","a:1:{s:16:\"pa_product_color\";s:5:\"sinij\";}");
INSERT INTO `wp_postmeta` VALUES("3719","220","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3720","220","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3721","220","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3722","220","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3723","220","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3724","220","_thumbnail_id","94");
INSERT INTO `wp_postmeta` VALUES("3725","220","_stock","");
INSERT INTO `wp_postmeta` VALUES("3726","220","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3727","220","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3728","220","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3729","220","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3730","220","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3731","220","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3732","220","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3733","220","_price","399");
INSERT INTO `wp_postmeta` VALUES("3734","220","_yoast_wpseo_primary_product_cat","21");
INSERT INTO `wp_postmeta` VALUES("3735","220","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("3736","222","_sku","");
INSERT INTO `wp_postmeta` VALUES("3737","222","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("3738","221","_sku","");
INSERT INTO `wp_postmeta` VALUES("3739","222","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3740","221","_regular_price","400");
INSERT INTO `wp_postmeta` VALUES("3741","222","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3742","221","_sale_price","300");
INSERT INTO `wp_postmeta` VALUES("3743","222","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3744","221","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3745","222","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3746","221","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3747","222","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3748","221","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3749","222","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3750","221","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3751","222","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3752","221","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3753","222","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3754","221","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3755","222","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3756","221","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3757","222","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3758","221","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3759","222","_weight","");
INSERT INTO `wp_postmeta` VALUES("3760","221","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3761","222","_length","");
INSERT INTO `wp_postmeta` VALUES("3762","221","_weight","");
INSERT INTO `wp_postmeta` VALUES("3763","222","_width","");
INSERT INTO `wp_postmeta` VALUES("3764","221","_length","");
INSERT INTO `wp_postmeta` VALUES("3765","222","_height","");
INSERT INTO `wp_postmeta` VALUES("3766","221","_width","");
INSERT INTO `wp_postmeta` VALUES("3767","222","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3768","221","_height","");
INSERT INTO `wp_postmeta` VALUES("3769","222","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3770","221","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3771","222","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3772","221","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3773","222","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3774","221","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3775","222","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3776","221","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3777","222","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3778","221","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3779","222","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3780","221","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3781","222","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3782","221","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3783","222","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3784","221","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3785","222","_stock","");
INSERT INTO `wp_postmeta` VALUES("3786","221","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3787","222","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3788","221","_thumbnail_id","6");
INSERT INTO `wp_postmeta` VALUES("3789","222","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3790","222","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3791","221","_stock","");
INSERT INTO `wp_postmeta` VALUES("3792","222","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3793","221","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3794","221","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3795","222","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3796","221","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3797","221","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3798","221","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3799","221","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3800","222","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3801","221","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3802","221","_price","300");
INSERT INTO `wp_postmeta` VALUES("3803","221","_yoast_wpseo_primary_product_cat","");
INSERT INTO `wp_postmeta` VALUES("3804","221","_yoast_wpseo_content_score","30");
INSERT INTO `wp_postmeta` VALUES("3805","222","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3806","222","_price","");
INSERT INTO `wp_postmeta` VALUES("3807","223","_sku","");
INSERT INTO `wp_postmeta` VALUES("3808","223","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("3809","223","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3810","223","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3811","223","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3812","223","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3813","223","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3814","223","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3815","223","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3816","223","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3817","223","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3818","223","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3819","223","_weight","");
INSERT INTO `wp_postmeta` VALUES("3820","223","_length","");
INSERT INTO `wp_postmeta` VALUES("3821","223","_width","");
INSERT INTO `wp_postmeta` VALUES("3822","223","_height","");
INSERT INTO `wp_postmeta` VALUES("3823","223","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3824","223","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3825","223","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3826","223","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3827","223","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3828","223","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3829","223","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3830","223","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3831","223","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3832","223","_stock","");
INSERT INTO `wp_postmeta` VALUES("3833","223","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3834","223","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3835","223","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3836","223","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3837","223","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3838","223","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3839","223","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3840","223","_price","");
INSERT INTO `wp_postmeta` VALUES("3841","224","_sku","");
INSERT INTO `wp_postmeta` VALUES("3842","224","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("3843","224","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3844","224","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3845","224","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3846","224","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3847","224","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3848","224","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3849","224","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3850","224","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3851","224","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3852","224","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3853","224","_weight","");
INSERT INTO `wp_postmeta` VALUES("3854","224","_length","");
INSERT INTO `wp_postmeta` VALUES("3855","224","_width","");
INSERT INTO `wp_postmeta` VALUES("3856","224","_height","");
INSERT INTO `wp_postmeta` VALUES("3857","224","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3858","224","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3859","224","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3860","224","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3861","224","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3862","224","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3863","224","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3864","224","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3865","224","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3866","224","_stock","");
INSERT INTO `wp_postmeta` VALUES("3867","224","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3868","224","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3869","224","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3870","224","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3871","224","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3872","224","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3873","224","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3874","224","_price","");
INSERT INTO `wp_postmeta` VALUES("3875","225","_sku","");
INSERT INTO `wp_postmeta` VALUES("3876","225","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("3877","225","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3878","225","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3879","225","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3880","225","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3881","225","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3882","225","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3883","225","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3884","225","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3885","225","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3886","225","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3887","225","_weight","");
INSERT INTO `wp_postmeta` VALUES("3888","225","_length","");
INSERT INTO `wp_postmeta` VALUES("3889","225","_width","");
INSERT INTO `wp_postmeta` VALUES("3890","225","_height","");
INSERT INTO `wp_postmeta` VALUES("3891","225","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3892","225","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3893","225","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3894","225","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3895","225","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3896","225","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3897","225","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3898","225","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3899","225","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3900","225","_stock","");
INSERT INTO `wp_postmeta` VALUES("3901","225","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3902","225","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3903","225","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3904","225","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3905","225","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3906","225","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3907","225","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3908","225","_price","");
INSERT INTO `wp_postmeta` VALUES("3909","226","_sku","");
INSERT INTO `wp_postmeta` VALUES("3910","226","_regular_price","");
INSERT INTO `wp_postmeta` VALUES("3911","226","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3912","226","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3913","226","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3914","226","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3915","226","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3916","226","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3917","226","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3918","226","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3919","226","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3920","226","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3921","226","_weight","");
INSERT INTO `wp_postmeta` VALUES("3922","226","_length","");
INSERT INTO `wp_postmeta` VALUES("3923","226","_width","");
INSERT INTO `wp_postmeta` VALUES("3924","226","_height","");
INSERT INTO `wp_postmeta` VALUES("3925","226","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3926","226","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3927","226","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("3928","226","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3929","226","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("3930","226","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("3931","226","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("3932","226","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("3933","226","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("3934","226","_stock","");
INSERT INTO `wp_postmeta` VALUES("3935","226","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("3936","226","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3937","226","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3938","226","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3939","226","_downloadable_files","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3940","226","_product_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3941","226","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("3942","226","_price","");
INSERT INTO `wp_postmeta` VALUES("3943","226","_edit_lock","1561798872:1");
INSERT INTO `wp_postmeta` VALUES("3944","222","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3945","222","_wp_trash_meta_time","1561798881");
INSERT INTO `wp_postmeta` VALUES("3946","222","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3947","226","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3948","226","_wp_trash_meta_time","1561798888");
INSERT INTO `wp_postmeta` VALUES("3949","226","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3950","225","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3951","225","_wp_trash_meta_time","1561798891");
INSERT INTO `wp_postmeta` VALUES("3952","225","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3953","224","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3954","224","_wp_trash_meta_time","1561798893");
INSERT INTO `wp_postmeta` VALUES("3955","224","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3956","223","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3957","223","_wp_trash_meta_time","1561798894");
INSERT INTO `wp_postmeta` VALUES("3958","223","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3959","221","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3960","221","_wp_trash_meta_time","1561798896");
INSERT INTO `wp_postmeta` VALUES("3961","221","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3962","220","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3963","220","_wp_trash_meta_time","1561798898");
INSERT INTO `wp_postmeta` VALUES("3964","220","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3965","219","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3966","219","_wp_trash_meta_time","1561798899");
INSERT INTO `wp_postmeta` VALUES("3967","219","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3968","218","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3969","218","_wp_trash_meta_time","1561798902");
INSERT INTO `wp_postmeta` VALUES("3970","218","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3973","217","_wp_desired_post_slug","");
INSERT INTO `wp_postmeta` VALUES("3974","217","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("3975","217","_wp_trash_meta_time","1561798922");
INSERT INTO `wp_postmeta` VALUES("3976","217","_wp_desired_post_slug","__trashed-10");
INSERT INTO `wp_postmeta` VALUES("3977","227","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("3978","227","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3979","227","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("3980","227","_edit_lock","1561798990:1");
INSERT INTO `wp_postmeta` VALUES("3981","227","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("3982","227","_sku","");
INSERT INTO `wp_postmeta` VALUES("3983","227","_regular_price","99");
INSERT INTO `wp_postmeta` VALUES("3984","227","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("3985","227","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("3986","227","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("3987","227","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("3988","227","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("3989","227","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("3990","227","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("3991","227","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("3992","227","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("3993","227","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("3994","227","_weight","");
INSERT INTO `wp_postmeta` VALUES("3995","227","_length","");
INSERT INTO `wp_postmeta` VALUES("3996","227","_width","");
INSERT INTO `wp_postmeta` VALUES("3997","227","_height","");
INSERT INTO `wp_postmeta` VALUES("3998","227","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("3999","227","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4000","227","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("4001","227","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4002","227","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("4003","227","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("4004","227","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("4005","227","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("4006","227","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("4007","227","_stock","");
INSERT INTO `wp_postmeta` VALUES("4008","227","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("4009","227","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("4010","227","_price","99");
INSERT INTO `wp_postmeta` VALUES("4011","227","_yoast_wpseo_primary_product_cat","35");
INSERT INTO `wp_postmeta` VALUES("4012","227","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("4013","228","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("4014","228","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4015","228","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("4016","228","_edit_lock","1561799073:1");
INSERT INTO `wp_postmeta` VALUES("4017","228","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("4018","228","_sku","");
INSERT INTO `wp_postmeta` VALUES("4019","228","_regular_price","99");
INSERT INTO `wp_postmeta` VALUES("4020","228","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("4021","228","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("4022","228","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("4023","228","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("4024","228","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("4025","228","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("4026","228","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("4027","228","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("4028","228","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("4029","228","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("4030","228","_weight","");
INSERT INTO `wp_postmeta` VALUES("4031","228","_length","");
INSERT INTO `wp_postmeta` VALUES("4032","228","_width","");
INSERT INTO `wp_postmeta` VALUES("4033","228","_height","");
INSERT INTO `wp_postmeta` VALUES("4034","228","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4035","228","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4036","228","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("4037","228","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4038","228","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("4039","228","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("4040","228","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("4041","228","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("4042","228","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("4043","228","_stock","");
INSERT INTO `wp_postmeta` VALUES("4044","228","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("4045","228","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("4046","228","_price","99");
INSERT INTO `wp_postmeta` VALUES("4047","228","_yoast_wpseo_primary_product_cat","45");
INSERT INTO `wp_postmeta` VALUES("4048","228","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES("4049","229","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("4050","229","_wc_rating_count","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4051","229","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("4052","229","_edit_lock","1561822297:1");
INSERT INTO `wp_postmeta` VALUES("4053","229","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("4054","229","_sku","");
INSERT INTO `wp_postmeta` VALUES("4055","229","_regular_price","150000");
INSERT INTO `wp_postmeta` VALUES("4056","229","_sale_price","");
INSERT INTO `wp_postmeta` VALUES("4057","229","_sale_price_dates_from","");
INSERT INTO `wp_postmeta` VALUES("4058","229","_sale_price_dates_to","");
INSERT INTO `wp_postmeta` VALUES("4059","229","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("4060","229","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("4061","229","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("4062","229","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("4063","229","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("4064","229","_low_stock_amount","");
INSERT INTO `wp_postmeta` VALUES("4065","229","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("4066","229","_weight","");
INSERT INTO `wp_postmeta` VALUES("4067","229","_length","");
INSERT INTO `wp_postmeta` VALUES("4068","229","_width","");
INSERT INTO `wp_postmeta` VALUES("4069","229","_height","");
INSERT INTO `wp_postmeta` VALUES("4070","229","_upsell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4071","229","_crosssell_ids","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4072","229","_purchase_note","");
INSERT INTO `wp_postmeta` VALUES("4073","229","_default_attributes","a:0:{}");
INSERT INTO `wp_postmeta` VALUES("4074","229","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("4075","229","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("4076","229","_product_image_gallery","");
INSERT INTO `wp_postmeta` VALUES("4077","229","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("4078","229","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("4079","229","_stock","");
INSERT INTO `wp_postmeta` VALUES("4080","229","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("4081","229","_product_version","3.5.7");
INSERT INTO `wp_postmeta` VALUES("4082","229","_price","150000");
INSERT INTO `wp_postmeta` VALUES("4083","229","_yoast_wpseo_primary_product_cat","36");
INSERT INTO `wp_postmeta` VALUES("4084","229","_yoast_wpseo_content_score","30");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2019-03-26 16:18:24","2019-03-26 13:18:24","<!-- wp:paragraph -->
<p> <br>[top_rated_products per_page=\"12\"] </p>
<!-- /wp:paragraph -->","Привет, мир!","","publish","open","open","","privet-mir","","","2019-04-10 22:09:10","2019-04-10 19:09:10","","0","http://localhost/tes/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("3","1","2019-03-26 16:18:24","2019-03-26 13:18:24","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://localhost/tes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","draft","closed","open","","privacy-policy","","","2019-03-26 16:18:24","2019-03-26 13:18:24","","0","http://localhost/tes/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("6","1","2019-03-29 13:16:25","2019-03-29 10:16:25","","cart_img","","inherit","open","closed","","cart_img","","","2019-03-29 13:16:25","2019-03-29 10:16:25","","0","http://localhost/tes/wp-content/uploads/2019/03/cart_img.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("22","1","2019-03-29 13:35:03","2019-03-29 10:35:03","","Товар","","publish","open","closed","","tovar","","","2019-03-29 13:35:03","2019-03-29 10:35:03","","0","http://localhost/tes/product/tovar/","0","product","","0");
INSERT INTO `wp_posts` VALUES("23","1","2019-03-29 13:35:05","2019-03-29 10:35:05","","Товар","","publish","open","closed","","tovar-2","","","2019-03-29 13:35:05","2019-03-29 10:35:05","","0","http://localhost/tes/product/tovar-2/","0","product","","0");
INSERT INTO `wp_posts` VALUES("24","1","2019-03-29 13:35:09","2019-03-29 10:35:09","","Товар","","publish","open","closed","","tovar-3","","","2019-03-29 13:35:09","2019-03-29 10:35:09","","0","http://localhost/tes/product/tovar-3/","0","product","","0");
INSERT INTO `wp_posts` VALUES("25","1","2019-03-29 13:35:11","2019-03-29 10:35:11","","Товар","","publish","open","closed","","tovar-4","","","2019-03-29 13:35:11","2019-03-29 10:35:11","","0","http://localhost/tes/product/tovar-4/","0","product","","0");
INSERT INTO `wp_posts` VALUES("26","1","2019-03-29 13:35:13","2019-03-29 10:35:13","","Товар","","publish","open","closed","","tovar-5","","","2019-03-29 13:35:13","2019-03-29 10:35:13","","0","http://localhost/tes/product/tovar-5/","0","product","","0");
INSERT INTO `wp_posts` VALUES("27","1","2019-03-29 13:35:15","2019-03-29 10:35:15","","Товар","","publish","open","closed","","tovar-6","","","2019-03-29 13:35:15","2019-03-29 10:35:15","","0","http://localhost/tes/product/tovar-6/","0","product","","0");
INSERT INTO `wp_posts` VALUES("28","1","2019-03-29 13:35:17","2019-03-29 10:35:17","","Товар","","publish","open","closed","","tovar-7","","","2019-03-29 13:35:17","2019-03-29 10:35:17","","0","http://localhost/tes/product/tovar-7/","0","product","","0");
INSERT INTO `wp_posts` VALUES("29","1","2019-03-29 13:35:19","2019-03-29 10:35:19","","Товар","","publish","open","closed","","tovar-8","","","2019-03-29 13:35:19","2019-03-29 10:35:19","","0","http://localhost/tes/product/tovar-8/","0","product","","0");
INSERT INTO `wp_posts` VALUES("30","1","2019-03-29 13:35:21","2019-03-29 10:35:21","","Товар 1","","publish","open","closed","","tovar-9","","","2019-03-29 14:45:40","2019-03-29 11:45:40","","0","http://localhost/tes/product/tovar-9/","0","product","","0");
INSERT INTO `wp_posts` VALUES("39","1","2019-03-29 14:39:35","2019-03-29 11:39:35","<!-- wp:paragraph {\"fontSize\":\"small\"} -->
<p class=\"has-small-font-size\"> <br>[woocommerce_cart] </p>
<!-- /wp:paragraph -->","Корзина","","publish","closed","closed","","korzina","","","2019-05-05 13:18:57","2019-05-05 10:18:57","","0","http://localhost/tes/?page_id=39","0","page","","0");
INSERT INTO `wp_posts` VALUES("40","1","2019-03-29 14:39:35","2019-03-29 11:39:35","<!-- wp:paragraph {\"fontSize\":\"small\"} -->
<p class=\"has-small-font-size\"></p>
<!-- /wp:paragraph -->","Корзина","","inherit","closed","closed","","39-revision-v1","","","2019-03-29 14:39:35","2019-03-29 11:39:35","","39","http://localhost/tes/2019/03/29/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("42","1","2019-04-07 14:42:12","2019-04-07 11:42:12","","avangard_logo","","inherit","open","closed","","avangard_logo","","","2019-04-16 18:51:46","2019-04-16 15:51:46","","91","http://localhost/tes/wp-content/uploads/2019/04/avangard_logo.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("43","1","2019-04-07 15:14:05","2019-04-07 12:14:05","","avangard_logo","","inherit","open","closed","","avangard_logo-2","","","2019-04-07 15:14:05","2019-04-07 12:14:05","","0","http://localhost/tes/wp-content/uploads/2019/04/avangard_logo.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("54","1","2019-04-08 20:47:20","2019-04-08 17:47:20","","Контакты","","publish","closed","closed","","kontakty","","","2019-04-08 20:47:21","2019-04-08 17:47:21","","0","http://localhost/tes/?page_id=54","0","page","","0");
INSERT INTO `wp_posts` VALUES("55","1","2019-04-08 20:47:20","2019-04-08 17:47:20","","Контакты","","inherit","closed","closed","","54-revision-v1","","","2019-04-08 20:47:20","2019-04-08 17:47:20","","54","http://localhost/tes/2019/04/08/54-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("56","1","2019-04-08 20:47:43","2019-04-08 17:47:43","<!-- wp:gallery -->
<ul class=\"wp-block-gallery columns-0 is-cropped\"></ul>
<!-- /wp:gallery -->

<!-- wp:paragraph -->
<p>Текст о доставке</p>
<!-- /wp:paragraph -->","Доставка","","publish","closed","closed","","dostavka","","","2019-04-15 22:21:23","2019-04-15 19:21:23","","0","http://localhost/tes/?page_id=56","0","page","","0");
INSERT INTO `wp_posts` VALUES("57","1","2019-04-08 20:47:43","2019-04-08 17:47:43","","Доставка","","inherit","closed","closed","","56-revision-v1","","","2019-04-08 20:47:43","2019-04-08 17:47:43","","56","http://localhost/tes/2019/04/08/56-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("59","1","2019-04-08 20:48:10","2019-04-08 17:48:10","","Как сделать заказ","","publish","closed","closed","","kak-sdelat-zakaz","","","2019-04-08 20:48:12","2019-04-08 17:48:12","","0","http://localhost/tes/?page_id=59","0","page","","0");
INSERT INTO `wp_posts` VALUES("60","1","2019-04-08 20:48:10","2019-04-08 17:48:10","","Как сделать заказ","","inherit","closed","closed","","59-revision-v1","","","2019-04-08 20:48:10","2019-04-08 17:48:10","","59","http://localhost/tes/2019/04/08/59-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("61","1","2019-04-08 20:52:25","2019-04-08 17:52:25","","Новинки","","publish","closed","closed","","novinki","","","2019-04-08 20:52:28","2019-04-08 17:52:28","","0","http://localhost/tes/?page_id=61","0","page","","0");
INSERT INTO `wp_posts` VALUES("62","1","2019-04-08 20:52:25","2019-04-08 17:52:25","","Новинки","","inherit","closed","closed","","61-revision-v1","","","2019-04-08 20:52:25","2019-04-08 17:52:25","","61","http://localhost/tes/2019/04/08/61-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("63","1","2019-04-08 20:52:41","2019-04-08 17:52:41","","Отзывы","","publish","closed","closed","","otzyvy","","","2019-04-08 20:52:42","2019-04-08 17:52:42","","0","http://localhost/tes/?page_id=63","0","page","","0");
INSERT INTO `wp_posts` VALUES("64","1","2019-04-08 20:52:41","2019-04-08 17:52:41","","Отзывы","","inherit","closed","closed","","63-revision-v1","","","2019-04-08 20:52:41","2019-04-08 17:52:41","","63","http://localhost/tes/2019/04/08/63-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("65","1","2019-04-08 20:57:36","2019-04-08 17:57:36","","Главная","","publish","closed","closed","","glavnaya","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=65","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("66","1","2019-04-08 20:57:36","2019-04-08 17:57:36"," ","","","publish","closed","closed","","66","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=66","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("67","1","2019-04-08 20:57:36","2019-04-08 17:57:36"," ","","","publish","closed","closed","","67","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=67","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("68","1","2019-04-08 20:57:37","2019-04-08 17:57:37"," ","","","publish","closed","closed","","68","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=68","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("69","1","2019-04-08 20:57:37","2019-04-08 17:57:37"," ","","","publish","closed","closed","","69","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=69","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("70","1","2019-04-08 20:57:37","2019-04-08 17:57:37"," ","","","publish","closed","closed","","70","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=70","6","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("72","1","2019-04-10 21:11:52","2019-04-10 18:11:52","<!-- wp:paragraph -->
<p>

[woocommerce_checkout]

</p>
<!-- /wp:paragraph -->","Страница оформления заказа","","publish","closed","closed","","oformleniya-zakaza","","","2019-05-17 11:35:07","2019-05-17 08:35:07","","0","http://localhost/tes/?page_id=72","0","page","","0");
INSERT INTO `wp_posts` VALUES("73","1","2019-04-10 21:11:52","2019-04-10 18:11:52","","оформления заказа","","inherit","closed","closed","","72-revision-v1","","","2019-04-10 21:11:52","2019-04-10 18:11:52","","72","http://localhost/tes/2019/04/10/72-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("75","1","2019-04-10 21:13:08","2019-04-10 18:13:08","<!-- wp:paragraph -->
<p>

[woocommerce_my_account]

</p>
<!-- /wp:paragraph -->","Мой акаунт","","publish","closed","closed","","moj-akaunt","","","2019-04-10 22:21:11","2019-04-10 19:21:11","","0","http://localhost/tes/?page_id=75","0","page","","0");
INSERT INTO `wp_posts` VALUES("76","1","2019-04-10 21:13:08","2019-04-10 18:13:08","","Мой акаунт","","inherit","closed","closed","","75-revision-v1","","","2019-04-10 21:13:08","2019-04-10 18:13:08","","75","http://localhost/tes/2019/04/10/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("77","1","2019-04-10 22:09:04","2019-04-10 19:09:04","<!-- wp:paragraph -->
<p> <br>[top_rated_products per_page=\"12\"] </p>
<!-- /wp:paragraph -->","Привет, мир!","","inherit","closed","closed","","1-revision-v1","","","2019-04-10 22:09:04","2019-04-10 19:09:04","","1","http://localhost/tes/2019/04/10/1-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("79","1","2019-04-10 22:10:37","2019-04-10 19:10:37","<!-- wp:paragraph -->
<p> <br><br></p>
<!-- /wp:paragraph -->","Привет, мир!","","inherit","closed","closed","","1-autosave-v1","","","2019-04-10 22:10:37","2019-04-10 19:10:37","","1","http://localhost/tes/2019/04/10/1-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("80","1","2019-04-10 22:11:21","2019-04-10 19:11:21","<!-- wp:paragraph {\"fontSize\":\"small\"} -->
<p class=\"has-small-font-size\">

[recent_products per_page=\"4\" columns=\"4\"]

</p>
<!-- /wp:paragraph -->","Корзина","","inherit","closed","closed","","39-revision-v1","","","2019-04-10 22:11:21","2019-04-10 19:11:21","","39","http://localhost/tes/2019/04/10/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("83","1","2019-04-10 22:19:11","2019-04-10 19:19:11","<!-- wp:paragraph {\"fontSize\":\"small\"} -->
<p class=\"has-small-font-size\"> <br>[woocommerce_cart] </p>
<!-- /wp:paragraph -->","Корзина","","inherit","closed","closed","","39-revision-v1","","","2019-04-10 22:19:11","2019-04-10 19:19:11","","39","http://localhost/tes/2019/04/10/39-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("84","1","2019-04-10 22:20:01","2019-04-10 19:20:01","<!-- wp:paragraph -->
<p>

[woocommerce_checkout]

</p>
<!-- /wp:paragraph -->","оформления заказа","","inherit","closed","closed","","72-revision-v1","","","2019-04-10 22:20:01","2019-04-10 19:20:01","","72","http://localhost/tes/2019/04/10/72-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("86","1","2019-04-10 22:21:03","2019-04-10 19:21:03","<!-- wp:paragraph -->
<p>

[woocommerce_my_account]

</p>
<!-- /wp:paragraph -->","Мой акаунт","","inherit","closed","closed","","75-revision-v1","","","2019-04-10 22:21:03","2019-04-10 19:21:03","","75","http://localhost/tes/2019/04/10/75-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("87","1","2019-04-15 22:21:21","2019-04-15 19:21:21","<!-- wp:gallery -->
<ul class=\"wp-block-gallery columns-0 is-cropped\"></ul>
<!-- /wp:gallery -->

<!-- wp:paragraph -->
<p>Текст о доставке</p>
<!-- /wp:paragraph -->","Доставка","","inherit","closed","closed","","56-revision-v1","","","2019-04-15 22:21:21","2019-04-15 19:21:21","","56","http://localhost/tes/2019/04/15/56-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("88","1","2019-04-15 22:31:40","2019-04-15 19:31:40","","Магазин","","publish","closed","closed","","88-2","","","2019-04-15 22:32:27","2019-04-15 19:32:27","","0","http://localhost/tes/?page_id=88","0","page","","0");
INSERT INTO `wp_posts` VALUES("89","1","2019-04-15 22:31:40","2019-04-15 19:31:40","<!-- wp:paragraph -->
<p>магазин</p>
<!-- /wp:paragraph -->","","","inherit","closed","closed","","88-revision-v1","","","2019-04-15 22:31:40","2019-04-15 19:31:40","","88","http://localhost/tes/2019/04/15/88-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("90","1","2019-04-15 22:32:25","2019-04-15 19:32:25","","Магазин","","inherit","closed","closed","","88-revision-v1","","","2019-04-15 22:32:25","2019-04-15 19:32:25","","88","http://localhost/tes/2019/04/15/88-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("91","1","2019-04-16 18:56:06","2019-04-16 15:56:06","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","атлас королевский","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","publish","open","closed","","orel","","","2019-05-01 19:27:24","2019-05-01 16:27:24","","0","http://localhost/tes/?post_type=product&#038;p=91","0","product","","1");
INSERT INTO `wp_posts` VALUES("93","1","2019-04-24 22:27:39","2019-04-24 19:27:39","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","атлас королевский","<ul><li>В наличии:&nbsp;30 м</li><li>Страна происхождения:&nbsp;ТУРЦИЯ</li><li>Состав:&nbsp;40% Вискоза, 50% Хлопок, 10% Полиэстр</li><li>Ширина:&nbsp;150 см</li><li>Плотнось: Толстая</li><li><br data-mce-bogus=\"1\"></li></ul>","inherit","closed","closed","","91-autosave-v1","","","2019-04-24 22:27:39","2019-04-24 19:27:39","","91","http://localhost/tes/2019/04/21/91-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("94","1","2019-04-22 14:26:12","2019-04-22 11:26:12","","img1","","inherit","open","closed","","img1","","","2019-04-22 14:26:12","2019-04-22 11:26:12","","91","http://localhost/tes/wp-content/uploads/2019/04/img1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("110","1","2019-04-24 21:00:32","2019-04-24 18:00:32","http://localhost/tes/wp-content/uploads/2019/04/WooCommerce-Quantity-Increment-master.zip","WooCommerce-Quantity-Increment-master.zip","","private","open","closed","","woocommerce-quantity-increment-master-zip","","","2019-04-24 21:00:32","2019-04-24 18:00:32","","0","http://localhost/tes/wp-content/uploads/2019/04/WooCommerce-Quantity-Increment-master.zip","0","attachment","","0");
INSERT INTO `wp_posts` VALUES("134","1","2019-05-03 00:31:10","2019-05-02 21:31:10","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","атлас шолк","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","publish","open","closed","","atlas-sholk","","","2019-06-26 17:08:14","2019-06-26 14:08:14","","0","http://localhost/tes/?post_type=product&#038;p=134","0","product","","4");
INSERT INTO `wp_posts` VALUES("135","1","2019-05-09 02:27:23","2019-05-08 23:27:23","<!-- wp:paragraph -->
<p>

[woocommerce_checkout]

</p>
<!-- /wp:paragraph -->","checkout","","inherit","closed","closed","","72-revision-v1","","","2019-05-09 02:27:23","2019-05-08 23:27:23","","72","http://localhost/tes/2019/05/09/72-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("138","1","2019-05-09 20:09:06","2019-05-09 17:09:06","<!-- wp:paragraph -->
<p>

[woocommerce_checkout]

</p>
<!-- /wp:paragraph -->","Страница оформления заказа","","inherit","closed","closed","","72-revision-v1","","","2019-05-09 20:09:06","2019-05-09 17:09:06","","72","http://localhost/tes/2019/05/09/72-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("139","1","2019-05-14 20:43:11","2019-05-14 17:43:11","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","Бензин 95 Лучшая цена года 20199","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","publish","open","closed","","benzin-95-luchshaya-tsena-goda-20199","","","2019-06-23 15:55:47","2019-06-23 12:55:47","","0","http://localhost/tes/?post_type=product&#038;p=139","0","product","","2");
INSERT INTO `wp_posts` VALUES("140","1","2019-05-14 20:41:41","2019-05-14 17:41:41","","01b2584ded19fbad4577127e404d88ffd35c379c9b","","inherit","open","closed","","01b2584ded19fbad4577127e404d88ffd35c379c9b","","","2019-05-14 20:41:41","2019-05-14 17:41:41","","139","http://localhost/tes/wp-content/uploads/2019/05/01b2584ded19fbad4577127e404d88ffd35c379c9b.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("142","1","2019-05-14 20:54:56","2019-05-14 17:54:56","вввывафвыафыввввывафвыафыввввывафвыафыв","атлас шолк","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","inherit","closed","closed","","134-autosave-v1","","","2019-05-14 20:54:56","2019-05-14 17:54:56","","134","http://localhost/tes/2019/05/14/134-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("148","1","2019-05-23 14:09:02","2019-05-23 11:09:02"," ","","","publish","closed","closed","","148","","","2019-05-23 14:09:02","2019-05-23 11:09:02","","0","http://localhost/tes/?p=148","7","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("151","1","2019-05-28 13:41:12","2019-05-28 10:41:12"," ","","","publish","closed","closed","","151","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=151","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("154","1","2019-05-28 14:44:19","2019-05-28 11:44:19"," ","","","publish","closed","closed","","154","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=154","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("155","1","2019-05-28 14:44:19","2019-05-28 11:44:19"," ","","","publish","closed","closed","","155","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=155","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("157","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","157","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=157","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("158","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","158","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=158","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("159","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","159","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=159","6","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("160","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","160","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=160","7","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("161","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","161","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=161","8","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("162","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","162","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=162","9","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("163","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","163","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=163","10","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("164","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","164","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=164","11","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("165","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","165","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=165","12","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("166","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","166","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=166","13","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("167","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","167","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=167","14","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("168","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","168","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=168","15","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("169","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","169","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=169","17","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("170","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","170","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=170","18","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("171","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","171","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=171","21","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("172","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","172","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=172","23","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("173","1","2019-05-30 16:14:25","2019-05-30 13:14:25"," ","","","publish","closed","closed","","173","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=173","24","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("174","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","174","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=174","25","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("175","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","175","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=175","26","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("176","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","176","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=176","27","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("177","1","2019-05-30 16:28:20","2019-05-30 13:28:20"," ","","","publish","closed","closed","","177","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=177","19","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("178","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","178","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=178","28","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("179","1","2019-05-30 16:28:20","2019-05-30 13:28:20"," ","","","publish","closed","closed","","179","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=179","20","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("180","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","180","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=180","22","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("181","1","2019-05-30 16:28:20","2019-05-30 13:28:20"," ","","","publish","closed","closed","","181","","","2019-05-30 16:28:20","2019-05-30 13:28:20","","0","http://localhost/tes/?p=181","16","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("182","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","182","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=182","29","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("183","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","183","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=183","30","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("184","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","184","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=184","31","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("185","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","185","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=185","32","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("186","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","186","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=186","33","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("187","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","187","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=187","34","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("188","1","2019-05-30 16:28:21","2019-05-30 13:28:21"," ","","","publish","closed","closed","","188","","","2019-05-30 16:28:21","2019-05-30 13:28:21","","0","http://localhost/tes/?p=188","35","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("190","1","2019-06-23 15:03:49","2019-06-23 12:03:49","{
    \"widget_woocommerce_layered_nav[2]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjg6ItCm0LLQtdGCIjtzOjk6ImF0dHJpYnV0ZSI7czoxMzoicHJvZHVjdF9jb2xvciI7czoxMjoiZGlzcGxheV90eXBlIjtzOjQ6Imxpc3QiO3M6MTA6InF1ZXJ5X3R5cGUiO3M6Mjoib3IiO30=\",
            \"title\": \"\\u0426\\u0432\\u0435\\u0442\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"6cd2d292da1fe70d206845455804f135\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-06-23 12:03:49\"
    }
}","","","trash","closed","closed","","e0176913-6a64-46d1-8cb6-0cb4e6a10a4a","","","2019-06-23 15:03:49","2019-06-23 12:03:49","","0","http://localhost/tes/2019/06/23/e0176913-6a64-46d1-8cb6-0cb4e6a10a4a/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("191","1","2019-06-23 15:05:53","2019-06-23 12:05:53","{
    \"woocommerce_shop_page_display\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-06-23 12:05:18\"
    },
    \"woocommerce_category_archive_display\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-06-23 12:05:53\"
    }
}","","","trash","closed","closed","","fcd372cb-492f-4134-ab93-4cdeefc158c4","","","2019-06-23 15:05:53","2019-06-23 12:05:53","","0","http://localhost/tes/?p=191","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("192","1","2019-06-27 14:20:28","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2019-06-27 14:20:28","0000-00-00 00:00:00","","0","http://localhost/tes/?p=192","0","post","","0");
INSERT INTO `wp_posts` VALUES("211","1","2019-06-28 17:18:07","2019-06-28 14:18:07","<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
<p class=\"has-huge-font-size\">пост 1 111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111</p>
<!-- /wp:paragraph -->","","","publish","open","open","","211","","","2019-06-28 17:18:09","2019-06-28 14:18:09","","0","http://localhost/tes/?p=211","0","post","","0");
INSERT INTO `wp_posts` VALUES("212","1","2019-06-28 17:18:07","2019-06-28 14:18:07","<!-- wp:paragraph {\"fontSize\":\"huge\"} -->
<p class=\"has-huge-font-size\">пост 1 111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111</p>
<!-- /wp:paragraph -->","","","inherit","closed","closed","","211-revision-v1","","","2019-06-28 17:18:07","2019-06-28 14:18:07","","211","http://localhost/tes/2019/06/28/211-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("213","1","2019-06-28 17:18:32","2019-06-28 14:18:32","<!-- wp:paragraph -->
<p> пост 2 111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111 </p>
<!-- /wp:paragraph -->","","","publish","open","open","","213","","","2019-06-28 17:18:34","2019-06-28 14:18:34","","0","http://localhost/tes/?p=213","0","post","","0");
INSERT INTO `wp_posts` VALUES("214","1","2019-06-28 17:18:32","2019-06-28 14:18:32","<!-- wp:paragraph -->
<p> пост 2 111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111 </p>
<!-- /wp:paragraph -->","","","inherit","closed","closed","","213-revision-v1","","","2019-06-28 17:18:32","2019-06-28 14:18:32","","213","http://localhost/tes/2019/06/28/213-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("215","1","2019-06-28 17:19:51","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p> пост</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>313111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111 </p>
<!-- /wp:paragraph -->","","","draft","open","open","","","","","2019-06-28 17:19:51","2019-06-28 14:19:51","","0","http://localhost/tes/?p=215","0","post","","0");
INSERT INTO `wp_posts` VALUES("216","1","2019-06-29 11:24:23","2019-06-29 08:24:23","","Шифон толстый","лям-лялям","publish","open","closed","","shifon-tolstyj","","","2019-06-29 11:24:23","2019-06-29 08:24:23","","0","http://localhost/tes/?post_type=product&#038;p=216","0","product","","0");
INSERT INTO `wp_posts` VALUES("217","1","2019-06-29 11:57:40","2019-06-29 08:57:40","","Шифон толстый (Копировать)","лям-лялям","trash","open","closed","","__trashed-10__trashed","","","2019-06-29 12:02:02","2019-06-29 09:02:02","","0","http://localhost/tes/?post_type=product&#038;p=217","0","product","","0");
INSERT INTO `wp_posts` VALUES("218","1","2019-06-29 11:57:43","2019-06-29 08:57:43","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","Бензин 95 Лучшая цена года 20199 (Копировать)","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","trash","open","closed","","__trashed-9","","","2019-06-29 12:01:42","2019-06-29 09:01:42","","0","http://localhost/tes/?post_type=product&#038;p=218","0","product","","0");
INSERT INTO `wp_posts` VALUES("219","1","2019-06-29 11:57:46","2019-06-29 08:57:46","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","атлас шолк (Копировать)","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","trash","open","closed","","__trashed-8","","","2019-06-29 12:01:39","2019-06-29 09:01:39","","0","http://localhost/tes/?post_type=product&#038;p=219","0","product","","0");
INSERT INTO `wp_posts` VALUES("220","1","2019-06-29 11:57:47","2019-06-29 08:57:47","<b>Атла́с</b> (араб., буквально — гладкий) — плотная <a title=\"Шёлк\" href=\"https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA\">шёлковая</a> или полушёлковая <a title=\"Ткань\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C\">ткань</a><sup id=\"cite_ref-1\" class=\"reference\"><a href=\"https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1\">[1]</a></sup> атласного <a title=\"Ткацкие переплетения\" href=\"https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F\">переплетения</a> с гладкой блестящей лицевой поверхностью. При атласном переплетении <a title=\"Уток\" href=\"https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA\">уто́к</a> выходит на лицевую поверхность через пять и более нитей основы. Этим достигается особая гладкость ткани. Атласы могут быть как гладкими, так и узорчатыми.

Атлас применяется для пошива одежды (например, <a title=\"Смокинг\" href=\"https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3\">смокингов</a>) и <a title=\"Обувь\" href=\"https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C\">обуви</a> (в том числе <a title=\"Пуанты\" href=\"https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B\">пуантов</a>), отделки праздничных церковных облачений, изготовления драпировок, обивки <a title=\"Мебель\" href=\"https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C\">мебели</a>, изготовления флагов и другого.","атлас королевский (Копировать)","<ul>
 	<li>В наличии: 30 м</li>
 	<li>Страна происхождения: ТУРЦИЯ</li>
 	<li>Состав: 40% Вискоза, 50% Хлопок, 10% Полиэстр</li>
 	<li>Ширина: 150 см</li>
 	<li>Плотность: Оч плотная</li>
</ul>","trash","open","closed","","__trashed-7","","","2019-06-29 12:01:38","2019-06-29 09:01:38","","0","http://localhost/tes/?post_type=product&#038;p=220","0","product","","0");
INSERT INTO `wp_posts` VALUES("221","1","2019-06-29 11:57:50","2019-06-29 08:57:50","","Товар 1 (Копировать)","","trash","open","closed","","__trashed-6","","","2019-06-29 12:01:36","2019-06-29 09:01:36","","0","http://localhost/tes/?post_type=product&#038;p=221","0","product","","0");
INSERT INTO `wp_posts` VALUES("222","1","2019-06-29 11:57:51","2019-06-29 08:57:51","","Товар (Копировать)","","trash","open","closed","","__trashed","","","2019-06-29 12:01:21","2019-06-29 09:01:21","","0","http://localhost/tes/?post_type=product&#038;p=222","0","product","","0");
INSERT INTO `wp_posts` VALUES("223","1","2019-06-29 11:57:52","2019-06-29 08:57:52","","Товар (Копировать)","","trash","open","closed","","__trashed-5","","","2019-06-29 12:01:34","2019-06-29 09:01:34","","0","http://localhost/tes/?post_type=product&#038;p=223","0","product","","0");
INSERT INTO `wp_posts` VALUES("224","1","2019-06-29 11:57:56","2019-06-29 08:57:56","","Товар (Копировать)","","trash","open","closed","","__trashed-4","","","2019-06-29 12:01:33","2019-06-29 09:01:33","","0","http://localhost/tes/?post_type=product&#038;p=224","0","product","","0");
INSERT INTO `wp_posts` VALUES("225","1","2019-06-29 11:57:57","2019-06-29 08:57:57","","Товар (Копировать)","","trash","open","closed","","__trashed-3","","","2019-06-29 12:01:31","2019-06-29 09:01:31","","0","http://localhost/tes/?post_type=product&#038;p=225","0","product","","0");
INSERT INTO `wp_posts` VALUES("226","1","2019-06-29 11:57:59","2019-06-29 08:57:59","","Товар (Копировать)","","trash","open","closed","","__trashed-2","","","2019-06-29 12:01:28","2019-06-29 09:01:28","","0","http://localhost/tes/?post_type=product&#038;p=226","0","product","","0");
INSERT INTO `wp_posts` VALUES("227","1","2019-06-29 12:05:23","2019-06-29 09:05:23","Оч свежая","курка свежая","","publish","open","closed","","kurka-svezhaya","","","2019-06-29 12:05:23","2019-06-29 09:05:23","","0","http://localhost/tes/?post_type=product&#038;p=227","0","product","","0");
INSERT INTO `wp_posts` VALUES("228","1","2019-06-29 12:06:44","2019-06-29 09:06:44","петушок свежий","петушок","","publish","open","closed","","petushok","","","2019-06-29 12:06:44","2019-06-29 09:06:44","","0","http://localhost/tes/?post_type=product&#038;p=228","0","product","","0");
INSERT INTO `wp_posts` VALUES("229","1","2019-06-29 12:07:41","2019-06-29 09:07:41","честно гоовалый","бык годовалый","","publish","open","closed","","byk-godovalyj","","","2019-06-29 12:07:41","2019-06-29 09:07:41","","0","http://localhost/tes/?post_type=product&#038;p=229","0","product","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("22","2","0");
INSERT INTO `wp_term_relationships` VALUES("22","15","0");
INSERT INTO `wp_term_relationships` VALUES("23","2","0");
INSERT INTO `wp_term_relationships` VALUES("23","15","0");
INSERT INTO `wp_term_relationships` VALUES("24","2","0");
INSERT INTO `wp_term_relationships` VALUES("24","15","0");
INSERT INTO `wp_term_relationships` VALUES("25","2","0");
INSERT INTO `wp_term_relationships` VALUES("25","15","0");
INSERT INTO `wp_term_relationships` VALUES("26","2","0");
INSERT INTO `wp_term_relationships` VALUES("26","15","0");
INSERT INTO `wp_term_relationships` VALUES("27","2","0");
INSERT INTO `wp_term_relationships` VALUES("27","15","0");
INSERT INTO `wp_term_relationships` VALUES("28","2","0");
INSERT INTO `wp_term_relationships` VALUES("28","15","0");
INSERT INTO `wp_term_relationships` VALUES("29","2","0");
INSERT INTO `wp_term_relationships` VALUES("29","15","0");
INSERT INTO `wp_term_relationships` VALUES("30","2","0");
INSERT INTO `wp_term_relationships` VALUES("30","15","0");
INSERT INTO `wp_term_relationships` VALUES("65","20","0");
INSERT INTO `wp_term_relationships` VALUES("66","20","0");
INSERT INTO `wp_term_relationships` VALUES("67","20","0");
INSERT INTO `wp_term_relationships` VALUES("68","20","0");
INSERT INTO `wp_term_relationships` VALUES("69","20","0");
INSERT INTO `wp_term_relationships` VALUES("70","20","0");
INSERT INTO `wp_term_relationships` VALUES("91","2","0");
INSERT INTO `wp_term_relationships` VALUES("91","21","0");
INSERT INTO `wp_term_relationships` VALUES("91","22","0");
INSERT INTO `wp_term_relationships` VALUES("134","2","0");
INSERT INTO `wp_term_relationships` VALUES("134","21","0");
INSERT INTO `wp_term_relationships` VALUES("134","28","0");
INSERT INTO `wp_term_relationships` VALUES("134","50","0");
INSERT INTO `wp_term_relationships` VALUES("139","2","0");
INSERT INTO `wp_term_relationships` VALUES("139","9","0");
INSERT INTO `wp_term_relationships` VALUES("139","21","0");
INSERT INTO `wp_term_relationships` VALUES("148","20","0");
INSERT INTO `wp_term_relationships` VALUES("151","32","0");
INSERT INTO `wp_term_relationships` VALUES("154","32","0");
INSERT INTO `wp_term_relationships` VALUES("155","32","0");
INSERT INTO `wp_term_relationships` VALUES("157","32","0");
INSERT INTO `wp_term_relationships` VALUES("158","32","0");
INSERT INTO `wp_term_relationships` VALUES("159","32","0");
INSERT INTO `wp_term_relationships` VALUES("160","32","0");
INSERT INTO `wp_term_relationships` VALUES("161","32","0");
INSERT INTO `wp_term_relationships` VALUES("162","32","0");
INSERT INTO `wp_term_relationships` VALUES("163","32","0");
INSERT INTO `wp_term_relationships` VALUES("164","32","0");
INSERT INTO `wp_term_relationships` VALUES("165","32","0");
INSERT INTO `wp_term_relationships` VALUES("166","32","0");
INSERT INTO `wp_term_relationships` VALUES("167","32","0");
INSERT INTO `wp_term_relationships` VALUES("168","32","0");
INSERT INTO `wp_term_relationships` VALUES("169","32","0");
INSERT INTO `wp_term_relationships` VALUES("170","32","0");
INSERT INTO `wp_term_relationships` VALUES("171","32","0");
INSERT INTO `wp_term_relationships` VALUES("172","32","0");
INSERT INTO `wp_term_relationships` VALUES("173","32","0");
INSERT INTO `wp_term_relationships` VALUES("174","32","0");
INSERT INTO `wp_term_relationships` VALUES("175","32","0");
INSERT INTO `wp_term_relationships` VALUES("176","32","0");
INSERT INTO `wp_term_relationships` VALUES("177","32","0");
INSERT INTO `wp_term_relationships` VALUES("178","32","0");
INSERT INTO `wp_term_relationships` VALUES("179","32","0");
INSERT INTO `wp_term_relationships` VALUES("180","32","0");
INSERT INTO `wp_term_relationships` VALUES("181","32","0");
INSERT INTO `wp_term_relationships` VALUES("182","32","0");
INSERT INTO `wp_term_relationships` VALUES("183","32","0");
INSERT INTO `wp_term_relationships` VALUES("184","32","0");
INSERT INTO `wp_term_relationships` VALUES("185","32","0");
INSERT INTO `wp_term_relationships` VALUES("186","32","0");
INSERT INTO `wp_term_relationships` VALUES("187","32","0");
INSERT INTO `wp_term_relationships` VALUES("188","32","0");
INSERT INTO `wp_term_relationships` VALUES("211","1","0");
INSERT INTO `wp_term_relationships` VALUES("213","1","0");
INSERT INTO `wp_term_relationships` VALUES("215","1","0");
INSERT INTO `wp_term_relationships` VALUES("216","2","0");
INSERT INTO `wp_term_relationships` VALUES("216","15","0");
INSERT INTO `wp_term_relationships` VALUES("217","2","0");
INSERT INTO `wp_term_relationships` VALUES("217","15","0");
INSERT INTO `wp_term_relationships` VALUES("218","2","0");
INSERT INTO `wp_term_relationships` VALUES("218","9","0");
INSERT INTO `wp_term_relationships` VALUES("218","21","0");
INSERT INTO `wp_term_relationships` VALUES("219","2","0");
INSERT INTO `wp_term_relationships` VALUES("219","21","0");
INSERT INTO `wp_term_relationships` VALUES("219","28","0");
INSERT INTO `wp_term_relationships` VALUES("219","50","0");
INSERT INTO `wp_term_relationships` VALUES("220","2","0");
INSERT INTO `wp_term_relationships` VALUES("220","21","0");
INSERT INTO `wp_term_relationships` VALUES("220","22","0");
INSERT INTO `wp_term_relationships` VALUES("221","2","0");
INSERT INTO `wp_term_relationships` VALUES("221","15","0");
INSERT INTO `wp_term_relationships` VALUES("222","2","0");
INSERT INTO `wp_term_relationships` VALUES("222","15","0");
INSERT INTO `wp_term_relationships` VALUES("223","2","0");
INSERT INTO `wp_term_relationships` VALUES("223","15","0");
INSERT INTO `wp_term_relationships` VALUES("224","2","0");
INSERT INTO `wp_term_relationships` VALUES("224","15","0");
INSERT INTO `wp_term_relationships` VALUES("225","2","0");
INSERT INTO `wp_term_relationships` VALUES("225","15","0");
INSERT INTO `wp_term_relationships` VALUES("226","2","0");
INSERT INTO `wp_term_relationships` VALUES("226","15","0");
INSERT INTO `wp_term_relationships` VALUES("227","2","0");
INSERT INTO `wp_term_relationships` VALUES("227","35","0");
INSERT INTO `wp_term_relationships` VALUES("228","2","0");
INSERT INTO `wp_term_relationships` VALUES("228","45","0");
INSERT INTO `wp_term_relationships` VALUES("229","2","0");
INSERT INTO `wp_term_relationships` VALUES("229","36","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","product_type","","0","16");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","product_visibility","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("11","11","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("12","12","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("13","13","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("14","14","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("15","15","product_cat","","0","10");
INSERT INTO `wp_term_taxonomy` VALUES("20","20","nav_menu","","0","7");
INSERT INTO `wp_term_taxonomy` VALUES("21","21","product_cat","","0","3");
INSERT INTO `wp_term_taxonomy` VALUES("22","22","product_tag","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("28","28","pa_plotnost","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("29","29","pa_plotnost","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("32","32","nav_menu","","0","35");
INSERT INTO `wp_term_taxonomy` VALUES("33","33","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("34","34","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("35","35","product_cat","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("36","36","product_cat","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("37","37","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("38","38","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("39","39","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("40","40","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("41","41","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("42","42","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("43","43","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("44","44","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("45","45","product_cat","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("46","46","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("47","47","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("48","48","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("49","49","product_color","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("50","50","pa_tsvet","Цвет красный","0","1");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_termmeta` VALUES("3","15","product_count_product_cat","10");
INSERT INTO `wp_termmeta` VALUES("6","21","order","2");
INSERT INTO `wp_termmeta` VALUES("7","21","product_count_product_cat","3");
INSERT INTO `wp_termmeta` VALUES("8","22","product_count_product_tag","1");
INSERT INTO `wp_termmeta` VALUES("19","28","order_pa_plotnost","0");
INSERT INTO `wp_termmeta` VALUES("20","28","label","1");
INSERT INTO `wp_termmeta` VALUES("21","29","order_pa_plotnost","0");
INSERT INTO `wp_termmeta` VALUES("22","29","label","2");
INSERT INTO `wp_termmeta` VALUES("25","33","order","1");
INSERT INTO `wp_termmeta` VALUES("26","33","display_type","");
INSERT INTO `wp_termmeta` VALUES("27","33","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("28","34","order","4");
INSERT INTO `wp_termmeta` VALUES("29","34","display_type","");
INSERT INTO `wp_termmeta` VALUES("30","34","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("31","35","order","5");
INSERT INTO `wp_termmeta` VALUES("32","35","display_type","");
INSERT INTO `wp_termmeta` VALUES("33","35","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("34","36","order","6");
INSERT INTO `wp_termmeta` VALUES("35","36","display_type","");
INSERT INTO `wp_termmeta` VALUES("36","36","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("37","37","order","10");
INSERT INTO `wp_termmeta` VALUES("38","37","display_type","");
INSERT INTO `wp_termmeta` VALUES("39","37","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("40","38","order","12");
INSERT INTO `wp_termmeta` VALUES("41","38","display_type","");
INSERT INTO `wp_termmeta` VALUES("42","38","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("43","39","order","7");
INSERT INTO `wp_termmeta` VALUES("44","39","display_type","");
INSERT INTO `wp_termmeta` VALUES("45","39","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("46","40","order","8");
INSERT INTO `wp_termmeta` VALUES("47","40","display_type","");
INSERT INTO `wp_termmeta` VALUES("48","40","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("49","41","order","9");
INSERT INTO `wp_termmeta` VALUES("50","41","display_type","");
INSERT INTO `wp_termmeta` VALUES("51","41","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("52","42","order","11");
INSERT INTO `wp_termmeta` VALUES("53","42","display_type","");
INSERT INTO `wp_termmeta` VALUES("54","42","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("55","43","order","13");
INSERT INTO `wp_termmeta` VALUES("56","43","display_type","");
INSERT INTO `wp_termmeta` VALUES("57","43","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("58","44","order","14");
INSERT INTO `wp_termmeta` VALUES("59","44","display_type","");
INSERT INTO `wp_termmeta` VALUES("60","44","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("61","45","order","3");
INSERT INTO `wp_termmeta` VALUES("62","45","display_type","");
INSERT INTO `wp_termmeta` VALUES("63","45","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("64","46","order","17");
INSERT INTO `wp_termmeta` VALUES("65","46","display_type","");
INSERT INTO `wp_termmeta` VALUES("66","46","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("67","47","order","15");
INSERT INTO `wp_termmeta` VALUES("68","47","display_type","");
INSERT INTO `wp_termmeta` VALUES("69","47","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("70","48","order","16");
INSERT INTO `wp_termmeta` VALUES("71","48","display_type","");
INSERT INTO `wp_termmeta` VALUES("72","48","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("73","15","order","18");
INSERT INTO `wp_termmeta` VALUES("74","15","display_type","");
INSERT INTO `wp_termmeta` VALUES("75","15","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("77","50","order_pa_tsvet","0");
INSERT INTO `wp_termmeta` VALUES("78","50","pa_tsvet_yith_wccl_value","#fc0000");
INSERT INTO `wp_termmeta` VALUES("79","35","product_count_product_cat","1");
INSERT INTO `wp_termmeta` VALUES("80","45","product_count_product_cat","1");
INSERT INTO `wp_termmeta` VALUES("81","36","product_count_product_cat","1");


DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","bez-rubriki","0");
INSERT INTO `wp_terms` VALUES("2","simple","simple","0");
INSERT INTO `wp_terms` VALUES("3","grouped","grouped","0");
INSERT INTO `wp_terms` VALUES("4","variable","variable","0");
INSERT INTO `wp_terms` VALUES("5","external","external","0");
INSERT INTO `wp_terms` VALUES("6","exclude-from-search","exclude-from-search","0");
INSERT INTO `wp_terms` VALUES("7","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `wp_terms` VALUES("8","featured","featured","0");
INSERT INTO `wp_terms` VALUES("9","outofstock","outofstock","0");
INSERT INTO `wp_terms` VALUES("10","rated-1","rated-1","0");
INSERT INTO `wp_terms` VALUES("11","rated-2","rated-2","0");
INSERT INTO `wp_terms` VALUES("12","rated-3","rated-3","0");
INSERT INTO `wp_terms` VALUES("13","rated-4","rated-4","0");
INSERT INTO `wp_terms` VALUES("14","rated-5","rated-5","0");
INSERT INTO `wp_terms` VALUES("15","шифон","shifon","0");
INSERT INTO `wp_terms` VALUES("20","Base","base","0");
INSERT INTO `wp_terms` VALUES("21","атлас","atlas","0");
INSERT INTO `wp_terms` VALUES("22","красный","krasnyj","0");
INSERT INTO `wp_terms` VALUES("28","Тонкая","tonkaya","0");
INSERT INTO `wp_terms` VALUES("29","толстая","tolstaya","0");
INSERT INTO `wp_terms` VALUES("32","каталог","katalog","0");
INSERT INTO `wp_terms` VALUES("33","Cатин","satin","0");
INSERT INTO `wp_terms` VALUES("34","Вельвет","velvet","0");
INSERT INTO `wp_terms` VALUES("35","Велюр","velyr","0");
INSERT INTO `wp_terms` VALUES("36","Гипюр","gipiyr","0");
INSERT INTO `wp_terms` VALUES("37","Кружево","kruzhevo","0");
INSERT INTO `wp_terms` VALUES("38","Макроме","makrome","0");
INSERT INTO `wp_terms` VALUES("39","Джинс","dzhins","0");
INSERT INTO `wp_terms` VALUES("40","Кожа искуственная","kozha-iskustvennaya","0");
INSERT INTO `wp_terms` VALUES("41","Костюмные ткани","kostyumnye-tkani","0");
INSERT INTO `wp_terms` VALUES("42","Лён","lyon","0");
INSERT INTO `wp_terms` VALUES("43","Меха Искуственные","meha-iskustvennye","0");
INSERT INTO `wp_terms` VALUES("44","Паетка","paetka","0");
INSERT INTO `wp_terms` VALUES("45","Бисер","biser","0");
INSERT INTO `wp_terms` VALUES("46","Ткани с Апликацией","tkani-s-aplikatsiej","0");
INSERT INTO `wp_terms` VALUES("47","Пальтовые Ткани","paltovye-tkani","0");
INSERT INTO `wp_terms` VALUES("48","Подкладочные ткани","podkladochnye-tkani","0");
INSERT INTO `wp_terms` VALUES("49","Фиолетовый","fioletovoy","0");
INSERT INTO `wp_terms` VALUES("50","Красный","krasnyj","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","Андрей");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","Домарацкий");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","wp496_privacy");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","0");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","192");
INSERT INTO `wp_usermeta` VALUES("20","1","wc_last_active","1562112000");
INSERT INTO `wp_usermeta` VALUES("21","1","dismissed_install_notice","1");
INSERT INTO `wp_usermeta` VALUES("22","1","dismissed_no_secure_connection_notice","1");
INSERT INTO `wp_usermeta` VALUES("23","1","dismissed_wootenberg_notice","1");
INSERT INTO `wp_usermeta` VALUES("24","1","_yoast_wpseo_profile_updated","1561731950");
INSERT INTO `wp_usermeta` VALUES("26","1","wp_user-settings","libraryContent=browse&widgets_access=on");
INSERT INTO `wp_usermeta` VALUES("27","1","wp_user-settings","libraryContent=browse&widgets_access=on");
INSERT INTO `wp_usermeta` VALUES("28","1","wp_user-settings-time","1561565781");
INSERT INTO `wp_usermeta` VALUES("29","1","wp_woocommerce_product_import_mapping","a:10:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";i:6;s:0:\"\";i:7;s:0:\"\";i:8;s:0:\"\";i:9;s:0:\"\";}");
INSERT INTO `wp_usermeta` VALUES("30","1","wp_product_import_error_log","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("33","1","last_login_time","2019-07-03 16:46:42");
INSERT INTO `wp_usermeta` VALUES("36","2","nickname","adminffffff");
INSERT INTO `wp_usermeta` VALUES("37","2","first_name","");
INSERT INTO `wp_usermeta` VALUES("38","2","last_name","");
INSERT INTO `wp_usermeta` VALUES("39","2","description","");
INSERT INTO `wp_usermeta` VALUES("40","2","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("41","2","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("42","2","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("43","2","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("44","2","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("45","2","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("46","2","locale","");
INSERT INTO `wp_usermeta` VALUES("47","2","wp_capabilities","a:1:{s:8:\"customer\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("48","2","wp_user_level","0");
INSERT INTO `wp_usermeta` VALUES("49","2","_yoast_wpseo_profile_updated","1554635439");
INSERT INTO `wp_usermeta` VALUES("50","2","session_tokens","a:1:{s:64:\"673e3bcda15dcad672a43750509528ca065dd31314ae0069034a131b8cb9f832\";a:4:{s:10:\"expiration\";i:1555845041;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";s:5:\"login\";i:1554635441;}}");
INSERT INTO `wp_usermeta` VALUES("51","2","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}");
INSERT INTO `wp_usermeta` VALUES("52","2","wc_last_active","1554595200");
INSERT INTO `wp_usermeta` VALUES("56","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("57","1","metaboxhidden_nav-menus","a:6:{i:0;s:18:\"add-post-type-post\";i:1;s:16:\"add-custom-links\";i:2;s:12:\"add-category\";i:3;s:12:\"add-post_tag\";i:4;s:15:\"add-product_tag\";i:5;s:30:\"woocommerce_endpoints_nav_link\";}");
INSERT INTO `wp_usermeta` VALUES("60","1","nav_menu_recently_edited","32");
INSERT INTO `wp_usermeta` VALUES("63","1","closedpostboxes_product","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("64","1","metaboxhidden_product","a:2:{i:0;s:10:\"postcustom\";i:1;s:7:\"slugdiv\";}");
INSERT INTO `wp_usermeta` VALUES("67","1","last_update","1558699219");
INSERT INTO `wp_usermeta` VALUES("68","1","billing_first_name","Андрей");
INSERT INTO `wp_usermeta` VALUES("69","1","billing_last_name","Домарацкий");
INSERT INTO `wp_usermeta` VALUES("70","1","billing_company","чп");
INSERT INTO `wp_usermeta` VALUES("71","1","billing_address_1","центральная 80");
INSERT INTO `wp_usermeta` VALUES("72","1","billing_address_2","");
INSERT INTO `wp_usermeta` VALUES("73","1","billing_city","Дв Кут");
INSERT INTO `wp_usermeta` VALUES("74","1","billing_state","Харьковская");
INSERT INTO `wp_usermeta` VALUES("75","1","billing_postcode","121212");
INSERT INTO `wp_usermeta` VALUES("76","1","billing_country","UA");
INSERT INTO `wp_usermeta` VALUES("77","1","billing_email","domaratskiy1990@gmail.com");
INSERT INTO `wp_usermeta` VALUES("78","1","billing_phone","0885014122");
INSERT INTO `wp_usermeta` VALUES("79","1","shipping_first_name","Андрей");
INSERT INTO `wp_usermeta` VALUES("80","1","shipping_last_name","Домарацкий");
INSERT INTO `wp_usermeta` VALUES("81","1","shipping_address_1","центральная 80");
INSERT INTO `wp_usermeta` VALUES("82","1","shipping_address_2","");
INSERT INTO `wp_usermeta` VALUES("83","1","shipping_city","Дв Кут");
INSERT INTO `wp_usermeta` VALUES("84","1","shipping_state","Харьковская");
INSERT INTO `wp_usermeta` VALUES("85","1","shipping_postcode","121212");
INSERT INTO `wp_usermeta` VALUES("86","1","shipping_country","UA");
INSERT INTO `wp_usermeta` VALUES("87","1","shipping_method","a:1:{i:0;s:11:\"flat_rate:1\";}");
INSERT INTO `wp_usermeta` VALUES("95","1","shipping_company","чп");
INSERT INTO `wp_usermeta` VALUES("133","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:2:{s:32:\"02522a2b2726fb0a03bb19f2d8d9524d\";a:11:{s:3:\"key\";s:32:\"02522a2b2726fb0a03bb19f2d8d9524d\";s:10:\"product_id\";i:134;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:750;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:750;s:8:\"line_tax\";i:0;}s:32:\"54229abfcfa5649e7003b83dd4755294\";a:11:{s:3:\"key\";s:32:\"54229abfcfa5649e7003b83dd4755294\";s:10:\"product_id\";i:91;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:399;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:399;s:8:\"line_tax\";i:0;}}}");
INSERT INTO `wp_usermeta` VALUES("135","1","closedpostboxes_nav-menus","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("138","1","meta-box-order_dashboard","a:4:{s:6:\"normal\";s:92:\"dashboard_right_now,dashboard_activity,wpseo-dashboard-overview,woocommerce_dashboard_status\";s:4:\"side\";s:54:\"dashboard_primary,woocommerce_dashboard_recent_reviews\";s:7:\"column3\";s:21:\"dashboard_quick_press\";s:7:\"column4\";s:0:\"\";}");
INSERT INTO `wp_usermeta` VALUES("141","1","session_tokens","a:4:{s:64:\"754e26cdf9b3466557c75400ae225d2a4953c318b5a160b6701fa1dc2cbfcd93\";a:4:{s:10:\"expiration\";i:1562334402;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36\";s:5:\"login\";i:1562161602;}s:64:\"edd3acdf40b4f0f6a3fea8696ef12544340c7c14f4595a2c03e9bfe16c75f354\";a:4:{s:10:\"expiration\";i:1562346676;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:77:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0\";s:5:\"login\";i:1562173876;}s:64:\"82ede7155807775aae024c72f82a950fcf2ae319d4f3ee2387643e24e080bbed\";a:4:{s:10:\"expiration\";i:1563387028;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36\";s:5:\"login\";i:1562177428;}s:64:\"9ee2cc74c9996abab970434a04aa38a8e2599486325e2e967677dc0a6c956978\";a:4:{s:10:\"expiration\";i:1563387028;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36\";s:5:\"login\";i:1562177428;}}");
INSERT INTO `wp_usermeta` VALUES("143","3","nickname","yana");
INSERT INTO `wp_usermeta` VALUES("144","3","first_name","");
INSERT INTO `wp_usermeta` VALUES("145","3","last_name","");
INSERT INTO `wp_usermeta` VALUES("146","3","description","");
INSERT INTO `wp_usermeta` VALUES("147","3","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("148","3","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("149","3","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("150","3","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("151","3","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("152","3","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("153","3","locale","");
INSERT INTO `wp_usermeta` VALUES("154","3","wp_capabilities","a:1:{s:8:\"customer\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("155","3","wp_user_level","0");
INSERT INTO `wp_usermeta` VALUES("156","3","_yoast_wpseo_profile_updated","1560855665");
INSERT INTO `wp_usermeta` VALUES("157","3","session_tokens","a:3:{s:64:\"a7329adadad6fd32f863fcace4493d3db21beb9ad84b3f49b37b5a66d95fadad\";a:4:{s:10:\"expiration\";i:1562065266;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36\";s:5:\"login\";i:1560855666;}s:64:\"5336887231268bb6909bcfd97b98ebe280f7d89641c0af52de58dac3b0c99d8f\";a:4:{s:10:\"expiration\";i:1561028569;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:77:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0\";s:5:\"login\";i:1560855769;}s:64:\"3cc50cffa524da26b0dc326a847327b8b057ca17a82463381afb8bb2fbeb3a21\";a:4:{s:10:\"expiration\";i:1561028618;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:77:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0\";s:5:\"login\";i:1560855818;}}");
INSERT INTO `wp_usermeta` VALUES("159","3","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:2:{s:32:\"02522a2b2726fb0a03bb19f2d8d9524d\";a:11:{s:3:\"key\";s:32:\"02522a2b2726fb0a03bb19f2d8d9524d\";s:10:\"product_id\";i:134;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:750;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:750;s:8:\"line_tax\";i:0;}s:32:\"54229abfcfa5649e7003b83dd4755294\";a:11:{s:3:\"key\";s:32:\"54229abfcfa5649e7003b83dd4755294\";s:10:\"product_id\";i:91;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:399;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:399;s:8:\"line_tax\";i:0;}}}");
INSERT INTO `wp_usermeta` VALUES("160","3","wc_last_active","1560816000");
INSERT INTO `wp_usermeta` VALUES("163","3","last_login_time","2019-06-18 14:03:38");
INSERT INTO `wp_usermeta` VALUES("165","1","wpp_review_notice","2019-06-22");
INSERT INTO `wp_usermeta` VALUES("168","1","dismissed_product_display_settings_moved_notice","1");
INSERT INTO `wp_usermeta` VALUES("169","1","wp_yoast_notifications","a:5:{i:0;a:2:{s:7:\"message\";s:1571:\"Мы заметили, вы используете Yoast SEO  в течение некоторого времени; мы надеемся, что вы любите его! Мы были бы в восторге, если вы могли бы <a href=\"https://yoa.st/rate-yoast-seo?php_version=7.1.29&platform=wordpress&platform_version=5.1.1&software=free&software_version=10.0.1&role=administrator&days_active=99\"> дать нам 5 звезд рейтинга на WordPress.org</a>!

Если у вас возникли проблемы, <a href=\"https://yoa.st/bugreport?php_version=7.1.29&platform=wordpress&platform_version=5.1.1&software=free&software_version=10.0.1&role=administrator&days_active=99\"> предоставьте отчет об ошибке </a> и мы сделаем все возможное, чтобы помочь вам.

Кстати, знаете ли вы, у нас также есть <a href=\'https://yoa.st/premium-notification?php_version=7.1.29&platform=wordpress&platform_version=5.1.1&software=free&software_version=10.0.1&role=administrator&days_active=99\'>Премиум плагин</a>? Он предлагает расширенные функции, такие как переадресация и поддержка нескольких ключевых слов. Он поставляется с 24/7 персональной поддержкой.

<a class=\"button\" href=\"http://localhost/tes/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell\"> Не показывать это уведомление больше </a>\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:19:\"wpseo-upsell-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.8;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:232:\"Не пропустите свои ошибки индексирования: <a href=\"http://localhost/tes/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">подключитесь к Google Search Console здесь</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:2;a:2:{s:7:\"message\";s:579:\"Yoast SEO и WooCommerce могут работать лучше, если вы добавите вспомогательный плагин. Пожалуйста, установите Yoast WooCommerce SEO, чтобы сделать вашу жизнь проще. <a href=\"https://yoa.st/1o0?php_version=7.1.29&platform=wordpress&platform_version=5.1.1&software=free&software_version=10.0.1&role=administrator&days_active=99\" aria-label=\"Больше информации о Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">Больше информации</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:3;a:2:{s:7:\"message\";s:387:\"У вас в WordPress, до сих пор установлено название сайта по умолчанию. Наверно лучше сделать его пустым, чем как сейчас. <a href=\"http://localhost/tes/wp-admin/customize.php?autofocus[control]=blogdescription\"> вы всегда можете исправить его в настройщике </a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:28:\"wpseo-dismiss-tagline-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:4;a:2:{s:7:\"message\";s:394:\"<strong>Серьёзная проблема для SEO: Вы блокируете доступ для поисковых роботов.</strong> Вы должны <a href=\"http://localhost/tes/wp-admin/options-reading.php\">зайти в Настройки чтения</a> и убрать галочку рядом с пунктом \"Видимость для поисковых систем\".\";s:7:\"options\";a:9:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:32:\"wpseo-dismiss-blog-public-notice\";s:5:\"nonce\";N;s:8:\"priority\";i:1;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$B2NF5wXurIyc4Hw.2kCx2VsfTDU1t91","admin","domaratskiy1990@gmail.com","","2019-03-26 13:18:23","","0","admin");
INSERT INTO `wp_users` VALUES("2","adminffffff","$P$B5jbzETchHzojvVyrMtwXBZMyNfXQT/","adminffffff","domaratskiyd1990@gmail.com","","2019-04-07 11:10:38","","0","adminffffff");
INSERT INTO `wp_users` VALUES("3","yana","$P$Bij/akzLf7OZ9n1exZyg2h09cmnwYr0","yana","domaratskiy1991@gmail.com","","2019-06-18 11:01:05","","0","yana");


DROP TABLE IF EXISTS `wp_wc_download_log`;

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wc_webhooks`;

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES("2","plotnost","Плотность","select","menu_order","1");
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES("5","tsvet","Цвет","select","menu_order","0");


DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_log`;

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_items`;

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_sessions`;

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_woocommerce_sessions` VALUES("17","1","a:11:{s:4:\"cart\";s:819:\"a:2:{s:32:\"02522a2b2726fb0a03bb19f2d8d9524d\";a:11:{s:3:\"key\";s:32:\"02522a2b2726fb0a03bb19f2d8d9524d\";s:10:\"product_id\";i:134;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:750;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:750;s:8:\"line_tax\";i:0;}s:32:\"54229abfcfa5649e7003b83dd4755294\";a:11:{s:3:\"key\";s:32:\"54229abfcfa5649e7003b83dd4755294\";s:10:\"product_id\";i:91;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:399;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:399;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:413:\"a:15:{s:8:\"subtotal\";s:7:\"1149.00\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:6:\"500.00\";s:12:\"shipping_tax\";d:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";d:0;s:12:\"discount_tax\";d:0;s:19:\"cart_contents_total\";s:7:\"1149.00\";s:17:\"cart_contents_tax\";d:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:4:\"0.00\";s:7:\"fee_tax\";d:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:7:\"1649.00\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:22:\"shipping_for_package_0\";s:459:\"a:2:{s:12:\"package_hash\";s:40:\"wc_ship_254ebb0740b3bb5e24c9dea2b21d0100\";s:5:\"rates\";a:1:{s:11:\"flat_rate:1\";O:16:\"WC_Shipping_Rate\":2:{s:7:\"\0*\0data\";a:6:{s:2:\"id\";s:11:\"flat_rate:1\";s:9:\"method_id\";s:9:\"flat_rate\";s:11:\"instance_id\";i:1;s:5:\"label\";s:25:\"Единая ставка\";s:4:\"cost\";s:6:\"500.00\";s:5:\"taxes\";a:0:{}}s:12:\"\0*\0meta_data\";a:1:{s:14:\"Позиции\";s:74:\"атлас шолк &times; 1, атлас королевский &times; 1\";}}}}\";s:25:\"previous_shipping_methods\";s:39:\"a:1:{i:0;a:1:{i:0;s:11:\"flat_rate:1\";}}\";s:23:\"chosen_shipping_methods\";s:29:\"a:1:{i:0;s:11:\"flat_rate:1\";}\";s:22:\"shipping_method_counts\";s:14:\"a:1:{i:0;i:1;}\";s:8:\"customer\";s:687:\"a:26:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"UA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"UA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}","1562334403");


DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_woocommerce_shipping_zone_locations` VALUES("1","1","UA","country");


DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_woocommerce_shipping_zone_methods` VALUES("1","1","flat_rate","1","1");
INSERT INTO `wp_woocommerce_shipping_zone_methods` VALUES("1","2","free_shipping","2","1");


DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_woocommerce_shipping_zones` VALUES("1","Доставка","0");


DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_wpf_filters`;

CREATE TABLE `wp_wpf_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL,
  `setting_data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_yoast_seo_links` VALUES("73","https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("74","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("75","https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("76","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("77","https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("78","https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("79","https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("80","https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("81","https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C","91","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("163","https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("164","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("165","https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("166","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("167","https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("168","https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("169","https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("170","https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("171","https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C","139","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("172","https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("173","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("174","https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("175","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("176","https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("177","https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("178","https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("179","https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("180","https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C","134","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("181","https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("182","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("183","https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("184","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("185","https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("186","https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("187","https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("188","https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("189","https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C","218","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("190","https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("191","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("192","https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("193","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("194","https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("195","https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("196","https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("197","https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("198","https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C","219","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("199","https://ru.wikipedia.org/wiki/%D0%A8%D1%91%D0%BB%D0%BA","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("200","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D0%BD%D1%8C","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("201","https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%BB%D0%B0%D1%81_(%D1%82%D0%BA%D0%B0%D0%BD%D1%8C)#cite_note-1","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("202","https://ru.wikipedia.org/wiki/%D0%A2%D0%BA%D0%B0%D1%86%D0%BA%D0%B8%D0%B5_%D0%BF%D0%B5%D1%80%D0%B5%D0%BF%D0%BB%D0%B5%D1%82%D0%B5%D0%BD%D0%B8%D1%8F","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("203","https://ru.wikipedia.org/wiki/%D0%A3%D1%82%D0%BE%D0%BA","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("204","https://ru.wikipedia.org/wiki/%D0%A1%D0%BC%D0%BE%D0%BA%D0%B8%D0%BD%D0%B3","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("205","https://ru.wikipedia.org/wiki/%D0%9E%D0%B1%D1%83%D0%B2%D1%8C","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("206","https://ru.wikipedia.org/wiki/%D0%9F%D1%83%D0%B0%D0%BD%D1%82%D1%8B","220","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES("207","https://ru.wikipedia.org/wiki/%D0%9C%D0%B5%D0%B1%D0%B5%D0%BB%D1%8C","220","0","external");


DROP TABLE IF EXISTS `wp_yoast_seo_meta`;

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_yoast_seo_meta` VALUES("1","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("2","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("3","","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("4","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("5","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("7","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("8","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("9","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("10","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("11","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("12","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("13","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("14","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("15","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("16","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("17","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("18","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("19","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("20","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("21","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("22","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("23","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("24","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("25","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("26","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("27","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("28","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("29","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("30","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("31","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("32","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("33","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("34","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("35","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("36","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("37","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("38","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("39","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("41","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("44","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("45","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("46","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("47","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("48","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("49","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("50","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("51","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("52","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("53","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("54","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("56","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("58","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("59","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("61","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("63","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("71","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("72","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("74","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("75","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("78","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("81","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("82","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("85","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("88","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("91","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("92","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("95","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("96","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("97","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("98","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("99","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("100","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("101","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("102","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("103","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("104","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("105","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("106","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("107","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("108","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("109","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("111","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("112","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("113","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("114","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("115","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("116","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("117","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("118","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("119","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("120","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("121","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("122","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("123","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("124","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("125","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("126","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("127","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("128","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("129","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("130","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("131","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("132","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("133","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("134","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("135","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("136","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("137","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("138","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("139","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("140","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("141","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("143","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("144","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("145","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("146","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("147","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("149","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("150","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("152","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("153","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("156","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("189","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("190","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("191","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("192","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("193","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("194","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("195","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("196","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("197","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("198","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("199","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("200","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("201","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("202","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("203","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("204","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("205","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("206","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("207","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("208","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("209","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("210","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("211","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("213","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("215","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("216","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("217","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("218","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("219","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("220","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("221","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("222","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("223","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("224","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("225","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("226","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("227","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("228","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("229","0","0");


